package com.itc.ncqa.main

import com.itc.ncqa.Constants.KpiConstants
import com.itc.ncqa.Functions.{DataLoadFunctions, UtilFunctions}
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.SparkConf
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.sql.functions._

import scala.collection.mutable

object NcqaAIS {

  def main(args: Array[String]): Unit = {


    //<editor-fold desc="Reading program arguments and SaprkSession oBject creation">

    val year = args(0)
    val measureId = args(1)
    val dbName = args(2)
    val baseMsrPath = args(3)

    /*calling function for setting the dbname for dbName variable*/
    KpiConstants.setDbName(dbName)
    val conf = new SparkConf().setAppName("NcqaProgram")
    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      .set("hive.exec.dynamic.partition.mode", "nonstrict")
      .set("spark.sql.shuffle.partitions","5")


    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    import spark.implicits._

    val yearStartDate = year+"-01-01"
    val yearEndDate = year+"-12-31"
    val prevYearStDate = year.toInt-1 +"-01-01"
    val prevYearEndDate = year.toInt-1 +"-12-31"
    val nineYearStDate = year.toInt-9 +"-01-01"
    val yearNovDate = year+"-11-01"
    val july1Date = year.toInt-1 +"-07-01"
    val june30Date = year+"-06-30"
    val jobId = spark.sparkContext.applicationId
    val baseDir = baseMsrPath + "/" + jobId
    val outDir = baseDir + "/Out"
    val intermediateDir = baseDir + "/Intermediate"

    //</editor-fold>

    //<editor-fold desc="Loading Required Tables to memory">


    val aLiat = List("col1")
    val msrVal = s"'$measureId'"
    val imamsrVal = s"'${KpiConstants.imaMeasureId}'"
    val ggMsrId = s"'${KpiConstants.ggMeasureId}'"
    val lobList = List(KpiConstants.commercialLobName, KpiConstants.medicaidLobName,KpiConstants.medicareLobName, KpiConstants.marketplaceLobName, KpiConstants.mmpLobName)
    val claimStatusList = List(KpiConstants.paidVal, KpiConstants.suspendedVal, KpiConstants.pendingVal, KpiConstants.deniedVal)

    val memqueryString = s"""SELECT * FROM ${KpiConstants.dbName}.${KpiConstants.membershipTblName} WHERE measure = $msrVal AND (member_plan_start_date IS  NOT NULL) AND(member_plan_end_date IS NOT NULL)"""
    val membershipDf = DataLoadFunctions.dataLoadFromHiveStageTable(spark,KpiConstants.dbName,KpiConstants.membershipTblName,memqueryString,aLiat)
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .repartition(1)

    val visitqueryString = s"""SELECT * FROM ${KpiConstants.dbName}.${KpiConstants.visitTblName} WHERE measure = $msrVal and  (service_date IS  NOT NULL) AND((admit_date IS NULL and discharge_date IS NULL) OR (ADMIT_DATE IS NOT NULL AND DISCHARGE_DATE IS NOT NULL))"""
    val visitsDf = DataLoadFunctions.dataLoadFromHiveStageTable(spark,KpiConstants.dbName,KpiConstants.visitTblName,visitqueryString,aLiat)
      .filter((($"${KpiConstants.dataSourceColName}".===("Claim"))&&($"${KpiConstants.claimstatusColName}".isin(claimStatusList:_*)))
        ||($"${KpiConstants.dataSourceColName}".===("RxClaim"))
        ||($"${KpiConstants.dataSourceColName}".===("Rx"))
        || ($"${KpiConstants.dataSourceColName}".===("Lab"))
        || ($"${KpiConstants.dataSourceColName}".===("Obs")))
      .drop(KpiConstants.lobProductColName, "latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name","product")
      .withColumn(KpiConstants.revenuecodeColName, when((length($"${KpiConstants.revenuecodeColName}").as[Int].===(3)),concat(lit("0" ),lit($"${KpiConstants.revenuecodeColName}"))).otherwise($"${KpiConstants.revenuecodeColName}"))
      .withColumn(KpiConstants.billtypecodeColName, when((length($"${KpiConstants.billtypecodeColName}").as[Int].===(3)),concat(lit("0" ),lit($"${KpiConstants.billtypecodeColName}"))).otherwise($"${KpiConstants.billtypecodeColName}"))
      .withColumn(KpiConstants.proccode2ColName, when(($"${KpiConstants.proccode2mod1ColName}".isin(KpiConstants.avoidCodeList:_*)) || ($"${KpiConstants.proccode2mod2ColName}".isin(KpiConstants.avoidCodeList:_*)),lit("NA")).otherwise($"${KpiConstants.proccode2ColName}"))
      .repartition(3)

    val medmonmemqueryString = s"""SELECT * FROM ${KpiConstants.dbName}.${KpiConstants.medmonmemTblName} WHERE measure = $msrVal"""
    val medmonmemDf = DataLoadFunctions.dataLoadFromHiveStageTable(spark,KpiConstants.dbName,KpiConstants.medmonmemTblName,medmonmemqueryString,aLiat)
      .filter(($"run_date".>=(yearStartDate)) && ($"run_date".<=(yearEndDate)))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .repartition(1)

    val refHedisqueryString =s"""SELECT * FROM  ${KpiConstants.dbName}.${KpiConstants.refHedisTblName} WHERE measureid = $msrVal OR measureid= $ggMsrId"""
    val refHedisDf = DataLoadFunctions.dataLoadFromHiveStageTable(spark,KpiConstants.dbName,KpiConstants.medmonmemTblName,refHedisqueryString,aLiat)
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")


    val refMedqueryString = s"""SELECT * FROM  ${KpiConstants.dbName}.${KpiConstants.refmedValueSetTblName} WHERE measure_id = $msrVal"""
    val ref_medvaluesetDf = DataLoadFunctions.dataLoadFromHiveStageTable(spark,KpiConstants.dbName,KpiConstants.medmonmemTblName,refMedqueryString,aLiat)
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")




    val refHedisqueryStringForIma =s"""SELECT * FROM  ${KpiConstants.dbName}.${KpiConstants.refHedisTblName} WHERE measureid = $imamsrVal"""
    val refHedisDf_Ima = DataLoadFunctions.dataLoadFromHiveStageTable(spark,KpiConstants.dbName,KpiConstants.medmonmemTblName,refHedisqueryStringForIma,aLiat)
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")

    // println("counts:"+membershipDf.count()+","+ visitsDf.count()+","+medmonmemDf.count() +","+refHedisDf.count()+","+ref_medvaluesetDf.count())

    //</editor-fold

    //<editor-fold desc="Age Filter And SN2 Removal Calculation">

    val ageFilterDf = membershipDf.filter((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",KpiConstants.months228).<=(yearEndDate)))

   /* val sn2Members = ageFilterDf.filter(($"${KpiConstants.lobProductColName}".===(KpiConstants.lobProductNameConVal))
      &&(((($"${KpiConstants.memStartDateColName}".>=(yearStartDate)) && ($"${KpiConstants.memStartDateColName}".<=(yearEndDate)))
      ||(($"${KpiConstants.memEndDateColName}".>=(yearStartDate)) && ($"${KpiConstants.memEndDateColName}".<=(yearEndDate))))
      || ((($"${KpiConstants.memStartDateColName}".<(yearStartDate)) && ($"${KpiConstants.memEndDateColName}".>(yearEndDate)))))
      &&(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}", KpiConstants.months792).<=(yearEndDate)))
      .select(KpiConstants.memberidColName).rdd.map(r => r.getString(0)).collect()
    val sn2RemovedMemDf = ageFilterDf.except(ageFilterDf.filter($"${KpiConstants.memberidColName}".isin(sn2Members:_*)))
*/
    //</editor-fold>

    //<editor-fold desc="Continuous Enrollment, Allowable Gap Calculation">

    val inputForContEnrolldf = ageFilterDf.select(KpiConstants.memberidColName, KpiConstants.benefitMedicalColname,
      KpiConstants.memStartDateColName,KpiConstants.memEndDateColName,
      KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName, KpiConstants.dateofbirthColName,KpiConstants.primaryPlanFlagColName)



    val mapForCeCurrYear = mutable.Map("start_date" -> "2018-01-01", "end_date" -> "2018-12-31","gapcount" -> "1",
      "checkval" -> "true","reqCovDays" -> "0","anchor_date" -> "2018-12-31")

    val contEnrollDf = UtilFunctions.contEnrollAndAllowableGapFilterFunction_AIS(spark,inputForContEnrolldf,mapForCeCurrYear)
      .select(KpiConstants.memberidColName,KpiConstants.dateofbirthColName, KpiConstants.lobColName, KpiConstants.lobProductColName,
              KpiConstants.payerColName,KpiConstants.primaryPlanFlagColName)

    contEnrollDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/contEnrollDf/")

    //</editor-fold>

    //<editor-fold desc="Dual Enrollment calculation">

    val contDf = spark.read.parquet(intermediateDir+ "/contEnrollDf/")
    val baseOutInDf = UtilFunctions.baseOutDataframeCreation_AIS(spark, contDf, lobList,measureId)
    val medicareContEnrollDf = baseOutInDf.filter($"${KpiConstants.lobColName}".===(KpiConstants.medicareLobName)).cache()

    /*Find out the Medicare Hospice Mmebers by lookung in the hospice flag in medicare_monthly_membership table*/
    val medicareHospiceDf = medicareContEnrollDf.as("df1").join(medmonmemDf.as("df2"), Seq(KpiConstants.memberidColName))
      .groupBy(KpiConstants.memberidColName).agg(countDistinct(when($"${KpiConstants.hospiceFlagColName}".===(KpiConstants.yesVal),1)).alias(KpiConstants.countColName))
      .filter($"${KpiConstants.countColName}".>(0))
      .select(KpiConstants.memberidColName)

    /*Remove the members who has lti flag inmonthly_medicare_membership table*/
    val baseOutDf = baseOutInDf

 /*   /*Find out the Medicare  Members who has atleast 1 lti_flag in medicare_monthly_membership table*/
    val medicareLtiDf = medicareContEnrollDf.as("df1").join(medmonmemDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select(s"df1.${KpiConstants.memberidColName}",KpiConstants.dateofbirthColName, KpiConstants.ltiFlagColName)
      .filter((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",KpiConstants.months792).<=(yearEndDate)))
      .groupBy(KpiConstants.memberidColName).agg(count(when($"${KpiConstants.ltiFlagColName}".===(KpiConstants.yesVal),1)).alias(KpiConstants.countColName))
      .filter($"${KpiConstants.countColName}".>=(1))
      .select(KpiConstants.memberidColName).rdd.map(r => r.getString(0)).collect()

    /*Remove the member's medicare and Medicare-Medicaid Plans data whao has atleast 1 LTI flag*/
    val baseOutDf = baseOutStep1Df.except(baseOutStep1Df.filter(($"${KpiConstants.memberidColName}".isin(medicareLtiDf:_*))
      &&(($"${KpiConstants.lobColName}".===(KpiConstants.medicareLobName))
      ||($"${KpiConstants.lobColName}".===(KpiConstants.mmpLobName)))))*/

    baseOutDf.coalesce(2)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/baseOutDf/")

  /*  baseOutDf.select(KpiConstants.memberidColName, KpiConstants.lobColName).distinct().coalesce(2)
      .write
      .mode(SaveMode.Append)
      .json(outDir +"/baseOutDf_json/")*/

    //</editor-fold>

    //<editor-fold desc="Initial Join with Ref_Hedis">

    val argmapforRefHedis = mutable.Map(KpiConstants.eligibleDfName -> visitsDf , KpiConstants.refHedisTblName -> refHedisDf,
      KpiConstants.refmedValueSetTblName -> ref_medvaluesetDf)

    val allValueList = List(KpiConstants.independentLabVal, KpiConstants.hospiceGrouperVal, KpiConstants.tdVaccineVal,
      KpiConstants.chemotherappygrouperVal,KpiConstants.chemotherappyEncounterVal,KpiConstants.bonemarrowTranGroVal, KpiConstants.immunoCompromisingVal,
      KpiConstants.cochlearImplantVal, KpiConstants.cochlearImplantDevVal,KpiConstants.cochlearImplantDiagVal, KpiConstants.afaVal, KpiConstants.scaHbsdVal,
      KpiConstants.cflVal,KpiConstants.adultInfVacVal, KpiConstants.vacCausingAdvEffVal,KpiConstants.tdapVaccineVal,KpiConstants.anaphylTdVacVal,
      KpiConstants.anaphylTdapVacVal, KpiConstants.postTetanusVacEncVal, KpiConstants.postDiphtheriaVacEncVal, KpiConstants.postPertussisVacEncVal,
      KpiConstants.herpesZosterLiveVaccineVal, KpiConstants.herpesZosterRecomVaccineVal, KpiConstants.advReaZosVacVal, KpiConstants.pneuConjuVaccine13Val,
      KpiConstants.pneuPolyVaccine23Val, KpiConstants.enceDuetoVacVal, KpiConstants.pneuVacAdvReacVal)

    val medicationlList = KpiConstants.emptyList
    val visitRefHedisDf = UtilFunctions.joinWithRefHedisFunction(spark,argmapforRefHedis,allValueList,medicationlList)


    val argmapforRefHedis_Ima = mutable.Map(KpiConstants.eligibleDfName -> visitsDf , KpiConstants.refHedisTblName -> refHedisDf_Ima,
                                            KpiConstants.refmedValueSetTblName -> ref_medvaluesetDf)
    val imaValueList = List(KpiConstants.encephalopathyVal)

    val visitRefHedisDf_Ima = UtilFunctions.joinWithRefHedisFunction(spark,argmapforRefHedis_Ima,imaValueList,medicationlList)

    val allVisistRefHedisDf = visitRefHedisDf.union(visitRefHedisDf_Ima)

    allVisistRefHedisDf
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/visitRefHedisDf/")

    //</editor-fold>

    //<editor-fold desc="Removal of Independent Lab Visits">


    val groupList = visitsDf.schema.fieldNames.toList.dropWhile(p=> p.equalsIgnoreCase(KpiConstants.memberidColName))
    val visitgroupedDf = spark.read.parquet(intermediateDir+ "/visitRefHedisDf/")
      .groupBy(KpiConstants.memberidColName, groupList:_*).agg(collect_set(KpiConstants.valuesetColName).alias(KpiConstants.valuesetColName))
      .select(KpiConstants.memberidColName,KpiConstants.dobColName, KpiConstants.serviceDateColName, KpiConstants.admitDateColName, KpiConstants.dischargeDateColName,
        KpiConstants.serviceeddateColname,KpiConstants.supplflagColName,KpiConstants.dataSourceColName, KpiConstants.labvalueColName, KpiConstants.iseyecareproviderColName,
        KpiConstants.isnephrologistColName, KpiConstants.valuesetColName)
      .repartition(2)


    /*visitgroupedDf.coalesce(2)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/visitgroupedDf/")*/


   /* visitgroupedDf.coalesce(2)
      .write
      .mode(SaveMode.Overwrite)
      .json(intermediateDir+ "/visitgroupedDf_json/")*/

    val indLabVisRemDf = visitgroupedDf.filter((!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)))
       /* ||((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)) && (array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hba1cTestVal)))
        ||((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)) && (array_contains($"${KpiConstants.valuesetColName}",KpiConstants.urineProteinTestVal))))
*/
    indLabVisRemDf.coalesce(2)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/indLabVisRemDf/")

    //</editor-fold>

    //<editor-fold desc="Hospice Removal">

    val baseMemDf = spark.read.parquet(intermediateDir+ "/baseOutDf/")
                         .select(KpiConstants.memberidColName,KpiConstants.dateofbirthColName, KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName).dropDuplicates()
                         .repartition(2)
    val hospiceInCurrYearMemDf = indLabVisRemDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hospiceGrouperVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)
     /* .dropDuplicates()
      .rdd
      .map(r=> r.getString(0))
      .collect()*/


  /*  val hospiceRemMemEnrollDf = baseMemDf.except(baseMemDf.filter($"${KpiConstants.memberidColName}".isin(hospiceInCurrYearMemDf:_*)))
      .select(KpiConstants.memberidColName,KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName, KpiConstants.memStartDateColName).dropDuplicates()
     hospiceRemMemEnrollDf.select(KpiConstants.memberidColName).distinct().coalesce(1)
       .write
       .mode(SaveMode.Append)
       .option("header", "true")
       .csv(outDir +"/hospiceRemMemEnrollDf/")*/

    //</editor-fold>

    //<editor-fold desc="Initial join function">

    val indLabVisInDf = spark.read.parquet(intermediateDir+ "/indLabVisRemDf/").repartition(2).cache()
    val argmapForVisittJoin = mutable.Map(KpiConstants.membershipTblName -> baseMemDf , KpiConstants.visitTblName -> indLabVisInDf)
    val validVisitsOutDf = UtilFunctions.initialJoinFunction(spark,argmapForVisittJoin).repartition(2).cache()
    validVisitsOutDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/validVisitsOutDf/")

    validVisitsOutDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .json(intermediateDir+ "/validVisitsOutDf_json/")

    //</editor-fold>

    //<editor-fold desc="Mandatory Exclusion Calculation">

    val visitForMandExclDf = spark.read.parquet(intermediateDir+ "/validVisitsOutDf/").repartition(3).cache()
    visitForMandExclDf.count()



    //<editor-fold desc="Active Chemotherappy">

    val activeChemotherappy_1Df =  visitForMandExclDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.chemotherappygrouperVal ))
                                                         ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.chemotherappyEncounterVal ))))

    val activeChemotherappy_2Df =  activeChemotherappy_1Df.filter((($"${KpiConstants.dataSourceColName}".===("Claim"))
                                                                &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate))
                                                                && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
                                                              ||(($"${KpiConstants.dataSourceColName}".===("Obs"))
                                                                &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate))
                                                                && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
                                                              ||(($"${KpiConstants.dataSourceColName}".===("Obs"))
                                                                &&(($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
                                                                && ($"${KpiConstants.serviceDateColName}".<=(prevYearEndDate)))
                                                                &&((($"${KpiConstants.serviceeddateColname}".>=(yearStartDate))
                                                                && ($"${KpiConstants.serviceeddateColname}".<=(yearEndDate)))
                                                                || ($"${KpiConstants.serviceeddateColname}".isNull) )))
                                                           .select(KpiConstants.memberidColName)

    val activeChemotherappyDf = activeChemotherappy_2Df
    //</editor-fold>

    //<editor-fold desc="Bone Marrow Transplant">

    val boneMarrowTrans_1Df = visitForMandExclDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.bonemarrowTranGroVal )))

    val boneMarrowTransDf = boneMarrowTrans_1Df.filter((($"${KpiConstants.dataSourceColName}".===("Claim"))
                                                      &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate))
                                                      && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
                                                    ||(($"${KpiConstants.dataSourceColName}".===("Obs"))
                                                      &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate))
                                                      && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
                                                    ||(($"${KpiConstants.dataSourceColName}".===("Obs"))
                                                      &&(($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
                                                      && ($"${KpiConstants.serviceDateColName}".<=(prevYearEndDate)))
                                                      &&((($"${KpiConstants.serviceeddateColname}".>=(yearStartDate))
                                                      && ($"${KpiConstants.serviceeddateColname}".<=(yearEndDate)))
                                                      || ($"${KpiConstants.serviceeddateColname}".isNull) )))
                                                .select(KpiConstants.memberidColName)

    //</editor-fold>

    //<editor-fold desc="Mandatory Exclusion 4">

    val mandExl4Df = visitForMandExclDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.immunoCompromisingVal ))
                                                ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.cochlearImplantVal ))
                                                ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.cochlearImplantDevVal ))
                                                ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.cochlearImplantDiagVal ))
                                                ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.afaVal ))
                                                ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.scaHbsdVal ))
                                                ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.cflVal )))
                                                &&($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.dobColName}") && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
                                         .select(KpiConstants.memberidColName)
    //</editor-fold>

    val mandExclUnionDf = activeChemotherappyDf.union(boneMarrowTransDf).union(mandExl4Df).union(medicareHospiceDf).union(hospiceInCurrYearMemDf)

    val eligibleVisitsDf = visitForMandExclDf.filter((((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",KpiConstants.months228).<=(yearEndDate))
                                                    && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",KpiConstants.months792).>(yearEndDate)))
                                                    && (($"${KpiConstants.lobColName}".===(KpiConstants.commercialLobName)) || ($"${KpiConstants.lobColName}".===(KpiConstants.medicaidLobName))))
                                                    ||((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",KpiConstants.months792).<=(yearEndDate))
                                                    &&($"${KpiConstants.lobColName}".===(KpiConstants.medicareLobName))))

    val stratInDf = eligibleVisitsDf.select(KpiConstants.memberidColName, KpiConstants.payerColName, KpiConstants.dateofbirthColName).dropDuplicates()

    val startOutDf = UtilFunctions.aisStratification(spark,stratInDf, yearStartDate).dropDuplicates()
    val epopMemDf = eligibleVisitsDf.select(KpiConstants.memberidColName).distinct().cache()

   /* startOutDf.coalesce(1)
       .write
       .mode(SaveMode.Append)
       .option("header", "true")
       .csv(outDir +"/startOutDf/")*/


    val mandExclDf = epopMemDf.intersect(mandExclUnionDf).dropDuplicates().cache()
   /* mandExclDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir +"/mandExclDf/")*/

    /*eligibleVisitsDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .json(intermediateDir + "/eligibleVisitsDf_json/")*/


    //</editor-fold>

    //<editor-fold desc="Denominator Calculation">

    val denominatorVisistsDf = eligibleVisitsDf.except(eligibleVisitsDf.filter($"${KpiConstants.memberidColName}".isin(mandExclDf.rdd.map(r => r.getString(0)).collect():_*)))

    denominatorVisistsDf.coalesce(2)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir + "/denominatorVisistsDf/")
    //</editor-fold>

    //<editor-fold desc="Numerator Calculation">

    val numeratorVisitsInDf = spark.read.parquet(intermediateDir + "/denominatorVisistsDf/")

    //<editor-fold desc="Numerator1 Calculation">

    val numerator1NonSupInDf = numeratorVisitsInDf.filter($"${KpiConstants.supplflagColName}".===("N"))

    //<editor-fold desc="Numerator1 Non Supplement Calculation">

    val numerator1NonSup_1Df = numerator1NonSupInDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.adultInfVacVal))
                                                         &&($"${KpiConstants.serviceDateColName}".>=(july1Date) && $"${KpiConstants.serviceDateColName}".<=(june30Date)))
                                                    .select(KpiConstants.memberidColName)

    val numerator1NonSup_2Df = numerator1NonSupInDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.vacCausingAdvEffVal))
                                                         &&($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.dobColName}")
                                                          &&$"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
                                                   .select(KpiConstants.memberidColName)

    val numerator1NonSupDf = numerator1NonSup_1Df.union(numerator1NonSup_2Df)
    //</editor-fold>

    //<editor-fold desc="Numerator1 Other Calculation">

    val numerator1Other_1Df = numeratorVisitsInDf.except(numeratorVisitsInDf.filter($"${KpiConstants.memberidColName}".isin(numerator1NonSupDf.rdd.map(r => r.getString(0)).collect():_*)))
                                                 .filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.adultInfVacVal))
                                                       &&($"${KpiConstants.serviceDateColName}".>=(july1Date) && $"${KpiConstants.serviceDateColName}".<=(june30Date)))
                                                  .select(KpiConstants.memberidColName)

    val numerator1Other_2Df = numeratorVisitsInDf.except(numeratorVisitsInDf.filter($"${KpiConstants.memberidColName}".isin(numerator1NonSupDf.rdd.map(r => r.getString(0)).collect():_*)))
                                                 .filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.vacCausingAdvEffVal))
                                                       &&($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.dobColName}")
                                                       &&$"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
                                                  .select(KpiConstants.memberidColName)

    val numerator1OtherDf = numerator1Other_1Df.union(numerator1Other_2Df)
    //</editor-fold>

    val numerator1Df = numerator1NonSupDf.union(numerator1OtherDf)

  /*  numerator1Df.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir +"/numerator1Df/")*/

    //</editor-fold>

    //<editor-fold desc="Numerator2 Calculation">

    val numerator2NonSupInDf = numeratorVisitsInDf.filter($"${KpiConstants.supplflagColName}".===("N"))

    //<editor-fold desc="Numerator2 Nonsupplemental Calculation">

    val numerator2NonSup_1Df = numerator2NonSupInDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.tdVaccineVal))
                                                          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.tdapVaccineVal)))
                                                          &&($"${KpiConstants.serviceDateColName}".>(nineYearStDate) && $"${KpiConstants.serviceDateColName}".<(yearEndDate)))
                                                    .select(KpiConstants.memberidColName)


    val numerator2NonSup_2Df = numerator2NonSupInDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.anaphylTdVacVal))
                                                          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.anaphylTdapVacVal))
                                                          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.postTetanusVacEncVal))
                                                          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.postDiphtheriaVacEncVal))
                                                          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.postPertussisVacEncVal)))
                                                          &&($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.dobColName}") && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
                                                    .select(KpiConstants.memberidColName)

    val numerator2NonSupDf = numerator2NonSup_1Df.union(numerator2NonSup_2Df)
    //</editor-fold>

    //<editor-fold desc="Numerator2 Other Calculation">

    val numerator2Other_1Df = numeratorVisitsInDf.except(numeratorVisitsInDf.filter($"${KpiConstants.memberidColName}".isin(numerator2NonSupDf.rdd.map(r => r.getString(0)).collect():_*)))
                                                 .filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.tdVaccineVal))
                                                        ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.tdapVaccineVal)))
                                                        &&($"${KpiConstants.serviceDateColName}".>(nineYearStDate) && $"${KpiConstants.serviceDateColName}".<(yearEndDate)))
                                                 .select(KpiConstants.memberidColName)


    val numerator2Other_2Df = numeratorVisitsInDf.except(numeratorVisitsInDf.filter($"${KpiConstants.memberidColName}".isin(numerator2NonSupDf.rdd.map(r => r.getString(0)).collect():_*)))
                                                 .filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.anaphylTdVacVal))
                                                   ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.anaphylTdapVacVal))
                                                   ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.postTetanusVacEncVal))
                                                   ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.postDiphtheriaVacEncVal))
                                                   ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.postPertussisVacEncVal)))
                                                   &&($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.dobColName}") && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
                                                  .select(KpiConstants.memberidColName)

    val numerator2OtherDf = numerator2Other_1Df.union(numerator2Other_2Df)
    //</editor-fold>


    val numerator2Df = numerator2NonSupDf.union(numerator2OtherDf)

   /* numerator2Df.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir +"/numerator2Df/")*/

    //</editor-fold>

    //<editor-fold desc="Numerator3 Calculation">

    val numerator3VisistsDf = numeratorVisitsInDf.filter((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}",KpiConstants.months600).<=(yearStartDate)))

    //<editor-fold desc="Numerator3 Non Supplement Calculation">

    val numerator3NonSupVisDf = numerator3VisistsDf.filter($"${KpiConstants.supplflagColName}".===("N"))

    val numerator3NonSup_1Df = numerator3NonSupVisDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.herpesZosterLiveVaccineVal))
                                                         &&(($"${KpiConstants.serviceDateColName}".>=(UtilFunctions.add_ncqa_months(spark, $"${KpiConstants.dobColName}", KpiConstants.months600)))
                                                         /*&&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))*/))
                                                    .select(KpiConstants.memberidColName)


    val numerator3NonSup_2_1Df = numerator3NonSupVisDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.herpesZosterRecomVaccineVal))
                                                           &&(($"${KpiConstants.serviceDateColName}".>=(UtilFunctions.add_ncqa_months(spark, $"${KpiConstants.dobColName}", KpiConstants.months600)))
                                                          /* &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))*/))
                                                      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)

    val numerator3NonSup_2Df = numerator3NonSup_2_1Df.as("df1").join(numerator3NonSup_2_1Df.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
                                                                      .filter(datediff($"df2.${KpiConstants.serviceDateColName}", $"df1.${KpiConstants.serviceDateColName}").>=(KpiConstants.days28))
                                                                      .select(s"df1.${KpiConstants.memberidColName}")

    val numerator3NonSup_3Df = numerator3NonSupVisDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.advReaZosVacVal))
                                                         &&(($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.dobColName}"))
                                                         &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
                                                    .select(KpiConstants.memberidColName)

    val numerator3NonSupDf = numerator3NonSup_1Df.union(numerator3NonSup_2Df).union(numerator3NonSup_3Df)
    //</editor-fold>

    //<editor-fold desc="Numerator3 Other Calculation">

    val numerator3OtherVisistsDf = numerator3VisistsDf.except(numerator3VisistsDf.filter($"${KpiConstants.memberidColName}".isin(numerator3NonSupDf.rdd.map(r => r.getString(0)).collect():_*)))

    val numerator3Other_1Df = numerator3OtherVisistsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.herpesZosterLiveVaccineVal))
                                                            &&(($"${KpiConstants.serviceDateColName}".>=(UtilFunctions.add_ncqa_months(spark, $"${KpiConstants.dobColName}", KpiConstants.months600)))
                                                            /*&&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))*/))
                                                      .select(KpiConstants.memberidColName)


    val numerator3Other_2_1Df = numerator3OtherVisistsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.herpesZosterRecomVaccineVal))
                                                             &&(($"${KpiConstants.serviceDateColName}".>=(UtilFunctions.add_ncqa_months(spark, $"${KpiConstants.dobColName}", KpiConstants.months600)))
                                                             /*&&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))*/))
                                                        .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)

    val numerator3Other_2Df = numerator3Other_2_1Df.as("df1").join(numerator3Other_2_1Df.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
                                                                    .filter(datediff($"df2.${KpiConstants.serviceDateColName}", $"df1.${KpiConstants.serviceDateColName}").>=(KpiConstants.days28))
                                                                    .select(s"df1.${KpiConstants.memberidColName}")

    val numerator3Other_3Df = numerator3OtherVisistsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.advReaZosVacVal))
                                                            &&(($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.dobColName}"))
                                                            &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
                                                      .select(KpiConstants.memberidColName)

    val numerator3OtherDf = numerator3Other_1Df.union(numerator3Other_2Df).union(numerator3Other_3Df)
    //</editor-fold>

    val numerator3Df = numerator3NonSupDf.union(numerator3OtherDf)

   /* numerator3Df.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir +"/numerator3Df/")*/

    //</editor-fold>

    //<editor-fold desc="Numerator4 Calculation">

    val numerator4VisistsDf = numeratorVisitsInDf.filter((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}",KpiConstants.months792).<=(yearStartDate))
                                                       &&($"${KpiConstants.lobColName}".===(KpiConstants.medicareLobName)))

    //<editor-fold desc="Numerator4 Non Supplement Calculation">

    val numerator4NonSupVisitsDf = numerator4VisistsDf.filter($"${KpiConstants.supplflagColName}".===("N"))

    val numerator4NonSup_1_1Df = numerator4NonSupVisitsDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.pneuConjuVaccine13Val)))
                                                                &&(($"${KpiConstants.serviceDateColName}".>=(UtilFunctions.add_ncqa_months(spark, $"${KpiConstants.dobColName}", KpiConstants.months720)))
                                                                /*&&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))*/))
                                                         .select(KpiConstants.memberidColName,KpiConstants.serviceDateColName)

    val numerator4NonSup_1_2Df = numerator4NonSupVisitsDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.pneuPolyVaccine23Val)))
                                                                &&(($"${KpiConstants.serviceDateColName}".>=(UtilFunctions.add_ncqa_months(spark, $"${KpiConstants.dobColName}", KpiConstants.months720)))
                                                                /*&&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))*/))
                                                          .select(KpiConstants.memberidColName,KpiConstants.serviceDateColName)


    val numerator4NonSup_1Df = numerator4NonSup_1_1Df.as("df1").join(numerator4NonSup_1_2Df.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
                                                               .filter(abs(datediff($"df2.${KpiConstants.serviceDateColName}", $"df1.${KpiConstants.serviceDateColName}")).>=(KpiConstants.days365))
                                                               .select($"df1.${KpiConstants.memberidColName}")


    val numerator4NonSup_2Df = numerator4NonSupVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.pneuVacAdvReacVal))
                                                       &&(($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.dobColName}")) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
                                                  .select(KpiConstants.memberidColName)

    val numerator4NonSupDf = numerator4NonSup_1Df.union(numerator4NonSup_2Df)

    //</editor-fold>

    //<editor-fold desc="Numerator4 Other Calculation">

    val numerator4OtherVisitsDf = numerator4VisistsDf.except(numerator4VisistsDf.filter($"${KpiConstants.memberidColName}".isin(numerator4NonSupDf.rdd.map(r => r.getString(0)).collect():_*)))

    val numerator4Other_1_1Df = numerator4OtherVisitsDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.pneuConjuVaccine13Val)))
                                                              &&(($"${KpiConstants.serviceDateColName}".>=(UtilFunctions.add_ncqa_months(spark, $"${KpiConstants.dobColName}", KpiConstants.months720)))
                                                              /*&&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))*/))
                                                        .select(KpiConstants.memberidColName,KpiConstants.serviceDateColName)

    val numerator4Other_1_2Df = numerator4OtherVisitsDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.pneuPolyVaccine23Val)))
                                                              &&(($"${KpiConstants.serviceDateColName}".>=(UtilFunctions.add_ncqa_months(spark, $"${KpiConstants.dobColName}", KpiConstants.months720)))
                                                              /*&&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))*/))
                                                        .select(KpiConstants.memberidColName,KpiConstants.serviceDateColName)


    val numerator4Other_1Df = numerator4Other_1_1Df.as("df1").join(numerator4Other_1_2Df.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
                                                                    .filter(abs(datediff($"df2.${KpiConstants.serviceDateColName}", $"df1.${KpiConstants.serviceDateColName}")).>=(KpiConstants.days365))
                                                                    .select($"df1.${KpiConstants.memberidColName}")


    val numerator4Other_2Df = numerator4OtherVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.pneuVacAdvReacVal))
                                                          &&(($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.dobColName}")) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
                                                     .select(KpiConstants.memberidColName)

    val numerator4OtherDf = numerator4Other_1Df.union(numerator4Other_2Df)

    //</editor-fold>


    val numerator4Df = numerator4NonSupDf.union(numerator4OtherDf)

   /* numerator4Df.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir +"/numerator4Df/")*/

    //</editor-fold>

    //</editor-fold>

    //<editor-fold desc="Output Function">

    val outMap = mutable.Map(KpiConstants.totalPopDfName -> startOutDf, KpiConstants.eligibleDfName -> epopMemDf,
      KpiConstants.mandatoryExclDfname -> mandExclDf, KpiConstants.optionalExclDfName -> spark.emptyDataFrame,
      KpiConstants.numeratorDfName -> numerator1Df , KpiConstants.numerator2DfName -> numerator2Df,
      KpiConstants.numerator3DfName -> numerator3Df, KpiConstants.numerator4DfName -> numerator4Df)


    val outDf = UtilFunctions.ncqaAISOutputDfCreation(spark,outMap)
    outDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir+ "/outDf/")
    //</editor-fold>

    //<editor-fold desc="Deleting the intermediate Files">

    val fileSystem = FileSystem.get(spark.sparkContext.hadoopConfiguration)
    fileSystem.delete(new Path(intermediateDir), true)
    //</editor-fold>

    spark.sparkContext.stop()

  }
}
