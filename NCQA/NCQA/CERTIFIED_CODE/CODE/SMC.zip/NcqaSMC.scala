package com.itc.ncqa.main

import com.itc.ncqa.Constants.KpiConstants
import com.itc.ncqa.Functions.UtilFunctions
import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkConf
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DateType
import org.apache.spark.sql.{SaveMode, SparkSession}

import scala.collection.mutable
//import org.apache.log4j.{Level, Logger}

object NcqaSMC extends  Serializable
{

  def main(args: Array[String]): Unit =
  {

    //<editor-fold desc="Reading program arguments and Spark Session object creation">

    val year = "2018"
    val measureId = "SMC"
    val baseMsrPath = "C:\\Users\\32676\\Desktop\\SMC2"

    System.setProperty("hadoop.home.dir", "D:\\hadoop_home")
   // System.setProperty("hadoop.home.dir", "D:\\WinUtil")

    val conf = new SparkConf().setAppName("NcqaProgram")
    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    conf.set("spark.sql.shuffle.partitions", "5")
    //.set("hive.exec.dynamic.partition.mode", "nonstrict")

    val spark = SparkSession.builder().config(conf).master("local").getOrCreate()

    val rootLogger = Logger.getRootLogger()
    rootLogger.setLevel(Level.ERROR)

    val yearStartDate = year+"-01-01"
    val PreYrStartDate = year.toInt -1 +"-01-01"
    val PreYrEndDate = year.toInt -1 +"-12-31"
    val yearEndDate = year+"-12-31"

    val jobId = spark.sparkContext.applicationId
    val baseDir = baseMsrPath + "/" + jobId
    val outDir = baseDir + "/Out"
    val intermediateDir = baseDir + "/Intermediate"
    val stagingDir =  baseDir + "/Staging"
    val temporary =  baseMsrPath + "/Temporary"

    //</editor-fold>

    //<editor-fold desc="Loading Required Tables to memory">

    import spark.implicits._

    val lobList = List(KpiConstants.medicaidLobName, KpiConstants.mmdLobName,KpiConstants.marketplaceLobName)

    val membershipDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\SMC\\SMC_VISIT\\MEMBERSHIP_ENROLLMENT.csv")
      .filter(($"${KpiConstants.considerationsColName}".===(KpiConstants.yesVal))
        && ($"${KpiConstants.memStartDateColName}".isNotNull)
        && ($"${KpiConstants.memEndDateColName}".isNotNull))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .withColumn(KpiConstants.memStartDateColName, to_date($"${KpiConstants.memStartDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.memEndDateColName, to_date($"${KpiConstants.memEndDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.dateofbirthColName, to_date($"${KpiConstants.dateofbirthColName}", KpiConstants.dateFormatString))
      .repartition(2).cache()

    println("-------------------membership----------------")
    membershipDf.filter($"${KpiConstants.memberidColName}".===("95377")).show()

    membershipDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(stagingDir+ "/membershipDf/")

    val claimStatusList = List(KpiConstants.paidVal, KpiConstants.suspendedVal, KpiConstants.pendingVal, KpiConstants.deniedVal)

    val visitsDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\SMC\\SMC_VISIT\\VISITS.csv")
      .filter(($"${KpiConstants.serviceDateColName}".isNotNull)
        && (($"${KpiConstants.admitDateColName}".isNotNull && $"${KpiConstants.dischargeDateColName}".isNotNull)
        || ($"${KpiConstants.admitDateColName}".isNull && $"${KpiConstants.dischargeDateColName}".isNull))
        &&((($"${KpiConstants.dataSourceColName}".===("Claim"))&&($"${KpiConstants.claimstatusColName}".isin(claimStatusList:_*)))
        || (($"${KpiConstants.dataSourceColName}".===("RxClaim"))&&($"${KpiConstants.claimstatusColName}".isin(claimStatusList:_*)))
        || ($"${KpiConstants.dataSourceColName}".===("Rx"))
        || ($"${KpiConstants.dataSourceColName}".===("Lab"))))
      .drop(KpiConstants.lobProductColName, "latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name","product")
      .withColumn(KpiConstants.dobColName, to_date($"${KpiConstants.dobColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.serviceDateColName, to_date($"${KpiConstants.serviceDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.admitDateColName, when($"${KpiConstants.admitDateColName}".isNotNull,to_date($"${KpiConstants.admitDateColName}",  KpiConstants.dateFormatString)))
      .withColumn(KpiConstants.dischargeDateColName, when($"${KpiConstants.dischargeDateColName}".isNotNull,to_date($"${KpiConstants.dischargeDateColName}",  KpiConstants.dateFormatString)))
      .withColumn(KpiConstants.medstartdateColName, when($"${KpiConstants.medstartdateColName}".isNotNull,to_date($"${KpiConstants.medstartdateColName}",  KpiConstants.dateFormatString)))
      .withColumn(KpiConstants.revenuecodeColName, when((length($"${KpiConstants.revenuecodeColName}").as[Int].===(3)),concat(lit("0" ),lit($"${KpiConstants.revenuecodeColName}"))).otherwise($"${KpiConstants.revenuecodeColName}"))
      .withColumn(KpiConstants.billtypecodeColName, when((length($"${KpiConstants.billtypecodeColName}").as[Int].===(3)),concat(lit("0" ),lit($"${KpiConstants.billtypecodeColName}"))).otherwise($"${KpiConstants.billtypecodeColName}"))
      .withColumn(KpiConstants.proccode2ColName, when(($"${KpiConstants.proccode2mod1ColName}".isin(KpiConstants.avoidCodeList:_*)) || ($"${KpiConstants.proccode2mod2ColName}".isin(KpiConstants.avoidCodeList:_*)),lit("NA")).otherwise($"${KpiConstants.proccode2ColName}"))
      .repartition(2).cache()

    visitsDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(stagingDir+ "/visitsDf/")

    println("-------------------visits----------------")
    visitsDf.filter($"${KpiConstants.memberidColName}".===("95377")).show()


    val refHedisDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\SMC\\REF_HEDIS2019\\REF_HEDIS2019.csv")
      .filter(($"${KpiConstants.measureIdColName}".===(KpiConstants.smcMeasureId)) || ($"${KpiConstants.measureIdColName}".===(KpiConstants.ggMeasureId)))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .repartition(2).cache()

    refHedisDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(stagingDir+ "/refHedisDf/")

    val ref_medvaluesetDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\SMC\\REF_MED_VALUE_SET\\REF_MED_VALUE_SET.csv")
      .filter(($"${KpiConstants.measure_idColName}".===(KpiConstants.smcMeasureId)) )
      .drop("latest_flag", "active_flag", "ingestion_date", "source_name" ,"user_name")
      .repartition(2).cache()

    ref_medvaluesetDf.coalesce(2)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(stagingDir+ "/ref_medvaluesetDf/")

    //</editor-fold>

    //<editor-fold desc="Eligible Population Calculation">

    //<editor-fold desc=" Age filter">

    val ageEndDate = year + "-12-31"
    val ageStartDate = year + "-01-01"

    val ageFilterDf = membershipDf.filter(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",KpiConstants.months216).<=(ageEndDate)
      && UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",KpiConstants.months780).>(ageEndDate))

    //ageFilterDf.show()
    println("Age -> " + ageFilterDf.count())
    ageFilterDf.filter($"${KpiConstants.memberidColName}" === ("95377")).show()


    //</editor-fold>

    //<editor-fold desc="Continuous Enrollment, Allowable Gap Calculation">

    val inputForContEnrolldf = ageFilterDf.select(KpiConstants.memberidColName, KpiConstants.benefitMedicalColname,
      KpiConstants.memStartDateColName,KpiConstants.memEndDateColName,
      KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName, KpiConstants.dateofbirthColName,KpiConstants.primaryPlanFlagColName)

    val mapForCeminus1y = mutable.Map("start_date" -> "2017-01-01", "end_date" -> "2017-12-31","gapcount" -> "1",
      "checkval" -> "false", "reqCovDays" -> "0")

    val ceOutminus1yDf = UtilFunctions.contEnrollAndAllowableGapFilterFunction(spark,inputForContEnrolldf,mapForCeminus1y)

    ceOutminus1yDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite).parquet(intermediateDir+ "/CEForFirstYear/")

    val ceOutMinus1y = spark.read.parquet(intermediateDir+ "/CEForFirstYear/").cache()

    val mapForCeCurrYear = mutable.Map("start_date" -> "2018-01-01", "end_date" -> "2018-12-31","gapcount" -> "1",
      "checkval" -> "true","reqCovDays" -> "0","anchor_date" -> "2018-12-31")

    val contEnrollInputDf = UtilFunctions.contEnrollAndAllowableGapFilterFunction(spark,ceOutMinus1y,mapForCeCurrYear)
      .select(KpiConstants.memberidColName, KpiConstants.dateofbirthColName, KpiConstants.memStartDateColName, KpiConstants.memEndDateColName,
        KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.primaryPlanFlagColName, KpiConstants.payerColName)

    contEnrollInputDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/contEnrollInputDf/")

    val contEnrollDf = spark.read.parquet(intermediateDir+ "/contEnrollInputDf/").cache()

    //</editor-fold>

    //<editor-fold desc="Dual Enrollment and SMC Lob filter">

    val baseOutDf = UtilFunctions.baseOutDataframeCreation(spark, contEnrollDf, lobList , measureId)

    val payerlist = List(KpiConstants.sn1PayerVal,KpiConstants.sn2PayerVal,KpiConstants.sn3PayerVal,KpiConstants.mmpPayerVal)

    val smcContEnrollDf = baseOutDf.filter($"${KpiConstants.lobColName}".isin(lobList:_*) && (!$"${KpiConstants.payerColName}".isin(payerlist:_*)))
      .dropDuplicates(). cache()

    println("w15ContEnrollDf" + smcContEnrollDf.count())
    smcContEnrollDf.filter($"${KpiConstants.memberidColName}" === ("95377")).show()

    smcContEnrollDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/w15ContEnrollDf/")

    val w15ContEnrollDf = spark.read.parquet(intermediateDir+ "/w15ContEnrollDf/").cache()

    //</editor-fold>

    //TODO : Check this one.All the valuesets and medications once.

    //<editor-fold desc="Initial Join with Ref_Hedis">visitRefHedisDf

    /*
    Electroconvulsive Therapy,Outpatient POS,Observation,Telehealth Modifier,BH Stand Alone Nonacute Inpatient,ED,IVD
,Acute Inpatient,AMI,Telephone Visits,BH Outpatient,Outpatient
,Schizophrenia,Community Mental Health Center POS,Inpatient Stay,Partial Hospitalization POS
,Partial Hospitalization/Intensive Outpatient,Online Assessments,Telehealth POS,Visit Setting Unspecified
,BH Stand Alone Acute Inpatient,CABG,PCI,Acute Inpatient POS,ED POS,LDL-C Tests,Nonacute Inpatient POS

    */

    val argmapforRefHedis = mutable.Map(KpiConstants.eligibleDfName -> visitsDf , KpiConstants.refHedisTblName -> refHedisDf,
      KpiConstants.refmedValueSetTblName -> ref_medvaluesetDf)
    val allValueList = List(KpiConstants.independentLabVal,KpiConstants.hospiceVal,KpiConstants.bHStandAloneAcuteInpatientVal,KpiConstants.bhStandAloneNonacuteInpatientVal,
      KpiConstants.schizophreniaVal,KpiConstants.bipolarDisorderVal,KpiConstants.ldlcTestsVal,KpiConstants.otherBipolarDisorder,
      KpiConstants.cabgVal,KpiConstants.nonacuteInpatientPosVal,KpiConstants.edPosVal,KpiConstants.electroconvulsiveTherapyVal,KpiConstants.acuteInpatientVal,
      KpiConstants.partialHospitalizationIntensiveOutpatientVal,KpiConstants.communityMentalHealthCenterPosVal,KpiConstants.acuteInpatientPosVal,
      KpiConstants.diabetesExclusionVal,KpiConstants.pciVal,KpiConstants.telehealthPosVal,KpiConstants.nonAcuteInPatientVal,KpiConstants.ivdVal,
      KpiConstants.outpatientPosVal,KpiConstants.bhOutpatientVal,KpiConstants.partialHospitalizationPosVal,KpiConstants.observationVal,KpiConstants.inPatientStayVal
      ,KpiConstants.onlineAssesmentVal,KpiConstants.amiVal,KpiConstants.diabetesVal ,KpiConstants.bhStandAloneNonacuteInpatientVal ,KpiConstants.edVal
      ,KpiConstants.telehealthModifierVal,KpiConstants.visitSettingUnspecifiedVal,KpiConstants.telephoneVisitsVal,KpiConstants.outPatientVal)

    val medList =List(KpiConstants.diabetesMedicationVal,KpiConstants.antipsychoticMedVal)

    val visitRefHedisDf = UtilFunctions.joinWithRefHedisFunction(spark,argmapforRefHedis,allValueList,medList)

    visitRefHedisDf.select($"${KpiConstants.memberidColName}",$"${KpiConstants.valuesetColName}")

    visitRefHedisDf.filter($"${KpiConstants.memberidColName}" === ("95377")).show()

    //</editor-fold>

    //<editor-fold desc="Removal of Independent Lab Visits">

    val groupList = visitsDf.schema.fieldNames.toList.dropWhile(p=> p.equalsIgnoreCase(KpiConstants.memberidColName))
    val visitgroupedDf = visitRefHedisDf.groupBy(KpiConstants.memberidColName, groupList:_*).agg(collect_list(KpiConstants.valuesetColName).alias(KpiConstants.valuesetColName))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName, KpiConstants.claimstatusColName,KpiConstants.dischargeDateColName,
        KpiConstants.dobColName,KpiConstants.supplflagColName , KpiConstants.valuesetColName,KpiConstants.genderColName
        ,KpiConstants.poscodeColName
      )

    val indLabVisRemDf = visitgroupedDf.filter((!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)
      ||((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ldlcTestsVal))))
    ).repartition(2).cache()

    println("indLabVisRemDf")
    indLabVisRemDf.filter($"${KpiConstants.memberidColName}" === ("95377")).show()

    val membertotalDf = w15ContEnrollDf.dropDuplicates()
    val argmapForVisittJoin = mutable.Map(KpiConstants.membershipTblName -> membertotalDf , KpiConstants.visitTblName -> indLabVisRemDf)
    val visitJoinedOutDf = UtilFunctions.initialJoinFunction(spark,argmapForVisittJoin)


    visitJoinedOutDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .parquet(intermediateDir+ "/visitJoinedOutDf")

    val visitJoinDf = spark.read
      .parquet(intermediateDir+ "/visitJoinedOutDf").repartition(2).cache()

    println("visitJoinDf")
    visitJoinDf.filter($"${KpiConstants.memberidColName}" === ("95377")).show()

    //</editor-fold>

    //<editor-fold desc="Hospice Removal">

    val hospiceInCurrYearMemDf = indLabVisRemDf.filter(
      (!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))  &&
        (array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hospiceVal))
        && ($"${KpiConstants.serviceDateColName}".>=(yearStartDate) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))

    println( "Hospice members")

    val hospicefinaldf =   hospiceInCurrYearMemDf.select(KpiConstants.memberidColName)
      .dropDuplicates()


    val hosiceremovalDf = visitJoinDf.except(visitJoinDf.filter($"${KpiConstants.memberidColName}".isin(
      hospicefinaldf.rdd.map(r=>r.getString(0)).collect():_*
    )))


    hosiceremovalDf.coalesce(3)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(temporary+ "/hosiceremovalDf/")

    //</editor-fold>

    //.parquet("/home/hbase/ncqa/smc/hosiceremovalDf/")

    // val hosiceremovalDf = spark.read.parquet("/home/hbase/ncqa/smc/hosiceremovalDf/").cache()

    println("hosiceremovalDf" + hosiceremovalDf.count() )

    //<editor-fold desc="Events Calculation">

    val eventsVisitsDf = hosiceremovalDf.filter($"${KpiConstants.supplflagColName}".===("N")
      && ($"${KpiConstants.claimstatusColName}".isin(claimStatusList:_*))).cache()
    eventsVisitsDf.count()

    println("eventsVisitsDf" + eventsVisitsDf.count() )
    eventsVisitsDf.filter($"${KpiConstants.memberidColName}" === ("95377")).show()

    //<editor-fold desc="Event Step - 1">

    val schievent1Df = eventsVisitsDf
      .filter(
        (((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.bHStandAloneAcuteInpatientVal))
          || ((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.visitSettingUnspecifiedVal))
          &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.acuteInpatientPosVal))))
          && ((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.schizophreniaVal)))
          &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
          &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))
          )) .select(KpiConstants.memberidColName )
      .repartition(2).cache()

    println("schievent1Df")

    //</editor-fold>

    val schieventSc2Df = eventsVisitsDf
      .filter(
        ( ((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.visitSettingUnspecifiedVal))
          &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outpatientPosVal)))

          || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.bhOutpatientVal))

          || ((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.visitSettingUnspecifiedVal))
          && (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.partialHospitalizationPosVal)))

          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.partialHospitalizationIntensiveOutpatientVal))

          ||((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.visitSettingUnspecifiedVal))
          &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.communityMentalHealthCenterPosVal)))

          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.electroconvulsiveTherapyVal))

          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.observationVal))

          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.edVal))

          ||((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.visitSettingUnspecifiedVal))
          &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.edPosVal)) )

          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.bhStandAloneNonacuteInpatientVal))

          ||((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.visitSettingUnspecifiedVal))
          &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.nonacuteInpatientPosVal)))

          ||((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.visitSettingUnspecifiedVal))
          && (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal)))
          )

          &&((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.schizophreniaVal))
          &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))

          &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      ).repartition(2).cache()

    println("schieventSc2Df" + schieventSc2Df.count())
    schieventSc2Df.filter($"${KpiConstants.memberidColName}" === ("95377")).show()

    val step1ScDf = schieventSc2Df

    println("step1ScDf" + step1ScDf.count())
    step1ScDf.filter($"${KpiConstants.memberidColName}" === ("95377")).show()

    step1ScDf.filter($"${KpiConstants.memberidColName}" === ("95377")).show()

    val schievent2MemVisits1Df = step1ScDf.groupBy(KpiConstants.memberidColName)
      .agg(countDistinct(KpiConstants.serviceDateColName).alias(KpiConstants.countColName))

    val schievent2_1ScDf = schievent2MemVisits1Df.filter($"${KpiConstants.countColName}".>=(2))
      .select(KpiConstants.memberidColName)

    println("schievent2_1ScDf" + schievent2_1ScDf.count())
    schievent2_1ScDf.filter($"${KpiConstants.memberidColName}" === ("95377")).show()

    //------------------------------------Bipolar-------------------------------

    val schieventBi2Df = eventsVisitsDf
      .filter(
        ( ((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.visitSettingUnspecifiedVal))
          &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outpatientPosVal)))

          || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.bhOutpatientVal))

          || ((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.visitSettingUnspecifiedVal))
          && (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.partialHospitalizationPosVal)))

          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.partialHospitalizationIntensiveOutpatientVal))

          ||((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.visitSettingUnspecifiedVal))
          &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.communityMentalHealthCenterPosVal)))

          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.electroconvulsiveTherapyVal))

          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.observationVal))

          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.edVal))

          ||((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.visitSettingUnspecifiedVal))
          &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.edPosVal)) )

          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.bhStandAloneNonacuteInpatientVal))

          ||((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.visitSettingUnspecifiedVal))
          &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.nonacuteInpatientPosVal)))

          ||((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.visitSettingUnspecifiedVal))
          && (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal)))
          )

          &&(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.bipolarDisorderVal))||
          ((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.otherBipolarDisorder))))
          &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))

          &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      ).repartition(2).cache()

    schieventBi2Df.filter($"${KpiConstants.memberidColName}" === ("95377")).show()

    val step1BiDf = schieventBi2Df //.union(schi2event2Df)

    println("step1BiDf" + step1BiDf.count())
    step1BiDf.filter($"${KpiConstants.memberidColName}" === ("95377")).show()

    val schievent2MemVisits1BiDf = step1BiDf.groupBy(KpiConstants.memberidColName)
      .agg(countDistinct(KpiConstants.serviceDateColName).alias(KpiConstants.countColName))

    val schievent2_1BiDf = schievent2MemVisits1BiDf.filter($"${KpiConstants.countColName}".>=(2))
      .select(KpiConstants.memberidColName)

    println("schievent2_1BiDf" + schievent2_1BiDf.count())
    schievent2_1BiDf.filter($"${KpiConstants.memberidColName}" === ("95377")).show()

    val schievent2_1Df = schievent2_1ScDf.union(schievent2_1BiDf)

    println("schievent2_1Df" + schievent2_1Df.count())

    schievent2_1Df.filter($"${KpiConstants.memberidColName}" === ("95377")).show()

    val step1eventvistMemDf = schievent2_1Df.union(schievent1Df)

    println("step1eventvistMemDf" + step1eventvistMemDf.count())
    step1eventvistMemDf.filter($"${KpiConstants.memberidColName}" === ("95377")).show()
    /*   //-----------------------------Trying Something New----------------------

      val epop = step1eventvistMemDf.distinct()

       epop.coalesce(1)
         .write
         .mode(SaveMode.Append)
         .option("header", "true")
         .csv(outDir+ "/EPop/")

       //------------------------------------------------------------------------ */

    val step1eventvistDf = step1eventvistMemDf.as("df1").join(eventsVisitsDf.as("df2"),
      $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select($"df2.*")

    println("step1eventvistDf" + step1eventvistDf.count())
    step1eventvistDf.filter($"${KpiConstants.memberidColName}" === ("95377")).show()

    //</editor-fold>

    //<editor-fold desc=" Events & Diagnosis ">

    //step1eventvistDf

    //<editor-fold desc="First Event">

    //val step2VisitsDf = eventsVisitsDf.filter($"${KpiConstants.memberidColName}".isin(step1eventvistDf.rdd.map(r => r.getString(0)).collect():_*)).cache()


    val event1_1Df = step1eventvistDf.filter((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.inPatientStayVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.amiVal)))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)))
      &&(($"${KpiConstants.dischargeDateColName}".>=(PreYrStartDate)) &&($"${KpiConstants.dischargeDateColName}".<=(PreYrEndDate))))
      .select(KpiConstants.memberidColName)

    println("event1_1Df" + event1_1Df.count())
    event1_1Df.filter($"${KpiConstants.memberidColName}" === ("95377")).show()

    val event1_2Df = step1eventvistDf.filter((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.cabgVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.pciVal)))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)))
      &&(($"${KpiConstants.serviceDateColName}".>=(PreYrStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(PreYrEndDate))))
      .select(KpiConstants.memberidColName)

    println("event1_2Df" + event1_2Df.count())
    event1_2Df.filter($"${KpiConstants.memberidColName}" === ("95377")).show()

    val event1Df = event1_1Df.union(event1_2Df)

    println("event1Df" + event1Df.count())
    event1Df.filter($"${KpiConstants.memberidColName}" === ("95377")).show()

    //</editor-fold>

    //<editor-fold desc="First Diagnosis">

    val event2Step1Df= step1eventvistDf.filter(((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.acuteInpatientVal)))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ivdVal)))
      &&((!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))))
      &&(($"${KpiConstants.serviceDateColName}".>=(PreYrStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(PreYrEndDate))))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName).distinct()

    //val event2Step1Df = event2Step1InDf.intersect(ivdMyDf)

    val event2Step1VisitsDf = event2Step1Df.groupBy(KpiConstants.memberidColName)
      .agg(countDistinct(KpiConstants.serviceDateColName).alias(KpiConstants.countColName))

    val diag1Step1Df = event2Step1VisitsDf.filter($"${KpiConstants.countColName}".>=(1))
      .select(KpiConstants.memberidColName)

    println("diag1Step1Df" + diag1Step1Df.count())
    diag1Step1Df.filter($"${KpiConstants.memberidColName}" === ("95377")).show()

    val event2Step2Df = step1eventvistDf.filter(((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.acuteInpatientVal)))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ivdVal)))
      &&((!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))))
      &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName).distinct()

    //val event2Step2Df = event2Step2InDf.intersect(ivdMyDf)

    val event2Step2VisitsDf = event2Step2Df.groupBy(KpiConstants.memberidColName)
      .agg(countDistinct(KpiConstants.serviceDateColName).alias(KpiConstants.countColName))

    val diag1Step2Df = event2Step2VisitsDf.filter($"${KpiConstants.countColName}".>=(1))
      .select(KpiConstants.memberidColName)

    println("diag1Step2Df"+ diag1Step2Df.count())
    diag1Step2Df.filter($"${KpiConstants.memberidColName}" === ("95377")).show()

    val diag1df = diag1Step1Df.intersect(diag1Step2Df)

    println("--------------------diag1df--------------------" + diag1df.count())
    diag1df.filter($"${KpiConstants.memberidColName}" === ("95377")).show()

    //</editor-fold>

    //<editor-fold desc="Second Diagnosis">

    //diag1Step2Df -> For the measurement year

    /* val diag2InDf = step1eventvistDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal))
       &&((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telephoneVisitsVal))
       ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.onlineAssesmentVal))
       ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
       ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal)))
       &&(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.ivdVal))
       &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
       &&(($"${KpiConstants.serviceDateColName}".>=(PreYrStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(PreYrEndDate)))))
       .select(KpiConstants.memberidColName).distinct()

       val diag2Df = diag2InDf.union(diag1Step2Df)
 */
    val diag2InPreDf = step1eventvistDf.filter((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ivdVal)))
      &&((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal)))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)))
      &&(($"${KpiConstants.serviceDateColName}".>=(PreYrStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(PreYrEndDate))))
      .select(KpiConstants.memberidColName)

    val diag2InDf = step1eventvistDf.filter((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ivdVal)))
      &&((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal)))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)))
      &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
      .select(KpiConstants.memberidColName)

    val diag2Df = diag2InDf.intersect(diag2InPreDf)

    println("diag2Df"  + diag2Df.count())
    diag2Df.filter($"${KpiConstants.memberidColName}" === ("95377")).show()

    //</editor-fold>

    //<editor-fold desc="Third Diagnosis">

    //diag1Step1Df -> For Pre measurement year
    /*
        val diag3InDf = step1eventvistDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal))
          &&((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telephoneVisitsVal))
          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.onlineAssesmentVal))
          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal)))
          &&(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.ivdVal))
          &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
          &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))))
          .select(KpiConstants.memberidColName)

        val diag3Df = diag1Step1Df.intersect(diag3InDf)*/

    val diag3InPreDf = step1eventvistDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ivdVal))
      &&((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telephoneVisitsVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.onlineAssesmentVal)))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)))
      &&(($"${KpiConstants.serviceDateColName}".>=(PreYrStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(PreYrEndDate))))
      .select(KpiConstants.memberidColName)

    val diag3InDf = step1eventvistDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ivdVal))
      &&((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telephoneVisitsVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.onlineAssesmentVal)))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)))
      &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
      .select(KpiConstants.memberidColName)

    val diag3Df = diag3InDf.intersect(diag3InPreDf)

    val step2OrStep3PrevDf = diag2InPreDf.union(diag3InPreDf)

    val step2OrStep3CurrDf = diag2InDf.union(diag3InDf)

    val ivd2Df = (diag1Step1Df.except(diag1Step2Df)).intersect(step2OrStep3CurrDf)

    val ivd3Df = (diag1Step2Df.except(diag1Step1Df)).intersect(step2OrStep3PrevDf)

    val diagDf = diag1df.union(ivd2Df).union(ivd3Df)


    println("diag3InDf"  + diag3InDf.count())
    diag3InDf.filter($"${KpiConstants.memberidColName}".===("95377")).show()

    //</editor-fold>

    // val diagDf = diag1df.union(diag2Df).union(diag3Df)

    println("diagDf"  + diagDf.count())
    diagDf.filter($"${KpiConstants.memberidColName}".===("95377")).show()

    val eligibleDf = event1Df.union(diagDf).distinct()

    println("eligibleDf" + eligibleDf.count())
    eligibleDf.filter($"${KpiConstants.memberidColName}".===("95377")).show()

    //</editor-fold>

    //val eligibleDf = step1eventvistDf.except(exclusionDf)

    eligibleDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir+ "/Eligible_Pop/")

    eligibleDf.coalesce(3)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(temporary+ "/eligibleDf/")

    //</editor-fold>

    //<editor-fold desc="Numerator Calculation">

    /* val hospDf = spark.read.parquet(temporary+ "/hosiceremovalDf/").cache()

     val epopDf = spark.read.parquet(temporary+ "/eligibleDf/").cache()

     val validvisitsDf = epopDf.as("df1").join(hospDf.as("df2"),
       $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
       .select($"df2.*")

     validvisitsDf.coalesce(1)
       .write
       .mode(SaveMode.Overwrite)
       .parquet(temporary + "/validvisitsDf/")

     val totalDf = spark.read.parquet(temporary+ "/validvisitsDf/").cache()
 */


    val validvisitsDf = eligibleDf.as("df1").join(hosiceremovalDf.as("df2"),
      $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select($"df2.*")

    validvisitsDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/validvisitsDf/")

    val totalDf = spark.read.parquet(intermediateDir+ "/validvisitsDf/").cache()



    val toutStratDf = totalDf.select($"${KpiConstants.memberidColName}",$"${KpiConstants.memberidColName}".as(KpiConstants.ncqaOutmemberIdCol),
      $"${KpiConstants.payerColName}".as(KpiConstants.ncqaOutPayerCol))
      .withColumn(KpiConstants.ncqaOutMeasureCol,lit(measureId)).distinct()

    toutStratDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir + "/toutStratDf")

    println("--------------------toutStratDf---------------------" + toutStratDf.count())
    toutStratDf.filter($"${KpiConstants.memberidColName}".===("95377")).show()

    val totalNonSuppDf = totalDf.filter($"${KpiConstants.supplflagColName}".===("N")).cache()
    totalNonSuppDf.count()

    //<editor-fold desc="SMC Non Supp Numerator Calculation">

    println("--------------------totalNonSuppDf---------------------" + totalNonSuppDf.count())
    totalNonSuppDf.filter($"${KpiConstants.memberidColName}".===("95377")).show()

    val numNonSuppDf = totalNonSuppDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ldlcTestsVal))
      //&&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)))
      &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))

    println("--------------------numNonSuppDf---------------------" + numNonSuppDf.count())
    numNonSuppDf.filter($"${KpiConstants.memberidColName}".===("95377")).show()

    //</editor-fold>

    //<editor-fold desc="SMC Other Mem Numerator Calculation">

    val totalMenOtherDf = totalDf.except(totalDf.filter($"${KpiConstants.memberidColName}".isin(numNonSuppDf.rdd.map(r=>r.getString(0)).collect():_*)))

    println("--------------------totalMenOtherDf---------------------" + totalMenOtherDf.count())
    totalMenOtherDf.filter($"${KpiConstants.memberidColName}".===("95377")).show()

    val numNMenOtherDf = totalMenOtherDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ldlcTestsVal))
      //&&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)))
      &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))


    println("--------------------numNMenOtherDf---------------------" + numNMenOtherDf.count())
    numNMenOtherDf.filter($"${KpiConstants.memberidColName}".===("95377")).show()

    //</editor-fold>

    val numeratorDf = numNonSuppDf.union(numNMenOtherDf)

    println("--------------------numeratorDf---------------------" + numeratorDf.count())
    numeratorDf.filter($"${KpiConstants.memberidColName}".===("95377")).show()

    val numDf = numeratorDf.select($"${KpiConstants.memberidColName}").distinct()

    val outMap = mutable.Map(KpiConstants.totalPopDfName -> toutStratDf, KpiConstants.eligibleDfName -> eligibleDf,
      //KpiConstants.eligibleDfName -> eligibleDf,KpiConstants.eligibleDfName -> epopDf,
      KpiConstants.mandatoryExclDfname -> spark.emptyDataFrame, KpiConstants.optionalExclDfName -> spark.emptyDataFrame,
      KpiConstants.numeratorDfName -> numDf)


    val outDf = UtilFunctions.ncqaOutputDfCreation(spark,outMap,measureId)
    outDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir+ "/outDf")

    println("--------------------outDf---------------------")
    outDf.filter($"${KpiConstants.memberidColName}".===("95377")).show()


    //</editor-fold>

    spark.sparkContext.stop()

  }

}
