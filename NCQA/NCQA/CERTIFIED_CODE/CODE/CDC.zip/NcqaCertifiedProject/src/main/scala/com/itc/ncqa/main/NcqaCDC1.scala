package com.itc.ncqa.main

import java.sql.Date

import com.itc.ncqa.Constants.KpiConstants
import com.itc.ncqa.Functions.{DataLoadFunctions, UtilFunctions}
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.SparkConf
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{FloatType, IntegerType, StringType}

import scala.collection.JavaConversions._
import scala.collection.mutable

case class CdcMember(member_id:String, data_source:String,lab_value:String, valueset:List[String], rank:String, service_date:Date)

object NcqaCDC1 extends Serializable {

  def main(args: Array[String]): Unit = {

    //<editor-fold desc="Reading program arguments and SaprkSession oBject creation">

    val year = args(0)
    val measureId = args(1)
    val dbName = args(2)
    val baseMsrPath = args(3)

    /*calling function for setting the dbname for dbName variable*/
    KpiConstants.setDbName(dbName)
    val conf = new SparkConf().setAppName("NcqaProgram")
    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      .set("hive.exec.dynamic.partition.mode", "nonstrict")
      .set("spark.sql.shuffle.partitions","5")


    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    import spark.implicits._

    val yearStartDate = year+"-01-01"
    val yearEndDate = year+"-12-31"
    val prevYearStDate = year.toInt-1 +"-01-01"
    val prevYearEndDate = year.toInt-1 +"-12-31"
    val yearNovDate = year+"-11-01"
    val oct1Date = year.toInt-2 +"-10-01"
    val jobId = spark.sparkContext.applicationId
    val baseDir = baseMsrPath + "/" + jobId
    val outDir = baseDir + "/Out"
    val intermediateDir = baseDir + "/Intermediate"

    //</editor-fold>

    //<editor-fold desc="Loading Required Tables to memory">


    val aLiat = List("col1")
    val msrVal = s"'$measureId'"
    val ggMsrId = s"'${KpiConstants.ggMeasureId}'"
    val lobList = List(KpiConstants.commercialLobName, KpiConstants.medicaidLobName,KpiConstants.medicareLobName, KpiConstants.marketplaceLobName, KpiConstants.mmpLobName)
    val claimStatusList = List(KpiConstants.paidVal, KpiConstants.suspendedVal, KpiConstants.pendingVal, KpiConstants.deniedVal)

    val memqueryString = s"""SELECT * FROM ${KpiConstants.dbName}.${KpiConstants.membershipTblName} WHERE measure = $msrVal AND (member_plan_start_date IS  NOT NULL) AND(member_plan_end_date IS NOT NULL)"""
    val membershipDf = DataLoadFunctions.dataLoadFromHiveStageTable(spark,KpiConstants.dbName,KpiConstants.membershipTblName,memqueryString,aLiat)
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .repartition(1)

    val visitqueryString = s"""SELECT * FROM ${KpiConstants.dbName}.${KpiConstants.visitTblName} WHERE measure = $msrVal and  (service_date IS  NOT NULL) AND((admit_date IS NULL and discharge_date IS NULL) OR (ADMIT_DATE IS NOT NULL AND DISCHARGE_DATE IS NOT NULL))"""
    val visitsDf = DataLoadFunctions.dataLoadFromHiveStageTable(spark,KpiConstants.dbName,KpiConstants.visitTblName,visitqueryString,aLiat)
      .filter((($"${KpiConstants.dataSourceColName}".===("Claim"))&&($"${KpiConstants.claimstatusColName}".isin(claimStatusList:_*)))
        ||($"${KpiConstants.dataSourceColName}".===("RxClaim"))
        ||($"${KpiConstants.dataSourceColName}".===("Rx"))
        || ($"${KpiConstants.dataSourceColName}".===("Lab")))
      .drop(KpiConstants.lobProductColName, "latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name","product")
      .withColumn(KpiConstants.revenuecodeColName, when((length($"${KpiConstants.revenuecodeColName}").as[Int].===(3)),concat(lit("0" ),lit($"${KpiConstants.revenuecodeColName}"))).otherwise($"${KpiConstants.revenuecodeColName}"))
      .withColumn(KpiConstants.billtypecodeColName, when((length($"${KpiConstants.billtypecodeColName}").as[Int].===(3)),concat(lit("0" ),lit($"${KpiConstants.billtypecodeColName}"))).otherwise($"${KpiConstants.billtypecodeColName}"))
      .withColumn(KpiConstants.proccode2ColName, when(($"${KpiConstants.proccode2mod1ColName}".isin(KpiConstants.avoidCodeList:_*)) || ($"${KpiConstants.proccode2mod2ColName}".isin(KpiConstants.avoidCodeList:_*)),lit("NA")).otherwise($"${KpiConstants.proccode2ColName}"))
      .repartition(3)

    val medmonmemqueryString = s"""SELECT * FROM ${KpiConstants.dbName}.${KpiConstants.medmonmemTblName} WHERE measure = $msrVal"""
    val medmonmemDf = DataLoadFunctions.dataLoadFromHiveStageTable(spark,KpiConstants.dbName,KpiConstants.medmonmemTblName,medmonmemqueryString,aLiat)
      .filter(($"run_date".>=(yearStartDate)) && ($"run_date".<=(yearEndDate)))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .repartition(1)

    medmonmemDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .json(intermediateDir+ "/medmonmemDf/")



    val refHedisqueryString =s"""SELECT * FROM  ${KpiConstants.dbName}.${KpiConstants.refHedisTblName} WHERE measureid = $msrVal OR measureid= $ggMsrId"""
    val refHedisDf = DataLoadFunctions.dataLoadFromHiveStageTable(spark,KpiConstants.dbName,KpiConstants.medmonmemTblName,refHedisqueryString,aLiat)
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")


    val refMedqueryString = s"""SELECT * FROM  ${KpiConstants.dbName}.${KpiConstants.refmedValueSetTblName} WHERE measure_id = $msrVal"""
    val ref_medvaluesetDf = DataLoadFunctions.dataLoadFromHiveStageTable(spark,KpiConstants.dbName,KpiConstants.medmonmemTblName,refMedqueryString,aLiat)
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")


    // println("counts:"+membershipDf.count()+","+ visitsDf.count()+","+medmonmemDf.count() +","+refHedisDf.count()+","+ref_medvaluesetDf.count())

    //</editor-fold

    //<editor-fold desc="Eligible Population">

    //<editor-fold desc="Age Filter And SN2 Removal Calculation">

    val ageFilterDf = membershipDf.filter((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",KpiConstants.months216).<=(yearEndDate))
                                                 &&(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",KpiConstants.months912).>(yearEndDate)))

    val sn2Members = ageFilterDf.filter(($"${KpiConstants.lobProductColName}".===(KpiConstants.lobProductNameConVal))
                                   &&(((($"${KpiConstants.memStartDateColName}".>=(yearStartDate)) && ($"${KpiConstants.memStartDateColName}".<=(yearEndDate)))
                                      ||(($"${KpiConstants.memEndDateColName}".>=(yearStartDate)) && ($"${KpiConstants.memEndDateColName}".<=(yearEndDate))))
                                      || ((($"${KpiConstants.memStartDateColName}".<(yearStartDate)) && ($"${KpiConstants.memEndDateColName}".>(yearEndDate)))))
                                   &&(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}", KpiConstants.months792).<=(yearEndDate)))
                                .select(KpiConstants.memberidColName).rdd.map(r => r.getString(0)).collect()
    val sn2RemovedMemDf = ageFilterDf.except(ageFilterDf.filter($"${KpiConstants.memberidColName}".isin(sn2Members:_*)))

    //</editor-fold>

    //<editor-fold desc="Continuous Enrollment, Allowable Gap Calculation">

    val inputForContEnrolldf = sn2RemovedMemDf.select(KpiConstants.memberidColName, KpiConstants.benefitMedicalColname,
      KpiConstants.memStartDateColName,KpiConstants.memEndDateColName,
      KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName, KpiConstants.dateofbirthColName,KpiConstants.primaryPlanFlagColName)



    val mapForCeCurrYear = mutable.Map("start_date" -> "2018-01-01", "end_date" -> "2018-12-31","gapcount" -> "1",
                                       "checkval" -> "true","reqCovDays" -> "0","anchor_date" -> "2018-12-31")

    val contEnrollDf = UtilFunctions.contEnrollAndAllowableGapFilterFunction(spark,inputForContEnrolldf,mapForCeCurrYear)
      .select(KpiConstants.memberidColName, KpiConstants.dateofbirthColName, KpiConstants.memStartDateColName, KpiConstants.memEndDateColName,
        KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.primaryPlanFlagColName,
        KpiConstants.payerColName)

    contEnrollDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/contEnrollDf/")

    contEnrollDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .json(intermediateDir+ "/contEnrollDf_json/")
    //</editor-fold>

    //<editor-fold desc="Dual Enrollment calculation">

    val contDf = spark.read.parquet(intermediateDir+ "/contEnrollDf/")
    val baseOutInDf = UtilFunctions.baseOutDataframeCreation(spark, contDf, lobList,measureId)
    val medicareContEnrollDf = baseOutInDf.filter($"${KpiConstants.lobColName}".===(KpiConstants.medicareLobName)).cache()
    medicareContEnrollDf.count()

    /*Find out the Medicare Hospice Mmebers by lookung in the hospice flag in medicare_monthly_membership table*/
    val medicareHospiceDf = medicareContEnrollDf.as("df1").join(medmonmemDf.as("df2"), Seq(KpiConstants.memberidColName))
      .groupBy(KpiConstants.memberidColName).agg(countDistinct(when($"${KpiConstants.hospiceFlagColName}".===(KpiConstants.yesVal),1)).alias(KpiConstants.countColName))
      .filter($"${KpiConstants.countColName}".>(0))
      .select(KpiConstants.memberidColName).rdd.map(r=> r.getString(0)).collect()

    /*Remove the members who has lti flag inmonthly_medicare_membership table*/
    val baseOutStep1Df = baseOutInDf.except(baseOutInDf.filter($"${KpiConstants.memberidColName}".isin(medicareHospiceDf:_*)))

    /*Find out the Medicare  Members who has atleast 1 lti_flag in medicare_monthly_membership table*/
    val medicareLtiDf = medicareContEnrollDf.as("df1").join(medmonmemDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select(s"df1.${KpiConstants.memberidColName}",KpiConstants.dateofbirthColName, KpiConstants.ltiFlagColName)
      .filter((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",KpiConstants.months792).<=(yearEndDate)))
      .groupBy(KpiConstants.memberidColName).agg(count(when($"${KpiConstants.ltiFlagColName}".===(KpiConstants.yesVal),1)).alias(KpiConstants.countColName))
      .filter($"${KpiConstants.countColName}".>=(1))
      .select(KpiConstants.memberidColName).rdd.map(r => r.getString(0)).collect()

    /*Remove the member's medicare and Medicare-Medicaid Plans data whao has atleast 1 LTI flag*/
    val baseOutDf = baseOutStep1Df.except(baseOutStep1Df.filter(($"${KpiConstants.memberidColName}".isin(medicareLtiDf:_*))
                                                             &&(($"${KpiConstants.lobColName}".===(KpiConstants.medicareLobName))
                                                              ||($"${KpiConstants.lobColName}".===(KpiConstants.mmpLobName)))))

    baseOutDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/baseOutDf/")

 /*   baseOutDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .json(intermediateDir+ "/baseOutDf_json/")
*/
    //</editor-fold>

    //<editor-fold desc="Initial Join with Ref_Hedis">

    val argmapforRefHedis = mutable.Map(KpiConstants.eligibleDfName -> visitsDf , KpiConstants.refHedisTblName -> refHedisDf,
      KpiConstants.refmedValueSetTblName -> ref_medvaluesetDf)

    val allValueList = List(KpiConstants.independentLabVal, KpiConstants.hospiceVal, KpiConstants.acuteInpatientVal,
      KpiConstants.diabetesVal, KpiConstants.telehealthModifierVal, KpiConstants.telehealthPosVal, KpiConstants.outPatientVal,
      KpiConstants.observationVal, KpiConstants.edVal, KpiConstants.nonAcuteInPatientVal, KpiConstants.telephoneVisitsVal,
      KpiConstants.onlineAssesmentVal, KpiConstants.fralityVal, KpiConstants.advancedIllVal,
      KpiConstants.cabgVal, KpiConstants.pciVal, KpiConstants.ivdVal, KpiConstants.thoraticAcriticVal,KpiConstants.chronicHeartFailureVal,
      KpiConstants.miVal, KpiConstants.ckdStage4Val, KpiConstants.dementiaVal, KpiConstants.fronDementiaVal, KpiConstants.blindnessVal,
      KpiConstants.lowerExtrAmputationVal, KpiConstants.esrdVal, KpiConstants.esrdObsoleteVal, KpiConstants.hba1cTestVal,
      KpiConstants.hba1cGtNineVal, KpiConstants.hba1cLtSevenVal, KpiConstants.hba1cBwSevenAndNineVal, KpiConstants.diabeticRetinalScreeningVal,
      KpiConstants.diabeticRetinalScreeningnegVal, KpiConstants.diabtesMellWoCompliVal, KpiConstants.diabeticReScreeWECProfessionalVal, KpiConstants.unilateralEyeEnucleationVal,
      KpiConstants.bilateralModifierVal, KpiConstants.unilateralEyeEnuLeftVal, KpiConstants.unilateralEyeEnuRightVal,KpiConstants.urineProteinTestVal,
      KpiConstants.nephropathyTreatmentVal, KpiConstants.kidneyTransplantVal, KpiConstants.remotebpmVal, KpiConstants.systolicLt140Val,
      KpiConstants.diastolicLt80Val, KpiConstants.diastolicBtwn8090Val, KpiConstants.systolicGtOrEq140Val, KpiConstants.diastolicGt90Val,
      KpiConstants.diabetesExclusionVal)

    val medicationlList = List(KpiConstants.diabetesMedicationVal, KpiConstants.dementiaMedicationVal, KpiConstants.aceInhArbMedVal)
    val visitRefHedisDf = UtilFunctions.joinWithRefHedisFunction(spark,argmapforRefHedis,allValueList,medicationlList)

    visitRefHedisDf
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/visitRefHedisDf/")

    //</editor-fold>

    //<editor-fold desc="Removal of Independent Lab Visits">


    val groupList = visitsDf.schema.fieldNames.toList.dropWhile(p=> p.equalsIgnoreCase(KpiConstants.memberidColName))
    val visitgroupedDf = spark.read.parquet(intermediateDir+ "/visitRefHedisDf/")
                                   .groupBy(KpiConstants.memberidColName, groupList:_*).agg(collect_set(KpiConstants.valuesetColName).alias(KpiConstants.valuesetColName))
                                   .select(KpiConstants.memberidColName,KpiConstants.dobColName, KpiConstants.serviceDateColName, KpiConstants.admitDateColName, KpiConstants.dischargeDateColName,
                                                KpiConstants.supplflagColName,KpiConstants.dataSourceColName, KpiConstants.labvalueColName, KpiConstants.iseyecareproviderColName,
                                                KpiConstants.isnephrologistColName, KpiConstants.valuesetColName)
                                        .repartition(2)


    visitgroupedDf.coalesce(2)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/visitgroupedDf/")

    /*visitgroupedDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .json(intermediateDir+ "/visitgroupedDf_json/")*/

    val indLabVisRemDf = spark.read.parquet(intermediateDir+ "/visitgroupedDf/")
                                    .filter((!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
                                            ||((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)) && (array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hba1cTestVal)))
                                            ||((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)) && (array_contains($"${KpiConstants.valuesetColName}",KpiConstants.urineProteinTestVal))))

    indLabVisRemDf.coalesce(2)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/indLabVisRemDf/")

    indLabVisRemDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .json(intermediateDir+ "/indLabVisRemDf_json/")

    //</editor-fold>

    //<editor-fold desc="Hospice Removal">

    val baseMemDf = spark.read.parquet(intermediateDir+ "/baseOutDf/").repartition(2)
    val hospiceInCurrYearMemDf = indLabVisRemDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hospiceVal))
                                                     &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
                                                     &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate))
                                                     &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
                                               .select(KpiConstants.memberidColName)
                                               .dropDuplicates()
                                               .rdd
                                               .map(r=> r.getString(0))
                                               .collect()


    val hospiceRemMemEnrollDf = baseMemDf.except(baseMemDf.filter($"${KpiConstants.memberidColName}".isin(hospiceInCurrYearMemDf:_*)))
      .select(KpiConstants.memberidColName,KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName, KpiConstants.memStartDateColName).dropDuplicates()
    /* hospiceRemMemEnrollDf.select(KpiConstants.memberidColName).distinct().coalesce(1)
       .write
       .mode(SaveMode.Append)
       .option("header", "true")
       .csv(outDir +"/hospiceRemMemEnrollDf/")*/

    //</editor-fold>

    //<editor-fold desc="Initial join function">

    val indLabVisInDf = spark.read.parquet(intermediateDir+ "/indLabVisRemDf/").repartition(2).cache()
    val argmapForVisittJoin = mutable.Map(KpiConstants.membershipTblName -> hospiceRemMemEnrollDf , KpiConstants.visitTblName -> indLabVisInDf)
    val validVisitsOutDf = UtilFunctions.initialJoinFunction(spark,argmapForVisittJoin).repartition(2).cache()
    validVisitsOutDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/validVisitsOutDf/")

    validVisitsOutDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .json(intermediateDir+ "/validVisitsOutDf_json/")

    //</editor-fold>

    //<editor-fold desc="Eligible Event Calculation">

    val validVisitsDf = spark.read.parquet(intermediateDir+ "/validVisitsOutDf/").repartition(2).cache()
    validVisitsDf.count()
   /* baseOutDf.unpersist()
    indLabVisRemDf.unpersist()*/

    val visitForEventDf = validVisitsDf.filter($"${KpiConstants.supplflagColName}".===("N"))

    //<editor-fold desc="First Event">

    val event1Df = visitForEventDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.acuteInpatientVal))
                                        &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabetesVal))
                                        &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
                                        &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal))
                                        &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
                                        &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
                                        &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
                                  .select(KpiConstants.memberidColName)
    //</editor-fold>

    //<editor-fold desc="Second Event">

    val event2Step1Df= visitForEventDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal))
                                              ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.observationVal))
                                              ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.edVal))
                                              ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.nonAcuteInPatientVal)))
                                           &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabetesVal))
                                           &&((!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
                                            &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal)))
                                            &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
                                           &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
                                           &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
                                      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)

    val event2Step2Df = visitForEventDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabetesVal))
                                            &&((!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telephoneVisitsVal))
                                             &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.onlineAssesmentVal)))
                                            &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
                                            &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
                                            &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
                                       .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)

    val event2AtLeast1VisitDf = event2Step1Df.intersect(event2Step2Df)

    /*member_id, count of visits*/
    val event2MemVisits1Df = event2AtLeast1VisitDf.groupBy(KpiConstants.memberidColName)
                                                  .agg(countDistinct(KpiConstants.serviceDateColName).alias(KpiConstants.countColName))


    //<editor-fold desc="2 or more visits">

    val event2_1Df = event2MemVisits1Df.filter($"${KpiConstants.countColName}".>=(2))
                                       .select(KpiConstants.memberidColName)
    //</editor-fold>

    //<editor-fold desc="1 Visit">

    val oneVisitInDf = event2MemVisits1Df.select(KpiConstants.memberidColName).except(event2_1Df).as("df1").join(visitForEventDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
                                         .select("df2.*")


    val event2Step3Df= oneVisitInDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal))
                                          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.observationVal))
                                          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.edVal)))
                                          &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabetesVal))
                                          &&((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
                                            ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal)))
                                          &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
                                          &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
                                          &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
                                   .select(KpiConstants.memberidColName)

    val event2Step4Df = oneVisitInDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabetesVal))
                                          &&((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telephoneVisitsVal))
                                           ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.onlineAssesmentVal)))
                                          &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
                                          &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
                                          &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
                                    .select(KpiConstants.memberidColName)

    val event2_2Df = event2Step3Df.union(event2Step4Df)
    //</editor-fold>

    val event2Df = event2_1Df.union(event2_2Df)
    //</editor-fold>

    //<editor-fold desc="Third Event">

    val event3Df = visitForEventDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabetesMedicationVal))
                                        &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
                                        &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
                                        &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
                                  .select(KpiConstants.memberidColName)
    //</editor-fold>

    val eventDf = event1Df.union(event2Df).union(event3Df)

    val totalPopVisitsDf = validVisitsDf.as("df1").join(eventDf.as("df2"), $"df1.${KpiConstants.memberidColName}"=== $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
                                        .select("df1.*")


    totalPopVisitsDf.coalesce(3)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir + "/totalPopVisitsDf/")


    //</editor-fold>

    //<editor-fold desc="Mandatory Exclusion Calculation">

    val visitForMandExclDf = spark.read.parquet(intermediateDir + "/totalPopVisitsDf/").repartition(3).cache()
    visitForMandExclDf.count()
    val visitForMandExclInDf = visitForMandExclDf.filter($"${KpiConstants.supplflagColName}".===("N")).cache()
    visitForMandExclInDf.count()

    //<editor-fold desc="Mandatory Exclusion">


    val mandatoryExcl3Sub1Df = visitForMandExclInDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.fralityVal))
                                                          &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
                                                        &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
                                                        &&(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}", KpiConstants.months792).<=(yearEndDate)))
                                                   .select(KpiConstants.memberidColName)
                                                   .distinct()

    val outPatAndAdvIllDf = visitForMandExclInDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal))
                                                      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.advancedIllVal))
                                                      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
                                                      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
                                                      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
                                                .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)



    val obsAndAdvIllDf = visitForMandExclInDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.observationVal))
                                                   &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.advancedIllVal))
                                                    &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
                                                   &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
                                                   &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
                                            .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)

    val edAndAdvIllDf = visitForMandExclInDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.edVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.advancedIllVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)

    val nAcuteInPatAndAdvIllDf = visitForMandExclInDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.nonAcuteInPatientVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.advancedIllVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)



    val mandatoryExcl3Sub21Df = outPatAndAdvIllDf.union(obsAndAdvIllDf).union(edAndAdvIllDf).union(nAcuteInPatAndAdvIllDf)
      .groupBy(KpiConstants.memberidColName)
      .agg(countDistinct(KpiConstants.serviceDateColName).alias("count"))
      .filter($"count".>=(2))
      .select(KpiConstants.memberidColName)


    val mandatoryExcl3Sub22Df = visitForMandExclInDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.acuteInpatientVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.advancedIllVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)

    val mandatoryExcl3Sub23Df = visitForMandExclInDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.dementiaMedicationVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)


    val mandatoryExcl3Sub2Df = mandatoryExcl3Sub21Df.union(mandatoryExcl3Sub22Df).union(mandatoryExcl3Sub23Df)

    val mandatoryExcl3Df = mandatoryExcl3Sub1Df.intersect(mandatoryExcl3Sub2Df)

    //</editor-fold>

    //</editor-fold>


    val eligibleVisitsDf = visitForMandExclDf.except(visitForMandExclDf.filter($"${KpiConstants.memberidColName}".isin(mandatoryExcl3Df.rdd.map(r=> r.getString(0)).collect():_*)))

    eligibleVisitsDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir + "/eligibleVisitsDf/")

    eligibleVisitsDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .json(intermediateDir + "/eligibleVisitsDf_json/")

    //</editor-fold>

    //<editor-fold desc="Stratification code">

    val stratInDf = spark.read.parquet(intermediateDir+ "/eligibleVisitsDf/")
                         .select(KpiConstants.memberidColName, KpiConstants.lobColName, KpiConstants.payerColName, KpiConstants.lobProductColName).distinct()
                         .repartition(2)

    val msrList = List(KpiConstants.cdc1MeasureId, KpiConstants.cdc2MeasureId, KpiConstants.cdc3MeasureId,
                       KpiConstants.cdc4MeasureId, KpiConstants.cdc7MeasureId, KpiConstants.cdc9MeasureId,
                       KpiConstants.cdc10MeasureId)

    val lobNameList = List(KpiConstants.commercialLobName, KpiConstants.medicaidLobName, KpiConstants.medicareLobName)
    val remMsrlist = List(KpiConstants.cdc1MeasureId, KpiConstants.cdc2MeasureId, KpiConstants.cdc3MeasureId,KpiConstants.cdc9MeasureId)


    val toutStrDf = UtilFunctions.toutOutputCreation(spark,stratInDf,msrList,lobNameList,remMsrlist)
                                 .select(KpiConstants.memberidColName, KpiConstants.ncqaOutMeasureCol,KpiConstants.ncqaOutPayerCol,  KpiConstants.lobColName)
                                 .distinct()

    val toutStrOutDf = toutStrDf.except(toutStrDf.filter(($"${KpiConstants.ncqaOutMeasureCol}".===(KpiConstants.cdc3MeasureId))
                                                       &&($"${KpiConstants.lobColName}".===(KpiConstants.medicareLobName))))

    /*Stratification code*/
    val stratificationInputDf = toutStrOutDf.filter(($"${KpiConstants.lobColName}".===(KpiConstants.medicareLobName))
                                               &&($"${KpiConstants.ncqaOutMeasureCol}".===(KpiConstants.cdc4MeasureId)))

    /* println("------------------------stratificationInputDf----------------------------")
     stratificationInputDf.filter($"${KpiConstants.memberidColName}".isin(List("101677","100879"):_*)).show()*/




    /*Step1*/
    val joinWithMedMonDf = stratificationInputDf.as("df1").join(medmonmemDf.as("df2"), Seq(KpiConstants.memberidColName))

    /* println("------------------------joinWithMedMonDf----------------------------")
     joinWithMedMonDf.filter($"${KpiConstants.memberidColName}".===("98067"))
       .select(KpiConstants.memberidColName, KpiConstants.memStartDateColName, KpiConstants.orecCodeColName, KpiConstants.lisPreSubsColName, KpiConstants.runDateColName).show()
 */




    /*create the window function based on partitioned by memebr_id and descending order of run_date*/
    val windowForStratification = Window.partitionBy(KpiConstants.memberidColName, KpiConstants.payerColName).orderBy(org.apache.spark.sql.functions.col(KpiConstants.runDateColName).desc)

    val rankColAddedDf = joinWithMedMonDf.withColumn(KpiConstants.rankColName, rank().over(windowForStratification))
      .filter($"${KpiConstants.rankColName}".<=(3))
      .withColumn(KpiConstants.lisPreSubsColName,concat(lit($"${KpiConstants.lisPreSubsColName}"), lit(":"), lit($"${KpiConstants.rankColName}")))
      .groupBy(KpiConstants.memberidColName, KpiConstants.ncqaOutPayerCol)
      .agg(first($"${KpiConstants.lobColName}").alias(KpiConstants.lobColName),
        first($"${KpiConstants.orecCodeColName}").alias(KpiConstants.orecCodeColName),
        collect_list(KpiConstants.lisPreSubsColName).alias(KpiConstants.lisPreSubsColName))

    //<editor-fold desc="Last 2 months enrolled memebers">

    /* val joinLast2MonthsMemDf = rankColAddedDf.filter(($"${KpiConstants.memStartDateColName}".>=(yearNovDate))
                                                      &&($"${KpiConstants.memStartDateColName}".<=(yearEndDate)))*/

    val joinLast2MonthsMemDf = rankColAddedDf.withColumn("count",size($"${KpiConstants.lisPreSubsColName}"))
                                             .filter($"count".<(3))
                                             .drop("count")

    val rankAdded2MonthsMemDf = joinLast2MonthsMemDf.withColumn(KpiConstants.ncqaOutMeasureCol,when($"${KpiConstants.orecCodeColName}".cast(IntegerType).===(0),lit("CDC4NON"))
      .when($"${KpiConstants.orecCodeColName}".cast(IntegerType).===(2) || $"${KpiConstants.orecCodeColName}".cast(IntegerType).===(9),lit("CDC4OT"))
      .when($"${KpiConstants.orecCodeColName}".cast(IntegerType).===(1) || $"${KpiConstants.orecCodeColName}".cast(IntegerType).===(3),lit("CDC4DIS")))
      .select(KpiConstants.memberidColName, KpiConstants.ncqaOutMeasureCol,KpiConstants.ncqaOutPayerCol,KpiConstants.lobColName )

    //</editor-fold>

    //<editor-fold desc="More than 2 months enrolled members">

    val joinFullYearMemDf = rankColAddedDf.except(joinLast2MonthsMemDf)

    /* joinFullYearMemDf.printSchema()
     println("-----------------------------joinFullYearMemDf-----------------------")
     joinFullYearMemDf.filter($"${KpiConstants.memberidColName}".===("106154")).show()*/




    /* val lis = udf((value : Seq[String]) =>  {
       val map = value.map(f => (f.split(":")(1).toInt, f.split(":")(0).toInt)).toMap
       if((map.get(1).get == map.get(2).get == map.get(3).get) || (map.get(1).get != map.get(2).get != map.get(3).get) || (map.get(1).get == map.get(2))) map.get(1).get
       else
         map.get(2).get
     }*/

  /*  val lis = udf((value : Seq[String]) =>  {
      val map = value.map(f => (f.split(":")(1).toInt, f.split(":")(0).toInt)).toMap
      if((map.get(2).get == map.get(3).get) && (map.get(1).get != map.get(2).get )) map.get(2).get
      else
        map.get(1).get
    }
    )*/

    val lis = udf((value : Seq[String]) =>  {
      val map = value.map(f => (f.split(":")(1).toInt, f.split(":")(0).toInt)).toMap

      if((map.get(1).get != map.get(2).get) && (map.get(2).get != map.get(3).get) && (map.get(1).get != map.get(3).get)){

        val li = map.toList.map(f => f._2).sorted

        /* println("list")
         li.foreach(f => println(f))*/
        val data = li match {

          case x if(li.filter(p => p <=0).length > li.filter(p => p >0).length) => li.filter(p => p <=0)(0)

          case x if(li.filter(p => p > 0).length > li.filter(p => p <= 0).length) => li.filter(p => p > 0)(0)

          case _ => li(0)
        }
        data
      }
      else if((map.get(2).get == map.get(3).get) && (map.get(1).get != map.get(2).get )) map.get(2).get


      else
        map.get(1).get
    }

    )


    val lisPreSubAddedDf = joinFullYearMemDf.withColumn(KpiConstants.lisPreSubsColName, lis($"${KpiConstants.lisPreSubsColName}"))

    /*println("-----------------------------lisPreSubAddedDf-----------------------")
    lisPreSubAddedDf.filter($"${KpiConstants.memberidColName}".===("106154")).show()*/



    val measAddedFullYearDf = lisPreSubAddedDf.withColumn(KpiConstants.ncqaOutMeasureCol, when(($"${KpiConstants.lisPreSubsColName}".cast(StringType).===(""))&& ($"${KpiConstants.orecCodeColName}".cast(StringType).===("")), lit("CDC4UN"))
      .when(($"${KpiConstants.lisPreSubsColName}".cast(StringType).=!=(""))&& ($"${KpiConstants.orecCodeColName}".cast(IntegerType).===(2) || $"${KpiConstants.orecCodeColName}".cast(IntegerType).===(9)), lit("CDC4OT"))
      .when(($"${KpiConstants.lisPreSubsColName}".cast(IntegerType).<=(0))&& ($"${KpiConstants.orecCodeColName}".cast(IntegerType).===(0)), lit("CDC4NON"))
      .when(($"${KpiConstants.lisPreSubsColName}".cast(IntegerType).>(0))&& ($"${KpiConstants.orecCodeColName}".cast(IntegerType).===(0)), lit("CDC4LISDE"))
      .when(($"${KpiConstants.lisPreSubsColName}".cast(IntegerType).<=(0))&& ($"${KpiConstants.orecCodeColName}".cast(IntegerType).===(1) || $"${KpiConstants.orecCodeColName}".cast(IntegerType).===(3)), lit("CDC4DIS"))
      .when(($"${KpiConstants.lisPreSubsColName}".cast(IntegerType).>(0))&& ($"${KpiConstants.orecCodeColName}".cast(IntegerType).===(1) || $"${KpiConstants.orecCodeColName}".cast(IntegerType).===(3)), lit("CDC4CMB")))
      .select(KpiConstants.memberidColName, KpiConstants.ncqaOutMeasureCol,KpiConstants.ncqaOutPayerCol, KpiConstants.lobColName)
    //</editor-fold>

    /*Medicare members startification*/
    val medicareMemStratifiedDf = rankAdded2MonthsMemDf.union(measAddedFullYearDf)

    /*Other LOB members startification*/
    val otherMemStratifiedDf = toutStrOutDf.except(stratificationInputDf)
                                        .select(KpiConstants.memberidColName,KpiConstants.ncqaOutMeasureCol,KpiConstants.ncqaOutPayerCol, KpiConstants.lobColName)

    val startifiedTotalPopDf = medicareMemStratifiedDf.union(otherMemStratifiedDf)
      .select(KpiConstants.memberidColName,KpiConstants.ncqaOutMeasureCol,KpiConstants.ncqaOutPayerCol)
      .dropDuplicates()

    startifiedTotalPopDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/startifiedTotalPopDf/")


    //</editor-fold>

    //<editor-fold desc="HBA1C<7.0 Denominator Calculation">

    val inDf = spark.read.parquet(intermediateDir+ "/eligibleVisitsDf/").repartition(2).cache()
    val denominatorInVisitDf = inDf.except(inDf.filter(($"${KpiConstants.lobColName}".===(KpiConstants.marketplaceLobName))
                                                      ||($"${KpiConstants.lobColName}".===(KpiConstants.medicareLobName))))
                                   .cache()
    denominatorInVisitDf.count()


    //<editor-fold desc="Age >65">

    val ageDenoFilterDf = denominatorInVisitDf.filter((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}",KpiConstants.months780).<=(yearEndDate)))
                                              .select(KpiConstants.memberidColName)
    //</editor-fold>

    //<editor-fold desc="CABG ">

    val cabgDf = denominatorInVisitDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.cabgVal))
                                           &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
                                           &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
                                           &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
                                      .select(KpiConstants.memberidColName)
    //</editor-fold>

    //<editor-fold desc="PCI">

    val pciDf = denominatorInVisitDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.pciVal))
                                          &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
                                        &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
                                        &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
                                    .select(KpiConstants.memberidColName)
    //</editor-fold>

    //<editor-fold desc="IVD Calculation">


    //<editor-fold desc="Step1 Calculation">

    val step1PrevYearDf = denominatorInVisitDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal))
                                                      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.acuteInpatientVal)))
                                                    &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ivdVal))
                                                    &&((!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
                                                      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal))
                                                    &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
                                                      /*&&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telephoneVisitsVal))
                                                      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.onlineAssesmentVal))*/)
                                                    &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
                                                    &&($"${KpiConstants.serviceDateColName}".<=(prevYearEndDate)))
                                              .select(KpiConstants.memberidColName)


    val step1CurrYearDf = denominatorInVisitDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal))
                                                     ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.acuteInpatientVal)))
                                                      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ivdVal))
                                                   &&((!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
                                                    &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal))
                                                    &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
                                                    /*&&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telephoneVisitsVal))
                                                    &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.onlineAssesmentVal))*/)
                                                    &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate))
                                                  &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
                                              .select(KpiConstants.memberidColName)

    val ivd1Df = step1PrevYearDf.intersect(step1CurrYearDf)

    //</editor-fold>

    //<editor-fold desc="Step2 Calculation">

    val step2PrevYearDf =  denominatorInVisitDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal))
                                                     &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ivdVal))
                                                    &&((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
                                                      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal)))
                                                    &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
                                                    &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
                                                    &&($"${KpiConstants.serviceDateColName}".<=(prevYearEndDate)))
                                               .select(KpiConstants.memberidColName)

    val step2CurrYearDf =  denominatorInVisitDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal))
                                                     &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ivdVal))
                                                     &&((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
                                                      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal)))
                                                     &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
                                                     &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate))
                                                     &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
                                               .select(KpiConstants.memberidColName)
    //</editor-fold>

    //<editor-fold desc="Step3 Calculation">

    val step3PrevYearDf =  denominatorInVisitDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ivdVal))
                                                    &&((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telephoneVisitsVal))
                                                     ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.onlineAssesmentVal)))
                                                     &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
                                                    &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
                                                    &&($"${KpiConstants.serviceDateColName}".<=(prevYearEndDate)))
                                        .select(KpiConstants.memberidColName)


    val step3CurYearDf =  denominatorInVisitDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ivdVal))
                                                   &&((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telephoneVisitsVal))
                                                   ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.onlineAssesmentVal)))
                                                    &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
                                                   &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate))
                                                   &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
                                              .select(KpiConstants.memberidColName)
    //</editor-fold>


    val step2OrStep3PrevDf = step2PrevYearDf.union(step3PrevYearDf)

    val step2OrStep3CurrDf = step2CurrYearDf.union(step3CurYearDf)


    val ivd2Df = (step1PrevYearDf.except(step1CurrYearDf)).intersect(step2OrStep3CurrDf)

    val ivd3Df = (step1CurrYearDf.except(step1PrevYearDf)).intersect(step2OrStep3PrevDf)

    val ivdDf = ivd1Df.union(ivd2Df).union(ivd3Df)

    //</editor-fold>

    //<editor-fold desc="Thoracic aortic aneurysm Calculation">



    val thoraticPrevYearDf = denominatorInVisitDf.filter((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.thoraticAcriticVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
      ||((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.acuteInpatientVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.thoraticAcriticVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal))))

      &&(($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
      &&($"${KpiConstants.serviceDateColName}".<=(prevYearEndDate))))
      .select(KpiConstants.memberidColName)

    /*println("---------------------thoraticPrevYearDf-------------------------")
    thoraticPrevYearDf.show()*/

    val thoraticCurrYearDf = denominatorInVisitDf.filter((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.thoraticAcriticVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
      ||((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.acuteInpatientVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.thoraticAcriticVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal))))

      &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
      .select(KpiConstants.memberidColName)

   /* println("---------------------thoraticCurrYearDf-------------------------")
    thoraticCurrYearDf.show()*/

    val thoraticDf = thoraticPrevYearDf.intersect(thoraticCurrYearDf)


    //</editor-fold>


    //<editor-fold desc="History of Valuelist Calculation">

    val hisValListFilterDf = denominatorInVisitDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.chronicHeartFailureVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.miVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ckdStage4Val))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.dementiaVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.fronDementiaVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.blindnessVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.lowerExtrAmputationVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
      &&(($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.dobColName}"))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
      .select(KpiConstants.memberidColName)

   /* println("---------------------hisValListFilterDf-------------------------")
    hisValListFilterDf.show()*/


    val esrdWoTeleHealthDf = denominatorInVisitDf.filter((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.esrdVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.esrdObsoleteVal)))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
      &&(($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.dobColName}"))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
      .select(KpiConstants.memberidColName)

   /* println("---------------------esrdWoTeleHealthDf-------------------------")
    esrdWoTeleHealthDf.show()*/

    val hisValuesDf = hisValListFilterDf.union(esrdWoTeleHealthDf)

    //</editor-fold>

    val reqExclDf = ageDenoFilterDf.union(cabgDf).union(pciDf).union(ivdDf).union(thoraticDf).union(hisValuesDf)

   /* reqExclDf.select(KpiConstants.memberidColName).distinct().coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir + "/reqExclDf/")
*/


    //</editor-fold>

    //<editor-fold desc="Temporary Numerator Calculation">

    val numvalidVisitsDf = spark.read.parquet(intermediateDir+ "/eligibleVisitsDf/").repartition(2).cache()
    numvalidVisitsDf.count()
    val numEpopDf = numvalidVisitsDf.select(KpiConstants.memberidColName).distinct()



    val nonSupNumVisitsDf = numvalidVisitsDf.filter($"${KpiConstants.supplflagColName}".===("N")).cache()
    nonSupNumVisitsDf.count()


    val numeratorWindow = Window.partitionBy(KpiConstants.memberidColName).orderBy(org.apache.spark.sql.functions.col(KpiConstants.serviceDateColName).desc)

   // val numeratorNewWindow = Window.partitionBy(KpiConstants.memberidColName).orderBy(org.apache.spark.sql.functions.col(KpiConstants.serviceDateColName))

    val vhba1cVisistsDf =  numvalidVisitsDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.hba1cTestVal))
      ||((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.hba1cLtSevenVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.hba1cBwSevenAndNineVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.hba1cGtNineVal))))
      &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
      .withColumn(KpiConstants.rankColName, rank().over(numeratorWindow))
      .select(KpiConstants.memberidColName, KpiConstants.dataSourceColName, KpiConstants.labvalueColName,
              KpiConstants.valuesetColName, KpiConstants.rankColName, KpiConstants.serviceDateColName)



    val cdc1TmpNumDf = vhba1cVisistsDf.select(KpiConstants.memberidColName).distinct()

    cdc1TmpNumDf.select(KpiConstants.memberidColName).distinct().coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir + "/cdc1TmpNumDf/")


    //<editor-fold desc="Members who has no HbA1c value set">

    val cdc2Step1Df = numEpopDf.except(cdc1TmpNumDf)

    //</editor-fold>


    val vhba1cDs = vhba1cVisistsDf.as[CdcMember]


    def func2(rows:List[CdcMember]):(String,List[String])={



      val latestVisit = rows(0)
     // println("latestVisit:"+ latestVisit)

      val last7DaysVisists = rows.filter(cdc => ((Math.abs(cdc.service_date.getTime - latestVisit.service_date.getTime)) <= 604800000 ))
     // last7DaysVisists.foreach( f => println(f))

      for(cdc <- last7DaysVisists) {

        val res = cdc match {

          case x if (x.data_source.equals("Lab")) => {
            val str = x match {

              case y if (y.lab_value.isEmpty) => ""

              case y if ((y.lab_value.toFloat >= 8.0f) && (y.lab_value.toFloat <= 9.0f)) => KpiConstants.cdc1MeasureId

              case y if (y.lab_value.toFloat > 9.0f) => KpiConstants.cdc2MeasureId

              case y if (y.lab_value.toFloat < 7.0f) => KpiConstants.cdc3MeasureId + "," + KpiConstants.cdc10MeasureId

              case y if (y.lab_value.toFloat < 8.0f) => KpiConstants.cdc10MeasureId

              case _ => ""
            }
            if (!str.equals(""))
              return (cdc.member_id, str.split(",").toList)
          }

          case x if (x.data_source.equals("Claim")) => {

           /* println("claim data")
            println(x.valueset.mkString(","))*/
            /* val bool = if (((rows.indexOf(x) + 1 < rows.length) && (rows(rows.indexOf(x) + 1).data_source.equals("Lab"))  && (!rows(rows.indexOf(x) + 1).lab_value.isEmpty) && ((rows(rows.indexOf(x)).service_date.getTime - rows(rows.indexOf(x) + 1).service_date.getTime) < 604800000)) ||
               ((rows.indexOf(x) - 1 >= 0) && (rows(rows.indexOf(x) - 1).data_source.equals("Lab"))  && (!rows(rows.indexOf(x) - 1).lab_value.isEmpty) && ((rows(rows.indexOf(x) - 1).service_date.getTime - rows(rows.indexOf(x)).service_date.getTime) < 604800000))) false else true
 */

            val str = x match {

              /*case y if ((!y.valueset.contains(KpiConstants.hba1cGtNineVal)) && (!y.valueset.contains(KpiConstants.hba1cLtSevenVal))

                        && (!y.valueset.contains(KpiConstants.hba1cBwSevenAndNineVal))) => KpiConstants.cdc2MeasureId*/

              case y if ((y.valueset.contains(KpiConstants.hba1cGtNineVal)) && (!y.valueset.contains(KpiConstants.independentLabVal))) => KpiConstants.cdc2MeasureId

              case y if ((y.valueset.contains(KpiConstants.hba1cLtSevenVal)) && (!y.valueset.contains(KpiConstants.independentLabVal))) => KpiConstants.cdc3MeasureId + "," + KpiConstants.cdc10MeasureId

              case y if ((y.valueset.contains(KpiConstants.hba1cBwSevenAndNineVal)) && (!y.valueset.contains(KpiConstants.independentLabVal))) => KpiConstants.cdc1MeasureId

              case _ => ""

            }

            if (!str.equals(""))
              return (cdc.member_id, str.split(",").toList)

          }
        }
      }

      if(rows.count(cdc => (cdc.valueset.contains(KpiConstants.hba1cBwSevenAndNineVal))&& (!cdc.valueset.contains(KpiConstants.independentLabVal)))> 0) return (rows(0).member_id,List(KpiConstants.cdc1MeasureId))


      (rows(0).member_id,List(KpiConstants.cdc2MeasureId))
    }



    val groupedDs = vhba1cDs.groupByKey(inds => inds.member_id)
      .mapGroups((k,itr) => (k, itr.toList))

    val resFuncDf = groupedDs.map(f => func2(f._2)).toDF(KpiConstants.memberidColName,"Meas")

    val cdc2OtherDf = resFuncDf.filter(array_contains($"Meas",KpiConstants.cdc2MeasureId))
                               .select(KpiConstants.memberidColName)

    val cdc3OtherDf = resFuncDf.filter(array_contains($"Meas",KpiConstants.cdc3MeasureId))
                               .select(KpiConstants.memberidColName)

    val cdc10OtherDf = resFuncDf.filter(array_contains($"Meas",KpiConstants.cdc10MeasureId))
                                .select(KpiConstants.memberidColName)


    //<editor-fold desc="CDC4(Eye Exam)">

    //<editor-fold desc="CDC4 Non Supplement Numerator">

    //<editor-fold desc="CDC4_1">

    val cdc4NonSupStep1Df = nonSupNumVisitsDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabeticRetinalScreeningVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal))
      &&($"${KpiConstants.iseyecareproviderColName}".===("Y")))
      &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)
    //</editor-fold>

    //<editor-fold desc="CDC4_2">

    val cdc4NonSupStep2Df = nonSupNumVisitsDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabeticRetinalScreeningVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabeticRetinalScreeningnegVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal))
      &&($"${KpiConstants.iseyecareproviderColName}".===("Y")))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate) && $"${KpiConstants.serviceDateColName}".<=(prevYearEndDate)))
      .select(KpiConstants.memberidColName)
    //</editor-fold>

    //<editor-fold desc="CDC4_3">

    val cdc4NonSupStep3Df = nonSupNumVisitsDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabeticRetinalScreeningVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabtesMellWoCompliVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal))
      &&($"${KpiConstants.iseyecareproviderColName}".===("Y")))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate) && $"${KpiConstants.serviceDateColName}".<=(prevYearEndDate)))
      .select(KpiConstants.memberidColName)

    println("--------cdc4NonSupStep3Df-----------")
    cdc4NonSupStep3Df.show()
    //</editor-fold>

    //<editor-fold desc="CDC4_4">

    val cdc4NonSupStep4Df = nonSupNumVisitsDf.filter((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabeticReScreeWECProfessionalVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabeticRetinalScreeningnegVal)))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
      &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)

   /* println("---------------cdc4NonSupStep4Df------------------------")
    cdc4NonSupStep4Df.show()*/

    //</editor-fold>

    //<editor-fold desc="CDC4_5">

    val cdc4NonSupStep5Df = nonSupNumVisitsDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabeticReScreeWECProfessionalVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabeticRetinalScreeningnegVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate) && $"${KpiConstants.serviceDateColName}".<=(prevYearEndDate)))
      .select(KpiConstants.memberidColName)
    //</editor-fold>

    //<editor-fold desc="CDC4_6">

    val cdc4NonSupStep6Df = nonSupNumVisitsDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.unilateralEyeEnucleationVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.bilateralModifierVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
      &&($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.dobColName}") && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)
    //</editor-fold>

    //<editor-fold desc="CDC4_7">

    val cdc4NonSupStep7_1Df = nonSupNumVisitsDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.unilateralEyeEnucleationVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
      &&($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.dobColName}") && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)

    val cdc4NonSupStep7Df = cdc4NonSupStep7_1Df.as("df1").join(cdc4NonSupStep7_1Df.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .filter(abs(datediff($"df1.${KpiConstants.serviceDateColName}", $"df2.${KpiConstants.serviceDateColName}")).>=(14))
      .select(s"df1.${KpiConstants.memberidColName}")
    //</editor-fold>

    //<editor-fold desc="CDC4_8">

    val cdc4NonSupStep8_1Df = nonSupNumVisitsDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.unilateralEyeEnuLeftVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
      &&($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.dobColName}") && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)

    val cdc4NonSupStep8_2Df = nonSupNumVisitsDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.unilateralEyeEnuRightVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
      &&($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.dobColName}") && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)

    val cdc4NonSupStep8Df = cdc4NonSupStep8_1Df.intersect(cdc4NonSupStep8_2Df)
    //</editor-fold>

    //<editor-fold desc="CDC4_9">

    val cdc4NonSupStep9_1Df = nonSupNumVisitsDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.unilateralEyeEnucleationVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
      &&($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.dobColName}") && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)


    val cdc4NonSupStep9_2Df = nonSupNumVisitsDf.filter((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.unilateralEyeEnuLeftVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.unilateralEyeEnuRightVal)))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
      &&($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.dobColName}") && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)

    val cdc4NonSupStep9Df = cdc4NonSupStep9_1Df.as("df1").join(cdc4NonSupStep9_2Df.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .filter(abs(datediff($"df1.${KpiConstants.serviceDateColName}", $"df2.${KpiConstants.serviceDateColName}")).>=(14))
      .select(s"df1.${KpiConstants.memberidColName}")
    //</editor-fold>

    val cdc4NonSupDf = cdc4NonSupStep1Df.union(cdc4NonSupStep2Df).union(cdc4NonSupStep3Df).union(cdc4NonSupStep4Df).union(cdc4NonSupStep5Df)
      .union(cdc4NonSupStep6Df).union(cdc4NonSupStep7Df).union(cdc4NonSupStep8Df).union(cdc4NonSupStep9Df)
    //</editor-fold>

    //<editor-fold desc="CDC4 Other Numerator">

    val cdc4OtherVisistsDf = numvalidVisitsDf.except(numvalidVisitsDf.filter($"${KpiConstants.memberidColName}".isin(cdc4NonSupDf.rdd.map(r =>r.getString(0)).collect():_*)))

    //<editor-fold desc="CDC4_1">

    val cdc4OtherStep1Df = cdc4OtherVisistsDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabeticRetinalScreeningVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal))
      &&($"${KpiConstants.iseyecareproviderColName}".===("Y")))
      &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)
    //</editor-fold>

    //<editor-fold desc="CDC4_2">

    val cdc4OtherStep2Df = cdc4OtherVisistsDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabeticRetinalScreeningVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabeticRetinalScreeningnegVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal))
      &&($"${KpiConstants.iseyecareproviderColName}".===("Y")))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate) && $"${KpiConstants.serviceDateColName}".<=(prevYearEndDate)))
      .select(KpiConstants.memberidColName)
    //</editor-fold>

    //<editor-fold desc="CDC4_3">

    val cdc4OtherStep3Df = cdc4OtherVisistsDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabeticRetinalScreeningVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabtesMellWoCompliVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal))
      &&($"${KpiConstants.iseyecareproviderColName}".===("Y")))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate) && $"${KpiConstants.serviceDateColName}".<=(prevYearEndDate)))
      .select(KpiConstants.memberidColName)
    //</editor-fold>

    //<editor-fold desc="CDC4_4">

    val cdc4OtherStep4Df = cdc4OtherVisistsDf.filter((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabeticReScreeWECProfessionalVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabeticRetinalScreeningnegVal)))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
      &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)
   /* println("---------------cdc4OtherStep4Df------------------------")
    cdc4OtherStep4Df.show()*/

    //</editor-fold>

    //<editor-fold desc="CDC4_5">

    val cdc4OtherStep5Df = cdc4OtherVisistsDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabeticReScreeWECProfessionalVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabeticRetinalScreeningnegVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate) && $"${KpiConstants.serviceDateColName}".<=(prevYearEndDate)))
      .select(KpiConstants.memberidColName)
    //</editor-fold>

    //<editor-fold desc="CDC4_6">

    val cdc4OtherStep6Df = cdc4OtherVisistsDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.unilateralEyeEnucleationVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.bilateralModifierVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
      &&($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.dobColName}") && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)
    //</editor-fold>

    //<editor-fold desc="CDC4_7">

    val cdc4OtherStep7_1Df = cdc4OtherVisistsDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.unilateralEyeEnucleationVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
      &&($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.dobColName}") && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)

    val cdc4OtherStep7Df = cdc4NonSupStep7_1Df.as("df1").join(cdc4NonSupStep7_1Df.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .filter(abs(datediff($"df1.${KpiConstants.serviceDateColName}", $"df2.${KpiConstants.serviceDateColName}")).>=(14))
      .select(s"df1.${KpiConstants.memberidColName}")
    //</editor-fold>

    //<editor-fold desc="CDC4_8">

    val cdc4OtherStep8_1Df = cdc4OtherVisistsDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.unilateralEyeEnuLeftVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
      &&($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.dobColName}") && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)

    val cdc4OtherStep8_2Df = nonSupNumVisitsDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.unilateralEyeEnuRightVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
      &&($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.dobColName}") && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)

    val cdc4OtherStep8Df = cdc4NonSupStep8_1Df.intersect(cdc4NonSupStep8_2Df)
    //</editor-fold>

    //<editor-fold desc="CDC4_9">

    val cdc4OtherStep9_1Df = cdc4OtherVisistsDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.unilateralEyeEnucleationVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
      &&($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.dobColName}") && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)


    val cdc4OtherStep9_2Df = cdc4OtherVisistsDf.filter((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.unilateralEyeEnuLeftVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.unilateralEyeEnuRightVal)))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
      &&($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.dobColName}") && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)

    val cdc4OtherStep9Df = cdc4NonSupStep9_1Df.as("df1").join(cdc4NonSupStep9_2Df.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .filter(abs(datediff($"df1.${KpiConstants.serviceDateColName}", $"df2.${KpiConstants.serviceDateColName}")).>=(14))
      .select(s"df1.${KpiConstants.memberidColName}")
    //</editor-fold>

    val cdc4OtherDf = cdc4OtherStep1Df.union(cdc4OtherStep2Df).union(cdc4OtherStep3Df).union(cdc4OtherStep4Df).union(cdc4OtherStep5Df)
      .union(cdc4OtherStep6Df).union(cdc4OtherStep7Df).union(cdc4OtherStep8Df).union(cdc4OtherStep9Df)

    //</editor-fold>

    val cdc4TmpNumDf = cdc4NonSupDf.union(cdc4OtherDf)

  /*  println("-------------------cdc4TmpNumDf----------------------")
    cdc4TmpNumDf.show(100)*/

     cdc4TmpNumDf.select(KpiConstants.memberidColName).distinct().coalesce(1)
       .write
       .mode(SaveMode.Append)
       .option("header", "true")
       .csv(outDir + "/cdc4TmpNumDf/")

    //</editor-fold>

    //<editor-fold desc="CDC7(Medical Attention for Nephropathy)">

    val cdc7NonSupDf = nonSupNumVisitsDf.filter((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.urineProteinTestVal))
                                                      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.nephropathyTreatmentVal))
                                                      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ckdStage4Val))
                                                      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.kidneyTransplantVal))
                                                      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.aceInhArbMedVal)))
                                                   ||((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.esrdVal))
                                                    &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
                                                    &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal))
                                                    &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
                                                   ||($"${KpiConstants.isnephrologistColName}".===("Y")))
                                                   &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate)
                                                    && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
                                            .select(KpiConstants.memberidColName)


    val cdc7OtherDf = numvalidVisitsDf.except(numvalidVisitsDf.filter($"${KpiConstants.memberidColName}".isin(cdc7NonSupDf.rdd.map(r => r.getString(0)).collect():_*)))
                                      .filter((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.urineProteinTestVal))
                                              ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.nephropathyTreatmentVal))
                                              ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ckdStage4Val))
                                              ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.kidneyTransplantVal))
                                              ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.aceInhArbMedVal)))
                                            ||((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.esrdVal))
                                              &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
                                              &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal))
                                              &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
                                            ||($"${KpiConstants.isnephrologistColName}".===("Y")))
                                            &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate)
                                              && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
                                      .select(KpiConstants.memberidColName)

    val cdc7TmpDf = cdc7NonSupDf.union(cdc7OtherDf)

    cdc7TmpDf.select(KpiConstants.memberidColName).distinct().coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir + "/cdc7TmpDf/")

    //</editor-fold>

    //<editor-fold desc="CDC9(BP Control <140/90 mm Hg)">

    val cdc9NonSupStep1Df = nonSupNumVisitsDf.filter((((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.outPatientVal))
      ||(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.nonAcuteInPatientVal))
      ||(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.remotebpmVal)))
      &&(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.systolicLt140Val))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.systolicGtOrEq140Val))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)))
      &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)
      .groupBy(KpiConstants.memberidColName).agg(max(KpiConstants.serviceDateColName).alias(KpiConstants.serviceDateColName))

    val cdc9NonSupStep2Df = nonSupNumVisitsDf.filter((((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.outPatientVal))
      ||(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.nonAcuteInPatientVal))
      ||(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.remotebpmVal)))
      &&((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.diastolicLt80Val))
      ||(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.diastolicBtwn8090Val)))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.diastolicGt90Val))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)))
      &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)
      .groupBy(KpiConstants.memberidColName).agg(max(KpiConstants.serviceDateColName).alias(KpiConstants.serviceDateColName))

    val cdc9NonSupDf = cdc9NonSupStep1Df.intersect(cdc9NonSupStep2Df)
                                        .select(KpiConstants.memberidColName)


    val cdc9OtherVisistsDf = numvalidVisitsDf.except(numvalidVisitsDf.filter($"${KpiConstants.memberidColName}".isin(cdc9NonSupDf.rdd.map(r => r.getString(0)).collect():_*)))


    val cdc9OtherStep1Df = cdc9OtherVisistsDf.filter((((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.outPatientVal))
      ||(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.nonAcuteInPatientVal))
      ||(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.remotebpmVal)))
      &&(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.systolicLt140Val))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.systolicGtOrEq140Val))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)))
      &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)
      .groupBy(KpiConstants.memberidColName).agg(max(KpiConstants.serviceDateColName).alias(KpiConstants.serviceDateColName))


    val cdc9OtherStep2Df = cdc9OtherVisistsDf.filter((((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.outPatientVal))
      ||(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.nonAcuteInPatientVal))
      ||(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.remotebpmVal)))
      &&((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.diastolicLt80Val))
      ||(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.diastolicBtwn8090Val)))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.diastolicGt90Val))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)))
      &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)
      .groupBy(KpiConstants.memberidColName).agg(max(KpiConstants.serviceDateColName).alias(KpiConstants.serviceDateColName))

    val cdc9OtherDf = cdc9OtherStep1Df.intersect(cdc9OtherStep2Df)
      .select(KpiConstants.memberidColName)

    val cdc9TmpDf = cdc9NonSupDf.union(cdc9OtherDf)

    cdc9TmpDf.select(KpiConstants.memberidColName).distinct().coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir + "/cdc9TmpDf/")
    //</editor-fold>

    val cdc2TmpDf = cdc2Step1Df.union(cdc2OtherDf)
    //val cdc2TmpDf = cdc2Step1Df.union(cdc2NonSupDf).union(cdc2OtherDf)
    cdc2TmpDf.select(KpiConstants.memberidColName).distinct().coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir + "/cdc2TmpDf/")

    val cdc3TmpDf = cdc3OtherDf.except(reqExclDf)
    cdc3TmpDf.select(KpiConstants.memberidColName).distinct().coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir + "/cdc3TmpDf/")

    val cdc10TmpDf =  cdc10OtherDf
    cdc10TmpDf.select(KpiConstants.memberidColName).distinct().coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir + "/cdc10TmpDf/")

    //</editor-fold>

    //<editor-fold desc="Optional Exclusion Calculation">

    val numIntersectDf = cdc1TmpNumDf.intersect(cdc2TmpDf).intersect(cdc3TmpDf)
                                     .intersect(cdc4TmpNumDf).intersect(cdc7TmpDf)
                                     .intersect(cdc9TmpDf).intersect(cdc10TmpDf)
    val optInVisitsDf = numvalidVisitsDf.except(numvalidVisitsDf.filter($"${KpiConstants.memberidColName}".isin(numIntersectDf.rdd.map(r => r.getString(0)).collect():_*)))

    val optExclMemDf = optInVisitsDf.select(KpiConstants.memberidColName).distinct()

    val optExclNonSupStep1Df = optExclMemDf.except(optInVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.diabetesVal))
                                                                            &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
                                                                            &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
                                                                      .select(KpiConstants.memberidColName))


    val optExclNonSupStep2Df = optInVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.diabetesExclusionVal))
                                                       &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
                                                       &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
                                                 .select(KpiConstants.memberidColName)

    val optExclDf = optExclNonSupStep1Df.intersect(optExclNonSupStep2Df)

    optExclDf.select(KpiConstants.memberidColName).distinct().coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir + "/optExclDf/")
    //</editor-fold>

    //<editor-fold desc="Numerator Calculation">

    val cdc1NumDf = cdc1TmpNumDf.except(optExclDf)

    val cdc2NumDf = cdc2TmpDf.except(optExclDf)

    val cdc3NumDf = cdc3TmpDf.except(optExclDf)

    val cdc4NumDf = cdc4TmpNumDf.except(optExclDf)

    val cdc7NumDf = cdc7TmpDf.except(optExclDf)

    val cdc9NumDf = cdc9TmpDf.except(optExclDf)

    val cdc10NumDf = cdc10TmpDf.except(optExclDf)

    //</editor-fold>

    /*Ncqa Output creation */

    val totalPopOutDf = spark.read.parquet(intermediateDir+ "/startifiedTotalPopDf/").repartition(2)
    val denominatorPopDf = totalPopOutDf.select(KpiConstants.memberidColName).distinct()

    val outMap = mutable.Map(KpiConstants.totalPopDfName -> totalPopOutDf, KpiConstants.eligibleDfName -> denominatorPopDf,
      KpiConstants.mandatoryExclDfname -> reqExclDf, KpiConstants.optionalExclDfName -> optExclDf,
      KpiConstants.numeratorDfName ->  cdc1NumDf , KpiConstants.numerator2DfName -> cdc2NumDf,
      KpiConstants.numerator3DfName -> cdc3NumDf, KpiConstants.numerator4DfName -> cdc4NumDf,
      KpiConstants.numerator5DfName -> cdc7NumDf, KpiConstants.numerator6DfName -> cdc9NumDf,
      KpiConstants.numerator7DfName -> cdc10NumDf)


    val outDf = UtilFunctions.ncqaCDCOutputDfCreation(spark,outMap)
    outDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir+ "/outDf/")


    //<editor-fold desc="Deleting the intermediate Files">

    val fileSystem = FileSystem.get(spark.sparkContext.hadoopConfiguration)
    fileSystem.delete(new Path(intermediateDir), true)
    //</editor-fold>

    spark.sparkContext.stop()
  }
}
