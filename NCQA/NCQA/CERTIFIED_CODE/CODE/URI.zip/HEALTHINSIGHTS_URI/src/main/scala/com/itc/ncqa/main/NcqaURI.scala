package com.itc.ncqa.main

import com.itc.ncqa.Constants.KpiConstants
import com.itc.ncqa.Functions.{DataLoadFunctions, UtilFunctions}
import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkConf
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType

import scala.collection.mutable

object NcqaURI {
  def main(args: Array[String]): Unit = {

    val StringtoIntger =udf((value:String) => value.toInt)
    //<editor-fold desc="Reading program arguments and SaprkSession oBject creation">

    //    val year = args(0)
    //    val measureId = args(1)
    //    val dbName = args(2)

    val measureId = "URI"
    val year = "2018"
    /*calling function for setting the dbname for dbName variable*/
    // KpiConstants.setDbName(dbName)
    //    val conf = new SparkConf().setAppName("NcqaProgram")
    //    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    //      .set("hive.exec.dynamic.partition.mode", "nonstrict")
    //    .set("spark.sql.shuffle.partitions","5")

    val conf = new SparkConf().setAppName("NcqaProgram").setMaster("local[*]")
    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      .set("hive.exec.dynamic.partition.mode", "nonstrict")
      .set("spark.sql.shuffle.partitions","5")
    val spark = SparkSession.builder().config(conf).getOrCreate()

    // val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    import spark.implicits._
    val rootLogger=Logger.getRootLogger()
    rootLogger.setLevel(Level.ERROR)
    //</editor-fold>

    //<editor-fold desc="Loading Required Tables to memory">

    val ystDate = year+"-01-01"
    val yendDate = year+"-12-31"
    val aLiat = List("col1")
    val msrVal = s"'$measureId'"
    val ggMsrId = s"'${KpiConstants.ggMeasureId}'"
    val lobList = List(KpiConstants.commercialLobName, KpiConstants.medicaidLobName, KpiConstants.marketplaceLobName)
    val ((membershipDf,visitsDf,refHedisDf,ref_medvaluesetDf)) = DataLoadFunctions.readdatafromlocal(spark,measureId,year)
    val readallrefhedisDf=DataLoadFunctions.readallrefhedis(spark,measureId,year)
    val ageEndDate = year + "-12-31"
    val ageStartDate = year + "-01-01"
    val IntakeStartDate = year.toInt-1 + "-07-01"
    val IntakeEndDate = year + "-06-30"

    val ICDList = List("J00","J06.0","J06.9")
//    def is_icd: (String => Boolean) = {
//
//      val ICDList = List("J03.81", "J03.91", "J02.9", "J03.80", "J03.90", "J03.00", "J03.01")
//      InputCode =>   if ((InputCode) == "null" || InputCode.isEmpty ) true
//      else  ICDList.contains(InputCode)
//    }
//    import org.apache.spark.sql.functions.udf
//    val ICDUDF = udf(is_icd)


    println("InputVisistsDF")
    visitsDf.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    visitsDf.filter($"${KpiConstants.memberidColName}" === ("95381")).show()
    println("InputmembersDF")
    membershipDf.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    membershipDf.filter($"${KpiConstants.memberidColName}" === ("95381")).show()
    //temporary-1//
    println("membershipDf_visitsDf_refHedisDf_ref_medvaluesetDf")
    membershipDf.show(10)
    visitsDf.show(10)
    println("membershipDfInput")
    membershipDf.filter($"${KpiConstants.memberidColName}" === ("95282")).show()

    visitsDf.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    refHedisDf.show(10)
    ref_medvaluesetDf.show(10)
    /* read from local*/
    //</editor-fold


    //<editor-fold desc="Eligible Population Calculation">

    //<editor-fold desc=" filter">



    //   val visitsDfWithAgeFilter = visitsDf.withColumn("Lastdayinmyear",add_months($"${KpiConstants.dobColName}",216)).withColumn("age",when ((dayofmonth($"${KpiConstants.dobColName}")===30 && month($"${KpiConstants.dobColName}")===6),round(datediff(lit(IntakeEndDate), $"${KpiConstants.dobColName}")/365.25)).otherwise(datediff(lit(IntakeEndDate), $"${KpiConstants.dobColName}")/365.25)).filter($"age">=3 and $"age"<18 )
    //  val visitsDfWithAgeFilter = visitsDf.filter((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}",KpiConstants.months156).>=(IntakeStartDate)) && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}",KpiConstants.months156).<=(IntakeEndDate)))
    val visitsDfWithAgeFilter = visitsDf.filter((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}",KpiConstants.months03).<=(IntakeStartDate))
      &&(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}",KpiConstants.months228).>(IntakeEndDate))
    )
    println("ageFilterDf")
    visitsDfWithAgeFilter.show()

    println("visitsDfWithAgeFilter")
    visitsDfWithAgeFilter.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    visitsDfWithAgeFilter.filter($"${KpiConstants.memberidColName}" === ("95381")).show()

    val visitsDfWithNonsupplementDF=visitsDfWithAgeFilter.filter($"${KpiConstants.supplflagColName}".===("N"))

    println("visitsDfWithNonsupplementDF")
    visitsDfWithNonsupplementDF.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    visitsDfWithNonsupplementDF.filter($"${KpiConstants.memberidColName}" === ("95381")).show()

    val argmapforRefHedis = mutable.Map(KpiConstants.eligibleDfName -> visitsDfWithNonsupplementDF , KpiConstants.refHedisTblName -> refHedisDf,KpiConstants.refmedValueSetTblName -> ref_medvaluesetDf)

    val allValueList = List(KpiConstants.independentLabVal, KpiConstants.hospiceVal,KpiConstants.uriVal,KpiConstants.edVal,KpiConstants.observationVal,KpiConstants.inPatientStayVal,KpiConstants.outPatientVal,KpiConstants.pharyngitisVal,KpiConstants.competingDiagnosisVal)
    val medList =List(KpiConstants.cwpAntibioticMedicationListsVal)

    val visitRefHedisDf = UtilFunctions.joinWithRefHedisFunction(spark,argmapforRefHedis,allValueList,medList)
    println("visitRefHedisDf")
    visitRefHedisDf.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    visitRefHedisDf.filter($"${KpiConstants.memberidColName}" === ("95381")).show()
    //

    val visitsDfWithNonsupplementDFforphy =visitsDfWithNonsupplementDF.withColumn("secdiagcode",when((trim($"${KpiConstants.diagcode2ColName}").isNull || trim($"${KpiConstants.diagcode2ColName}")==="null"),true)
      .otherwise(trim($"${KpiConstants.diagcode2ColName}").isin(ICDList:_*)) &&
      when((trim($"${KpiConstants.diagcode3ColName}").isNull || trim($"${KpiConstants.diagcode3ColName}")==="null"),true)
        .otherwise(trim($"${KpiConstants.diagcode3ColName}").isin(ICDList:_*)) &&
      when((trim($"${KpiConstants.diagcode4ColName}").isNull || trim($"${KpiConstants.diagcode4ColName}")==="null"),true)
        .otherwise(trim($"${KpiConstants.diagcode4ColName}").isin(ICDList:_*))  &&
      when((trim($"${KpiConstants.diagcode5ColName}").isNull || trim($"${KpiConstants.diagcode5ColName}")==="null"),true)
        .otherwise(trim($"${KpiConstants.diagcode5ColName}").isin(ICDList:_*))   &&
      when((trim($"${KpiConstants.diagcode6ColName}").isNull || trim($"${KpiConstants.diagcode6ColName}")==="null"),true)
        .otherwise(trim($"${KpiConstants.diagcode6ColName}").isin(ICDList:_*))   &&
      when((trim($"${KpiConstants.diagcode7ColName}").isNull || trim($"${KpiConstants.diagcode7ColName}")==="null"),true)
        .otherwise(trim($"${KpiConstants.diagcode7ColName}").isin(ICDList:_*))   &&
      when((trim($"${KpiConstants.diagcode8ColName}").isNull || trim($"${KpiConstants.diagcode8ColName}")==="null"),true)
        .otherwise(trim($"${KpiConstants.diagcode9ColName}").isin(ICDList:_*))   &&
      when((trim($"${KpiConstants.diagcode8ColName}").isNull || trim($"${KpiConstants.diagcode9ColName}")==="null"),true)
        .otherwise(trim($"${KpiConstants.diagcode9ColName}").isin(ICDList:_*))   &&
      when((trim($"${KpiConstants.diagcode10ColName}").isNull || trim($"${KpiConstants.diagcode10ColName}")==="null"),true)
        .otherwise(trim($"${KpiConstants.diagcode10ColName}").isin(ICDList:_*)) )
      // .withColumn("SECPHY",UtilFunctions.ncqa_is_icd_code(spark,$"${KpiConstants.diagcode2ColName}"))
      .filter($"${KpiConstants.dataSourceColName}"===("Claim") )


    println("visitsDfWithNonsupplementDFforphy")
    visitsDfWithNonsupplementDFforphy.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    visitsDfWithNonsupplementDFforphy.filter($"${KpiConstants.memberidColName}" === ("95381")).show()

    val  visitRefHedisDftemp1= visitsDfWithNonsupplementDFforphy.as("df1").join(readallrefhedisDf.as("df2"), (trim($"df1.${KpiConstants.primaryDiagnosisColname}") === trim($"df2.${KpiConstants.codeColName}") )
      && $"df2.${KpiConstants.valuesetColName}"===KpiConstants.uriVal
      , KpiConstants.leftOuterJoinType)
      .join(readallrefhedisDf.as("df3"), (trim($"df1.${KpiConstants.poscodeColName}") === trim($"df3.${KpiConstants.codeColName}") )
        && $"df3.${KpiConstants.valuesetColName}"===KpiConstants.independentLabVal
        , KpiConstants.leftOuterJoinType)
      .join(readallrefhedisDf.as("df4"), (trim($"df1.${KpiConstants.billtypecodeColName}") === trim($"df4.${KpiConstants.codeColName}") )
        && $"df4.${KpiConstants.valuesetColName}"===KpiConstants.inPatientStayVal && $"df4.${KpiConstants.measureIdColName}"===KpiConstants.uriMeasureId
        , KpiConstants.leftOuterJoinType)
      .select($"df1.${KpiConstants.memberidColName}",$"df1.${KpiConstants.serviceDateColName}", $"df2.${KpiConstants.valuesetColName}".alias("primarydiagvalueset"),$"df3.${KpiConstants.valuesetColName}".alias("Independentvalueset"),$"df1.secdiagcode",$"df4.${KpiConstants.valuesetColName}".alias("InpatientStay")).distinct()


    visitRefHedisDftemp1.filter($"Independentvalueset".isNull).coalesce(1)
      .write
      .mode(SaveMode.Append)
      .parquet("/home/hbase/ncqa/URI/visitRefHedisDftemp1/")

    val visittmp1Df = spark.read.parquet("/home/hbase/ncqa/URI/visitRefHedisDftemp1/").cache()

    visittmp1Df.show()
    //  val visitwithphyDf = visittmp1Df.filter($"primarydiagvalueset"==={KpiConstants.uriVal}).select($"${KpiConstants.memberidColName}").distinct()
    val visitwithnonphyDf = visittmp1Df.filter($"primarydiagvalueset".isNull).select($"${KpiConstants.memberidColName}",$"${KpiConstants.serviceDateColName}").distinct()
    val visitwithphy_secnonphydf = visittmp1Df.filter($"primarydiagvalueset"==={KpiConstants.uriVal} && !($"secdiagcode") ).select($"${KpiConstants.memberidColName}",$"${KpiConstants.serviceDateColName}").distinct()
    val visitsecnonphydf_inpatient = visittmp1Df.filter($"InpatientStay".isNotNull && $"primarydiagvalueset".isNull ).select($"${KpiConstants.memberidColName}",$"${KpiConstants.serviceDateColName}").distinct()

    // val visitwithbothDf = visittmp2Df.filter($"diagvalueset"==={KpiConstants.uriVal}).select($"${KpiConstants.memberidColName}",$"${KpiConstants.serviceDateColName}").distinct()

    // val visitfinalphyDf =visitwithphyDf.intersect(visitwithnonphyDf)
    val visitfinalphyDf =visitwithnonphyDf.union(visitwithphy_secnonphydf).except(visitsecnonphydf_inpatient)
    //.except(visitwithbothDf)

    println("visitfinalphyDf")
    visitfinalphyDf.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    visitfinalphyDf.filter($"${KpiConstants.memberidColName}" === ("95381")).show()
    visitfinalphyDf.show(20)

    val  visitRefHedisDfwithpharyngi= visitRefHedisDf.as("df1").join(refHedisDf.as("df2"), $"df1.${KpiConstants.primaryDiagnosisColname}" === $"df2.${KpiConstants.codeColName}"
      && ($"df2.${KpiConstants.valuesetColName}".===(KpiConstants.uriVal))
      , KpiConstants.leftOuterJoinType)
      .join(refHedisDf.as("df3"), ($"df1.${KpiConstants.diagcode2ColName}" === $"df3.${KpiConstants.codeColName}"
        || $"df1.${KpiConstants.diagcode3ColName}" === $"df3.${KpiConstants.codeColName}"
        || $"df1.${KpiConstants.diagcode4ColName}" === $"df3.${KpiConstants.codeColName}"
        || $"df1.${KpiConstants.diagcode5ColName}" === $"df3.${KpiConstants.codeColName}"
        || $"df1.${KpiConstants.diagcode6ColName}" === $"df3.${KpiConstants.codeColName}"
        || $"df1.${KpiConstants.diagcode7ColName}" === $"df3.${KpiConstants.codeColName}"
        || $"df1.${KpiConstants.diagcode8ColName}" === $"df3.${KpiConstants.codeColName}"
        || $"df1.${KpiConstants.diagcode9ColName}" === $"df3.${KpiConstants.codeColName}"
        || $"df1.${KpiConstants.diagcode10ColName}" === $"df3.${KpiConstants.codeColName}" ) && ($"df3.${KpiConstants.valuesetColName}".===(KpiConstants.uriVal))
        , KpiConstants.leftOuterJoinType)
      .select($"df1.*", $"df2.${KpiConstants.valuesetColName}".alias("primarydiagvalueset"),$"df3.${KpiConstants.valuesetColName}".alias("diagvalueset")).distinct()


    visitRefHedisDfwithpharyngi.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    visitRefHedisDfwithpharyngi.filter($"${KpiConstants.memberidColName}" === ("95381")).show()

    //</editor-fold>
    //  visitRefHedisDfwithpharyngi.printSchema()
    val groupList = visitsDf.schema.fieldNames.toList.dropWhile(p=> p.equalsIgnoreCase(KpiConstants.memberidColName))

    val visitgroupedDf = visitRefHedisDfwithpharyngi.groupBy(KpiConstants.memberidColName, groupList:_*).agg(collect_list(KpiConstants.valuesetColName).alias(KpiConstants.valuesetColName),collect_list($"primarydiagvalueset").alias("primarydiagvalueset"),collect_list($"diagvalueset").alias("diagvalueset")).withColumn("rx_days_supplied_1", col("rx_days_supplied").cast("Int")).withColumn("rx_date",expr("date_add(service_date,rx_days_supplied_1)"))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName, KpiConstants.admitDateColName, KpiConstants.dischargeDateColName,
        KpiConstants.dobColName,KpiConstants.rxdayssuppliedColName,"rx_date",KpiConstants.supplflagColName,KpiConstants.dataSourceColName, KpiConstants.ispcpColName,KpiConstants.isobgynColName, KpiConstants.valuesetColName,"diagvalueset","primarydiagvalueset",KpiConstants.genderColName)
    println("visitgroupedDf")
    visitgroupedDf.printSchema()
    //visitgroupedDf.show()

    visitgroupedDf.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    visitgroupedDf.filter($"${KpiConstants.memberidColName}" === ("95381")).show()
    //    visitgroupedDf.coalesce(1)
    //      .write
    //      .mode(SaveMode.Append)
    //      .text("/home/hbase/ncqa/URI/visitgroupedDf/")
    //    //<editor-fold desc="Removal of Independent Lab Visits">


    val indLabVisRemDf = visitgroupedDf.filter(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)
      //      ||(
      //        (array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      //      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.groupAStrepTestsVal))
      //      )
    )
    println("indLabVisRemDf")
    indLabVisRemDf.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    indLabVisRemDf.filter($"${KpiConstants.memberidColName}" === ("95381")).show()

    val  visitsHospice= indLabVisRemDf.filter(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hospiceVal) &&($"${KpiConstants.serviceDateColName}".>=(ageStartDate) && $"${KpiConstants.serviceDateColName}".<=(ageEndDate))).select($"${KpiConstants.memberidColName}")

    val visitsHospiceremovalDF=indLabVisRemDf.except(visitgroupedDf.filter($"${KpiConstants.memberidColName}".isin(
      visitsHospice.rdd.map(r=>r.getString(0)).collect():_*)))

    visitsHospiceremovalDF.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .parquet("/home/hbase/ncqa/URI/visitsHospiceremoval/")


    val visitsHospiceremoval = spark.read.parquet("/home/hbase/ncqa/URI/visitsHospiceremoval/").cache()

    println("visitsHospiceremoval")
    visitsHospiceremoval.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    visitsHospiceremoval.filter($"${KpiConstants.memberidColName}" === ("95381")).show()


    // visitsHospiceremoval.show()
    val visits_step1 =visitsHospiceremoval.filter( (array_contains($"${KpiConstants.valuesetColName}",KpiConstants.outPatientVal) ||
      array_contains($"${KpiConstants.valuesetColName}",KpiConstants.edVal) || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.observationVal) ||
      array_contains($"${KpiConstants.valuesetColName}",KpiConstants.inPatientStayVal)
      and ($"${KpiConstants.serviceDateColName}".>=(IntakeStartDate) && $"${KpiConstants.serviceDateColName}".<=(IntakeEndDate))) || ( $"${KpiConstants.dataSourceColName}"=!=("Claim") ))

    val visits_step_ED_OBR =visitsHospiceremoval.filter(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.edVal) || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.observationVal) ).select(KpiConstants.memberidColName)

    println("visits_step1")
    visits_step1.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    visits_step1.filter($"${KpiConstants.memberidColName}" === ("95381")).show()

    //    println("visits_step2")
    //    visits_step2.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    //    visits_step2.filter($"${KpiConstants.memberidColName}" === ("95381")).show()

    println("visits_step_ED_OBR")
    visits_step_ED_OBR.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    visits_step_ED_OBR.filter($"${KpiConstants.memberidColName}" === ("95381")).show()

    val visits_step1_inpatient_temp =visits_step1.filter(( array_contains($"${KpiConstants.valuesetColName}",KpiConstants.inPatientStayVal)
      && ( $"${KpiConstants.dataSourceColName}"===("Claim") ))).select(KpiConstants.memberidColName,KpiConstants.serviceDateColName,KpiConstants.admitDateColName,KpiConstants.dischargeDateColName)

    println("visits_step1")
    visits_step1.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    visits_step1.filter($"${KpiConstants.memberidColName}" === ("95381")).show()

    val visits_step1_inpatient_with_ED_OBR=visits_step1_inpatient_temp.as("claimsVisitis").join(visits_step_ED_OBR.as("InPatient"),$"claimsVisitis.${KpiConstants.memberidColName}" === $"InPatient.${KpiConstants.memberidColName}"
      , KpiConstants.innerJoinType).select("claimsVisitis.*")

    println("visits_step1_inpatient_with_ED_OBR")
    visits_step1_inpatient_with_ED_OBR.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    visits_step1_inpatient_with_ED_OBR.filter($"${KpiConstants.memberidColName}" === ("95381")).show()

    println("visits_step1_inpatient_temp")
    visits_step1_inpatient_temp.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    visits_step1_inpatient_temp.filter($"${KpiConstants.memberidColName}" === ("95381")).show()

    //     val visits_step1_inpatient_1 =visits_step1.as("claimsVisitis").join(visits_step1_inpatient_with_ED_OBR.as("InPatient"),$"claimsVisitis.${KpiConstants.memberidColName}" === $"InPatient.${KpiConstants.memberidColName}"
    //      && ( $"claimsVisitis.${KpiConstants.serviceDateColName}" between (date_add($"InPatient.${KpiConstants.admitDateColName}" ,-1) , $"InPatient.${KpiConstants.dischargeDateColName}") ) && ( $"claimsVisitis.${KpiConstants.dataSourceColName}"===("Claim"))
    //      , KpiConstants.innerJoinType).select($"claimsVisitis.*").distinct()

    val visits_step1_inpatient_1 =visits_step1.as("claimsVisitis").join(visits_step1_inpatient_with_ED_OBR.as("InPatient"),($"claimsVisitis.${KpiConstants.memberidColName}" === $"InPatient.${KpiConstants.memberidColName}"
      &&  ($"claimsVisitis.${KpiConstants.admitDateColName}"===($"InPatient.${KpiConstants.admitDateColName}")
      ||  ($"claimsVisitis.${KpiConstants.serviceDateColName}" between (date_add($"InPatient.${KpiConstants.admitDateColName}" ,-1) , $"InPatient.${KpiConstants.dischargeDateColName}")))
      && ( $"claimsVisitis.${KpiConstants.dataSourceColName}"===("Claim")) )
      , KpiConstants.innerJoinType).select($"claimsVisitis.*").distinct()

    println("visits_step1_inpatient_1")
    visits_step1_inpatient_1.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    visits_step1_inpatient_1.filter($"${KpiConstants.memberidColName}" === ("95381")).show()

    val visits_step1_inpatient =visits_step1.except(visits_step1_inpatient_1)
    //    val visits_step1_inpatient =visits_step1.filter(!((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.edVal) || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.observationVal))
    //      and array_contains($"${KpiConstants.valuesetColName}",KpiConstants.inPatientStayVal)
    //      and ($"${KpiConstants.serviceDateColName}" between (date_add($"${KpiConstants.admitDateColName}" ,-1) , $"${KpiConstants.dischargeDateColName}"))) || ( $"${KpiConstants.dataSourceColName}"=!=("Claim") ))

    println("visits_step1_inpatient")
    visits_step1_inpatient.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    visits_step1_inpatient.filter($"${KpiConstants.memberidColName}" === ("95381")).show()

    val  claimsVisitis =visits_step1_inpatient.filter(( $"${KpiConstants.dataSourceColName}"===("Claim")  ))

    val vistitwithnonphyonsamedayvisits= claimsVisitis.except(
      claimsVisitis.as("df1").join(visitfinalphyDf.as("df2"), ( $"df1.${KpiConstants.memberidColName}"===$"df2.${KpiConstants.memberidColName}"
        && $"df1.${KpiConstants.serviceDateColName}"===$"df2.${KpiConstants.serviceDateColName}"),KpiConstants.innerJoinType).select($"df1.*"))


    val otherVisists=visits_step1_inpatient.filter(( $"${KpiConstants.dataSourceColName}"===("RxClaim") ))

    val URIAntibioticVisits= otherVisists.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.cwpAntibioticMedicationListsVal)))

    val CompetingDiagnosisVisits= visitsHospiceremoval.filter(
      (array_contains($"${KpiConstants.valuesetColName}",KpiConstants.pharyngitisVal)
        || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.competingDiagnosisVal)))

    println("CompetingDiagnosisVisits")
    CompetingDiagnosisVisits.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    CompetingDiagnosisVisits.filter($"${KpiConstants.memberidColName}" === ("95381")).show()

    println("URIAntibioticVisits")
    URIAntibioticVisits.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    URIAntibioticVisits.filter($"${KpiConstants.memberidColName}" === ("95381")).show()

    println("vistitwithnonphyonsamedayvisits")
    vistitwithnonphyonsamedayvisits.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    vistitwithnonphyonsamedayvisits.filter($"${KpiConstants.memberidColName}" === ("95381")).show()


    val URIAntibioticVisitswithin_step3=vistitwithnonphyonsamedayvisits.as("claimsVisitis").
      join(URIAntibioticVisits.as("URIAntibioticVisits"),$"claimsVisitis.${KpiConstants.memberidColName}" === $"URIAntibioticVisits.${KpiConstants.memberidColName}"
      && (
     ( $"URIAntibioticVisits.${KpiConstants.serviceDateColName}" <= date_add($"claimsVisitis.${KpiConstants.serviceDateColName}" ,-30)
      && ( $"URIAntibioticVisits.rx_date"  >= $"claimsVisitis.${KpiConstants.serviceDateColName}"  ) )
      ||
      (datediff($"claimsVisitis.${KpiConstants.serviceDateColName}" ,$"URIAntibioticVisits.${KpiConstants.serviceDateColName}") > lit(30)
        && ( $"URIAntibioticVisits.rx_date"  >= $"claimsVisitis.${KpiConstants.serviceDateColName}"  ))
      )
      , KpiConstants.innerJoinType).select($"claimsVisitis.member_id",$"claimsVisitis.service_date",$"claimsVisitis.valueset").distinct()

   val  visitswithoutexclusion =vistitwithnonphyonsamedayvisits.as("claimsVisitis").select($"claimsVisitis.member_id",$"claimsVisitis.service_date",$"claimsVisitis.valueset").distinct()
    println("URIAntibioticVisitswithin_step3")
    URIAntibioticVisitswithin_step3.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    URIAntibioticVisitswithin_step3.filter($"${KpiConstants.memberidColName}" === ("95381")).show()

    val URIAntibioticVisitswithinlast30days=vistitwithnonphyonsamedayvisits.as("claimsVisitis").join(URIAntibioticVisits.as("URIAntibioticVisits"),$"claimsVisitis.${KpiConstants.memberidColName}" === $"URIAntibioticVisits.${KpiConstants.memberidColName}"
      && ( $"URIAntibioticVisits.${KpiConstants.serviceDateColName}" between  (date_add($"claimsVisitis.${KpiConstants.serviceDateColName}" ,-30), date_add($"claimsVisitis.${KpiConstants.serviceDateColName}" ,-1)) )
      , KpiConstants.innerJoinType).select($"claimsVisitis.member_id",$"claimsVisitis.service_date",$"claimsVisitis.valueset").distinct()


    println("URIAntibioticVisitswithinlast30days")
    URIAntibioticVisitswithinlast30days.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    URIAntibioticVisitswithinlast30days.filter($"${KpiConstants.memberidColName}" === ("95381")).show()

    //val
    // URIAntibioticVisitswithin_step3


    val URIAntibioticVisitswithnotin3days=vistitwithnonphyonsamedayvisits.as("claimsVisitis").join(CompetingDiagnosisVisits.as("URIAntibioticVisits"),$"claimsVisitis.${KpiConstants.memberidColName}" === $"URIAntibioticVisits.${KpiConstants.memberidColName}"
      &&  ( $"URIAntibioticVisits.${KpiConstants.serviceDateColName}" between  (date_add($"claimsVisitis.${KpiConstants.serviceDateColName}" ,0), date_add($"claimsVisitis.${KpiConstants.serviceDateColName}" ,3)) )
      , KpiConstants.innerJoinType).select($"claimsVisitis.member_id",$"claimsVisitis.service_date",$"claimsVisitis.valueset").distinct()

    println("URIAntibioticVisitswithnotin3days")
    URIAntibioticVisitswithnotin3days.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    URIAntibioticVisitswithnotin3days.filter($"${KpiConstants.memberidColName}" === ("95381")).show()


    //    val URIAntibioticVisitswithinbeyond3days=claimsVisitis.as("claimsVisitis").join(URIAntibioticVisits.as("URIAntibioticVisits"),$"claimsVisitis.${KpiConstants.memberidColName}" === $"URIAntibioticVisits.${KpiConstants.memberidColName}"
    //      && ( $"URIAntibioticVisits.${KpiConstants.serviceDateColName}" .> (date_add($"claimsVisitis.${KpiConstants.serviceDateColName}" ,3)))
    //      , KpiConstants.innerJoinType).select($"claimsVisitis.member_id",$"claimsVisitis.service_date",$"claimsVisitis.valueset").distinct()

    //    println("URIAntibioticVisitswithinbeyond3days")
    //    URIAntibioticVisitswithinbeyond3days.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    //    URIAntibioticVisitswithinbeyond3days.filter($"${KpiConstants.memberidColName}" === ("95381")).show()


    val ExcludeStep3= visitswithoutexclusion.except(URIAntibioticVisitswithnotin3days.union(URIAntibioticVisitswithin_step3).union(URIAntibioticVisitswithinlast30days)
    )
    println("ExcludeStep3")
    ExcludeStep3.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    ExcludeStep3.filter($"${KpiConstants.memberidColName}" === ("95381")).show()


    val URIAntibioticfinalVisits= ExcludeStep3
    println("URIAntibioticfinalVisits")
    URIAntibioticfinalVisits.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    URIAntibioticfinalVisits.filter($"${KpiConstants.memberidColName}" === ("95381")).show()



    val indexwindow=Window.partitionBy(s"${KpiConstants.memberidColName}").orderBy(org.apache.spark.sql.functions.col(s"${KpiConstants.serviceDateColName}").desc)

    val URIVistitsInput =URIAntibioticfinalVisits.filter( (array_contains($"${KpiConstants.valuesetColName}",KpiConstants.outPatientVal) ||
      array_contains($"${KpiConstants.valuesetColName}",KpiConstants.edVal) || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.observationVal) ))
      .withColumn("indexStartdate",min($"${KpiConstants.serviceDateColName}").over(indexwindow)).
      select(KpiConstants.memberidColName,KpiConstants.serviceDateColName,KpiConstants.valuesetColName,"indexStartdate")



    println("URIVistitsInput")
    URIVistitsInput.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    URIVistitsInput.filter($"${KpiConstants.memberidColName}" === ("95381")).show()

    URIVistitsInput.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .parquet("/home/hbase/ncqa/URI/URIVistitsInput/")



    val URIVistitsInputDf = spark.read.parquet("/home/hbase/ncqa/URI/URIVistitsInput/").cache()



    URIVistitsInputDf.show()
    //    step1df.show()
    //    step1df.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    //    spark.sparkContext.stop()

    //  val ageFilterDf = membershipDf.withColumn("Lastdayinmyear",add_months($"${KpiConstants.dateofbirthColName}",216)).withColumn("age",when ((dayofmonth($"${KpiConstants.dateofbirthColName}")===30 && month($"${KpiConstants.dateofbirthColName}")===6),round(datediff(lit(IntakeEndDate), $"${KpiConstants.dateofbirthColName}")/365.25)).otherwise(datediff(lit(IntakeEndDate), $"${KpiConstants.dateofbirthColName}")/365.25)).filter($"age">=3 and $"age"<18 )
    println("ageFilterDf")

    val ageFilterDf = membershipDf.filter((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",KpiConstants.months03).<=(IntakeStartDate))
      &&(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",KpiConstants.months228).>(IntakeEndDate)))

    //   ageFilterDf.filter($"${KpiConstants.memberidColName}" === ("95273")).show()

    val vistitsandmemberdf=URIVistitsInputDf.as("claimsVisitis").join(ageFilterDf.as("membershipDf"),$"claimsVisitis.${KpiConstants.memberidColName}" === $"membershipDf.${KpiConstants.memberidColName}"
      and ($"claimsVisitis.indexStartdate".>=(IntakeStartDate) && $"claimsVisitis.indexStartdate".<=(IntakeEndDate))
      , KpiConstants.innerJoinType).select($"membershipDf.*",$"claimsVisitis.service_date",$"claimsVisitis.indexStartdate")
    //</editor-fold>

    println("vistitsandmemberdf")
    vistitsandmemberdf.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    vistitsandmemberdf.filter($"${KpiConstants.memberidColName}" === ("95381")).show()
    //<editor-fold desc="Continuous Enrollment, Allowable Gap Calculation">

    val inputForContEnrolldf = vistitsandmemberdf.select(KpiConstants.memberidColName, KpiConstants.benefitMedicalColname,
      KpiConstants.memStartDateColName,KpiConstants.memEndDateColName,
      KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName, KpiConstants.dateofbirthColName,KpiConstants.primaryPlanFlagColName,"service_date","indexStartdate")

    val benNonMedRemDf = inputForContEnrolldf.filter($"${KpiConstants.benefitMedicalColname}".===(KpiConstants.yesVal) and $"${KpiConstants.benefitdrugColName}".===(KpiConstants.yesVal))
    // val argMapForContEnrollFunction = mutable.Map(KpiConstants.ageStartKeyName -> "12", )
    val contEnrollInDf = benNonMedRemDf.withColumn(KpiConstants.contenrollLowCoName,date_add($"${KpiConstants.serviceDateColName}",-30))
      .withColumn(KpiConstants.contenrollUppCoName,date_add($"${KpiConstants.serviceDateColName}",3))
      .withColumn(KpiConstants.anchorDateColName, date_add($"${KpiConstants.serviceDateColName}",3))


    /* println("contEnrollInDf")
     contEnrollInDf.filter($"${KpiConstants.memberidColName}" === ("117463")).show()*/

    val contEnrollStep1Df = contEnrollInDf.filter((($"${KpiConstants.memStartDateColName}".>=($"${KpiConstants.contenrollLowCoName}")) && ($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.contenrollUppCoName}")))
      || (($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.contenrollLowCoName}")) && ($"${KpiConstants.memEndDateColName}".<=($"${KpiConstants.contenrollUppCoName}")))
      ||($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.contenrollLowCoName}") && ($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.contenrollUppCoName}"))))
      .withColumn(KpiConstants.anchorflagColName, when( ($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.anchorDateColName}"))
        && ($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.anchorDateColName}")), lit(1)).otherwise(lit(0)))
      .withColumn(KpiConstants.contEdFlagColName, when( ($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.contenrollUppCoName}"))
        && ($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.contenrollUppCoName}")), lit(1)).otherwise(lit(0)))

    println("contEnrollStep1Df")
    contEnrollStep1Df.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    contEnrollStep1Df.filter($"${KpiConstants.memberidColName}" === ("95381")).show()

    /*Step3(select the members who satisfy both (min_start_date- ces and cee- max_end_date <= allowable gap) conditions)*/
    val listDf = contEnrollStep1Df.groupBy($"${KpiConstants.memberidColName}")
      .agg(max($"${KpiConstants.memEndDateColName}").alias(KpiConstants.maxMemEndDateColName),
        min($"${KpiConstants.memStartDateColName}").alias(KpiConstants.minMemStDateColName),
        first($"${KpiConstants.contenrollLowCoName}").alias(KpiConstants.contenrollLowCoName),
        first($"${KpiConstants.contenrollUppCoName}").alias(KpiConstants.contenrollUppCoName),
        sum($"${KpiConstants.anchorflagColName}").alias(KpiConstants.anchorflagColName))
      .filter((date_add($"max_mem_end_date",KpiConstants.days45).>=($"${KpiConstants.contenrollUppCoName}"))
        && (date_sub($"min_mem_start_date",KpiConstants.days45).<=($"${KpiConstants.contenrollLowCoName}"))
        &&($"${KpiConstants.anchorflagColName}").>(0))
      .select($"${KpiConstants.memberidColName}")

    val contEnrollStep2Df = contEnrollStep1Df.as("df1").join(listDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select("df1.*")

    println("contEnrollStep2Df")
    contEnrollStep2Df.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    contEnrollStep2Df.filter($"${KpiConstants.memberidColName}" === ("95381")).show()
    /* printf("contEnrollStep2Df")
     contEnrollStep2Df.show()*/

    /*window function creation based on partioned by member_sk and order by mem_start_date*/
    val contWindowVal = Window.partitionBy(s"${KpiConstants.memberidColName}",s"${KpiConstants.serviceDateColName}").orderBy(org.apache.spark.sql.functions.col(s"${KpiConstants.memEndDateColName}").desc,org.apache.spark.sql.functions.col(s"${KpiConstants.memStartDateColName}"))


    /* added 3 columns (date_diff(datediff b/w next start_date and current end_date for each memeber),
     anchorflag(if member is continuously enrolled on anchor date 1, otherwise 0)
     count(if date_diff>1 1, otherwise 0) over window*/
    val contEnrollStep3Df = contEnrollStep2Df.withColumn(KpiConstants.overlapFlagColName, when(($"${KpiConstants.memStartDateColName}".>=(lag($"${KpiConstants.memStartDateColName}",1).over(contWindowVal)) && $"${KpiConstants.memStartDateColName}".<=(lag($"${KpiConstants.memEndDateColName}",1).over(contWindowVal))
      && ($"${KpiConstants.memEndDateColName}".>=(lag($"${KpiConstants.memStartDateColName}",1).over(contWindowVal)) && $"${KpiConstants.memEndDateColName}".<=(lag($"${KpiConstants.memEndDateColName}",1).over(contWindowVal))))
      ,lit(1))
      .when(($"${KpiConstants.memStartDateColName}".<(lag($"${KpiConstants.memStartDateColName}",1).over(contWindowVal)))
        && ($"${KpiConstants.memEndDateColName}".>=(lag($"${KpiConstants.memStartDateColName}",1 ).over(contWindowVal)) && $"${KpiConstants.memEndDateColName}".<=(lag($"${KpiConstants.memEndDateColName}",1).over(contWindowVal)))
        ,lit(2)).otherwise(lit(0)))

      .withColumn(KpiConstants.coverageDaysColName,when($"${KpiConstants.overlapFlagColName}".===(0) ,datediff(when($"${KpiConstants.memEndDateColName}".<=($"${KpiConstants.contenrollUppCoName}"), $"${KpiConstants.memEndDateColName}").otherwise($"${KpiConstants.contenrollUppCoName}")
        ,when($"${KpiConstants.memStartDateColName}".>=($"${KpiConstants.contenrollLowCoName}"), $"${KpiConstants.memStartDateColName}").otherwise($"${KpiConstants.contenrollLowCoName}"))+ 1 )
        .when($"${KpiConstants.overlapFlagColName}".===(2), datediff( when($"${KpiConstants.contenrollLowCoName}".>=(lag( $"${KpiConstants.memStartDateColName}",1).over(contWindowVal)), $"${KpiConstants.contenrollLowCoName}").otherwise(lag( $"${KpiConstants.memStartDateColName}",1).over(contWindowVal))
          ,$"${KpiConstants.memStartDateColName}")+1 )
        .otherwise(0))

      .withColumn(KpiConstants.countColName, when(when($"${KpiConstants.overlapFlagColName}".===(0), datediff(lag($"${KpiConstants.memStartDateColName}",1).over(contWindowVal), $"${KpiConstants.memEndDateColName}"))
        .otherwise(0).>(1),lit(1))
        .otherwise(lit(0)) )


    println("contEnrollStep3Df")
    contEnrollStep3Df.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    contEnrollStep3Df.filter($"${KpiConstants.memberidColName}" === ("95381")).show()


    val contEnrollStep5Df = contEnrollStep3Df.groupBy(KpiConstants.memberidColName,KpiConstants.serviceDateColName)
      .agg(min($"${KpiConstants.memStartDateColName}").alias(KpiConstants.minMemStDateColName),
        max($"${KpiConstants.memEndDateColName}").alias(KpiConstants.maxMemEndDateColName),
        sum($"${KpiConstants.countColName}").alias(KpiConstants.countColName),
        sum($"${KpiConstants.coverageDaysColName}").alias(KpiConstants.coverageDaysColName),
        first($"${KpiConstants.contenrollLowCoName}").alias(KpiConstants.contenrollLowCoName),
        first($"${KpiConstants.contenrollUppCoName}").alias(KpiConstants.contenrollUppCoName))
      .withColumn(KpiConstants.reqCovDaysColName, (datediff($"${KpiConstants.contenrollUppCoName}", $"${KpiConstants.contenrollLowCoName}")))


    println("contEnrollStep5Df")
    contEnrollStep5Df.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    contEnrollStep5Df.filter($"${KpiConstants.memberidColName}" === ("95381")).show()

    val contEnrollmemDf = contEnrollStep5Df.filter(((($"${KpiConstants.countColName}") + (when(date_sub($"min_mem_start_date", 1).>=($"${KpiConstants.contenrollLowCoName}"),lit(1)).otherwise(lit(0)))
      + (when(date_add($"max_mem_end_date", 1).<=($"${KpiConstants.contenrollUppCoName}"),lit(1)).otherwise(lit(0)))).<=(0) )
      && ($"${KpiConstants.coverageDaysColName}".>=($"${KpiConstants.reqCovDaysColName}")))
      .select(KpiConstants.memberidColName,KpiConstants.serviceDateColName).distinct()

    println("contEnrollmemDf")
    contEnrollmemDf.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    contEnrollmemDf.filter($"${KpiConstants.memberidColName}" === ("95381")).show()


    /* printf("contEnrollmemDf")
     contEnrollmemDf.show()*/

    val contEnrollDf = contEnrollStep1Df.as("df1").join(contEnrollmemDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .filter($"df1.${KpiConstants.contEdFlagColName}".===(1))
      .select(s"df1.${KpiConstants.memberidColName}", s"df1.${KpiConstants.lobColName}", s"df1.${KpiConstants.lobProductColName}",s"df1.${KpiConstants.payerColName}",s"df1.${KpiConstants.primaryPlanFlagColName}").cache()
    /* printf("contEnrollDf")
     contEnrollDf.show()*/
    //</editor-fold>
    //<editor-fold desc="Dual Enrollment and URI Lob filter">

    val URIVistitsInput_1 =contEnrollmemDf.groupBy($"${KpiConstants.memberidColName}").agg(min($"${KpiConstants.serviceDateColName}").alias("indexStartdate"))
      .select(KpiConstants.memberidColName,"indexStartdate")

    println("URIVistitsInput_1")
    URIVistitsInput_1.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    URIVistitsInput_1.filter($"${KpiConstants.memberidColName}" === ("95381")).show()

    val baseOutDf = UtilFunctions.baseOutDataframeCreation(spark, contEnrollDf, lobList)
    baseOutDf.show()

    val URIContEnrollDf = baseOutDf.filter($"${KpiConstants.lobColName}".isin(lobList:_*)).dropDuplicates().cache()
    URIContEnrollDf.count()

    println("URIContEnrollDf")
    URIContEnrollDf.show()
    val toutStrDf =URIContEnrollDf.select($"${KpiConstants.memberidColName}",$"${KpiConstants.memberidColName}".as(KpiConstants.ncqaOutmemberIdCol),$"${KpiConstants.payerColName}".as(KpiConstants.ncqaOutPayerCol))
      .withColumn(KpiConstants.ncqaOutMeasureCol,lit(measureId))

    val eligiblePopDf=URIContEnrollDf.select(KpiConstants.memberidColName)
    URIContEnrollDf.select(KpiConstants.memberidColName).distinct().coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("/home/hbase/ncqa/URI/EPOP/")

    val  eligiblePop =spark.read.option("header", "true").csv("/home/hbase/ncqa/URI/EPOP/")
    // val URIVistitsInputDf = spark.read.parquet("/home/hbase/ncqa/URI/URIVistitsInput/").cache()

    val URINumerator = visitsDfWithNonsupplementDF.as("df1")
      .join(eligiblePop.as("df2"), ($"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}" && $"df1.${KpiConstants.claimstatusColName}".=!=("2")
         ), KpiConstants.innerJoinType )
      .join(ref_medvaluesetDf.as("df3"),
        ($"df1.${KpiConstants.ndcCodeColName}" === $"df3.${KpiConstants.ndcCodeColName}"
          && $"df3.${KpiConstants.medicatiolListColName}"===KpiConstants.cwpAntibioticMedicationListsVal ) , KpiConstants.innerJoinType)
    .join(URIVistitsInput_1.as("df4"),($"df1.${KpiConstants.memberidColName}" === $"df4.${KpiConstants.memberidColName}" &&
        $"df2.${KpiConstants.memberidColName}" === $"df4.${KpiConstants.memberidColName}" &&
        ( $"df1.${KpiConstants.serviceDateColName}"  between ( $"df4.indexStartdate",date_add($"df4.indexStartdate",3) ))
        ) ,KpiConstants.innerJoinType )
      .select($"df1.${KpiConstants.memberidColName}")


    println("URINumerator")
    URINumerator.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    URINumerator.filter($"${KpiConstants.memberidColName}" === ("95381")).show()
    println("URIVistitsInput_1")
    URIVistitsInput_1.filter($"${KpiConstants.memberidColName}" === ("95282")).show()
    URIVistitsInput_1.filter($"${KpiConstants.memberidColName}" === ("95381")).show()

    URINumerator.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("/home/hbase/ncqa/URI/Numerator/")

    val outMap = mutable.Map(KpiConstants.totalPopDfName -> toutStrDf, KpiConstants.eligibleDfName -> eligiblePopDf,
      KpiConstants.mandatoryExclDfname -> spark.emptyDataFrame, KpiConstants.optionalExclDfName -> spark.emptyDataFrame,
      KpiConstants.numeratorDfName -> URINumerator )

    val outDf = UtilFunctions.ncqaOutputDfCreation(spark,outMap,measureId)
    outDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("/home/hbase/ncqa/URI/outDf/")
  }

}
