/*
package main.scala.com.itc.ncqa.Functions

import com.itc.ncqa.Constants.KpiConstants
import com.itc.ncqa.Functions.SparkObject.spark
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.{add_months, date_sub, lit, when}

import scala.collection.JavaConversions.mutableSeqAsJavaList
import scala.collection.mutable
import scala.collection.mutable.Seq

class trial {

  def ncqaOutputDfCreation(spark: SparkSession, dfMap:mutable.Map[String, DataFrame],measureId: String): DataFrame = {

    import spark.implicits._

    val totalPopDf = dfMap.get(KpiConstants.totalPopDfName).getOrElse(spark.emptyDataFrame)
    val eligiblePopDf = dfMap.get(KpiConstants.eligibleDfName).getOrElse(spark.emptyDataFrame)
    val mandatoryExclDf = dfMap.get(KpiConstants.mandatoryExclDfname).getOrElse(spark.emptyDataFrame)
    val optionalExclDf = dfMap.get(KpiConstants.optionalExclDfName).getOrElse(spark.emptyDataFrame)
    val numeratorPopDf = dfMap.get(KpiConstants.numeratorDfName).getOrElse(spark.emptyDataFrame)
    val productPlanDf = dfMap.get(KpiConstants.productPlanTblName).getOrElse(spark.emptyDataFrame)
    val monthlyMemDf = dfMap.get(KpiConstants.factMonMembershipTblName).getOrElse(spark.emptyDataFrame)
    val generalMemDf = dfMap.get(KpiConstants.generalmembershipTblName).getOrElse(spark.emptyDataFrame)


    val eligiblePopList = if(eligiblePopDf.count() > 0) eligiblePopDf.as[String].collectAsList() else mutableSeqAsJavaList(Seq(""))
    val mandatoryExclList = if(mandatoryExclDf.count() > 0) mandatoryExclDf.as[String].collectAsList() else mutableSeqAsJavaList(Seq(""))
    val optionalExclList = if(optionalExclDf.count() > 0) optionalExclDf.as[String].collectAsList() else mutableSeqAsJavaList(Seq(""))
    val numeratorPopList = if(numeratorPopDf.count() > 0) numeratorPopDf.as[String].collectAsList() else mutableSeqAsJavaList(Seq(""))


    val epopColAddedDf = if (eligiblePopList.isEmpty) totalPopDf.withColumn(KpiConstants.ncqaOutEpopCol, lit(KpiConstants.zeroVal))
    else
      totalPopDf.withColumn(KpiConstants.ncqaOutEpopCol, when(totalPopDf.col(KpiConstants.memberidColName).isin(eligiblePopList: _*), lit(KpiConstants.oneVal)).otherwise(lit(KpiConstants.zeroVal)))



    val exclColAddedDf = if (optionalExclList.isEmpty) epopColAddedDf.withColumn(KpiConstants.ncqaOutExclCol, lit(KpiConstants.zeroVal))
    else
      epopColAddedDf.withColumn(KpiConstants.ncqaOutExclCol, when(epopColAddedDf.col(KpiConstants.memberidColName).isin(optionalExclList: _*), lit(KpiConstants.oneVal)).otherwise(lit(KpiConstants.zeroVal)))


    val rexclColAddedDf = if (mandatoryExclList.isEmpty) exclColAddedDf.withColumn(KpiConstants.ncqaOutRexclCol, lit(KpiConstants.zeroVal))
    else
      exclColAddedDf.withColumn(KpiConstants.ncqaOutRexclCol, when(exclColAddedDf.col(KpiConstants.memberidColName).isin(mandatoryExclList: _*), lit(KpiConstants.oneVal)).otherwise(lit(KpiConstants.zeroVal)))


    val numColAddedDf = if (numeratorPopList.isEmpty) rexclColAddedDf.withColumn(KpiConstants.ncqaOutNumCol, lit(KpiConstants.zeroVal))
    else
      rexclColAddedDf.withColumn(KpiConstants.ncqaOutNumCol, when(exclColAddedDf.col(KpiConstants.memberidColName).isin(numeratorPopList: _*), lit(KpiConstants.oneVal)).otherwise(lit(KpiConstants.zeroVal)))


    val measAddedDf = numColAddedDf.withColumnRenamed(KpiConstants.memberidColName, KpiConstants.ncqaOutmemberIdCol)
      .withColumn(KpiConstants.ncqaOutMeasureCol,lit(measureId))
      .withColumn(KpiConstants.ncqaOutIndCol, lit(KpiConstants.zeroVal))

    val prodplanAddedDf = measAddedDf.as("df1").join(productPlanDf.as("df2"), $"df1.${KpiConstants.lobProductColName}" === $"df2.${KpiConstants.lobProductColName}", KpiConstants.innerJoinType)
      .select("df1.*", s"df2.${KpiConstants.codeColName}")
      .withColumnRenamed(KpiConstants.codeColName, KpiConstants.ncqaOutPayerCol)

    val my_upperDate = year + "-12-31"
    val my_lowerDate = year + "-01-01"

    val conEnrEndDate = null
    val enr_upperdate = my_upperDate
    val enr_lowerdate = date_sub(my_upperDate,61)
    val file_rundate_lower = date_sub(my_upperDate,31)
    val file_rundate_upper = my_upperDate


    //Check whether lob = "Medicare".
    /*val joinMonthlymemAndEgligiblePopDf = eligiblePopDf.as("df1").join(monthlyMemDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
                          .filter(($"df1.${KpiConstants.lobColName}" === $"${KpiConstants.medicareLobName}") &&
                            ( ($"df2.${KpiConstants.rundateName}" > $"my_lowerDate") && ($"df2.${KpiConstants.rundateName}" < $"my_upperDate")))*/

    val joinMonthlymemAndEgligiblePopDf = eligiblePopDf.as("df1").join(monthlyMemDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .filter(($"df1.${KpiConstants.lobColName}" === $"${KpiConstants.medicareLobName}"))

    val generalMemStateDf = generalMemDf.select($"${KpiConstants.memberidColName}",$"${KpiConstants.stateColName}")

    val joinWithGenMemDf = joinMonthlymemAndEgligiblePopDf.as("df1").
      join(generalMemStateDf.as("df2"),$"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)

    //<editor-fold desc="Chunk 1 -> 2 months">

    val GenMemInEnrDf = joinWithGenMemDf.filter(($"${KpiConstants.memStartDateColName}" > $"enr_lowerDate") && ($"df2.${KpiConstants.memStartDateColName}" < $"enr_upperDate"))
      .filter(($"${KpiConstants.rundateName}" > $"file_rundate_lower") && ($"df2.${KpiConstants.rundateName}" < $"enr_upperDate"))


    val measAndGenMemInEnrDf = GenMemInEnrDf.withColumn(KpiConstants.measColName,
       when(($"${KpiConstants.orecCode}" === 0),"BCSNON")
      .when(($"${KpiConstants.orecCode}" === $"${KpiConstants.measurement2Val}"),"BCSOT")
      .when((($"${KpiConstants.orecCode}" === 1) || ($"${KpiConstants.orecCode}" === 3)),"BCSDIS")
         .when((($"${KpiConstants.orecCode}" === "") || ($"${KpiConstants.orecCode}" === "Peurto Rico")),"BCSUN")
    )

    //</editor-fold>

/*--------*/

    val GenMemInEnrDf1 = joinWithGenMemDf.except(GenMemInEnrDf)

    //<editor-fold desc="Chunk 2 -> 3 months">

    val month3start = date_sub($"conEnrEndDate" ,92 )
    val month2start = date_sub($"conEnrEndDate" ,61 )
    val month1start = date_sub($"conEnrEndDate" ,31 )

    val month3end = date_sub($"conEnrEndDate" ,62 )
    val month2end = date_sub($"conEnrEndDate" ,32 )
    val month1end = date_sub($"conEnrEndDate" ,1 )

    val lisVal1 = joinMonthlymemAndEgligiblePopDf.filter(($"${KpiConstants.rundateName}" > $"month1start") && ($"${KpiConstants.rundateName}" < $"month1end"))
    val lisVal2 = joinMonthlymemAndEgligiblePopDf.filter(($"${KpiConstants.rundateName}" > $"month2start") && ($"${KpiConstants.rundateName}" < $"month2end"))
    val lisVal3 = joinMonthlymemAndEgligiblePopDf.filter(($"${KpiConstants.rundateName}" > $"month3start") && ($"${KpiConstants.rundateName}" < $"month3end"))

    val lisList1 = lisVal1.select(KpiConstants.lisPremiumSubColName).rdd.map(r => r(0))
    val lisList2 = lisVal2.select(KpiConstants.lisPremiumSubColName).rdd.map(r => r(0))
    val lisList3 = lisVal3.select(KpiConstants.lisPremiumSubColName).rdd.map(r => r(0))

    val orec_code_dec = joinMonthlymemAndEgligiblePopDf.filter(($"${KpiConstants.rundateName}" > $"month3start") && ($"${KpiConstants.rundateName}" < $"month3end"))
      .select($"${KpiConstants.orecCode}")


    if((lisList1 == lisList2) && (lisList2 == lisList3))
    {
      $"${KpiConstants.lisPremiumSubColName}" = lisList1
      $"${KpiConstants.orecCode}"=  orec_code_dec
    }

    else  if(((lisVal1 != lisVal2) && (lisVal1 == lisVal3)) || ((lisVal1 != lisVal3) && (lisVal2 == lisVal3)) ||
                                ((lisVal2 != lisVal3) && (lisVal1 == lisVal2)))
    {
      $"${KpiConstants.lisPremiumSubColName}" = lisList2
      $"${KpiConstants.orecCode}" =  orec_code_dec
    }

    else if((lisVal1 != lisVal2) && (lisVal1 != lisVal3) && (lisVal2 != lisVal3))
    {
      $"${KpiConstants.lisPremiumSubColName}" = lisList3
      $"${KpiConstants.orecCode}" =  orec_code_dec
    }


    //orec code = orec code for december

    val measAndjoinDf = joinMonthlymemAndEgligiblePopDf.withColumn(KpiConstants.measColName,when(($"${KpiConstants.lisPremiumSubColName}" <= 0) && ($"${KpiConstants.orecCode}" = 0),"BCSNON")
      .when(($"${KpiConstants.lisPremiumSubColName}" > 0) && ($"${KpiConstants.orecCode}" == 0),"BCSLIDE")
      .when(($"${KpiConstants.lisPremiumSubColName}" <= 0) && ($"${KpiConstants.orecCode}" == 0),"BCSDIS")
      .when(($"${KpiConstants.lisPremiumSubColName}" < 0) && (($"${KpiConstants.orecCode}" == 1) || ($"${KpiConstants.orecCode}" == 3)),"BCSCMB")
      .when(($"${KpiConstants.lisPremiumSubColName}".isNull) && ($"${KpiConstants.orecCode}".isNull),"BCSUN")
    )


    //</editor-fold>

    val resultDf = prodplanAddedDf.select(KpiConstants.outncqaFormattedList.head, KpiConstants.outncqaFormattedList.tail: _*)
    resultDf

  }


}*/
