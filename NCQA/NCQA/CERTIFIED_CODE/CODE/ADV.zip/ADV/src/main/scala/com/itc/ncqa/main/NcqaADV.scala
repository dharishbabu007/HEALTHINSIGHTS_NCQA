package main.scala.com.itc.ncqa.main

import main.scala.com.itc.ncqa.Constants.KpiConstants
import main.scala.com.itc.ncqa.Functions.UtilFunctions
import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkConf
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.sql.functions._

import scala.collection.mutable

object NcqaADV {

  def main(args: Array[String]): Unit =
  {

    //<editor-fold desc="Reading program arguments and Spark Session object creation">

    val year = "2018"
    val measureId = "ADV"
    val baseMsrPath = "/home/hbase/ncqa/adv"

    System.setProperty("hadoop.home.dir", "D:\\WinUtil")

    val conf = new SparkConf().setAppName("NcqaProgram")
    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    conf.set("spark.sql.shuffle.partitions", "5")
    //.set("hive.exec.dynamic.partition.mode", "nonstrict")

    val spark = SparkSession.builder().config(conf).master("local").getOrCreate()

    val rootLogger = Logger.getRootLogger()
    rootLogger.setLevel(Level.ERROR)

    val yearStartDate = year+"-01-01"
    val yearStartDate1 = year.toInt -1 +"-01-01"
    val yearEndDate = year+"-12-31"

    val jobId = spark.sparkContext.applicationId
    val baseDir = baseMsrPath + "/" + jobId
    val outDir = baseDir + "/Out"
    val intermediateDir = baseDir + "/Intermediate"
    val stagingDir =  baseDir + "/Staging"

    //</editor-fold>

    //<editor-fold desc="Loading Required Tables to memory">

    import spark.implicits._

    val ystDate = year+"-01-01"
    val yendDate = year+"-12-31"

    val lobList = List(KpiConstants.medicaidLobName,KpiConstants.marketplaceLobName)

     val membershipDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\ADV\\Test\\MEMBERSHIP_ENROLLMENT.csv")
   // val membershipDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\ADV\\MEMBERSHIP_ENROLLMENT.csv")
      .filter(($"${KpiConstants.considerationsColName}".===(KpiConstants.yesVal))
        && ($"${KpiConstants.memStartDateColName}".isNotNull)
        && ($"${KpiConstants.memEndDateColName}".isNotNull))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .withColumn(KpiConstants.memStartDateColName, to_date($"${KpiConstants.memStartDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.memEndDateColName, to_date($"${KpiConstants.memEndDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.dateofbirthColName, to_date($"${KpiConstants.dateofbirthColName}", KpiConstants.dateFormatString))
      .repartition(2).cache()

    println("--------------------------Membership DF------------------------")
    membershipDf.filter($"${KpiConstants.memberidColName}".===("96090")).show()

    membershipDf.coalesce(2)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(stagingDir+ "/membershipDf/")

    val claimStatusList = List(KpiConstants.paidVal, KpiConstants.suspendedVal, KpiConstants.pendingVal, KpiConstants.deniedVal)

    val visitsDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\ADV\\Test\\VISITS.csv")
     //val visitsDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\ADV\\VISITS.csv")
      .filter(($"${KpiConstants.serviceDateColName}".isNotNull)
        && (($"${KpiConstants.admitDateColName}".isNotNull && $"${KpiConstants.dischargeDateColName}".isNotNull)
        || ($"${KpiConstants.admitDateColName}".isNull && $"${KpiConstants.dischargeDateColName}".isNull))
        &&((($"${KpiConstants.dataSourceColName}".===("Claim"))&&($"${KpiConstants.claimstatusColName}".isin(claimStatusList:_*)))
        || (($"${KpiConstants.dataSourceColName}".===("RxClaim"))&&($"${KpiConstants.claimstatusColName}".isin(claimStatusList:_*)))
        || ($"${KpiConstants.dataSourceColName}".===("Rx"))
        || ($"${KpiConstants.dataSourceColName}".===("Lab"))))
      .drop(KpiConstants.lobProductColName, "latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name","product")
      .withColumn(KpiConstants.dobColName, to_date($"${KpiConstants.dobColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.serviceDateColName, to_date($"${KpiConstants.serviceDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.admitDateColName, when($"${KpiConstants.admitDateColName}".isNotNull,to_date($"${KpiConstants.admitDateColName}",  KpiConstants.dateFormatString)))
      .withColumn(KpiConstants.dischargeDateColName, when($"${KpiConstants.dischargeDateColName}".isNotNull,to_date($"${KpiConstants.dischargeDateColName}",  KpiConstants.dateFormatString)))
      .withColumn(KpiConstants.medstartdateColName, when($"${KpiConstants.medstartdateColName}".isNotNull,to_date($"${KpiConstants.medstartdateColName}",  KpiConstants.dateFormatString)))
      .withColumn(KpiConstants.revenuecodeColName, when((length($"${KpiConstants.revenuecodeColName}").as[Int].===(3)),concat(lit("0" ),lit($"${KpiConstants.revenuecodeColName}"))).otherwise($"${KpiConstants.revenuecodeColName}"))
      .withColumn(KpiConstants.billtypecodeColName, when((length($"${KpiConstants.billtypecodeColName}").as[Int].===(3)),concat(lit("0" ),lit($"${KpiConstants.billtypecodeColName}"))).otherwise($"${KpiConstants.billtypecodeColName}"))
      .withColumn(KpiConstants.proccode2ColName, when(($"${KpiConstants.proccode2mod1ColName}".isin(KpiConstants.avoidCodeList:_*)) || ($"${KpiConstants.proccode2mod2ColName}".isin(KpiConstants.avoidCodeList:_*)),lit("NA")).otherwise($"${KpiConstants.proccode2ColName}"))
      .repartition(2).cache()

    println("--------------------------visitsDf------------------------")
    visitsDf.filter($"${KpiConstants.memberidColName}".===("96090")).show()

    visitsDf.coalesce(2)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(stagingDir+ "/visitsDf/")


    val refHedisDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\ADV\\Test\\REF_HEDIS2019.csv")
       //val refHedisDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\ADV\\REF_HEDIS2019.csv")
      .filter(
       // ($"${KpiConstants.measureIdColName}".===(KpiConstants.advMeasureId)) ||
         ($"${KpiConstants.measureIdColName}".===(KpiConstants.ggMeasureId)))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .repartition(2).cache()

    refHedisDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(stagingDir+ "/refHedisDf/")

    println("---------------------------Ref Hedis--------------------------------")
    refHedisDf.show()

    val ref_medvaluesetDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\ADV\\Test\\REF_MED_VALUE_SET.csv")
     //val ref_medvaluesetDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\ADV\\REF_MED_VALUE_SET.csv")
      .filter(($"${KpiConstants.measure_idColName}".===(KpiConstants.advMeasureId)) )
      .drop("latest_flag", "active_flag", "ingestion_date", "source_name" ,"user_name")
      .repartition(2).cache()

    ref_medvaluesetDf.coalesce(2)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(stagingDir+ "/ref_medvaluesetDf/")

    println("---------------------------ref_medvaluesetDf--------------------------------")
    ref_medvaluesetDf.show()


    //</editor-fold>

    //<editor-fold desc="Eligible Population Calculation">

    //<editor-fold desc="Age Filter">

    val ageEndDate = year + "-12-31"
    val ageStartDate = year + "-01-01"

    val ageClDate = year+ "-12-31"

    /* The Member should be younger than 20 years on 31st December Measurement Year.*/

    val ageFilterDf = membershipDf.withColumn("age",datediff(lit(ageEndDate),$"${KpiConstants.dateofbirthColName}")/365.25)
      .filter((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",24).<=(ageClDate))
        && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",252).>(ageClDate)))
      .select(KpiConstants.memberidColName, KpiConstants.benefitMedicalColname, KpiConstants.memStartDateColName,KpiConstants.memEndDateColName,
      KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName, KpiConstants.dateofbirthColName,KpiConstants.primaryPlanFlagColName,"age")
      .cache()

    println("-------------------After ageFilterDf-------------")
    ageFilterDf.filter($"${KpiConstants.memberidColName}".===("96090")).show()

    //</editor-fold>

    //<editor-fold desc="Continuous Enrollment, Allowable Gap Calculation">

    val inputForContEnrolldf = ageFilterDf.select(KpiConstants.memberidColName, KpiConstants.benefitMedicalColname,
      KpiConstants.memStartDateColName,KpiConstants.memEndDateColName,
      KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName, KpiConstants.dateofbirthColName,KpiConstants.primaryPlanFlagColName)

    val mapForCeCurrYear = mutable.Map("start_date" -> "2018-01-01", "end_date" -> "2018-12-31","gapcount" -> "1",
      "checkval" -> "true","reqCovDays" -> "0","anchor_date" -> "2018-12-31")

    val contEnrollDf = UtilFunctions.contEnrollAndAllowableGapFilterFunction(spark,inputForContEnrolldf,mapForCeCurrYear)
      .select(KpiConstants.memberidColName, KpiConstants.dateofbirthColName, KpiConstants.memStartDateColName, KpiConstants.memEndDateColName,
        KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.primaryPlanFlagColName, KpiConstants.payerColName)

    contEnrollDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/contEnrollDf/")

    println("----------------------After contEnrollDf-----------------------")
    contEnrollDf.filter($"${KpiConstants.memberidColName}".===("96090")).show()

    //</editor-fold>

    //<editor-fold desc="Dual Enrollment and ADV Lob filter">

    val conEnrDf = spark.read.parquet(intermediateDir+ "/contEnrollDf/").cache()

    val baseOutDf = UtilFunctions.baseOutDataframeCreation(spark, conEnrDf, lobList , measureId)

    /*

    /*Removing the SN payer members from the EPOP  */

    val snPayerList = List(KpiConstants.sn1PayerVal, KpiConstants.sn2PayerVal, KpiConstants.sn3PayerVal, KpiConstants.mmpPayerVal)
    val baseOutDf = baseOutMedHosRemDf.except(baseOutMedHosRemDf.filter($"${KpiConstants.payerColName}".isin(snPayerList:_*)))

    */

    println("-------------------After baseOutDf-------------")
    baseOutDf.filter($"${KpiConstants.memberidColName}".===("96090")).show()

    val advContEnrollDf = baseOutDf.filter($"${KpiConstants.lobColName}".isin(lobList:_*)).dropDuplicates().cache()
    advContEnrollDf.count()

    advContEnrollDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/advContEnrollDf/")

    println("-------------------After Dual Enrollment-------------")
    advContEnrollDf.filter($"${KpiConstants.memberidColName}".===("96090")).show()

    //</editor-fold>

    //<editor-fold desc="Initial Join with Ref_Hedis">

    val visDf = spark.read.parquet(stagingDir+ "/visitsDf/").cache()

    val refHedDf = spark.read.parquet(stagingDir+ "/refHedisDf/").cache()

    val argmapforRefHedis = mutable.Map(KpiConstants.eligibleDfName -> visDf , KpiConstants.refHedisTblName -> refHedDf)
    val allValueList = List(KpiConstants.independentLabVal, KpiConstants.hospiceVal)

    val medList = KpiConstants.emptyList
    val visitRefHedisDf = UtilFunctions.joinWithRefHedisFunction(spark,argmapforRefHedis,allValueList,medList)
      .withColumn("age",datediff(lit(ageEndDate),$"${KpiConstants.dobColName}")/365.25)

    println("-------------------After visitRefHedisDf-------------")
    visitRefHedisDf/*.filter($"${KpiConstants.memberidColName}".===("96090"))*/.show()

    visitRefHedisDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/visitRefHedisDf/")

    //</editor-fold>

    //<editor-fold desc="Removal of Independent Lab Visits">

    val visRefHedDf = spark.read.parquet(intermediateDir+ "/visitRefHedisDf/").cache()

    val groupList = visDf.schema.fieldNames.toList.dropWhile(p=> p.equalsIgnoreCase(KpiConstants.memberidColName))

    val visitgroupedDf = visRefHedDf.groupBy(KpiConstants.memberidColName, groupList:_*).agg(collect_list(KpiConstants.valuesetColName).alias(KpiConstants.valuesetColName))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName, KpiConstants.admitDateColName, KpiConstants.dischargeDateColName,
        KpiConstants.dobColName,KpiConstants.supplflagColName, KpiConstants.ispcpColName,KpiConstants.isdentistColName, KpiConstants.valuesetColName,KpiConstants.genderColName)


    val indLabVisRemDf = visitgroupedDf.filter(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)).repartition(2).cache()
    indLabVisRemDf.count()

    println("-------------------After indLabVisRemDf-------------")
    indLabVisRemDf.show()
    //indLabVisRemDf.filter($"${KpiConstants.isdentistColName}".===("Y")).show()

    //</editor-fold>

    //<editor-fold desc="Hospice Removal">

    val conEnrResDf = spark.read.parquet(intermediateDir+ "/advContEnrollDf/").cache()

    val hospiceInCurrYearMemDf = indLabVisRemDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hospiceVal))
      &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate)
      && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)
      .dropDuplicates()
      .rdd
      .map(r=> r.getString(0))
      .collect()

    val df =  indLabVisRemDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hospiceVal))
      &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
    //.select(KpiConstants.memberidColName)

    println("-------------------df-------------")
    df/*.filter($"${KpiConstants.memberidColName}".===("96090"))*/.show()

    val hospiceRemMemEnrollDf = conEnrResDf.except(conEnrResDf.filter($"${KpiConstants.memberidColName}".isin(hospiceInCurrYearMemDf:_*)))

    println("-------------------hospiceRemMemEnrollDf-------------")
    hospiceRemMemEnrollDf.filter($"${KpiConstants.memberidColName}".===("96090")).show()

    hospiceRemMemEnrollDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/hospiceRemMemEnrollDf/")

    val totalPopOutDf = hospiceRemMemEnrollDf.distinct()

    println("-------------------After totalPopOutDf-------------")
    totalPopOutDf/*.filter($"${KpiConstants.memberidColName}".===("96090"))*/.show()

    totalPopOutDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .csv(outDir+ "/totalPopOutDf/")

    //</editor-fold>

    //<editor-fold desc="EPOP Generation">

    val eligiblePopDf = totalPopOutDf.select(KpiConstants.memberidColName).distinct().repartition(2).cache()
    eligiblePopDf.count()

    println("-------------------Selective Epop-------------------")
    eligiblePopDf.filter($"${KpiConstants.memberidColName}".===("96090")).show()

    eligiblePopDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir + "/epop-csv")

    //</editor-fold>

    //<editor-fold desc="ADV Stratification">

    val toutStrDf= totalPopOutDf.withColumn("Classfication",
      when(((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",24).<=(ageClDate))
        && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",48).>(ageClDate))),lit("CH1")).
        when(((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",48).<=(ageClDate))
          && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",84).>(ageClDate))),lit("CH2")).
        when(((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",84).<=(ageClDate))
          && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",132).>(ageClDate))),lit("CH3")).
        when(((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",132).<=(ageClDate))
          && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",180).>(ageClDate))),lit("CH4")).
        when(((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",180).<=(ageClDate))
          && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",228).>(ageClDate))),lit("CH5")).
        when(((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",228).<=(ageClDate))
          && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",252).>(ageClDate))),lit("CH6"))
    )


    println("-----------------------toutStratDf-------------------------------")
    toutStrDf.filter($"${KpiConstants.memberidColName}".===("96090")).show()

    val statification = Seq(("CH1", (KpiConstants.adv1MeasureId)),("CH2", (KpiConstants.adv2MeasureId)),("CH3", (KpiConstants.adv3MeasureId)),
      ("CH4", (KpiConstants.adv4MeasureId)),("CH5", (KpiConstants.adv5MeasureId)),("CH6", (KpiConstants.adv6MeasureId))).toDF("Classfication","Measure")

    println("-----------------------statification-------------------------------")
    statification.show()

    val visitJoinedOutDf=toutStrDf.as("df1").join(statification.as("df2"), $"df1.Classfication"===$"df2.Classfication", KpiConstants.innerJoinType)
      .select("df1.*","df2.Measure").cache()

    println("-----------------------visitJoinedOutDf-------------------------------")
    visitJoinedOutDf.filter($"${KpiConstants.memberidColName}".===("96090")).show()

    val toutStratOutDf = visitJoinedOutDf.select($"${KpiConstants.memberidColName}".as(KpiConstants.ncqaOutmemberIdCol),
      $"${KpiConstants.payerColName}".as(KpiConstants.ncqaOutPayerCol), $"Measure".alias(KpiConstants.ncqaOutMeasureCol)).distinct()

    toutStratOutDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir + "/toutStratOutDf")

    //</editor-fold>

    //</editor-fold>

    //<editor-fold desc="Numerator Part">

    //<editor-fold desc="Initial join function">

    val argmapForVisittJoin = mutable.Map(KpiConstants.membershipTblName -> totalPopOutDf , KpiConstants.visitTblName -> visitsDf)

    val visitJoinedDf = UtilFunctions.initialJoinFunction(spark,argmapForVisittJoin)
      .withColumn("age",datediff(lit(ageEndDate),$"${KpiConstants.dobColName}")/365.25)

    println("------------------------visitJoinedDf----------------------------")
    visitJoinedDf.filter($"${KpiConstants.memberidColName}".===("96090")).show()

    advContEnrollDf.unpersist()
    visitgroupedDf.unpersist()
    eligiblePopDf.unpersist()

    //</editor-fold>

    //<editor-fold desc="ADV Numerator Calculation">

    //<editor-fold desc="ADV Non Supp Numerator Calculation">

    val visitNonSuppDf = visitJoinedDf.filter($"${KpiConstants.supplflagColName}".===("N")).cache()
    visitNonSuppDf.count()

    println("--------------------visitNonSuppDf---------------------")
    visitNonSuppDf.filter($"${KpiConstants.memberidColName}".===("96090")).show()

    //<editor-fold desc="For 2 to 4 Years">

    val adv2to4NonSuppDf = visitNonSuppDf.filter((//(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.dentalVal))  &&
      (($"${KpiConstants.isdentistColName}".===("Y"))))
      && ((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",24).<=(ageClDate))
      && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",48).>(ageClDate)))
      && (($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))


    println("--------------------adv2to4NonSuppDf---------------------")
    adv2to4NonSuppDf.filter($"${KpiConstants.memberidColName}".===("96090")).show()

    //</editor-fold>

    //<editor-fold desc="For 4 to 7 Years">

    val adv4to7NonSuppDf = visitNonSuppDf.filter((//(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.dentalVal))  &&
      (($"${KpiConstants.isdentistColName}".===("Y"))))
      && ((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",48).<=(ageClDate))
      && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",84).>(ageClDate)))
      && (($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))


    println("--------------------adv4to7NonSuppDf---------------------")
    adv4to7NonSuppDf.filter($"${KpiConstants.memberidColName}".===("96090")).show()

    //</editor-fold>

    //<editor-fold desc="For 7 to 11 Years">

    val adv7to11NonSuppDf = visitNonSuppDf.filter((//(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.dentalVal))  &&
      (($"${KpiConstants.isdentistColName}".===("Y")) ))
      && ((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",84).<=(ageClDate))
      && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",132).>(ageClDate)))
      && (($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))


    println("--------------------adv7to11NonSuppDf---------------------")
    adv7to11NonSuppDf.filter($"${KpiConstants.memberidColName}".===("96090")).show()

    //</editor-fold>

    //<editor-fold desc="For 11 to 15 Years">

    val adv11to15NonSuppDf = visitNonSuppDf.filter((//(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.dentalVal))  &&
      (($"${KpiConstants.isdentistColName}".===("Y")) ))
      && ((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",144).<=(ageClDate))
      && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",240).>(ageClDate)))
      && (($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))


    println("--------------------adv11to15NonSuppDf---------------------")
    adv11to15NonSuppDf.filter($"${KpiConstants.memberidColName}".===("96090")).show()

    //</editor-fold>

    //<editor-fold desc="For 15 to 19 Years">

    val adv15to19NonSuppDf = visitNonSuppDf.filter((//(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.dentalVal))  &&
      (($"${KpiConstants.isdentistColName}".===("Y")) ))
      && ((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",180).<=(ageClDate))
      && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",228).>(ageClDate)))
      && (($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))


    println("--------------------adv15to19NonSuppDf---------------------")
    adv15to19NonSuppDf.filter($"${KpiConstants.memberidColName}".===("96090")).show()

    //</editor-fold>

    //<editor-fold desc="For 19 to 21 Years">

    val adv19to21NonSuppDf = visitNonSuppDf.filter((//(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.dentalVal))  &&
      (($"${KpiConstants.isdentistColName}".===("Y")) ))
      && ((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",228).<=(ageClDate))
      && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",252).>(ageClDate)))
      && (($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))


    println("--------------------adv19to21NonSuppDf---------------------")
    adv19to21NonSuppDf.filter($"${KpiConstants.memberidColName}".===("96090")).show()

    //</editor-fold>

    val advMenNonSuppDf =  adv2to4NonSuppDf.union(adv4to7NonSuppDf).union(adv7to11NonSuppDf).union(adv11to15NonSuppDf)
                            .union(adv15to19NonSuppDf).union(adv19to21NonSuppDf).distinct()

    println("--------------------advMenNonSuppDf---------------------")
    advMenNonSuppDf.filter($"${KpiConstants.memberidColName}".===("96090")).show()

    //</editor-fold>

    //<editor-fold desc="ADV Other Mem Numerator Calculation">

    val visitForMenOtherDf = visitJoinedDf.except(visitJoinedDf.filter($"${KpiConstants.memberidColName}".isin(advMenNonSuppDf.rdd.map(r=>r.getString(0)).collect():_*)))

    //<editor-fold desc="For 2 to 4 Years">

    val adv2to4MenOtherDf = visitForMenOtherDf.filter((//(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.dentalVal))  &&
      (($"${KpiConstants.isdentistColName}".===("Y")) ))
      && ((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",24).<=(ageClDate))
      && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",48).>(ageClDate)))
      && (($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))


    println("--------------------adv2to4MenOtherDf---------------------")
    adv2to4MenOtherDf.filter($"${KpiConstants.memberidColName}".===("96090")).show()

    //</editor-fold>

    //<editor-fold desc="For 4 to 7 Years">

    val adv4to7MenOtherDf = visitForMenOtherDf.filter((//(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.dentalVal))  &&
      (($"${KpiConstants.isdentistColName}".===("Y")) ))
      && ((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",48).<=(ageClDate))
      && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",84).>(ageClDate)))
      && (($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))


    println("--------------------adv4to7MenOtherDf---------------------")
    adv4to7MenOtherDf.filter($"${KpiConstants.memberidColName}".===("96090")).show()

    //</editor-fold>

    //<editor-fold desc="For 7 to 11 Years">

    val adv7to11MenOtherDf = visitForMenOtherDf.filter((//(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.dentalVal))  &&
      (($"${KpiConstants.isdentistColName}".===("Y")) ))
      && ((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",84).<=(ageClDate))
      && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",132).>(ageClDate)))
      && (($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))


    println("--------------------adv7to11MenOtherDf---------------------")
    adv7to11MenOtherDf.filter($"${KpiConstants.memberidColName}".===("96090")).show()

    //</editor-fold>

    //<editor-fold desc="For 11 to 15 Years">

    val adv11to15MenOtherDf = visitForMenOtherDf.filter((//(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.dentalVal))  &&
      (($"${KpiConstants.isdentistColName}".===("Y")) ))
      && ((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",132).<=(ageClDate))
      && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",180).>(ageClDate)))
      && (($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))


    println("--------------------adv11to15MenOtherDf---------------------")
    adv11to15MenOtherDf.filter($"${KpiConstants.memberidColName}".===("96090")).show()

    //</editor-fold>

    //<editor-fold desc="For 15 to 19 Years">

    val adv15to19MenOtherDf = visitForMenOtherDf.filter((//(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.dentalVal))  &&
      (($"${KpiConstants.isdentistColName}".===("Y")) ))
      && ((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",180).<=(ageClDate))
      && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",228).>(ageClDate)))
      && (($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))


    println("--------------------adv15to19MenOtherDf---------------------")
    adv15to19MenOtherDf.filter($"${KpiConstants.memberidColName}".===("96090")).show()

    //</editor-fold>

    //<editor-fold desc="For 19 to 21 Years">

    val adv19to21MenOtherDf = visitForMenOtherDf.filter((//(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.dentalVal))  &&
      (($"${KpiConstants.isdentistColName}".===("Y")) ))
      && ((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",228).<=(ageClDate))
      && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",252).>(ageClDate)))
      && (($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))


    println("--------------------adv19to21MenOtherDf---------------------")
    adv19to21MenOtherDf.filter($"${KpiConstants.memberidColName}".===("96090")).show()

    //</editor-fold>

    val advMenOtherDf =  adv2to4MenOtherDf.union(adv4to7MenOtherDf).union(adv7to11MenOtherDf).union(adv11to15MenOtherDf)
                          .union(adv15to19MenOtherDf).union(adv19to21MenOtherDf).distinct()

    println("--------------------After advMenOtherDf---------------------")
    advMenOtherDf.filter($"${KpiConstants.memberidColName}".===("96090")).show()


    //</editor-fold>

    //</editor-fold>

    //<editor-fold desc="Output File Creation">

    val numeratorDf = advMenOtherDf.union(advMenNonSuppDf).distinct()


    println("--------------------After numeratorDf---------------------")
    numeratorDf.filter($"${KpiConstants.memberidColName}".===("96090")).show()

    val numDf = numeratorDf.select($"${KpiConstants.memberidColName}").distinct()

    val outMap = mutable.Map(KpiConstants.totalPopDfName -> toutStratOutDf, KpiConstants.eligibleDfName -> eligiblePopDf,
      KpiConstants.mandatoryExclDfname -> spark.emptyDataFrame, KpiConstants.optionalExclDfName -> spark.emptyDataFrame,
      KpiConstants.numeratorDfName -> numDf)


    val outDf = UtilFunctions.ncqaOutputDfCreation(spark,outMap,measureId)
    outDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir+ "/outDf")

    //</editor-fold>

    //</editor-fold>

    spark.sparkContext.stop()
  }

}
