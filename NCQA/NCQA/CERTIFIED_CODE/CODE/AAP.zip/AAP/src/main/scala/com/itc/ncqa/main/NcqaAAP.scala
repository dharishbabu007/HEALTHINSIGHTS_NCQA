package main.scala.com.itc.ncqa.main

import main.scala.com.itc.ncqa.Constants
import main.scala.com.itc.ncqa.Constants.KpiConstants
import main.scala.com.itc.ncqa.Functions.UtilFunctions
import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkConf
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DateType

import scala.collection.mutable

object NcqaAAP {

  def main(args: Array[String]): Unit =
  {

    //<editor-fold desc="Reading program arguments and Spark Session object creation">

    val year = "2018"
    val measureId = "AAP"

    System.setProperty("hadoop.home.dir", "D:\\WinUtil")

    val conf = new SparkConf().setAppName("NcqaProgram")
    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    conf.set("spark.sql.shuffle.partitions", "5")
    //.set("hive.exec.dynamic.partition.mode", "nonstrict")

    val spark = SparkSession.builder().config(conf).master("local").getOrCreate()

    //spark.setConf("spark.sql.tungsten.enabled", "false")

    val rootLogger = Logger.getRootLogger()
    rootLogger.setLevel(Level.ERROR)

    //</editor-fold>

    //<editor-fold desc="Loading Required Tables to memory">

    import spark.implicits._

    val ystDate = year+"-01-01"
    val yendDate = year+"-12-31"

    val lobList = List(KpiConstants.commercialLobName, KpiConstants.medicaidLobName, KpiConstants.medicareLobName,KpiConstants.mmdLobName)

   // val membershipDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\AAP\\MEMBERSHIP_ENROLLMENT.csv")

    val membershipDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\AAP\\Test\\MEMBERSHIP_ENROLLMENT.csv")

      .filter(($"${KpiConstants.considerationsColName}".===(KpiConstants.yesVal))
        && ($"${KpiConstants.memStartDateColName}".isNotNull)
        && ($"${KpiConstants.memEndDateColName}".isNotNull))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .withColumn(KpiConstants.memStartDateColName, to_date($"${KpiConstants.memStartDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.memEndDateColName, to_date($"${KpiConstants.memEndDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.dateofbirthColName, to_date($"${KpiConstants.dateofbirthColName}", KpiConstants.dateFormatString))
      .repartition(2).cache()

    println("--------------------------Membership DF------------------------")
    membershipDf.filter($"${KpiConstants.memberidColName}".===("95102")).show()

    val claimStatusList = List(KpiConstants.paidVal, KpiConstants.suspendedVal, KpiConstants.pendingVal, KpiConstants.deniedVal)

   // val visitsDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\AAP\\VISITS.csv")

    val visitsDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\AAP\\Test\\VISITS.csv")
      .filter(($"${KpiConstants.serviceDateColName}".isNotNull)
        && (($"${KpiConstants.admitDateColName}".isNotNull && $"${KpiConstants.dischargeDateColName}".isNotNull)
        || ($"${KpiConstants.admitDateColName}".isNull && $"${KpiConstants.dischargeDateColName}".isNull))
        &&((($"${KpiConstants.dataSourceColName}".===("Claim"))&&($"${KpiConstants.claimstatusColName}".isin(claimStatusList:_*)))
        || (($"${KpiConstants.dataSourceColName}".===("RxClaim"))&&($"${KpiConstants.claimstatusColName}".isin(claimStatusList:_*)))
        || ($"${KpiConstants.dataSourceColName}".===("Rx"))
        || ($"${KpiConstants.dataSourceColName}".===("Lab"))))
      .drop(KpiConstants.lobProductColName, "latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name","product")
      .withColumn(KpiConstants.dobColName, to_date($"${KpiConstants.dobColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.serviceDateColName, to_date($"${KpiConstants.serviceDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.admitDateColName, when($"${KpiConstants.admitDateColName}".isNotNull,to_date($"${KpiConstants.admitDateColName}",  KpiConstants.dateFormatString)))
      .withColumn(KpiConstants.dischargeDateColName, when($"${KpiConstants.dischargeDateColName}".isNotNull,to_date($"${KpiConstants.dischargeDateColName}",  KpiConstants.dateFormatString)))
      .withColumn(KpiConstants.medstartdateColName, when($"${KpiConstants.medstartdateColName}".isNotNull,to_date($"${KpiConstants.medstartdateColName}",  KpiConstants.dateFormatString)))
      .withColumn(KpiConstants.revenuecodeColName, when((length($"${KpiConstants.revenuecodeColName}").as[Int].===(3)),concat(lit("0" ),lit($"${KpiConstants.revenuecodeColName}"))).otherwise($"${KpiConstants.revenuecodeColName}"))
      .withColumn(KpiConstants.billtypecodeColName, when((length($"${KpiConstants.billtypecodeColName}").as[Int].===(3)),concat(lit("0" ),lit($"${KpiConstants.billtypecodeColName}"))).otherwise($"${KpiConstants.billtypecodeColName}"))
      .withColumn(KpiConstants.proccode2ColName, when(($"${KpiConstants.proccode2mod1ColName}".isin(KpiConstants.avoidCodeList:_*)) || ($"${KpiConstants.proccode2mod2ColName}".isin(KpiConstants.avoidCodeList:_*)),lit("NA")).otherwise($"${KpiConstants.proccode2ColName}"))
      .repartition(2).cache()

    println("--------------------------visitsDf------------------------")
    visitsDf.filter($"${KpiConstants.memberidColName}".===("95102")).show()
    visitsDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite)
      .parquet("/home/hbase/ncqa/aap/Test_AAP/visitsDf/")

   // val refHedisDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\AAP\\REF_HEDIS2019.csv")

    val refHedisDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\AAP\\Test\\REF_HEDIS2019.csv")
      .filter(($"${KpiConstants.measureIdColName}".===(KpiConstants.aapMeasureId)) || ($"${KpiConstants.measureIdColName}".===(KpiConstants.ggMeasureId)))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .repartition(2).cache()

    refHedisDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite)
      .parquet("/home/hbase/ncqa/aap/Test_AAP/refHedisDf/")

    //val medmonmemDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\AAP\\AAP_MONTHLY_MEMBERSHIP.csv")

    val medmonmemDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\AAP\\Test\\AAP_MONTHLY_MEMBERSHIP.csv")
      .withColumn(KpiConstants.runDateColName,to_date($"${KpiConstants.runDateColName}", KpiConstants.dateFormatString))
      .filter(($"${KpiConstants.runDateColName}".>=(ystDate)) && ($"${KpiConstants.runDateColName}".<=(yendDate)))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .repartition(2).cache()

    println("---------------------------Monthly Membership--------------------------------")
    medmonmemDf/*.filter($"${KpiConstants.memberidColName}".===("95102"))8*/.show()

    medmonmemDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite)
      .parquet("/home/hbase/ncqa/aap/Test_AAP/medmonmemDf/")

    //</editor-fold>

    //<editor-fold desc="Age Filter">

    val ageEndDate = year + "-12-31"
    val ageStartDate = year + "-01-01"

    val ageStartDate1 = year.toInt -2 + "-01-01"
    val ageClDate = year+ "-12-31"

    /* The Member should be older than or equal to 20 years on 31st December Measurement Year.*/
    val ageFilterDf = membershipDf.withColumn("age",datediff(lit(ageEndDate),$"${KpiConstants.dateofbirthColName}")/365.25)
      .filter( $"age">=20).select(KpiConstants.memberidColName, KpiConstants.benefitMedicalColname,
      KpiConstants.memStartDateColName,KpiConstants.memEndDateColName,
      KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName, KpiConstants.dateofbirthColName,KpiConstants.primaryPlanFlagColName,"age")
      .cache()

    println("-------------------After ageFilterDf-------------")
    ageFilterDf.filter($"${KpiConstants.memberidColName}".===("95102")).show()

    //</editor-fold>

    //<editor-fold desc="Continuous Enrollment, Allowable Gap Calculation">

    val inputForContEnrolldf = ageFilterDf.filter(($"${KpiConstants.memStartDateColName}".<=(ageEndDate))
      && ($"${KpiConstants.memEndDateColName}".>=(ageEndDate)))

    inputForContEnrolldf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite)
      .parquet("/home/hbase/ncqa/aap/Test_AAP/inputForContEnrolldf/")

    val IpContEnroll = spark.read.parquet("/home/hbase/ncqa/aap/Test_AAP/inputForContEnrolldf/").cache()

    println("----------------inputForContEnrolldf----------------------")
    IpContEnroll.filter($"${KpiConstants.memberidColName}".===("95102")).show()

    //<editor-fold desc="Continuous Enrollment Calculation For MMD , Medicare & Medicaid ">

    val CEMedDf = IpContEnroll.filter((($"${KpiConstants.lobColName}").===(KpiConstants.medicaidLobName)) ||
      (($"${KpiConstants.lobColName}").===(KpiConstants.medicareLobName)) || (($"${KpiConstants.lobColName}").===(KpiConstants.mmdLobName)) )
      .select(KpiConstants.memberidColName).distinct()

    println("-------------------------CEMedDf----------------------------")
    CEMedDf.filter($"${KpiConstants.memberidColName}".===("95102")).show()


    val contEnrollInMedDf = CEMedDf.select($"${KpiConstants.memberidColName}" as "df1_memberid")
      .as("df1").join(ageFilterDf.as("df2"),
      $"df1.df1_memberid" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select(KpiConstants.memberidColName, KpiConstants.benefitMedicalColname, KpiConstants.memStartDateColName,KpiConstants.memEndDateColName,
        KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName, KpiConstants.dateofbirthColName,KpiConstants.primaryPlanFlagColName,"age")

    println("-------------------------contEnrollInMedDf----------------------------")
    contEnrollInMedDf.filter($"${KpiConstants.memberidColName}".===("95102")).show()

    contEnrollInMedDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite).parquet("/home/hbase/ncqa/aap/Test_AAP/contEnrollInMedDf/")


    val ContEnrollMed = spark.read.parquet("/home/hbase/ncqa/aap/Test_AAP/contEnrollInMedDf/").cache()

    val mapForCeMed = mutable.Map("start_date" -> (year+"-01-01"), "end_date" -> (year+"-12-31"),"gapcount" -> "1", "checkval" -> "true","reqCovDays"-> "0","anchor_date" -> (year+"-12-31"))

    val contEnrollMedDf = UtilFunctions.contEnrollAndAllowableGapFilterFunction(spark,ContEnrollMed,mapForCeMed)
      .select(KpiConstants.memberidColName, KpiConstants.lobColName, KpiConstants.lobProductColName,
        KpiConstants.payerColName,KpiConstants.dateofbirthColName, KpiConstants.primaryPlanFlagColName)

      //.select(KpiConstants.memberidColName, KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName, KpiConstants.primaryPlanFlagColName,"age")

    contEnrollMedDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite).parquet("/home/hbase/ncqa/aap/Test_AAP/contEnrollMedDf/")

    contEnrollMedDf.select(KpiConstants.memberidColName).distinct().coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("/home/hbase/ncqa/aap/Test_AAP/contEnrollMedDf-CSV/")

    //</editor-fold>

    //<editor-fold desc="Continuous Enrollment Calculation For Commercial & Market Place ">

    val CECommDf = IpContEnroll.filter(($"${KpiConstants.lobColName}").===(KpiConstants.commercialLobName)).select(KpiConstants.memberidColName).distinct()

    println("-------------------------CECommDf----------------------------")
    CECommDf.filter($"${KpiConstants.memberidColName}".===("95102")).show()

    val contEnrollInCommTmpDf = CECommDf.select($"${KpiConstants.memberidColName}" as "df1_memberid")
      .as("df1").join(ageFilterDf.as("df2"),
      $"df1.df1_memberid" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select(KpiConstants.memberidColName, KpiConstants.benefitMedicalColname, KpiConstants.memStartDateColName,KpiConstants.memEndDateColName,
        KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName, KpiConstants.dateofbirthColName,KpiConstants.primaryPlanFlagColName,"age")

    println("-------------------------contEnrollInCommTmpDf----------------------------")
    contEnrollInCommTmpDf.filter($"${KpiConstants.memberidColName}".===("95102")).show()

    contEnrollInCommTmpDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite).parquet("/home/hbase/ncqa/aap/Test_AAP/contEnrollInCommTmpDf/")

    val ContEnrollComm = spark.read.parquet("/home/hbase/ncqa/aap/Test_AAP/contEnrollInCommTmpDf/").cache()

    val mapForCeminus3y = mutable.Map("start_date" -> (year.toInt-2+ "-01-01"), "end_date" -> (year.toInt-2+ "-12-31"),"gapcount" -> "1",
      "reqCovDays"-> "0","checkval" -> "false")

    val ceOutminus3yDf = UtilFunctions.contEnrollAndAllowableGapFilterFunction(spark,ContEnrollComm,mapForCeminus3y)

    println("----------------------------------ceOutminus3yDf-----------------------------")
    ceOutminus3yDf.show()

    ceOutminus3yDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite).parquet("/home/hbase/ncqa/aap/Test_AAP/ceOutminus3yDf/")


    val CeOut3y = spark.read.parquet("/home/hbase/ncqa/aap/Test_AAP/ceOutminus3yDf/").cache()

    val mapForCeminus2y = mutable.Map("start_date" -> (year.toInt-1+ "-01-01"), "end_date" -> (year.toInt-1+ "-12-31"),"gapcount" -> "1",
      "reqCovDays"-> "0","checkval" -> "false")

    val ceOutminus2yDf = UtilFunctions.contEnrollAndAllowableGapFilterFunction(spark,CeOut3y,mapForCeminus2y)

    ceOutminus2yDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite).parquet("/home/hbase/ncqa/aap/Test_AAP/ceOutminus2yDf/")


    val CeOut2y = spark.read.parquet("/home/hbase/ncqa/aap/Test_AAP/ceOutminus2yDf/").cache()

    val mapForCeminus1y = mutable.Map("start_date" -> (year+"-01-01"), "end_date" -> (year+"-12-31"),"gapcount" -> "1",
      "checkval" -> "true","reqCovDays"-> "0","anchor_date" -> (year+"-12-31"))

    val contEnrollInCommDf = UtilFunctions.contEnrollAndAllowableGapFilterFunction(spark,CeOut2y,mapForCeminus1y)
      .select(KpiConstants.memberidColName, KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName,
        KpiConstants.dateofbirthColName,KpiConstants.primaryPlanFlagColName)

    // .select(KpiConstants.memberidColName, KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName, KpiConstants.primaryPlanFlagColName,"age")

    contEnrollInCommDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite).parquet("/home/hbase/ncqa/aap/Test_AAP/contEnrollInCommDf/")

    //</editor-fold>


    val ContEnrollInComm = spark.read.parquet("/home/hbase/ncqa/aap/Test_AAP/contEnrollInCommDf/").cache()

    val ContEnrollInMed = spark.read.parquet("/home/hbase/ncqa/aap/Test_AAP/contEnrollMedDf/").cache()

    println("-------------------------ContEnrollInComm------------------------------")
    ContEnrollInComm.filter($"${KpiConstants.memberidColName}".===("95102")).show()

    println("-------------------------ContEnrollInMed------------------------------")
    ContEnrollInMed.filter($"${KpiConstants.memberidColName}".===("95102")).show()

    val contEnrollDf = ContEnrollInMed.union(ContEnrollInComm)

    println("-------------------------contEnrollDf------------------------------")
    contEnrollDf.filter($"${KpiConstants.memberidColName}".===("95102")).show()

    contEnrollDf.coalesce(2)
      .write
      .mode(SaveMode.Overwrite).parquet("/home/hbase/ncqa/aap/Test_AAP/contEnrollDf/")

    //</editor-fold>

    //<editor-fold desc="Dual Enrollment and AAP Lob filter">

    val ConEnrDf = spark.read.parquet("/home/hbase/ncqa/aap/Test_AAP/contEnrollDf/").cache()

    //val baseOutDf = UtilFunctions.baseOutDataframeCreation(spark, ConEnrDf, lobList , measureId)

    val baseOutMedHosRemDf = UtilFunctions.baseOutDataframeCreation(spark, ConEnrDf, lobList , measureId)

    /*Removing the SN payer members from the EPOP*/

    val snPayerList = List(KpiConstants.sn1PayerVal, KpiConstants.sn2PayerVal, KpiConstants.sn3PayerVal, KpiConstants.mmpPayerVal)
    val baseOutDf = baseOutMedHosRemDf.except(baseOutMedHosRemDf.filter($"${KpiConstants.payerColName}".isin(snPayerList:_*)))

    println("-------------------After baseOutDf-------------")
    baseOutDf.filter($"${KpiConstants.memberidColName}".===("95102")).show()

    val AapContEnrollDf = baseOutDf.filter($"${KpiConstants.lobColName}".isin(lobList:_*)).dropDuplicates().cache()
    AapContEnrollDf.count()

    //Modified Code
    val medicareContEnrollDf = AapContEnrollDf.filter($"${KpiConstants.lobColName}".===(KpiConstants.medicareLobName))

    println("-------------------After medicareContEnrollDf-------------")
    medicareContEnrollDf.filter($"${KpiConstants.memberidColName}".===("95102")).show()

    val MedMonDf = spark.read.parquet("/home/hbase/ncqa/aap/Test_AAP/medmonmemDf/").cache()

    val medicareHospiceDf = medicareContEnrollDf.as("df1").join(MedMonDf.as("df2"), Seq(KpiConstants.memberidColName))
      .groupBy(KpiConstants.memberidColName).agg(countDistinct(when($"hospice".===("Y"),1)).alias("count"))
      .filter($"count".>(0))
      .select(KpiConstants.memberidColName).rdd.map(r=> r.getString(0)).collect()

    println("-------------------After Medicare hospice-------------")
    //medicareHospiceDf.foreach(f=> println(f))

    val aapcontEnrollResDf = AapContEnrollDf.except(AapContEnrollDf.filter($"${KpiConstants.memberidColName}".isin(medicareHospiceDf:_*)))

    aapcontEnrollResDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite)
      .parquet("/home/hbase/ncqa/aap/Test_AAP/aapcontEnrollResDf/")

    println("-------------------After Dual Enrollment-------------")
    aapcontEnrollResDf.filter($"${KpiConstants.memberidColName}".===("95102")).show()

    //Ends here

    //</editor-fold>

    //<editor-fold desc="Initial Join with Ref_Hedis">

    val VisDf = spark.read.parquet("/home/hbase/ncqa/aap/Test_AAP/visitsDf/").cache()

    val RefHedDf = spark.read.parquet("/home/hbase/ncqa/aap/Test_AAP/refHedisDf/").cache()

    val argmapforRefHedis = mutable.Map(KpiConstants.eligibleDfName -> VisDf , KpiConstants.refHedisTblName -> RefHedDf)
    val allValueList = List(KpiConstants.independentLabVal, KpiConstants.hospiceVal,KpiConstants.ambulatoryVisitVal,KpiConstants.otherAmbulatoryVal,
      KpiConstants.telephoneVisitsVal,KpiConstants.onlineAssesmentVal)

    val medList = KpiConstants.emptyList
    val visitRefHedisDf = UtilFunctions.joinWithRefHedisFunction(spark,argmapforRefHedis,allValueList,medList)
      .withColumn("age",datediff(lit(ageEndDate),$"${KpiConstants.dobColName}")/365.25)

    println("-------------------After visitRefHedisDf-------------")
    visitRefHedisDf.filter($"${KpiConstants.memberidColName}".===("95102")).show()

    visitRefHedisDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite)
      .parquet("/home/hbase/ncqa/aap/Test_AAP/visitRefHedisDf/")

    //</editor-fold>

    //<editor-fold desc="Removal of Independent Lab Visits">

    val VisRefHedDf = spark.read.parquet("/home/hbase/ncqa/aap/Test_AAP/visitRefHedisDf/").cache()

    val groupList = VisDf.schema.fieldNames.toList.dropWhile(p=> p.equalsIgnoreCase(KpiConstants.memberidColName))

    val visitgroupedDf = VisRefHedDf.groupBy(KpiConstants.memberidColName, groupList:_*).agg(collect_list(KpiConstants.valuesetColName).alias(KpiConstants.valuesetColName))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName, KpiConstants.admitDateColName, KpiConstants.dischargeDateColName,
        KpiConstants.dobColName,KpiConstants.supplflagColName, KpiConstants.ispcpColName,KpiConstants.isobgynColName, KpiConstants.valuesetColName,KpiConstants.genderColName)


    val indLabVisRemDf = visitgroupedDf.filter(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)).repartition(2).cache()
    indLabVisRemDf.count()

    println("-------------------After indLabVisRemDf-------------")
    indLabVisRemDf.filter($"${KpiConstants.memberidColName}".===("95102")).show()


    //</editor-fold>

    //<editor-fold desc="Hospice Removal">

    val ConEnrResDf = spark.read.parquet("/home/hbase/ncqa/aap/Test_AAP/aapcontEnrollResDf/").cache()

    val yearStartDate = year+"-01-01"
    val yearEndDate = year+"-12-31"

    val hospiceInCurrYearMemDf = indLabVisRemDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hospiceVal))
      &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate)
      && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)
      .dropDuplicates()
      .rdd
      .map(r=> r.getString(0))
      .collect()

    val df =  indLabVisRemDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hospiceVal))
    &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
    //.select(KpiConstants.memberidColName)

    println("-------------------df-------------")
    df.filter($"${KpiConstants.memberidColName}".===("95102")).show()

    val hospiceRemMemEnrollDf = ConEnrResDf.except(ConEnrResDf.filter($"${KpiConstants.memberidColName}".isin(hospiceInCurrYearMemDf:_*)))

    println("-------------------hospiceRemMemEnrollDf-------------")
    hospiceRemMemEnrollDf.filter($"${KpiConstants.memberidColName}".===("95102")).show()

    hospiceRemMemEnrollDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite)
      .parquet("/home/hbase/ncqa/aap/Test_AAP/hospiceRemMemEnrollDf/")

    val totalPopOutDf = hospiceRemMemEnrollDf.distinct()

    println("-------------------After totalPopOutDf-------------")
    totalPopOutDf.filter($"${KpiConstants.memberidColName}".===("95102")).show()

    totalPopOutDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .csv("/home/hbase/ncqa/aap/Test_AAP/totalPopOutDf/")

    //</editor-fold>

    //<editor-fold desc="EPOP Generation">

    val toutStrDf =totalPopOutDf.select($"${KpiConstants.memberidColName}",$"${KpiConstants.memberidColName}"
      .as(KpiConstants.ncqaOutmemberIdCol),$"${KpiConstants.payerColName}".as(KpiConstants.ncqaOutPayerCol)).distinct()

    toutStrDf.coalesce(4)
      .write
      .mode(SaveMode.Append)
      .parquet("/home/hbase/ncqa/aap/Test_AAP/tout")


    val eligiblePopDf = totalPopOutDf.select(KpiConstants.memberidColName).distinct().repartition(2).cache()
    eligiblePopDf.count()

    eligiblePopDf.coalesce(4)
      .write
      .mode(SaveMode.Append)
      .parquet("/home/hbase/ncqa/aap/Test_AAP/epop")

    println("-------------------Selective Epop-------------------")
    eligiblePopDf.filter($"${KpiConstants.memberidColName}".===("95102")).show()

    eligiblePopDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("/home/hbase/ncqa/aap/Test_AAP/epop_csv")

    //</editor-fold>

    //<editor-fold desc="AAP Stratification">

    val toutStratDf= totalPopOutDf.withColumn("age",datediff(lit(ageEndDate),$"${KpiConstants.dateofbirthColName}")/365.25)
      .withColumn("Classfication",
      when((( $"age">=20 )&&( $"age"<45 )),lit("CH1")).
        when((( $"age">=45 )&&( $"age"<65 )),lit("CH2")).
        when(( $"age">=65 ),lit("CH3")))



    println("-----------------------toutStratDf-------------------------------")
    toutStratDf.filter($"${KpiConstants.memberidColName}".===("95102")).show()

    val statification = Seq(("CH1", "AAP1"),("CH2", "AAP2"),("CH3", "AAP3")).toDF("Classfication","Measure")

    println("-----------------------statification-------------------------------")
    statification.show()

    val visitJoinedOutDf=toutStratDf.as("df1").join(statification.as("df2"), $"df1.Classfication"===$"df2.Classfication", KpiConstants.innerJoinType)
      .select("df1.*","df2.Measure").cache()

    println("-----------------------visitJoinedDf-------------------------------")
    visitJoinedOutDf.filter($"${KpiConstants.memberidColName}".===("95102")).show()

    val toutStratOutDf = visitJoinedOutDf.select($"${KpiConstants.memberidColName}".as(KpiConstants.ncqaOutmemberIdCol),
      $"${KpiConstants.payerColName}".as(KpiConstants.ncqaOutPayerCol), $"Measure".alias(KpiConstants.ncqaOutMeasureCol)).distinct()

    toutStratOutDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("/home/hbase/ncqa/aap/Test_AAP/toutStratOutDf")


    //</editor-fold>

    //<editor-fold desc="Numerator Part">

    //<editor-fold desc="Initial join function">

    val argmapForVisittJoin = mutable.Map(KpiConstants.membershipTblName -> totalPopOutDf , KpiConstants.visitTblName -> indLabVisRemDf)

    val visitJoinedDf = UtilFunctions.initialJoinFunction(spark,argmapForVisittJoin)
      .withColumn("age",datediff(lit(ageEndDate),$"${KpiConstants.dobColName}")/365.25)

    println("------------------------visitJoinedOutDf----------------------------")
    visitJoinedDf.filter($"${KpiConstants.memberidColName}".===("95102")).show()

    AapContEnrollDf.unpersist()
    visitgroupedDf.unpersist()
    eligiblePopDf.unpersist()

    //</editor-fold>

    //<editor-fold desc="AAP Numerator Calculation">

    //<editor-fold desc="AAP Non Supp Numerator Calculation">

    val visitNonSuppDf = visitJoinedDf.filter($"${KpiConstants.supplflagColName}".===("N")).cache()
    visitNonSuppDf.count()

    println("--------------------visitNonSuppDf---------------------")
    visitNonSuppDf.filter($"${KpiConstants.memberidColName}".===("95102")).show()

    val toutDf = spark.read.parquet("/home/hbase/ncqa/aap/Test_AAP/tout")

    val denominatorPopDf = toutDf.select(KpiConstants.memberidColName).distinct().cache()

    //<editor-fold desc="For Age 20 to 45">

    val aap20To45NonSuppDf = visitNonSuppDf.filter(( $"age">=20 )&&( $"age"<45 ))
      .filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.ambulatoryVisitVal)
        || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.otherAmbulatoryVal))
        || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telephoneVisitsVal))
        || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.onlineAssesmentVal))))

    println("--------------------aap20To45NonSuppDf---------------------")
    aap20To45NonSuppDf.filter($"${KpiConstants.memberidColName}".===("95102")).show()


    //<editor-fold desc="Medicare & Medicaid">

    val aap20to45MedNonSuppDf = aap20To45NonSuppDf.filter(((($"${KpiConstants.lobColName}").===(KpiConstants.medicaidLobName)) ||
      (($"${KpiConstants.lobColName}").===(KpiConstants.medicareLobName)) || (($"${KpiConstants.lobColName}").===(KpiConstants.mmdLobName)))
      && (($"${KpiConstants.serviceDateColName}".>=(ageStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(ageEndDate))))

    println("--------------------aap20to45MedNonSuppDf---------------------")
    aap20to45MedNonSuppDf.filter($"${KpiConstants.memberidColName}".===("95102")).show()


    //</editor-fold>

    //<editor-fold desc="Commercial">

    val aap20to45CommNonSuppDf = aap20To45NonSuppDf.filter((($"${KpiConstants.lobColName}").===(KpiConstants.commercialLobName))
      && (($"${KpiConstants.serviceDateColName}".>=(ageStartDate1)) && ($"${KpiConstants.serviceDateColName}".<=(ageEndDate))))

    println("--------------------aap20to45CommNonSuppDf---------------------")
    aap20to45CommNonSuppDf.filter($"${KpiConstants.memberidColName}".===("95102")).show()

    //</editor-fold>

    val aap20to45NonSuppResDf = aap20to45MedNonSuppDf.union(aap20to45CommNonSuppDf)

    println("--------------------aap20to45NonSuppResDf---------------------")
    aap20to45NonSuppResDf.filter($"${KpiConstants.memberidColName}".===("95102")).show()

    //</editor-fold>

    //<editor-fold desc="For Age 45 to 65">

    val aap45To65NonSuppDf = visitNonSuppDf.filter(( $"age">=45 )&&( $"age"<65 ))
      .filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.ambulatoryVisitVal)
        || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.otherAmbulatoryVal))
        || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telephoneVisitsVal))
        || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.onlineAssesmentVal))))


    //<editor-fold desc="Medicare & Medicaid">

    val aap45to65MedNonSuppDf = aap45To65NonSuppDf.filter(((($"${KpiConstants.lobColName}").===(KpiConstants.medicaidLobName)) ||
      (($"${KpiConstants.lobColName}").===(KpiConstants.medicareLobName)) || (($"${KpiConstants.lobColName}").===(KpiConstants.mmdLobName)))
      && (($"${KpiConstants.serviceDateColName}".>=(ageStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(ageEndDate))))

    //</editor-fold>

    //<editor-fold desc="Commercial">

    val aap45to65CommNonSuppDf = aap45To65NonSuppDf.filter((($"${KpiConstants.lobColName}").===(KpiConstants.commercialLobName))
      && (($"${KpiConstants.serviceDateColName}".>=(ageStartDate1)) && ($"${KpiConstants.serviceDateColName}".<=(ageEndDate))))

    //</editor-fold>

    val aap45to65NonSuppResDf = aap45to65MedNonSuppDf.union(aap45to65CommNonSuppDf)

    //</editor-fold>

    //<editor-fold desc="For More than 65">

    val aapMorethan65NonSuppDf = visitNonSuppDf.filter(( $"age">=65 ))
      .filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.ambulatoryVisitVal)
        || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.otherAmbulatoryVal))
        || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telephoneVisitsVal))
        || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.onlineAssesmentVal))))


    //<editor-fold desc="Medicare & Medicaid">

    val aapMorethan65MedNonSuppDf = aapMorethan65NonSuppDf.filter(((($"${KpiConstants.lobColName}").===(KpiConstants.medicaidLobName)) ||
      (($"${KpiConstants.lobColName}").===(KpiConstants.medicareLobName)) || (($"${KpiConstants.lobColName}").===(KpiConstants.mmdLobName)))
      && (($"${KpiConstants.serviceDateColName}".>=(ageStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(ageEndDate))))

    println("--------------------aapMorethan65MedNonSuppDf---------------------")
    aapMorethan65MedNonSuppDf.filter($"${KpiConstants.memberidColName}".===("95102")).show()

    //</editor-fold>

    //<editor-fold desc="Commercial">

    val aapMorethan65CommNonSuppDf = aapMorethan65NonSuppDf.filter((($"${KpiConstants.lobColName}").===(KpiConstants.commercialLobName))
      && (($"${KpiConstants.serviceDateColName}".>=(ageStartDate1)) && ($"${KpiConstants.serviceDateColName}".<=(ageEndDate))))

    aapMorethan65CommNonSuppDf.filter($"${KpiConstants.memberidColName}".===("95102")).show()

    //</editor-fold>

    val aapMorethan65NonSuppResDf = aapMorethan65MedNonSuppDf.union(aapMorethan65CommNonSuppDf)

    println("--------------------aapMorethan65NonSuppResDf---------------------")
    aapMorethan65NonSuppResDf.filter($"${KpiConstants.memberidColName}".===("95102")).show()


    //</editor-fold>

    val aapMenNonSuppDf =  aap20to45NonSuppResDf.union(aap45to65NonSuppResDf).union(aapMorethan65NonSuppResDf)

    //</editor-fold>

    //<editor-fold desc="AAP Other Mem Numerator Calculation">

    val visitForMenOtherDf = visitJoinedDf.except(visitJoinedDf.filter($"${KpiConstants.memberidColName}".isin(aapMenNonSuppDf.rdd.map(r=>r.getString(0)).collect():_*)))

    //<editor-fold desc="For Age 20 to 45">

    val aap20To45MenOtherDf = visitForMenOtherDf.filter(( $"age">=20 )&&( $"age"<45 ))
      .filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.ambulatoryVisitVal)
        || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.otherAmbulatoryVal))
        || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telephoneVisitsVal))
        || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.onlineAssesmentVal))))

    //<editor-fold desc="Medicare & Medicaid">

    val aap20to45MedMenOtherDf = aap20To45MenOtherDf.filter(((($"${KpiConstants.lobColName}").===(KpiConstants.medicaidLobName)) ||
      (($"${KpiConstants.lobColName}").===(KpiConstants.medicareLobName)) || (($"${KpiConstants.lobColName}").===(KpiConstants.mmdLobName)))
      && (($"${KpiConstants.serviceDateColName}".>=(ageStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(ageEndDate))))
    //</editor-fold>

    //<editor-fold desc="Commercial">

    val aap20to45CommMenOtherDf = aap20To45MenOtherDf.filter((($"${KpiConstants.lobColName}").===(KpiConstants.commercialLobName))
      && (($"${KpiConstants.serviceDateColName}".>=(ageStartDate1)) && ($"${KpiConstants.serviceDateColName}".<=(ageEndDate))))

    //</editor-fold>

    val aap20to45MenOtherResDf = aap20to45MedMenOtherDf.union(aap20to45CommMenOtherDf)

    //</editor-fold>

    //<editor-fold desc="For Age 45 to 65">

    val aap45To65MenOtherDf = visitForMenOtherDf.filter(( $"age">=45 )&&( $"age"<65 ))
      .filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.ambulatoryVisitVal)
        || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.otherAmbulatoryVal))
        || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telephoneVisitsVal))
        || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.onlineAssesmentVal))))


    //<editor-fold desc="Medicare & Medicaid">

    val aap45to65MedMenOtherDf = aap45To65MenOtherDf.filter(((($"${KpiConstants.lobColName}").===(KpiConstants.medicaidLobName)) ||
      (($"${KpiConstants.lobColName}").===(KpiConstants.medicareLobName)) || (($"${KpiConstants.lobColName}").===(KpiConstants.mmdLobName)))
      && (($"${KpiConstants.serviceDateColName}".>=(ageStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(ageEndDate))))

    //</editor-fold>

    //<editor-fold desc="Commercial">

    val aap45to65CommMenOtherDf = aap45To65MenOtherDf.filter((($"${KpiConstants.lobColName}").===(KpiConstants.commercialLobName))
      && (($"${KpiConstants.serviceDateColName}".>=(ageStartDate1)) && ($"${KpiConstants.serviceDateColName}".<=(ageEndDate))))


    //</editor-fold>

    val aap45to65MenOtherResDf = aap45to65CommMenOtherDf.union(aap45to65MedMenOtherDf)

    //</editor-fold>

    //<editor-fold desc="For More than 65">

    val aapMorethan65MenOtherDf = visitNonSuppDf.filter(( $"age">=65 ))
      .filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.ambulatoryVisitVal)
        || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.otherAmbulatoryVal))
        || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telephoneVisitsVal))
        || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.onlineAssesmentVal))))


    //<editor-fold desc="Medicare & Medicaid">

    val aapMorethan65MedMenOtherDf = aapMorethan65MenOtherDf.filter(((($"${KpiConstants.lobColName}").===(KpiConstants.medicaidLobName)) ||
      (($"${KpiConstants.lobColName}").===(KpiConstants.medicareLobName)) || (($"${KpiConstants.lobColName}").===(KpiConstants.mmdLobName)))
      && (($"${KpiConstants.serviceDateColName}".>=(ageStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(ageEndDate))))
    println("--------------------aapMorethan65MedMenOtherDf---------------------")

    aapMorethan65MedMenOtherDf.filter($"${KpiConstants.memberidColName}".===("95102")).show()
    //</editor-fold>

    //<editor-fold desc="Commercial">

    val aapMorethan65CommMenOtherDf = aapMorethan65MenOtherDf.filter((($"${KpiConstants.lobColName}").===(KpiConstants.commercialLobName))
      && (($"${KpiConstants.serviceDateColName}".>=(ageStartDate1)) && ($"${KpiConstants.serviceDateColName}".<=(ageEndDate))))


    //</editor-fold>

    val aapMorethan65MenOtherResDf = aapMorethan65MedMenOtherDf.union(aapMorethan65CommMenOtherDf)

    //</editor-fold>

    //</editor-fold>

    val aap20to45NumDf = aap20to45NonSuppResDf.union(aap20to45MenOtherResDf).dropDuplicates()
    val aap45to65NumDf = aap45to65NonSuppResDf.union(aap45to65MenOtherResDf).dropDuplicates()
    val aapMorethan65Df = aapMorethan65NonSuppResDf.union(aapMorethan65MenOtherResDf).dropDuplicates()

    val numeratorDf = aap20to45NumDf.union(aap45to65NumDf).union(aapMorethan65Df).select(KpiConstants.memberidColName).distinct()

    numeratorDf.printSchema()

    val outMap = mutable.Map(KpiConstants.totalPopDfName -> toutStratOutDf, KpiConstants.eligibleDfName -> eligiblePopDf,
      KpiConstants.mandatoryExclDfname -> spark.emptyDataFrame, KpiConstants.optionalExclDfName -> spark.emptyDataFrame,
      KpiConstants.numeratorDfName -> numeratorDf)


    val outDf = UtilFunctions.ncqaOutputDfCreation(spark,outMap,measureId)
    outDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("/home/hbase/ncqa/aap/Test_AAP/outDf")


    //</editor-fold>

    //</editor-fold>

    spark.sparkContext.stop()
  }
}
