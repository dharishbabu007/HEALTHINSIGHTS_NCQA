package com.itc.ncqa.main

import com.itc.ncqa.Constants.KpiConstants
import com.itc.ncqa.Functions.{DataLoadFunctions, UtilFunctions}
import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkConf
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

import scala.collection.mutable

object NcqaNCS {

  def main(args: Array[String]): Unit = {

    //<editor-fold desc="Reading program arguments and SaprkSession oBject creation">

    //    val year = args(0)
    //    val measureId = args(1)
    //    val dbName = args(2)

    val measureId = "NCS"
    val year = "2018"
    /*calling function for setting the dbname for dbName variable*/
    // KpiConstants.setDbName(dbName)
    //    val conf = new SparkConf().setAppName("NcqaProgram")
    //    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    //      .set("hive.exec.dynamic.partition.mode", "nonstrict")
    //    .set("spark.sql.shuffle.partitions","5")

    val conf = new SparkConf().setAppName("NcqaProgram").setMaster("local[*]")
    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      .set("hive.exec.dynamic.partition.mode", "nonstrict")
      .set("spark.sql.shuffle.partitions","5")
    val spark = SparkSession.builder().config(conf).getOrCreate()

    // val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    import spark.implicits._
    val rootLogger=Logger.getRootLogger()
    rootLogger.setLevel(Level.ERROR)
    //</editor-fold>

    //<editor-fold desc="Loading Required Tables to memory">

    val ystDate = year+"-01-01"
    val yendDate = year+"-12-31"
    val aLiat = List("col1")
    val msrVal = s"'$measureId'"
    val ggMsrId = s"'${KpiConstants.ggMeasureId}'"
    val lobList = List(KpiConstants.commercialLobName, KpiConstants.medicaidLobName )
    val claimStatusList = List(KpiConstants.paidVal, KpiConstants.suspendedVal, KpiConstants.pendingVal , KpiConstants.deniedVal)
    val numClaimStatusList = List(KpiConstants.paidVal, KpiConstants.suspendedVal, KpiConstants.pendingVal )

    /*read from db*/
    //    val memqueryString = s"""SELECT * FROM ${KpiConstants.dbName}.${KpiConstants.membershipTblName} WHERE measure = $msrVal AND (member_plan_start_date IS  NOT NULL) AND(member_plan_end_date IS NOT NULL)"""
    //    val membershipDf = DataLoadFunctions.dataLoadFromHiveStageTable(spark,KpiConstants.dbName,KpiConstants.membershipTblName,memqueryString,aLiat)
    //      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
    //      .repartition(2)
    //
    //
    //
    //
    //    val claimStatusList = List(KpiConstants.paidVal, KpiConstants.suspendedVal, KpiConstants.pendingVal, KpiConstants.deniedVal)
    //    val visitqueryString = s"""SELECT * FROM ${KpiConstants.dbName}.${KpiConstants.visitTblName} WHERE measure = $msrVal and  (service_date IS  NOT NULL) AND((admit_date IS NULL and discharge_date IS NULL) OR (ADMIT_DATE IS NOT NULL AND DISCHARGE_DATE IS NOT NULL))"""
    //    val visitsDf = DataLoadFunctions.dataLoadFromHiveStageTable(spark,KpiConstants.dbName,KpiConstants.visitTblName,visitqueryString,aLiat)
    //      .filter((($"${KpiConstants.dataSourceColName}".===("Claim"))&&($"${KpiConstants.claimstatusColName}".isin(claimStatusList:_*)))
    //        ||(($"${KpiConstants.dataSourceColName}".===("RxClaim"))&&($"${KpiConstants.claimstatusColName}".isin(claimStatusList:_*)))
    //        ||($"${KpiConstants.dataSourceColName}".===("Rx")))
    //      .drop(KpiConstants.lobProductColName, "latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name","product")
    //      .withColumn(KpiConstants.revenuecodeColName, when((length($"${KpiConstants.revenuecodeColName}").as[Int].===(3)),concat(lit("0" ),lit($"${KpiConstants.revenuecodeColName}"))).otherwise($"${KpiConstants.revenuecodeColName}"))
    //      .withColumn(KpiConstants.billtypecodeColName, when((length($"${KpiConstants.billtypecodeColName}").as[Int].===(3)),concat(lit("0" ),lit($"${KpiConstants.billtypecodeColName}"))).otherwise($"${KpiConstants.billtypecodeColName}"))
    //      .withColumn(KpiConstants.proccode2ColName, when(($"${KpiConstants.proccode2mod1ColName}".isin(KpiConstants.avoidCodeList:_*)) || ($"${KpiConstants.proccode2mod2ColName}".isin(KpiConstants.avoidCodeList:_*)),lit("NA")).otherwise($"${KpiConstants.proccode2ColName}"))
    //      .repartition(2)
    //
    //    val medmonmemqueryString = s"""SELECT * FROM ${KpiConstants.dbName}.${KpiConstants.medmonmemTblName} WHERE measure = $msrVal"""
    //    val medmonmemDf = DataLoadFunctions.dataLoadFromHiveStTable(spark,KpiConstants.dbName,KpiConstants.medmonmemTblName,medmonmemqueryString,aLiat)
    //      .filter(($"run_date".>=(ystDate)) && ($"run_date".<=(yendDate)))
    //      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
    //      .repartition(2)
    //
    //    val refHedisqueryString =s"""SELECT * FROM  ${KpiConstants.dbName}.${KpiConstants.refHedisTblName} WHERE measureid = $msrVal OR measureid= $ggMsrId"""
    //    val refHedisDf = DataLoadFunctions.dataLoadFromHiveStTable(spark,KpiConstants.dbName,KpiConstants.medmonmemTblName,refHedisqueryString,aLiat)
    //      /* val refHedisDf = DataLoadFunctions.referDataLoadFromTrtModel(spark, KpiConstants.dbName, KpiConstants.refHedisTblName)
    //                                         .filter(($"${KpiConstants.measureIdColName}".===(KpiConstants.cbpMeasureId))
    //                                              || ($"${KpiConstants.measureIdColName}".===(KpiConstants.ggMeasureId)))*/
    //      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
    //
    //
    //    val refMedqueryString = s"""SELECT * FROM  ${KpiConstants.dbName}.${KpiConstants.refmedValueSetTblName} WHERE measure_id = $msrVal"""
    //    val ref_medvaluesetDf = DataLoadFunctions.dataLoadFromHiveStTable(spark,KpiConstants.dbName,KpiConstants.medmonmemTblName,refMedqueryString,aLiat)
    //      /* val ref_medvaluesetDf = DataLoadFunctions.referDataLoadFromTrtModel(spark,KpiConstants.dbName,KpiConstants.refmedValueSetTblName)
    //                                                .filter($"${KpiConstants.measure_idColName}".===(KpiConstants.cbpMeasureId))*/
    //      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")

    /*read from db*/
    // println("counts:"+membershipDf.count()+","+ visitsDf.count()+","+medmonmemDf.count() +","+refHedisDf.count()+","+ref_medvaluesetDf.count())
    /* read from local*/
   // val ((membershipDf,visitsDf,refHedisDf,ref_medvaluesetDf)) = DataLoadFunctions.readdatafromlocal(spark,measureId,year)

  /*  val Mpath = "D:\\HealthCare Insight Docs\\NcqaNCSInput\\MEMBERSHIP_ENROLLMENT.csv"
    val membershipDf = spark.read.options(Map("inferSchema"->"true","sep"->",","header"->"true")).csv(Mpath)
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .repartition(2)
    val Vpath = "D:\\HealthCare Insight Docs\\NcqaNCSInput\\VISITS.csv"
    val visitsDf =  spark.read.options(Map("inferSchema"->"true","sep"->",","header"->"true")).csv(Vpath)
      .filter((($"${KpiConstants.dataSourceColName}".===("Claim"))&&($"${KpiConstants.claimstatusColName}".isin(claimStatusList:_*)))
      ||(($"${KpiConstants.dataSourceColName}".===("RxClaim"))&&($"${KpiConstants.claimstatusColName}".isin(claimStatusList:_*)))
      ||($"${KpiConstants.dataSourceColName}".===("Rx")))
      .drop(KpiConstants.lobProductColName, "latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name","product")
      .withColumn(KpiConstants.revenuecodeColName, when((length($"${KpiConstants.revenuecodeColName}").as[Int].===(3)),concat(lit("0" ),lit($"${KpiConstants.revenuecodeColName}"))).otherwise($"${KpiConstants.revenuecodeColName}"))
      .withColumn(KpiConstants.billtypecodeColName, when((length($"${KpiConstants.billtypecodeColName}").as[Int].===(3)),concat(lit("0" ),lit($"${KpiConstants.billtypecodeColName}"))).otherwise($"${KpiConstants.billtypecodeColName}"))
      .withColumn(KpiConstants.proccode2ColName, when(($"${KpiConstants.proccode2mod1ColName}".isin(KpiConstants.avoidCodeList:_*)) || ($"${KpiConstants.proccode2mod2ColName}".isin(KpiConstants.avoidCodeList:_*)),lit("NA")).otherwise($"${KpiConstants.proccode2ColName}")) .repartition(2)

    val Rhpath = "D:\\HealthCare Insight Docs\\NcqaNCSInput\\REF_HEDIS2019.csv"
    val refHedisDf =  spark.read.options(Map("inferSchema"->"true","sep"->",","header"->"true")).csv(Rhpath)
      .filter(($"${KpiConstants.measureIdColName}".===(KpiConstants.cbpMeasureId))
                                                 || ($"${KpiConstants.measureIdColName}".===(KpiConstants.ggMeasureId)))
        .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")

    val Rmpath = "D:\\HealthCare Insight Docs\\NcqaNCSInput\\REF_MED_VALUESET.csv"
    val ref_medvaluesetDf =  spark.read.options(Map("inferSchema"->"true","sep"->",","header"->"true")).csv(Rmpath)
      .filter($"${KpiConstants.measure_idColName}".===(KpiConstants.cbpMeasureId))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")

*/

  /*  //temporary-1//
    println("membershipDf_visitsDf_refHedisDf_ref_medvaluesetDf")
    membershipDf.show(10)
    visitsDf.show(10)
    println("membershipDfInput")
  //  membershipDf.filter($"${KpiConstants.memberidColName}" === ("95273")).show()

   // visitsDf.filter($"${KpiConstants.memberidColName}" === ("95273")).show()


 */
  val ((membershipDf,visitsDf,refHedisDf,ref_medvaluesetDf)) = DataLoadFunctions.readdatafromlocal(spark,measureId,year)

    println("MembershipDF")
    membershipDf.show(10)
    println("visitsDf")
   // visitsDf.printSchema()
    visitsDf.show(10)
    println("refHedisDf")
    refHedisDf.show(10)

    println("ref_medvaluesetDf")
    ref_medvaluesetDf.show(10)
    /* read from local*/
    //</editor-fold


    //<editor-fold desc="Eligible Population Calculation">

    //<editor-fold desc=" filter">


    val ageEndDate = year + "-12-31"
    val ageStartDate = year + "-01-01"

    val ageFilterDf = membershipDf
      .withColumn("Lastdayinmyear", UtilFunctions.add_ncqa_months(spark , $"${KpiConstants.dateofbirthColName}" , 300 ))  //  add_months($"${KpiConstants.dateofbirthColName}",300))
      .withColumn("age",when ((dayofmonth($"${KpiConstants.dateofbirthColName}")===31 && month($"${KpiConstants.dateofbirthColName}")===12),round(datediff(lit(ageEndDate), $"${KpiConstants.dateofbirthColName}")/365.25)).otherwise(datediff(lit(ageEndDate), $"${KpiConstants.dateofbirthColName}")/365.25)).filter($"age">=16 and $"age"<21 && $"${KpiConstants.genderColName}" === ("F") && $"Lastdayinmyear"=!=lit(ageEndDate))
    println("ageFilterDf")
   // ageFilterDf.filter($"${KpiConstants.memberidColName}" === ("95211")).show()

    //ageFilterDf.filter($"${KpiConstants.memberidColName}" === ("95173")).show()

   // ageFilterDf.show()

    //</editor-fold>

    //<editor-fold desc="Continuous Enrollment, Allowable Gap Calculation">

    val inputForContEnrolldf = ageFilterDf.select(KpiConstants.memberidColName, KpiConstants.benefitMedicalColname,
      KpiConstants.memStartDateColName,KpiConstants.memEndDateColName,
      KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName,
      KpiConstants.dateofbirthColName,KpiConstants.primaryPlanFlagColName )

   // println("inputForContEnrolldf")

   // inputForContEnrolldf.filter($"${KpiConstants.memberidColName}" === ("95211")).show()
   // inputForContEnrolldf.filter($"${KpiConstants.memberidColName}" === ("95173")).show()


   // inputForContEnrolldf.show()



    val benNonMedRemDf = inputForContEnrolldf.filter($"${KpiConstants.benefitMedicalColname}".===(KpiConstants.yesVal))
    // val argMapForContEnrollFunction = mutable.Map(KpiConstants.ageStartKeyName -> "12", )


   // benNonMedRemDf.show()

    val contEnrollInDf = benNonMedRemDf.withColumn(KpiConstants.contenrollLowCoName,UtilFunctions.add_ncqa_months(spark,lit(ageStartDate), 0))
      .withColumn(KpiConstants.contenrollUppCoName,UtilFunctions.add_ncqa_months(spark,lit(ageEndDate), 0))
      .withColumn(KpiConstants.anchorDateColName, UtilFunctions.add_ncqa_months(spark,lit(ageEndDate), 0))

     // println("contEnrollInDf")
   // println("contEnrollInDf")
    //contEnrollInDf.show()

    val contEnrollStep1Df = contEnrollInDf.filter((($"${KpiConstants.memStartDateColName}".>=($"${KpiConstants.contenrollLowCoName}")) && ($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.contenrollUppCoName}")))
      || (($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.contenrollLowCoName}")) && ($"${KpiConstants.memEndDateColName}".<=($"${KpiConstants.contenrollUppCoName}")))
      ||($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.contenrollLowCoName}") && ($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.contenrollUppCoName}"))))
      .withColumn(KpiConstants.anchorflagColName, when( ($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.anchorDateColName}"))
        && ($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.anchorDateColName}")), lit(1)).otherwise(lit(0)))
      .withColumn(KpiConstants.contEdFlagColName, when( ($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.contenrollUppCoName}"))
        && ($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.contenrollUppCoName}")), lit(1)).otherwise(lit(0)))

    //println("contEnrollStep1Df")
     // contEnrollStep1Df.show()

    /*Step3(select the members who satisfy both (min_start_date- ces and cee- max_end_date <= allowable gap) conditions)*/
    val listDf = contEnrollStep1Df.groupBy($"${KpiConstants.memberidColName}")
      .agg(max($"${KpiConstants.memEndDateColName}").alias(KpiConstants.maxMemEndDateColName),
        min($"${KpiConstants.memStartDateColName}").alias(KpiConstants.minMemStDateColName),
        first($"${KpiConstants.contenrollLowCoName}").alias(KpiConstants.contenrollLowCoName),
        first($"${KpiConstants.contenrollUppCoName}").alias(KpiConstants.contenrollUppCoName),
        sum($"${KpiConstants.anchorflagColName}").alias(KpiConstants.anchorflagColName))
      .filter((date_add($"max_mem_end_date",KpiConstants.days45).>=($"${KpiConstants.contenrollUppCoName}"))
        && (date_sub($"min_mem_start_date",KpiConstants.days45).<=($"${KpiConstants.contenrollLowCoName}"))
        &&($"${KpiConstants.anchorflagColName}").>(0))
      .select($"${KpiConstants.memberidColName}")

    //println("listDf")
    //listDf.show()

    val contEnrollStep2Df = contEnrollStep1Df.as("df1").join(listDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select("df1.*")

      // printf("contEnrollStep2Df")
     //contEnrollStep2Df.show()

    /*window function creation based on partioned by member_sk and order by mem_start_date*/
    val contWindowVal = Window.partitionBy(s"${KpiConstants.memberidColName}").orderBy(org.apache.spark.sql.functions.col(s"${KpiConstants.memEndDateColName}").desc,org.apache.spark.sql.functions.col(s"${KpiConstants.memStartDateColName}"))


    /* added 3 columns (date_diff(datediff b/w next start_date and current end_date for each memeber),
     anchorflag(if member is continuously enrolled on anchor date 1, otherwise 0)
     count(if date_diff>1 1, otherwise 0) over window*/
    val contEnrollStep3Df = contEnrollStep2Df.withColumn(KpiConstants.overlapFlagColName, when(($"${KpiConstants.memStartDateColName}".>=(lag($"${KpiConstants.memStartDateColName}",1).over(contWindowVal)) && $"${KpiConstants.memStartDateColName}".<=(lag($"${KpiConstants.memEndDateColName}",1).over(contWindowVal))
      && ($"${KpiConstants.memEndDateColName}".>=(lag($"${KpiConstants.memStartDateColName}",1).over(contWindowVal)) && $"${KpiConstants.memEndDateColName}".<=(lag($"${KpiConstants.memEndDateColName}",1).over(contWindowVal))))
      ,lit(1))
      .when(($"${KpiConstants.memStartDateColName}".<(lag($"${KpiConstants.memStartDateColName}",1).over(contWindowVal)))
        && ($"${KpiConstants.memEndDateColName}".>=(lag($"${KpiConstants.memStartDateColName}",1 ).over(contWindowVal)) && $"${KpiConstants.memEndDateColName}".<=(lag($"${KpiConstants.memEndDateColName}",1).over(contWindowVal)))
        ,lit(2)).otherwise(lit(0)))

      .withColumn(KpiConstants.coverageDaysColName,when($"${KpiConstants.overlapFlagColName}".===(0) ,datediff(when($"${KpiConstants.memEndDateColName}".<=($"${KpiConstants.contenrollUppCoName}"), $"${KpiConstants.memEndDateColName}").otherwise($"${KpiConstants.contenrollUppCoName}")
        ,when($"${KpiConstants.memStartDateColName}".>=($"${KpiConstants.contenrollLowCoName}"), $"${KpiConstants.memStartDateColName}").otherwise($"${KpiConstants.contenrollLowCoName}"))+ 1 )
        .when($"${KpiConstants.overlapFlagColName}".===(2), datediff( when($"${KpiConstants.contenrollLowCoName}".>=(lag( $"${KpiConstants.memStartDateColName}",1).over(contWindowVal)), $"${KpiConstants.contenrollLowCoName}").otherwise(lag( $"${KpiConstants.memStartDateColName}",1).over(contWindowVal))
          ,$"${KpiConstants.memStartDateColName}")+1 )
        .otherwise(0))

      .withColumn(KpiConstants.countColName, when(when($"${KpiConstants.overlapFlagColName}".===(0), datediff(lag($"${KpiConstants.memStartDateColName}",1).over(contWindowVal), $"${KpiConstants.memEndDateColName}"))
        .otherwise(0).>(1),lit(1))
        .otherwise(lit(0)) )


    //println("contEnrollStep3Df")

    val contEnrollStep5Df = contEnrollStep3Df.groupBy(KpiConstants.memberidColName)
      .agg(min($"${KpiConstants.memStartDateColName}").alias(KpiConstants.minMemStDateColName),
        max($"${KpiConstants.memEndDateColName}").alias(KpiConstants.maxMemEndDateColName),
        sum($"${KpiConstants.countColName}").alias(KpiConstants.countColName),
        sum($"${KpiConstants.coverageDaysColName}").alias(KpiConstants.coverageDaysColName),
        first($"${KpiConstants.contenrollLowCoName}").alias(KpiConstants.contenrollLowCoName),
        first($"${KpiConstants.contenrollUppCoName}").alias(KpiConstants.contenrollUppCoName))
      .withColumn(KpiConstants.reqCovDaysColName, (datediff($"${KpiConstants.contenrollUppCoName}", $"${KpiConstants.contenrollLowCoName}")-44))


    //println("contEnrollStep5Df")



    val contEnrollmemDf = contEnrollStep5Df.filter(((($"${KpiConstants.countColName}") + (when(date_sub($"min_mem_start_date", 1).>=($"${KpiConstants.contenrollLowCoName}"),lit(1)).otherwise(lit(0)))
      + (when(date_add($"max_mem_end_date", 1).<=($"${KpiConstants.contenrollUppCoName}"),lit(1)).otherwise(lit(0)))).<=(1) )
      && ($"${KpiConstants.coverageDaysColName}".>=($"${KpiConstants.reqCovDaysColName}")))
      .select(KpiConstants.memberidColName).distinct()


      //printf("contEnrollmemDf")
    // contEnrollmemDf.show()

    val contEnrollDf = contEnrollStep1Df.as("df1").join(contEnrollmemDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .filter($"df1.${KpiConstants.contEdFlagColName}".===(1))
      .select(s"df1.${KpiConstants.memberidColName}", s"df1.${KpiConstants.lobColName}", s"df1.${KpiConstants.lobProductColName}",s"df1.${KpiConstants.payerColName}",s"df1.${KpiConstants.primaryPlanFlagColName}").cache()

    // printf("contEnrollDf")

    // contEnrollDf.show()

  //</editor-fold>

    //<editor-fold desc="Dual Enrollment and W15 Lob filter">

    val baseOutDf = UtilFunctions.baseOutDataframeCreation(spark, contEnrollDf, lobList , measureId)

    // printf("baseOutDf")
   // baseOutDf.show()

    val w15ContEnrollDf = baseOutDf.filter($"${KpiConstants.lobColName}".isin(lobList:_*)).dropDuplicates()

      . cache()

  //  val memJoinDF = baseOutDf.filter($"${KpiConstants.lobColName}".isin(lobList:_*)).dropDuplicates()

   // .select(s"df1.${KpiConstants.memberidColName}",s"df1.${KpiConstants.payerColName}" ).distinct()

    //w15ContEnrollDf.count()

    //w15ContEnrollDf.printSchema()

   // println("Eligible Population")

    //w15ContEnrollDf.show()


  //</editor-fold>

    //<editor-fold desc="Initial Join with Ref_Hedis">visitRefHedisDf

    val argmapforRefHedis = mutable.Map(KpiConstants.eligibleDfName -> visitsDf , KpiConstants.refHedisTblName -> refHedisDf,KpiConstants.refmedValueSetTblName -> ref_medvaluesetDf)
    val allValueList = List(KpiConstants.independentLabVal, KpiConstants.hospiceVal,KpiConstants.hivVal,KpiConstants.hivType2Val,KpiConstants.disordersoftheImmuneSystemVal,KpiConstants.cervicalCytologyVal,KpiConstants.hpvTestsVal,KpiConstants.cervicalCancerVal)


    val medList =List()

    val visitRefHedisDf = UtilFunctions.joinWithRefHedisFunction(spark,argmapforRefHedis,allValueList,medList)

    println("visitRefHedisDf")

    visitRefHedisDf.printSchema()

    //visitRefHedisDf.show()

    println("visitRefHedisDf")

    // visitRefHedisDf.filter($"${KpiConstants.memberidColName}" === ("95273")).show()

    //</editor-fold>

    //<editor-fold desc="Removal of Independent Lab Visits">

    val groupList = visitsDf.schema.fieldNames.toList.dropWhile(p=> p.equalsIgnoreCase(KpiConstants.memberidColName))
    val visitgroupedDf = visitRefHedisDf.groupBy(KpiConstants.memberidColName, groupList:_*).agg(collect_list(KpiConstants.valuesetColName).alias(KpiConstants.valuesetColName))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName, KpiConstants.claimstatusColName,
        KpiConstants.dobColName,KpiConstants.supplflagColName , KpiConstants.valuesetColName,KpiConstants.genderColName)

   // val NoSuppplematalDf = visitgroupedDf.filter($"${KpiConstants.supplflagColName}".===(KpiConstants.noVal))

   // println("visitgroupedDf")

    println("visitgroupedDf")


    val indLabVisRemDf = visitgroupedDf.filter(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)
      ||((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.hpvTestsVal)))
      ||((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.cervicalCytologyVal)))

      ).repartition(2).cache()

    //</editor-fold>

    //<editor-fold desc="Hospice Removal">

    val yearStartDate = year+"-01-01"
    val yearEndDate = year+"-12-31"
   // val yearEndDate = "2019-01-01"
    val hospiceInCurrYearMemDf = indLabVisRemDf.filter(
      (!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))  &&
      (array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hospiceVal))
      && ($"${KpiConstants.serviceDateColName}".>=(yearStartDate) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))

    println( "Hospice filter")

    // hospiceInCurrYearMemDf.show()


    val finaldf =   hospiceInCurrYearMemDf .select(KpiConstants.memberidColName)
      .dropDuplicates()

    //</editor-fold>


    //<editor-fold desc="Cervical Cancer Value Set Exclusion">


    //</editor-fold>

  //  val totalPopOutDf = w15ContEnrollDf.except(finaldf).distinct()

    val totalPopOutDf = w15ContEnrollDf.except(w15ContEnrollDf.filter($"${KpiConstants.memberidColName}".isin(
      finaldf.rdd.map(r=>r.getString(0)).collect():_*
    )))

    /*
    println("Eligible Population")
    //totalPopOutDf.show()
      totalPopOutDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("D:\\HealthCare Insight Docs\\NcqaNCSOutput")

*/
    val denominatorDf = totalPopOutDf.select(KpiConstants.memberidColName).distinct()
    val argmapForVisittJoin = mutable.Map(KpiConstants.membershipTblName -> denominatorDf , KpiConstants.visitTblName -> indLabVisRemDf)
    val visitJoinedOutDf = UtilFunctions.initialJoinFunction(spark,argmapForVisittJoin)


    val ReqExclusionDf = visitJoinedOutDf.filter(
      (array_contains($"${KpiConstants.valuesetColName}",KpiConstants.cervicalCancerVal)
        ||(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hivVal))
         ||(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.disordersoftheImmuneSystemVal))
         ||(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hivType2Val))
          )
        &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
         && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))
     && ($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.dobColName}")))



    val rxdf  = ReqExclusionDf.select(KpiConstants.memberidColName).dropDuplicates()
/*
    rxdf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("D:\\HealthCare Insight Docs\\NcqaNCSOutput")
*/

    val numDf = denominatorDf.except(rxdf).distinct()

    val numeratorVisistDf =  numDf.as("df1").join(visitJoinedOutDf.as("df2")
      , $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}"
      , KpiConstants.innerJoinType)
      .select ("df1.*" ,s"df2.${KpiConstants.serviceDateColName}" , s"df2.${KpiConstants.valuesetColName}" , s"df2.${KpiConstants.supplflagColName}" , s"df2.${KpiConstants.claimstatusColName}" )

    val nonSupNumVisitDf = numeratorVisistDf.filter(($"${KpiConstants.supplflagColName}".===("N") )
      && ($"${KpiConstants.claimstatusColName}".isin(numClaimStatusList:_*))
      && ($"${KpiConstants.serviceDateColName}".>=(yearStartDate) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate))
    ).cache()


    val ncsNumNonsupDf =  nonSupNumVisitDf.filter(( (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.hpvTestsVal)))
        || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.cervicalCytologyVal))
        && ($"${KpiConstants.serviceDateColName}".>=(yearStartDate) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select($"${KpiConstants.memberidColName}"  )
      . distinct().cache()

//  println("ncsNumNonsupDf")
/*
    ncsNumNonsupDf.distinct().coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("D:\\HealthCare Insight Docs\\NcqaNCSOutput")


*/
    totalPopOutDf.printSchema()


    val toutStrDf =totalPopOutDf.select($"${KpiConstants.memberidColName}",  $"${KpiConstants.memberidColName}".as(KpiConstants.ncqaOutmemberIdCol),
       $"${KpiConstants.payerColName}".as(KpiConstants.ncqaOutPayerCol)) .withColumn(KpiConstants.ncqaOutMeasureCol,lit(measureId))

    toutStrDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .parquet("D:\\HealthCare Insight Docs\\ReadParquet")

    val OutStrDf = spark.read.parquet("D:\\HealthCare Insight Docs\\ReadParquet").repartition(2).cache()

    denominatorDf. coalesce(1)
      .write
      .mode(SaveMode.Append)
      .parquet("D:\\HealthCare Insight Docs\\ReadPqEpop")

    val eligiblePopDf = spark.read.parquet("D:\\HealthCare Insight Docs\\ReadPqEpop").repartition(2).cache()

    rxdf. coalesce(1)
      .write
      .mode(SaveMode.Append)
      .parquet("D:\\HealthCare Insight Docs\\ReadPqREx")

    val rExDf = spark.read.parquet("D:\\HealthCare Insight Docs\\ReadPqREx").repartition(2).cache()

    ncsNumNonsupDf. coalesce(1)
      .write
      .mode(SaveMode.Append)
      .parquet("D:\\HealthCare Insight Docs\\ReadPqNcsNum")

    val ncsNumfinalDf = spark.read.parquet("D:\\HealthCare Insight Docs\\ReadPqNcsNum").repartition(2).cache()


    //<editor-fold desc="Ncqa Output Creation">


    val outMap = mutable.Map(KpiConstants.totalPopDfName -> OutStrDf, KpiConstants.eligibleDfName -> eligiblePopDf  ,
      KpiConstants.mandatoryExclDfname -> rExDf , KpiConstants.optionalExclDfName -> spark.emptyDataFrame,
      KpiConstants.numeratorDfName -> ncsNumfinalDf )


    val outDf = UtilFunctions.ncqaOutputDfCreation(spark,outMap,measureId)

    outDf.printSchema()

    outDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("D:\\HealthCare Insight Docs\\NCS_FINAL_OUTPUT")


    //</editor-fold>

    spark.sparkContext.stop()



  }

}
