package com.itc.ncqa.main

import com.itc.ncqa.Constants.KpiConstants
import com.itc.ncqa.Functions.{DataLoadFunctions, UtilFunctions}
import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkConf
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

import scala.collection.mutable

object NcqaSMD {

  def main(args: Array[String]): Unit = {


    val measureId = "SMD"
    val year = "2018"
    val PreYrStartDate = year.toInt -1 +"-01-01"

       val conf = new SparkConf().setAppName("NcqaProgram").setMaster("local[*]")
    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      .set("hive.exec.dynamic.partition.mode", "nonstrict")
      .set("spark.sql.shuffle.partitions","5")
    val spark = SparkSession.builder().config(conf).getOrCreate()

     import spark.implicits._
    val rootLogger=Logger.getRootLogger()
    rootLogger.setLevel(Level.ERROR)
    //</editor-fold>

    //<editor-fold desc="Loading Required Tables to memory">

    val lobList = List(  KpiConstants.medicaidLobName , KpiConstants.mmdLobName )
    val claimStatusList = List(KpiConstants.paidVal, KpiConstants.suspendedVal, KpiConstants.pendingVal , KpiConstants.deniedVal)

    val ((membershipDf,visitsDf,refHedisDf,ref_medvaluesetDf)) = DataLoadFunctions.readdatafromlocal(spark,measureId,year)

   // println("MembershipDF")
   // membershipDf.show(10)
   // println("visitsDf")
    // visitsDf.printSchema()
   // visitsDf.show(10)
   // println("refHedisDf")
   // refHedisDf.show(10)

   // println("ref_medvaluesetDf")
    // ref_medvaluesetDf.show(10)
    /* read from local*/
    //</editor-fold


    //<editor-fold desc="Eligible Population Calculation">

    //<editor-fold desc=" filter">


    val ageEndDate = year + "-12-31"
    val ageStartDate = year + "-01-01"

    val ageFilterDf = membershipDf.filter(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",KpiConstants.months216).<=(ageEndDate)
      && UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",KpiConstants.months780).>(ageEndDate))

     //ageFilterDf.show()

    //ageFilterDf.filter($"${KpiConstants.memberidColName}" === ("100377")).show()


    //</editor-fold>

    //<editor-fold desc="Continuous Enrollment, Allowable Gap Calculation">

    val inputForContEnrolldf = ageFilterDf.select(KpiConstants.memberidColName, KpiConstants.benefitMedicalColname,
      KpiConstants.memStartDateColName,KpiConstants.memEndDateColName,
      KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName,
      KpiConstants.dateofbirthColName,KpiConstants.primaryPlanFlagColName )



    val benNonMedRemDf = inputForContEnrolldf.filter($"${KpiConstants.benefitMedicalColname}".===(KpiConstants.yesVal))


    val contEnrollInDf = benNonMedRemDf.withColumn(KpiConstants.contenrollLowCoName,UtilFunctions.add_ncqa_months(spark,lit(ageStartDate), 0))
      .withColumn(KpiConstants.contenrollUppCoName,UtilFunctions.add_ncqa_months(spark,lit(ageEndDate), 0))
      .withColumn(KpiConstants.anchorDateColName, UtilFunctions.add_ncqa_months(spark,lit(ageEndDate), 0))


    val contEnrollStep1Df = contEnrollInDf.filter((($"${KpiConstants.memStartDateColName}".>=($"${KpiConstants.contenrollLowCoName}")) && ($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.contenrollUppCoName}")))
      || (($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.contenrollLowCoName}")) && ($"${KpiConstants.memEndDateColName}".<=($"${KpiConstants.contenrollUppCoName}")))
      ||($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.contenrollLowCoName}") && ($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.contenrollUppCoName}"))))
      .withColumn(KpiConstants.anchorflagColName, when( ($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.anchorDateColName}"))
        && ($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.anchorDateColName}")), lit(1)).otherwise(lit(0)))
      .withColumn(KpiConstants.contEdFlagColName, when( ($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.contenrollUppCoName}"))
        && ($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.contenrollUppCoName}")), lit(1)).otherwise(lit(0)))


    /*Step3(select the members who satisfy both (min_start_date- ces and cee- max_end_date <= allowable gap) conditions)*/
    val listDf = contEnrollStep1Df.groupBy($"${KpiConstants.memberidColName}")
      .agg(max($"${KpiConstants.memEndDateColName}").alias(KpiConstants.maxMemEndDateColName),
        min($"${KpiConstants.memStartDateColName}").alias(KpiConstants.minMemStDateColName),
        first($"${KpiConstants.contenrollLowCoName}").alias(KpiConstants.contenrollLowCoName),
        first($"${KpiConstants.contenrollUppCoName}").alias(KpiConstants.contenrollUppCoName),
        sum($"${KpiConstants.anchorflagColName}").alias(KpiConstants.anchorflagColName))
      .filter((date_add($"max_mem_end_date",KpiConstants.days45).>=($"${KpiConstants.contenrollUppCoName}"))
        && (date_sub($"min_mem_start_date",KpiConstants.days45).<=($"${KpiConstants.contenrollLowCoName}"))
        &&($"${KpiConstants.anchorflagColName}").>(0))
      .select($"${KpiConstants.memberidColName}")


    val contEnrollStep2Df = contEnrollStep1Df.as("df1").join(listDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select("df1.*")

    /*window function creation based on partioned by member_sk and order by mem_start_date*/
    val contWindowVal = Window.partitionBy(s"${KpiConstants.memberidColName}").orderBy(org.apache.spark.sql.functions.col(s"${KpiConstants.memEndDateColName}").desc,org.apache.spark.sql.functions.col(s"${KpiConstants.memStartDateColName}"))


    /* added 3 columns (date_diff(datediff b/w next start_date and current end_date for each memeber),
     anchorflag(if member is continuously enrolled on anchor date 1, otherwise 0)
     count(if date_diff>1 1, otherwise 0) over window*/
    val contEnrollStep3Df = contEnrollStep2Df.withColumn(KpiConstants.overlapFlagColName, when(($"${KpiConstants.memStartDateColName}".>=(lag($"${KpiConstants.memStartDateColName}",1).over(contWindowVal)) && $"${KpiConstants.memStartDateColName}".<=(lag($"${KpiConstants.memEndDateColName}",1).over(contWindowVal))
      && ($"${KpiConstants.memEndDateColName}".>=(lag($"${KpiConstants.memStartDateColName}",1).over(contWindowVal)) && $"${KpiConstants.memEndDateColName}".<=(lag($"${KpiConstants.memEndDateColName}",1).over(contWindowVal))))
      ,lit(1))
      .when(($"${KpiConstants.memStartDateColName}".<(lag($"${KpiConstants.memStartDateColName}",1).over(contWindowVal)))
        && ($"${KpiConstants.memEndDateColName}".>=(lag($"${KpiConstants.memStartDateColName}",1 ).over(contWindowVal)) && $"${KpiConstants.memEndDateColName}".<=(lag($"${KpiConstants.memEndDateColName}",1).over(contWindowVal)))
        ,lit(2)).otherwise(lit(0)))

      .withColumn(KpiConstants.coverageDaysColName,when($"${KpiConstants.overlapFlagColName}".===(0) ,datediff(when($"${KpiConstants.memEndDateColName}".<=($"${KpiConstants.contenrollUppCoName}"), $"${KpiConstants.memEndDateColName}").otherwise($"${KpiConstants.contenrollUppCoName}")
        ,when($"${KpiConstants.memStartDateColName}".>=($"${KpiConstants.contenrollLowCoName}"), $"${KpiConstants.memStartDateColName}").otherwise($"${KpiConstants.contenrollLowCoName}"))+ 1 )
        .when($"${KpiConstants.overlapFlagColName}".===(2), datediff( when($"${KpiConstants.contenrollLowCoName}".>=(lag( $"${KpiConstants.memStartDateColName}",1).over(contWindowVal)), $"${KpiConstants.contenrollLowCoName}").otherwise(lag( $"${KpiConstants.memStartDateColName}",1).over(contWindowVal))
          ,$"${KpiConstants.memStartDateColName}")+1 )
        .otherwise(0))

      .withColumn(KpiConstants.countColName, when(when($"${KpiConstants.overlapFlagColName}".===(0), datediff(lag($"${KpiConstants.memStartDateColName}",1).over(contWindowVal), $"${KpiConstants.memEndDateColName}"))
        .otherwise(0).>(1),lit(1))
        .otherwise(lit(0)) )

    val contEnrollStep5Df = contEnrollStep3Df.groupBy(KpiConstants.memberidColName)
      .agg(min($"${KpiConstants.memStartDateColName}").alias(KpiConstants.minMemStDateColName),
        max($"${KpiConstants.memEndDateColName}").alias(KpiConstants.maxMemEndDateColName),
        sum($"${KpiConstants.countColName}").alias(KpiConstants.countColName),
        sum($"${KpiConstants.coverageDaysColName}").alias(KpiConstants.coverageDaysColName),
        first($"${KpiConstants.contenrollLowCoName}").alias(KpiConstants.contenrollLowCoName),
        first($"${KpiConstants.contenrollUppCoName}").alias(KpiConstants.contenrollUppCoName))
      .withColumn(KpiConstants.reqCovDaysColName, (datediff($"${KpiConstants.contenrollUppCoName}", $"${KpiConstants.contenrollLowCoName}")-44))

    val contEnrollmemDf = contEnrollStep5Df.filter(((($"${KpiConstants.countColName}") + (when(date_sub($"min_mem_start_date", 1).>=($"${KpiConstants.contenrollLowCoName}"),lit(1)).otherwise(lit(0)))
      + (when(date_add($"max_mem_end_date", 1).<=($"${KpiConstants.contenrollUppCoName}"),lit(1)).otherwise(lit(0)))).<=(1) )
      && ($"${KpiConstants.coverageDaysColName}".>=($"${KpiConstants.reqCovDaysColName}")))
      .select(KpiConstants.memberidColName).distinct()

    val contEnrollDf = contEnrollStep1Df.as("df1").join(contEnrollmemDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .filter($"df1.${KpiConstants.contEdFlagColName}".===(1))
      .select(s"df1.${KpiConstants.memberidColName}", s"df1.${KpiConstants.lobColName}", s"df1.${KpiConstants.lobProductColName}",s"df1.${KpiConstants.payerColName}",s"df1.${KpiConstants.primaryPlanFlagColName}").cache()


    //</editor-fold>

    //<editor-fold desc="Dual Enrollment and W15 Lob filter">

    val baseOutDf = UtilFunctions.baseOutDataframeCreation(spark, contEnrollDf, lobList , measureId)

    val payerlist = List(KpiConstants.sn1PayerVal,KpiConstants.sn2PayerVal,KpiConstants.sn3PayerVal,KpiConstants.mmpPayerVal)

    val w15ContEnrollDf = baseOutDf.filter($"${KpiConstants.lobColName}".isin(lobList:_*) &&

      (!$"${KpiConstants.payerColName}".isin(payerlist:_*))
    ).dropDuplicates()
      . cache()

   // println("Payer List")

   // w15ContEnrollDf.select($"${KpiConstants.payerColName}" ).distinct().show

   //  println("w15ContEnrollDf")

   // w15ContEnrollDf.filter($"${KpiConstants.memberidColName}" === ("100377")).show()

   // w15ContEnrollDf.show()


    //</editor-fold>

    //<editor-fold desc="Initial Join with Ref_Hedis">visitRefHedisDf

    val argmapforRefHedis = mutable.Map(KpiConstants.eligibleDfName -> visitsDf , KpiConstants.refHedisTblName -> refHedisDf,KpiConstants.refmedValueSetTblName -> ref_medvaluesetDf)
    val allValueList = List(KpiConstants.independentLabVal, KpiConstants.hospiceVal
      ,KpiConstants.bHStandAloneAcuteInpatientVal,KpiConstants.schizophreniaVal,KpiConstants.visitSettingUnspecifiedVal
      ,KpiConstants.acuteInpatientPosVal  ,KpiConstants.outPatientVal,KpiConstants.observationVal
      ,KpiConstants.edVal,KpiConstants.nonAcuteInPatientVal ,KpiConstants.telehealthModifierVal
      ,KpiConstants.telehealthPosVal,KpiConstants.telephoneVisitsVal,KpiConstants.onlineAssesmentVal
      ,KpiConstants.hba1cTestVal , KpiConstants.ldlcTestsVal,KpiConstants.diabetesVal,KpiConstants.diabetesExclusionVal
      ,KpiConstants.outpatientPosVal , KpiConstants.bhOutpatientVal,KpiConstants.partialHospitalizationPosVal,KpiConstants.partialHospitalizationIntensiveOutpatientVal
      ,KpiConstants.communityMentalHealthCenterPosVal , KpiConstants.bhStandAloneNonacuteInpatientVal,KpiConstants.nonacuteInpatientPosVal,KpiConstants.edPosVal
      ,KpiConstants.electroconvulsiveTherapyVal,KpiConstants.acuteInpatientVal  , KpiConstants.diabetesMedicationVal
    )


    val medList =List(KpiConstants.diabetesMedicationVal)

    val visitRefHedisDf = UtilFunctions.joinWithRefHedisFunction(spark,argmapforRefHedis,allValueList,medList)

    println("visitRefHedisDf")

    visitRefHedisDf.select($"${KpiConstants.memberidColName}",$"${KpiConstants.valuesetColName}")

  //  visitRefHedisDf.filter($"${KpiConstants.memberidColName}" === ("95314")).show()


    // visitRefHedisDf.filter($"${KpiConstants.memberidColName}" === ("95273")).show()

    //</editor-fold>

    //<editor-fold desc="Removal of Independent Lab Visits">

    val groupList = visitsDf.schema.fieldNames.toList.dropWhile(p=> p.equalsIgnoreCase(KpiConstants.memberidColName))
    val visitgroupedDf = visitRefHedisDf.groupBy(KpiConstants.memberidColName, groupList:_*).agg(collect_list(KpiConstants.valuesetColName).alias(KpiConstants.valuesetColName))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName, KpiConstants.claimstatusColName,
        KpiConstants.dobColName,KpiConstants.supplflagColName , KpiConstants.valuesetColName,KpiConstants.genderColName
      ,KpiConstants.poscodeColName
      )

   /* println("visitgroupedDf")
    visitgroupedDf.filter($"${KpiConstants.memberidColName}" === ("100267")).show()

     val noSupvisitgroupedDf = visitgroupedDf.filter($"${KpiConstants.supplflagColName}".===(KpiConstants.noVal))


    println("noSupvisitgroupedDf")
    noSupvisitgroupedDf.filter($"${KpiConstants.memberidColName}" === ("100267")).show()
*/

    val indLabVisRemDf = visitgroupedDf.filter(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)
      ||((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.hba1cTestVal)))
      ||((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ldlcTestsVal)))

    ).repartition(2).cache()

      println("indLabVisRemDf")
   // indLabVisRemDf.filter($"${KpiConstants.memberidColName}" === ("95314")).show()

    val membertotalDf = w15ContEnrollDf.dropDuplicates()
    val argmapForVisittJoin = mutable.Map(KpiConstants.membershipTblName -> membertotalDf , KpiConstants.visitTblName -> indLabVisRemDf)
    val visitJoinedOutDf = UtilFunctions.initialJoinFunction(spark,argmapForVisittJoin)


    visitJoinedOutDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .parquet("D:\\HealthCare Insight Docs\\ReadParquet\\PqVisit")

    val visitJoinDf = spark.read.parquet("D:\\HealthCare Insight Docs\\ReadParquet\\PqVisit").repartition(2).cache()

    println("visitJoinDf")
   // visitJoinDf.filter($"${KpiConstants.memberidColName}" === ("95314")).show()


    val yearStartDate = year+"-01-01"
    val yearEndDate = year+"-12-31"

    //</editor-fold>

    //<editor-fold desc="Hospice Removal">

    // val yearEndDate = "2019-01-01"
    val hospiceInCurrYearMemDf = indLabVisRemDf.filter(
      (!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))  &&
        (array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hospiceVal))
        && ($"${KpiConstants.serviceDateColName}".>=(yearStartDate) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))

    println( "Hospice members")

  //   hospiceInCurrYearMemDf.show()

    println("hospiceInCurrYearMemDf")
   // hospiceInCurrYearMemDf.filter($"${KpiConstants.memberidColName}" === ("95314")).show()

    val hospicefinaldf =   hospiceInCurrYearMemDf .select(KpiConstants.memberidColName)
      .dropDuplicates()

    //</editor-fold>


    val hosiceremovalDf = visitJoinDf.except(visitJoinDf.filter($"${KpiConstants.memberidColName}".isin(
      hospicefinaldf.rdd.map(r=>r.getString(0)).collect():_*
    )))



    println("hosiceremovalDf")
    //hosiceremovalDf.filter($"${KpiConstants.memberidColName}" === ("95314")).show()

    val eventsVisitsDf = hosiceremovalDf.filter($"${KpiConstants.supplflagColName}".===("N")
      && ($"${KpiConstants.claimstatusColName}".isin(claimStatusList:_*))).cache()
    eventsVisitsDf.count()
  //  hosiceremovalDf.show()

    val schievent1Df = eventsVisitsDf
      .filter(
        (((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.bHStandAloneAcuteInpatientVal))
            || ((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.visitSettingUnspecifiedVal))
          &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.acuteInpatientPosVal)))
          )
          &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.schizophreniaVal))
          &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal))
          )
          &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate))
          &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))
          )
    ) .select(KpiConstants.memberidColName )
      .repartition(2).cache()

    println("schievent1Df")
    //schievent1Df.show()

    //schievent1Df.filter($"${KpiConstants.memberidColName}" === ("95314")).show()

    val schievent2Df = eventsVisitsDf
      .filter(
        ( ((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.visitSettingUnspecifiedVal))
          &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outpatientPosVal)))

          || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.bhOutpatientVal))

          || ((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.visitSettingUnspecifiedVal))
          && (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.partialHospitalizationPosVal)))

          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.partialHospitalizationIntensiveOutpatientVal))

          ||((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.visitSettingUnspecifiedVal))
          &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.communityMentalHealthCenterPosVal)))

           ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.electroconvulsiveTherapyVal))

          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.observationVal))

          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.edVal))

          ||((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.visitSettingUnspecifiedVal))
          &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.edPosVal)) )

          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.bhStandAloneNonacuteInpatientVal))

          ||((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.visitSettingUnspecifiedVal))
          &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.nonacuteInpatientPosVal)))

          ||((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.visitSettingUnspecifiedVal))
          && (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal)))
          )

         // &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal))

          &&((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.schizophreniaVal))
          &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))

          &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate))
          &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      ) //.select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)
      .repartition(2).cache()

    /*
    val schi2event2Df =  eventsVisitsDf .filter(

      (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.electroconvulsiveTherapyVal))
        &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate))
        &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))) )
      //.select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)
      .repartition(2).cache()
*/
    val step1Df = schievent2Df //.union(schi2event2Df)

    println("step1Df")

   // step1Df.filter($"${KpiConstants.memberidColName}" === ("95314")).show()

    val schievent2MemVisits1Df = step1Df.groupBy(KpiConstants.memberidColName)
      .agg(countDistinct(KpiConstants.serviceDateColName).alias(KpiConstants.countColName))

    val schievent2_1Df = schievent2MemVisits1Df.filter($"${KpiConstants.countColName}".>=(2))
      .select(KpiConstants.memberidColName)

    println("schievent2_1Df")

   //schievent2_1Df.filter($"${KpiConstants.memberidColName}" === ("95314")).show()

val step1eventvistDf =    schievent2_1Df.union(schievent1Df) .select(KpiConstants.memberidColName ).distinct()

    println("step1eventvistDf")
   // step1eventvistDf.filter($"${KpiConstants.memberidColName}" === ("95314")).show()

    val step2VisitsDf = eventsVisitsDf.filter($"${KpiConstants.memberidColName}".isin(step1eventvistDf.rdd.map(r => r.getString(0)).collect():_*)).cache()


    val event1Df = step2VisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.acuteInpatientVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabetesVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&($"${KpiConstants.serviceDateColName}".>=(PreYrStartDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)
    //</editor-fold>
    // println("event1Df")
   // event1Df.show()

    println("event1Df")
  //  event1Df.filter($"${KpiConstants.memberidColName}" === ("95314")).show()


    //<editor-fold desc="Second Event">

    val event2Step1Df= step2VisitsDf.filter((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.observationVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.edVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.nonAcuteInPatientVal)))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabetesVal))
      &&((!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal)))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)))
      &&(($"${KpiConstants.serviceDateColName}".>=(PreYrStartDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName).distinct()

    println("event2Step1Df")
    //event2Step1Df.filter($"${KpiConstants.memberidColName}" === ("95314")).show()

    val event2Step2Df = step2VisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabetesVal))
      &&((!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telephoneVisitsVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.onlineAssesmentVal)))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&($"${KpiConstants.serviceDateColName}".>=(PreYrStartDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName).distinct()

    println("event2Step2Df")
//    event2Step2Df.show

    //event2Step2Df.filter($"${KpiConstants.memberidColName}" === ("95314")).show()
    val event2AtLeast1VisitDf = event2Step1Df.intersect(event2Step2Df)

    println("--------------------event2AtLeast1VisitDf--------------------")
    //event2AtLeast1VisitDf.filter($"${KpiConstants.memberidColName}" === ("95314")).show()
    /*member_id, count of visits*/
    val event2MemVisits1Df = event2AtLeast1VisitDf.groupBy(KpiConstants.memberidColName)
      .agg(countDistinct(KpiConstants.serviceDateColName).alias(KpiConstants.countColName))

    println("--------------------event2MemVisits1Df--------------------")
    //event2MemVisits1Df.filter($"${KpiConstants.memberidColName}" === ("95314")).show()


    //<editor-fold desc="2 or more visits">

    val event2_1Df = event2MemVisits1Df.filter($"${KpiConstants.countColName}".>=(2))
      .select(KpiConstants.memberidColName)
    //</editor-fold>

    //<editor-fold desc="1 Visit">

    println("event2_1Df")
    //event2_1Df.filter($"${KpiConstants.memberidColName}" === ("95314")).show()

    val diabeve2df = event2AtLeast1VisitDf.except(event2AtLeast1VisitDf.filter($"${KpiConstants.memberidColName}".isin(event2_1Df.rdd.map(r => r.getString(0)).collect():_*)))

    val oneVisitInDf = event2MemVisits1Df.select(KpiConstants.memberidColName).except(event2_1Df).as("df1")
    .join(step2VisitsDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}"
    , KpiConstants.innerJoinType)
      .select("df2.*")

    //val oneVisitInDf = event2MemVisits1Df.except(event2MemVisits1Df
     // .filter($"${KpiConstants.memberidColName}".isin(event2_1Df.rdd.map(r => r.getString(0)).collect():_*)))



    println("oneVisitInDf")
    //oneVisitInDf.filter($"${KpiConstants.memberidColName}" === ("95314")).show()


    val event2Step3Df= oneVisitInDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.observationVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.edVal)))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabetesVal))
      &&((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal)))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&($"${KpiConstants.serviceDateColName}".>=(PreYrStartDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)

    println("event2Step3Df")
    //event2Step3Df.filter($"${KpiConstants.memberidColName}" === ("95314")).show()

    val event2Step4Df = oneVisitInDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabetesVal))
      &&((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telephoneVisitsVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.onlineAssesmentVal)))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&($"${KpiConstants.serviceDateColName}".>=(PreYrStartDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)

    println("event2Step4Df")
    //event2Step4Df.filter($"${KpiConstants.memberidColName}" === ("95314")).show()

    val event2_2Df = (event2Step3Df.union(event2Step4Df)).as("df1").join(diabeve2df.as("df2"), $"df1.${KpiConstants.memberidColName}"=== $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
                                   .filter($"df1.${KpiConstants.serviceDateColName}".=!=($"df2.${KpiConstants.serviceDateColName}"))
                                   .select(s"df1.${KpiConstants.memberidColName}")
    //</editor-fold>

    val event2Df = event2_1Df.union(event2_2Df) .select(KpiConstants.memberidColName)

    println("event2Df")
   // event2Df.filter($"${KpiConstants.memberidColName}" === ("95314")).show()

    //</editor-fold>

    //<editor-fold desc="Third Event">

    val event3Df = step2VisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabetesMedicationVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&($"${KpiConstants.serviceDateColName}".>=(PreYrStartDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)
    //</editor-fold>

    println("event3Df")
   // event3Df.filter($"${KpiConstants.memberidColName}" === ("95314")).show()



   val diabstep2Df = event1Df.union(event2Df).union(event3Df)

//    val diabstep2Df  = diabevent1df.union(diabevent2Df).union(diabevent3df).union(diabevent4df)

    println("diabstep2Df")
   // diabstep2Df.filter($"${KpiConstants.memberidColName}" === ("95314")).show()

  //  println("diabstep2Df")
   // diabstep2Df.show()

     //step1eventvistDf.except(diabstep2Df)

    val ePopDf =  step1eventvistDf.filter($"${KpiConstants.memberidColName}".isin(
      diabstep2Df.rdd.map(r=>r.getString(0)).collect():_* ))

    println("Eligible Pop")
   // memeventdf.show
/*
    ePopDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("D:\\HealthCare Insight Docs\\SMD_Output")
*/
//    spark.sparkContext.stop()

    val tempnumstep1visitDf =  hosiceremovalDf.filter($"${KpiConstants.memberidColName}".isin(
      ePopDf.rdd.map(r=>r.getString(0)).collect():_* ))

    //tempnumstep1visitDf.filter($"${KpiConstants.memberidColName}" === ("102767")).show()


    val temphba1cDf = tempnumstep1visitDf.filter(
      (array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hba1cTestVal))
        &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate))
        &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)) )
      .select($"${KpiConstants.memberidColName}"  )
      . distinct().cache()

    println("temphba1cDf")

    temphba1cDf.filter($"${KpiConstants.memberidColName}" === ("102767")).show()

    val templdlcDf = tempnumstep1visitDf.filter(
      (array_contains($"${KpiConstants.valuesetColName}",KpiConstants.ldlcTestsVal))
        &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate))
        &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)) )
      .select($"${KpiConstants.memberidColName}"  )
      . distinct().cache()

    println("templdlcDf")

    templdlcDf.filter($"${KpiConstants.memberidColName}" === ("102767")).show()

    val tempnumstep1df = (temphba1cDf.intersect(templdlcDf))
      .select($"${KpiConstants.memberidColName}"  )
      . distinct().cache()


    println("tempnumstep1df")

//    tempnumstep1df.filter($"${KpiConstants.memberidColName}" === ("102767")).show()


   // val totalPopOutDf  = hosiceremovalDf.filter($"${KpiConstants.memberidColName}".isin(tempnumDf.rdd.map(r => r.getString(0)).collect():_*)).cache()

    val tempnumvistsdf = ePopDf.except(tempnumstep1df)


    println("tempnumvistsdf")

  //  tempnumvistsdf.filter($"${KpiConstants.memberidColName}" === ("102767")).show()


  //  val tempnumvistsdf = ePopDf.except(tempFinalNumDf)

   val totalPopOutDf  = hosiceremovalDf.filter($"${KpiConstants.memberidColName}".isin(tempnumvistsdf.rdd.map(r => r.getString(0)).collect():_*)).cache()

    println("totalPopOutDf")

    //totalPopOutDf.filter($"${KpiConstants.memberidColName}" === ("102767")).show()

    //println("Diabetes")
    //totalPopOutDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.diabetesVal)
    //  && $"${KpiConstants.memberidColName}" === ("102767")) ).show()
    //println("reverseDiabetes")
    //totalPopOutDf.filter(!(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.diabetesVal)
      //&& $"${KpiConstants.memberidColName}" === ("102767"))).show()

    val diaboptExclusionDf = totalPopOutDf.filter(
      (array_contains($"${KpiConstants.valuesetColName}",KpiConstants.diabetesVal))
        //  &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
        &&($"${KpiConstants.serviceDateColName}".>=(PreYrStartDate))
        &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))
        && ($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.dobColName}")))
      .select(KpiConstants.memberidColName).distinct

    //println("diaboptExclusionDf")

    //diaboptExclusionDf.filter($"${KpiConstants.memberidColName}" === ("102767")).show()

    val diabexoptExclusionDf = totalPopOutDf.filter(
      (array_contains($"${KpiConstants.valuesetColName}",KpiConstants.diabetesExclusionVal))
        //&&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
        &&($"${KpiConstants.serviceDateColName}".>=(PreYrStartDate))
        &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))
        && ($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.dobColName}")))
      .select(KpiConstants.memberidColName).distinct

    println("diabexoptExclusionDf")

    diabexoptExclusionDf.filter($"${KpiConstants.memberidColName}" === ("102767")).show()

    val optExclusionDf =  (diabexoptExclusionDf.except(diaboptExclusionDf))
      .select(KpiConstants.memberidColName).distinct


    println("optExclusionDf")

  //  optExclusionDf.filter($"${KpiConstants.memberidColName}" === ("102767")).show()

    //optExclusionDf.show()
/*
    optExclusionDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("D:\\HealthCare Insight Docs\\SMD_Output")

*/
    val numSmdDf = tempnumstep1df.except(optExclusionDf)


    println("numSmdDf")

//    numSmdDf.filter($"${KpiConstants.memberidColName}" === ("102767")).show()

   // val numSmdDf = tempFinalNumDf.except(optExclusionDf)

  /*  numSmdDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("D:\\HealthCare Insight Docs\\SMD_Output")
*/

    val toutStrDf =tempnumstep1visitDf.select($"${KpiConstants.memberidColName}",  $"${KpiConstants.memberidColName}".as(KpiConstants.ncqaOutmemberIdCol),
      $"${KpiConstants.payerColName}".as(KpiConstants.ncqaOutPayerCol)) .withColumn(KpiConstants.ncqaOutMeasureCol,lit(measureId)).distinct()


    //<editor-fold desc="Ncqa Output Creation">


    val outMap = mutable.Map(KpiConstants.totalPopDfName -> toutStrDf, KpiConstants.eligibleDfName -> ePopDf  ,
      KpiConstants.mandatoryExclDfname -> spark.emptyDataFrame , KpiConstants.optionalExclDfName -> optExclusionDf,
      KpiConstants.numeratorDfName -> numSmdDf )


    val outDf = UtilFunctions.ncqaOutputDfCreation(spark,outMap,measureId)

    outDf.printSchema()

    outDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("D:\\HealthCare Insight Docs\\SMD_Output")


  }


}
