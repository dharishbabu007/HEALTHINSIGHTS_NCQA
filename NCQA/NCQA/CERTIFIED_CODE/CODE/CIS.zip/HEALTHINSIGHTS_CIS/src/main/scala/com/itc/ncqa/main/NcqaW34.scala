package com.itc.ncqa.main

import com.itc.ncqa.Constants.KpiConstants
import com.itc.ncqa.Functions.{DataLoadFunctions, UtilFunctions}
import org.apache.spark.sql.SparkSession
//import com.itc.ncqa.Functions.SparkObject._
import org.apache.spark.SparkConf
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.log4j.{Level,Logger}
import scala.collection.mutable

//case class Member(member_id:String, service_date:Date)
//case class GroupMember(member_id:String, dateList:List[Long])

object NcqaW34 {


    def main(args: Array[String]): Unit = {

        //<editor-fold desc="Reading program arguments and SaprkSession oBject creation">

//        val year = args(0)
//        val lob_name = args(1)
//        val programType = args(2)
//        val dbName = args(3)
//        val measureId = args(4)
//        var data_source = ""
val measureId = "W34"
 val year = "2018"

        val conf = new SparkConf().setAppName("NcqaProgram").setMaster("local[*]")
        conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
          .set("hive.exec.dynamic.partition.mode", "nonstrict")
      .set("spark.sql.shuffle.partitions","5")


        val spark = SparkSession.builder().config(conf).getOrCreate()
        import spark.implicits._
        //</editor-fold>
      val rootLogger=Logger.getRootLogger()
      rootLogger.setLevel(Level.ERROR)
      //<editor-fold desc="Loading Required Tables to memory">


       val ((membershipDf,visitsDf,refHedisDf,ref_medvaluesetDf)) = DataLoadFunctions.readdatafromlocal(spark,measureId,year)
      //temporary-1//
      println("membershipDf_visitsDf_refHedisDf_ref_medvaluesetDf")
      membershipDf.show(10)
      visitsDf.show(10)
      visitsDf.filter($"${KpiConstants.memberidColName}" === ("99998")).show()
      refHedisDf.show(10)
      ref_medvaluesetDf.show(10)
      //temporary-1//
        val aLiat = List("col1")
        val msrVal = "'"+measureId+"'"
        val lobList = List(KpiConstants.commercialLobName, KpiConstants.medicaidLobName, KpiConstants.marketplaceLobName, KpiConstants.mmdLobName)

        val ageEndDate = year + "-12-31"
        val ageStartDate = year + "-01-01"


      val ageFilterDf = membershipDf.
        withColumn("age",datediff(lit(ageEndDate),$"${KpiConstants.dateofbirthColName}")/365.25).filter($"age">=3 and $"age"<7)

     //temporary-2//
      println("ageFilterDf")
      ageFilterDf.show()
      //temporary-2//

        val inputForContEnrolldf = ageFilterDf.select(KpiConstants.memberidColName, KpiConstants.benefitMedicalColname,
            KpiConstants.memStartDateColName,KpiConstants.memEndDateColName,
            KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName, KpiConstants.dateofbirthColName,KpiConstants.primaryPlanFlagColName)

        val benNonMedRemDf = inputForContEnrolldf.filter($"${KpiConstants.benefitMedicalColname}".===(KpiConstants.yesVal))
        // val argMapForContEnrollFunction = mutable.Map(KpiConstants.ageStartKeyName -> "12", )
       val contEnrollInDf = benNonMedRemDf.withColumn(KpiConstants.contenrollLowCoName,UtilFunctions.add_ncqa_months(spark,lit(ageStartDate), 0))
        .withColumn(KpiConstants.contenrollUppCoName,UtilFunctions.add_ncqa_months(spark,lit(ageEndDate), 0))
        .withColumn(KpiConstants.anchorDateColName, UtilFunctions.add_ncqa_months(spark,lit(ageEndDate), 0))
      contEnrollInDf.printSchema()
      contEnrollInDf.show()

      val contEnrollStep1Df = contEnrollInDf.filter((($"${KpiConstants.memStartDateColName}".>=($"${KpiConstants.contenrollLowCoName}")) && ($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.contenrollUppCoName}")))
        || (($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.contenrollLowCoName}")) && ($"${KpiConstants.memEndDateColName}".<=($"${KpiConstants.contenrollUppCoName}")))
        ||($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.contenrollLowCoName}") && ($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.contenrollUppCoName}"))))
        .withColumn(KpiConstants.anchorflagColName, when( ($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.anchorDateColName}"))
          && ($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.anchorDateColName}")), lit(1)).otherwise(lit(0)))
        .withColumn(KpiConstants.contEdFlagColName, when( ($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.contenrollUppCoName}"))
          && ($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.contenrollUppCoName}")), lit(1)).otherwise(lit(0)))
/*temp3 */
 printf("contEnrollStep1Df")
contEnrollStep1Df.show()
      /*temp3 */
      /*Step3(select the members who satisfy both (min_start_date- ces and cee- max_end_date <= allowable gap) conditions)*/
      val listDf = contEnrollStep1Df.groupBy($"${KpiConstants.memberidColName}")
        .agg(max($"${KpiConstants.memEndDateColName}").alias(KpiConstants.maxMemEndDateColName),
          min($"${KpiConstants.memStartDateColName}").alias(KpiConstants.minMemStDateColName),
          first($"${KpiConstants.contenrollLowCoName}").alias(KpiConstants.contenrollLowCoName),
          first($"${KpiConstants.contenrollUppCoName}").alias(KpiConstants.contenrollUppCoName),
          sum($"${KpiConstants.anchorflagColName}").alias(KpiConstants.anchorflagColName))
        .filter((date_add($"max_mem_end_date",KpiConstants.days45).>=($"${KpiConstants.contenrollUppCoName}"))
          && (date_sub($"min_mem_start_date",KpiConstants.days45).<=($"${KpiConstants.contenrollLowCoName}"))
          &&($"${KpiConstants.anchorflagColName}").>(0))
        .select($"${KpiConstants.memberidColName}")

      val contEnrollStep2Df = contEnrollStep1Df.as("df1").join(listDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
        .select("df1.*")

      /*temp3 */
      printf("contEnrollStep2Df")
      contEnrollStep2Df.show()
      /*temp3 */
      // contEnrollStep3Df.printSchema()
      /*window function creation based on partioned by member_sk and order by mem_start_date*/
      val contWindowVal = Window.partitionBy(s"${KpiConstants.memberidColName}").orderBy(org.apache.spark.sql.functions.col(s"${KpiConstants.memEndDateColName}").desc,org.apache.spark.sql.functions.col(s"${KpiConstants.memStartDateColName}"))


      /* added 3 columns (date_diff(datediff b/w next start_date and current end_date for each memeber),
       anchorflag(if member is continuously enrolled on anchor date 1, otherwise 0)
       count(if date_diff>1 1, otherwise 0) over window*/
      val contEnrollStep3Df = contEnrollStep2Df.withColumn(KpiConstants.overlapFlagColName, when(($"${KpiConstants.memStartDateColName}".>=(lag($"${KpiConstants.memStartDateColName}",1).over(contWindowVal)) && $"${KpiConstants.memStartDateColName}".<=(lag($"${KpiConstants.memEndDateColName}",1).over(contWindowVal))
        && ($"${KpiConstants.memEndDateColName}".>=(lag($"${KpiConstants.memStartDateColName}",1).over(contWindowVal)) && $"${KpiConstants.memEndDateColName}".<=(lag($"${KpiConstants.memEndDateColName}",1).over(contWindowVal))))
        ,lit(1))
        .when(($"${KpiConstants.memStartDateColName}".<(lag($"${KpiConstants.memStartDateColName}",1).over(contWindowVal)))
          && ($"${KpiConstants.memEndDateColName}".>=(lag($"${KpiConstants.memStartDateColName}",1 ).over(contWindowVal)) && $"${KpiConstants.memEndDateColName}".<=(lag($"${KpiConstants.memEndDateColName}",1).over(contWindowVal)))
          ,lit(2)).otherwise(lit(0)))

        .withColumn(KpiConstants.coverageDaysColName,when($"${KpiConstants.overlapFlagColName}".===(0) ,datediff(when($"${KpiConstants.memEndDateColName}".<=($"${KpiConstants.contenrollUppCoName}"), $"${KpiConstants.memEndDateColName}").otherwise($"${KpiConstants.contenrollUppCoName}")
          ,when($"${KpiConstants.memStartDateColName}".>=($"${KpiConstants.contenrollLowCoName}"), $"${KpiConstants.memStartDateColName}").otherwise($"${KpiConstants.contenrollLowCoName}"))+ 1 )
          .when($"${KpiConstants.overlapFlagColName}".===(2), datediff( when($"${KpiConstants.contenrollLowCoName}".>=(lag( $"${KpiConstants.memStartDateColName}",1).over(contWindowVal)), $"${KpiConstants.contenrollLowCoName}").otherwise(lag( $"${KpiConstants.memStartDateColName}",1).over(contWindowVal))
            ,$"${KpiConstants.memStartDateColName}")+1 )
          .otherwise(0))

        .withColumn(KpiConstants.countColName, when(when($"${KpiConstants.overlapFlagColName}".===(0), datediff(lag($"${KpiConstants.memStartDateColName}",1).over(contWindowVal), $"${KpiConstants.memEndDateColName}"))
          .otherwise(0).>(1),lit(1))
          .otherwise(lit(0)) )

      /*temp3 */
      printf("contEnrollStep3Df")
      contEnrollStep3Df.show()
      /*temp3 */

      val contEnrollStep5Df = contEnrollStep3Df.groupBy(KpiConstants.memberidColName)
        .agg(min($"${KpiConstants.memStartDateColName}").alias(KpiConstants.minMemStDateColName),
          max($"${KpiConstants.memEndDateColName}").alias(KpiConstants.maxMemEndDateColName),
          sum($"${KpiConstants.countColName}").alias(KpiConstants.countColName),
          sum($"${KpiConstants.coverageDaysColName}").alias(KpiConstants.coverageDaysColName),
          first($"${KpiConstants.contenrollLowCoName}").alias(KpiConstants.contenrollLowCoName),
          first($"${KpiConstants.contenrollUppCoName}").alias(KpiConstants.contenrollUppCoName))


      val contEnrollmemDf = contEnrollStep5Df.filter(((($"${KpiConstants.countColName}") + (when(date_sub($"min_mem_start_date", 1).>=($"${KpiConstants.contenrollLowCoName}"),lit(1)).otherwise(lit(0)))
        + (when(date_add($"max_mem_end_date", 1).<=($"${KpiConstants.contenrollUppCoName}"),lit(1)).otherwise(lit(0)))).<=(1) )
        && ($"${KpiConstants.coverageDaysColName}".>=(320)))
        .select(KpiConstants.memberidColName).distinct()

      /*temp3 */
      printf("contEnrollmemDf")
      contEnrollmemDf.show()
      /*temp3 */


      //val contEnrollmemDf = UtilFunctions.contEnrollAndAllowableGapFilter(spark,inputForContEnrolldf,KpiConstants.commondateformatName,argMap)

      val contEnrollDf = contEnrollStep1Df.as("df1").join(contEnrollmemDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
        .filter($"df1.${KpiConstants.contEdFlagColName}".===(1))
        .select(s"df1.${KpiConstants.memberidColName}", s"df1.${KpiConstants.lobColName}", s"df1.${KpiConstants.lobProductColName}",s"df1.${KpiConstants.payerColName}",s"df1.${KpiConstants.primaryPlanFlagColName}").cache()
      /*temp3 */
      printf("contEnrollDf")
      contEnrollDf.show()
      /*temp3 */

      val baseOutDf = UtilFunctions.baseOutDataframeCreation(spark, contEnrollDf, lobList)

      /*temp3 */
      printf("baseOutDf")
      //baseOutDf.show()
      /*temp3 */

      val imaContEnrollDf = baseOutDf.filter($"${KpiConstants.lobColName}".isin(lobList:_*)).dropDuplicates().cache()
      imaContEnrollDf.count()
      //imaContEnrollDf.show()
      imaContEnrollDf.select(KpiConstants.memberidColName).distinct().coalesce(1)
        .write
        .mode(SaveMode.Append)
        .option("header", "true")
        .csv("/home/hbase/ncqa/w34/imaContEnrollDf/")
      //</editor-fold>

      //<editor-fold desc="Initial Join with Ref_Hedis">

      val argmapforRefHedis = mutable.Map(KpiConstants.eligibleDfName -> visitsDf , KpiConstants.refHedisTblName -> refHedisDf)
      val allValueList = List(KpiConstants.independentLabVal, KpiConstants.hospiceVal,KpiConstants.wellCareVal)


      val medList = KpiConstants.emptyList
      val visitRefHedisDf = UtilFunctions.joinWithRefHedisFunction(spark,argmapforRefHedis,allValueList,medList)
     println("visitRefHedisDf")
      visitRefHedisDf.filter($"${KpiConstants.memberidColName}" === ("99998")).show()
      //visitRefHedisDf.show()
      //</editor-fold>

      //<editor-fold desc="Removal of Independent Lab Visits">

      val groupList = visitsDf.schema.fieldNames.toList.dropWhile(p=> p.equalsIgnoreCase(KpiConstants.memberidColName))
      val visitgroupedDf = visitRefHedisDf.groupBy(KpiConstants.memberidColName, groupList:_*).agg(collect_list(KpiConstants.valuesetColName).alias(KpiConstants.valuesetColName))
        .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName, KpiConstants.admitDateColName, KpiConstants.dischargeDateColName,
          KpiConstants.dobColName,KpiConstants.supplflagColName, KpiConstants.ispcpColName,KpiConstants.isobgynColName, KpiConstants.valuesetColName)

      visitgroupedDf.filter($"${KpiConstants.memberidColName}" === ("99998")).show()

      val indLabVisRemDf = visitgroupedDf.filter(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)).repartition(2).cache()
      indLabVisRemDf.count()
      println("indLabVisRemDf")
      indLabVisRemDf.filter($"${KpiConstants.memberidColName}" === ("99998")).show()
      //</editor-fold>

      //<editor-fold desc="Hospice Removal">

      val yearStartDate = year+"-01-01"
      val yearEndDate = year+"-12-31"
      val hospiceInCurrYearMemDf = indLabVisRemDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hospiceVal))
        &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
        .select(KpiConstants.memberidColName)
        .dropDuplicates()

      hospiceInCurrYearMemDf.coalesce(1)
         .write
         .mode(SaveMode.Append)
         .option("header", "true")
         .csv("/home/hbase/ncqa/w34/hospiceInCurrYearMemDf/")

      //</editor-fold>

      val totalPopmemidDf = imaContEnrollDf.select(KpiConstants.memberidColName).except(hospiceInCurrYearMemDf).distinct()
        .rdd
        .map(r=> r.getString(0))
        .collect()


      //val eligibleMemDf = hospiceRemovedMemsDf.select(KpiConstants.memberidColName).distinct().intersect(validVisitsDf.select(KpiConstants.memberidColName)).dropDuplicates()
      val totalPopOutDf = imaContEnrollDf.filter($"${KpiConstants.memberidColName}".isin(totalPopmemidDf:_*))
        .select(KpiConstants.memberidColName,KpiConstants.lobColName, KpiConstants.payerColName).dropDuplicates()

//      val msrList = List(KpiConstants.imahpvMeasureId, KpiConstants.imamenMeasureId, KpiConstants.imatdMeasureId,
//        KpiConstants.imacmb1MeasureId, KpiConstants.imacmb2MeasureId)
//
//      val lobNameList = List(KpiConstants.commercialLobName, KpiConstants.medicaidLobName)
//      val remMsrlist = List(KpiConstants.imacmb1MeasureId)
//      val toutStrDf = UtilFunctions.toutOutputCreation(spark,totalPopOutDf,msrList,lobNameList,remMsrlist)
//        .select(KpiConstants.memberidColName, KpiConstants.ncqaOutPayerCol, KpiConstants.ncqaOutMeasureCol)
//        .repartition(2)
val toutStrDf =totalPopOutDf.select($"${KpiConstants.memberidColName}",$"${KpiConstants.memberidColName}".as(KpiConstants.ncqaOutmemberIdCol),$"${KpiConstants.payerColName}".as(KpiConstants.ncqaOutPayerCol))
    .withColumn(KpiConstants.ncqaOutMeasureCol,lit(measureId))
toutStrDf.coalesce(1)
        .write
        .mode(SaveMode.Append)
        .parquet("/home/hbase/ncqa/w34/tout/")

      val eligiblePopDf = totalPopOutDf.select(KpiConstants.memberidColName).distinct().repartition(2).cache()
      eligiblePopDf.count()
      //</editor-fold>

      //<editor-fold desc="Dinominator calculation">

      val denominatorDf = eligiblePopDf
      denominatorDf.repartition(2).cache()
      denominatorDf.count()
      denominatorDf.show()

      denominatorDf.coalesce(1)
        .write
        .mode(SaveMode.Append)
        .option("header", "true")
        .csv("/home/hbase/ncqa/ima/denominator/")

      val argmapForVisittJoin = mutable.Map(KpiConstants.membershipTblName -> denominatorDf , KpiConstants.visitTblName -> indLabVisRemDf)
      val visitJoinedOutDf = UtilFunctions.initialJoinFunction(spark,argmapForVisittJoin)
      visitJoinedOutDf.count()
      visitJoinedOutDf.coalesce(1)
        .write
        .mode(SaveMode.Append)
        .parquet("/home/hbase/ncqa/w34/visitJoinedDf/")

    //</editor-fold>

      //<editor-fold desc="W34  Numerator Calculation">

      val visitJoinedDf = spark.read.parquet("/home/hbase/ncqa/w34/visitJoinedDf/").repartition(2).cache()
      visitJoinedDf.count()
      val visitNonSuppDf = visitJoinedDf.filter($"${KpiConstants.supplflagColName}".===("N")).cache()
      visitNonSuppDf.count()
      val toutDf = spark.read.parquet("/home/hbase/ncqa/w34/tout/")
     val denominatorPopDf = toutDf.select(KpiConstants.memberidColName).distinct().cache()



      //<editor-fold desc="IMA Menucocal Tmp Numerator Calculation">

      //val imaMenValueSet = List(KpiConstants.meningococcalVal)
      val w34NumnonsupDf = visitNonSuppDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.wellCareVal))
        &&($"${KpiConstants.ispcpColName}".===("Y") )
        &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
        .select(s"${KpiConstants.memberidColName}")

    //  val imaMenOtherMemIdDf = denominatorPopDf.except(w34NumnonsupDf)

      val visitForMenOtherDf = visitJoinedDf.except(visitJoinedDf.filter($"${KpiConstants.memberidColName}".isin(
        w34NumnonsupDf.rdd.map(r=>r.getString(0)).collect():_*
      )))

      val w34NumotherDf = visitForMenOtherDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.wellCareVal))
        &&($"${KpiConstants.ispcpColName}".===("Y") )
        &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
        .select(s"${KpiConstants.memberidColName}")

      val w34NumDf = w34NumnonsupDf.union(w34NumotherDf).dropDuplicates().cache()

      w34NumDf.coalesce(1)
        .write
        .mode(SaveMode.Append)
        .option("header", "true")
        .csv("/home/hbase/ncqa/w34/W34NumDf/")

      val outMap = mutable.Map(KpiConstants.totalPopDfName -> toutStrDf, KpiConstants.eligibleDfName -> eligiblePopDf,
        KpiConstants.mandatoryExclDfname -> spark.emptyDataFrame, KpiConstants.optionalExclDfName -> spark.emptyDataFrame,
        KpiConstants.numeratorDfName -> w34NumDf )



      val outDf = UtilFunctions.ncqaOutputDfCreation(spark,outMap,measureId)
      outDf.coalesce(1)
        .write
        .mode(SaveMode.Append)
        .option("header", "true")
        .csv("/home/hbase/ncqa/w34/outDf/")


      spark.sparkContext.stop()

    }

}
