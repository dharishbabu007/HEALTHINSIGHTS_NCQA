package com.itc.ncqa.main

import com.itc.ncqa.Constants.KpiConstants
import com.itc.ncqa.Functions.{DataLoadFunctions, UtilFunctions}
import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkConf
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

import scala.collection.mutable

object NcqaCIS {

  def main(args: Array[String]): Unit = {

    val StringtoIntger = udf((value: String) => value.toInt)
    //<editor-fold desc="Reading program arguments and SaprkSession oBject creation">

    //    val year = args(0)
    //    val measureId = args(1)
    //    val dbName = args(2)

    val measureId = "CIS"
    val year = "2018"
    /*calling function for setting the dbname for dbName variable*/
    // KpiConstants.setDbName(dbName)
    //    val conf = new SparkConf().setAppName("NcqaProgram")
    //    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    //      .set("hive.exec.dynamic.partition.mode", "nonstrict")
    //    .set("spark.sql.shuffle.partitions","5")

    val conf = new SparkConf().setAppName("NcqaProgram").setMaster("local[*]")
    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      .set("hive.exec.dynamic.partition.mode", "nonstrict")
      .set("spark.sql.shuffle.partitions", "5")
    val spark = SparkSession.builder().config(conf).getOrCreate()

    // val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    import spark.implicits._
    val rootLogger = Logger.getRootLogger()
    rootLogger.setLevel(Level.ERROR)
    //</editor-fold>

    //<editor-fold desc="Loading Required Tables to memory">

    val ystDate = year + "-01-01"
    val yendDate = year + "-12-31"
    val aLiat = List("col1")
    val msrVal = s"'$measureId'"
    val ggMsrId = s"'${KpiConstants.ggMeasureId}'"
    val lobList = List(KpiConstants.commercialLobName, KpiConstants.medicaidLobName, KpiConstants.marketplaceLobName)
    val ((membershipDf, visitsDf, refHedisDf, ref_medvaluesetDf)) = DataLoadFunctions.readdatafromlocal(spark, measureId, year)

    val ageEndDate = year + "-12-31"
    val ageStartDate = year + "-01-01"


    println("InputVisistsDF")
    visitsDf.filter($"${KpiConstants.memberidColName}" === ("95100")).show()
    visitsDf.filter($"${KpiConstants.memberidColName}" === ("135236")).show()
/* comments */
/*        println("InputmembersDF")
    membershipDf.filter($"${KpiConstants.memberidColName}" === ("95100")).show()
    membershipDf.filter($"${KpiConstants.memberidColName}" === ("135236")).show()

    val ageFilterDf = membershipDf.filter((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",KpiConstants.months24).>=(ageStartDate)) && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",KpiConstants.months24).<=(ageEndDate)))
    println("ageFilterDf")
    ageFilterDf.filter($"${KpiConstants.memberidColName}" === ("95273")).show()
    val inputForContEnrolldf = ageFilterDf.select(KpiConstants.memberidColName, KpiConstants.benefitMedicalColname,
      KpiConstants.memStartDateColName,KpiConstants.memEndDateColName,
      KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName, KpiConstants.dateofbirthColName,KpiConstants.primaryPlanFlagColName)

    val benNonMedRemDf = inputForContEnrolldf.filter($"${KpiConstants.benefitMedicalColname}".===(KpiConstants.yesVal))
    // val argMapForContEnrollFunction = mutable.Map(KpiConstants.ageStartKeyName -> "12", )
    val contEnrollInDf = benNonMedRemDf.withColumn(KpiConstants.contenrollLowCoName,UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}", KpiConstants.months12))
      .withColumn(KpiConstants.contenrollUppCoName,UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}", KpiConstants.months24))
      .withColumn(KpiConstants.anchorDateColName, UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}", KpiConstants.months24))


    /* println("contEnrollInDf")
     contEnrollInDf.filter($"${KpiConstants.memberidColName}" === ("117463")).show()*/


    val contEnrollStep1Df = contEnrollInDf.filter((($"${KpiConstants.memStartDateColName}".>=($"${KpiConstants.contenrollLowCoName}")) && ($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.contenrollUppCoName}")))
      || (($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.contenrollLowCoName}")) && ($"${KpiConstants.memEndDateColName}".<=($"${KpiConstants.contenrollUppCoName}")))
      ||($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.contenrollLowCoName}") && ($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.contenrollUppCoName}"))))
      .withColumn(KpiConstants.anchorflagColName, when( ($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.anchorDateColName}"))
        && ($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.anchorDateColName}")), lit(1)).otherwise(lit(0)))
      .withColumn(KpiConstants.contEdFlagColName, when( ($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.contenrollUppCoName}"))
        && ($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.contenrollUppCoName}")), lit(1)).otherwise(lit(0)))

    /* println("contEnrollStep1Df")
     contEnrollStep1Df.filter($"${KpiConstants.memberidColName}" === ("117463")).show()*/


    /*Step3(select the members who satisfy both (min_start_date- ces and cee- max_end_date <= allowable gap) conditions)*/
    val listDf = contEnrollStep1Df.groupBy($"${KpiConstants.memberidColName}")
      .agg(max($"${KpiConstants.memEndDateColName}").alias(KpiConstants.maxMemEndDateColName),
        min($"${KpiConstants.memStartDateColName}").alias(KpiConstants.minMemStDateColName),
        first($"${KpiConstants.contenrollLowCoName}").alias(KpiConstants.contenrollLowCoName),
        first($"${KpiConstants.contenrollUppCoName}").alias(KpiConstants.contenrollUppCoName),
        sum($"${KpiConstants.anchorflagColName}").alias(KpiConstants.anchorflagColName))
      .filter((date_add($"max_mem_end_date",KpiConstants.days45).>=($"${KpiConstants.contenrollUppCoName}"))
        && (date_sub($"min_mem_start_date",KpiConstants.days45).<=($"${KpiConstants.contenrollLowCoName}"))
        &&($"${KpiConstants.anchorflagColName}").>(0))
      .select($"${KpiConstants.memberidColName}")

    val contEnrollStep2Df = contEnrollStep1Df.as("df1").join(listDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select("df1.*")

    /* printf("contEnrollStep2Df")
     contEnrollStep2Df.show()*/

    /*window function creation based on partioned by member_sk and order by mem_start_date*/
    val contWindowVal = Window.partitionBy(s"${KpiConstants.memberidColName}").orderBy(org.apache.spark.sql.functions.col(s"${KpiConstants.memEndDateColName}").desc,org.apache.spark.sql.functions.col(s"${KpiConstants.memStartDateColName}"))


    /* added 3 columns (date_diff(datediff b/w next start_date and current end_date for each memeber),
     anchorflag(if member is continuously enrolled on anchor date 1, otherwise 0)
     count(if date_diff>1 1, otherwise 0) over window*/
    val contEnrollStep3Df = contEnrollStep2Df.withColumn(KpiConstants.overlapFlagColName, when(($"${KpiConstants.memStartDateColName}".>=(lag($"${KpiConstants.memStartDateColName}",1).over(contWindowVal)) && $"${KpiConstants.memStartDateColName}".<=(lag($"${KpiConstants.memEndDateColName}",1).over(contWindowVal))
      && ($"${KpiConstants.memEndDateColName}".>=(lag($"${KpiConstants.memStartDateColName}",1).over(contWindowVal)) && $"${KpiConstants.memEndDateColName}".<=(lag($"${KpiConstants.memEndDateColName}",1).over(contWindowVal))))
      ,lit(1))
      .when(($"${KpiConstants.memStartDateColName}".<(lag($"${KpiConstants.memStartDateColName}",1).over(contWindowVal)))
        && ($"${KpiConstants.memEndDateColName}".>=(lag($"${KpiConstants.memStartDateColName}",1 ).over(contWindowVal)) && $"${KpiConstants.memEndDateColName}".<=(lag($"${KpiConstants.memEndDateColName}",1).over(contWindowVal)))
        ,lit(2)).otherwise(lit(0)))

      .withColumn(KpiConstants.coverageDaysColName,when($"${KpiConstants.overlapFlagColName}".===(0) ,datediff(when($"${KpiConstants.memEndDateColName}".<=($"${KpiConstants.contenrollUppCoName}"), $"${KpiConstants.memEndDateColName}").otherwise($"${KpiConstants.contenrollUppCoName}")
        ,when($"${KpiConstants.memStartDateColName}".>=($"${KpiConstants.contenrollLowCoName}"), $"${KpiConstants.memStartDateColName}").otherwise($"${KpiConstants.contenrollLowCoName}"))+ 1 )
        .when($"${KpiConstants.overlapFlagColName}".===(2), datediff( when($"${KpiConstants.contenrollLowCoName}".>=(lag( $"${KpiConstants.memStartDateColName}",1).over(contWindowVal)), $"${KpiConstants.contenrollLowCoName}").otherwise(lag( $"${KpiConstants.memStartDateColName}",1).over(contWindowVal))
          ,$"${KpiConstants.memStartDateColName}")+1 )
        .otherwise(0))

      .withColumn(KpiConstants.countColName, when(when($"${KpiConstants.overlapFlagColName}".===(0), datediff(lag($"${KpiConstants.memStartDateColName}",1).over(contWindowVal), $"${KpiConstants.memEndDateColName}"))
        .otherwise(0).>(1),lit(1))
        .otherwise(lit(0)) )


    /* println("contEnrollStep3Df")
     contEnrollStep3Df.filter($"${KpiConstants.memberidColName}" === ("117463")).show()*/



    val contEnrollStep5Df = contEnrollStep3Df.groupBy(KpiConstants.memberidColName)
      .agg(min($"${KpiConstants.memStartDateColName}").alias(KpiConstants.minMemStDateColName),
        max($"${KpiConstants.memEndDateColName}").alias(KpiConstants.maxMemEndDateColName),
        sum($"${KpiConstants.countColName}").alias(KpiConstants.countColName),
        sum($"${KpiConstants.coverageDaysColName}").alias(KpiConstants.coverageDaysColName),
        first($"${KpiConstants.contenrollLowCoName}").alias(KpiConstants.contenrollLowCoName),
        first($"${KpiConstants.contenrollUppCoName}").alias(KpiConstants.contenrollUppCoName))
      .withColumn(KpiConstants.reqCovDaysColName, (datediff($"${KpiConstants.contenrollUppCoName}", $"${KpiConstants.contenrollLowCoName}")-44))



    val contEnrollmemDf = contEnrollStep5Df.filter(((($"${KpiConstants.countColName}") + (when(date_sub($"min_mem_start_date", 1).>=($"${KpiConstants.contenrollLowCoName}"),lit(1)).otherwise(lit(0)))
      + (when(date_add($"max_mem_end_date", 1).<=($"${KpiConstants.contenrollUppCoName}"),lit(1)).otherwise(lit(0)))).<=(1) )
      && ($"${KpiConstants.coverageDaysColName}".>=($"${KpiConstants.reqCovDaysColName}")))
      .select(KpiConstants.memberidColName).distinct()


    /* printf("contEnrollmemDf")
     contEnrollmemDf.show()*/

    val contEnrollDf = contEnrollStep1Df.as("df1").join(contEnrollmemDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .filter($"df1.${KpiConstants.contEdFlagColName}".===(1))
      .select(s"df1.${KpiConstants.memberidColName}", s"df1.${KpiConstants.lobColName}", s"df1.${KpiConstants.lobProductColName}",s"df1.${KpiConstants.payerColName}",s"df1.${KpiConstants.primaryPlanFlagColName}").cache()

    /* printf("contEnrollDf")
     contEnrollDf.show()*/

    //</editor-fold>

    //<editor-fold desc="Dual Enrollment and CIS Lob filter">

    val baseOutDf = UtilFunctions.baseOutDataframeCreation(spark, contEnrollDf, lobList)

    /*printf("baseOutDf")
    baseOutDf.show()*/

    println("baseOutDf")
    baseOutDf.filter($"${KpiConstants.memberidColName}" === ("96249")).show()

    val CISContEnrollDf = baseOutDf.filter($"${KpiConstants.lobColName}".isin(lobList:_*)).dropDuplicates().cache()
    CISContEnrollDf.count()

    CISContEnrollDf.select(KpiConstants.memberidColName).distinct().coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("/home/hbase/ncqa/CIS/CISContEnrollDf/")
    //</editor-fold>

    //<editor-fold desc="Initial Join with Ref_Hedis">

    val argmapforRefHedis = mutable.Map(KpiConstants.eligibleDfName -> visitsDf , KpiConstants.refHedisTblName -> refHedisDf)
    val allValueList = List(KpiConstants.independentLabVal, KpiConstants.hospiceVal,KpiConstants.mrVacVal,KpiConstants.dtapVacAdmVal,KpiConstants.ipvVaccineVal,KpiConstants.mmrVacVal,KpiConstants.mumpsVal,KpiConstants.mumpsVacVal,KpiConstants.measelesVal,KpiConstants.rubellaVal,KpiConstants.measlesVacVal,KpiConstants.rubellaVacVal,KpiConstants.physicalActCounselVal,KpiConstants.pregnancyVal,KpiConstants.dtapVacAdmVal,KpiConstants.ipvVaccineVal,KpiConstants.hibVacVal,KpiConstants.vzvVacVal,KpiConstants.vzvVal,KpiConstants.hepatitisAVal,KpiConstants.hepatitisAVacVal,KpiConstants.pneuConjuVaccine13Val,KpiConstants.pneConjVacVal,KpiConstants.influenzaVacVal,KpiConstants.influenzaVaccineVal,KpiConstants.rotavirusVac2Val,KpiConstants.rotavirusVac3Val,KpiConstants.anaReactVacVal,KpiConstants.encephalopathyVal,KpiConstants.vacCauseAdvEffVal,KpiConstants.disordersoftheImmuneSystemVal,KpiConstants.hivType2Val,KpiConstants.hivVal,KpiConstants.mallNeoLymTisVal,
      KpiConstants.intussusceptionVal,KpiConstants.severeCombImmunVal,KpiConstants.hepatitisBVacVal,KpiConstants.hepatitisBVal,KpiConstants.hepatitisBnewVacVal)


    val medList = KpiConstants.emptyList
    val visitRefHedisDf = UtilFunctions.joinWithRefHedisFunction(spark,argmapforRefHedis,allValueList,medList)
    /*println("visitRefHedisDf")
f    visitRefHedisDf.filter($"${KpiConstants.memberidColName}" === ("107650")).show()*/

    //</editor-fold>

    //<editor-fold desc="Removal of Independent Lab Visits">

    val groupList = visitsDf.schema.fieldNames.toList.dropWhile(p=> p.equalsIgnoreCase(KpiConstants.memberidColName))
    val visitgroupedDf = visitRefHedisDf.groupBy(KpiConstants.memberidColName, groupList:_*).agg(collect_list(KpiConstants.valuesetColName).alias(KpiConstants.valuesetColName))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName, KpiConstants.admitDateColName, KpiConstants.dischargeDateColName,
        KpiConstants.dobColName,KpiConstants.supplflagColName, KpiConstants.ispcpColName,KpiConstants.isobgynColName, KpiConstants.valuesetColName,KpiConstants.genderColName)

    /*visitgroupedDf.filter($"${KpiConstants.memberidColName}" === ("107650")).show()*/

    val indLabVisRemDf = visitgroupedDf.filter(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)).repartition(2).cache()
    indLabVisRemDf.count()
    println("indLabVisRemDf")
    indLabVisRemDf.filter($"${KpiConstants.memberidColName}" === ("96249")).show()
    //</editor-fold>

    //<editor-fold desc="Hospice Removal">

    val yearStartDate = year+"-01-01"
    val yearEndDate = year+"-12-31"
    val hospiceInCurrYearMemDf = indLabVisRemDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hospiceVal))
      &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)
      .dropDuplicates()

    hospiceInCurrYearMemDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("/home/hbase/ncqa/CIS/hospiceInCurrYearMemDf/")

    //</editor-fold>

    val totalPopOutDf = CISContEnrollDf.except(CISContEnrollDf.filter($"${KpiConstants.memberidColName}".isin(hospiceInCurrYearMemDf.rdd.map(r=>r.getString(0)).collect():_*)))

    val msrList = List(KpiConstants.cisDtpaMeasureId,KpiConstants.cisIpvMeasureId,KpiConstants.cisHiBMeasureId,KpiConstants.cisPneuMeasureId,KpiConstants.cisInflMeasureId,
      KpiConstants.cisRotaMeasureId,KpiConstants.cisMmrMeasureId,KpiConstants.cisHepbMeasureId,KpiConstants.cisVzvMeasureId,KpiConstants.cisHepaMeasureId,
      KpiConstants.cisCmb10MeasureId,KpiConstants.cisCmb9MeasureId,KpiConstants.cisCmb8MeasureId,KpiConstants.cisCmb7MeasureId,KpiConstants.cisCmb6MeasureId,
      KpiConstants.cisCmb5MeasureId,KpiConstants.cisCmb4MeasureId,KpiConstants.cisCmb3MeasureId,KpiConstants.cisCmb2MeasureId)

    val lobNameList = List(KpiConstants.commercialLobName, KpiConstants.medicaidLobName)
    val remMsrlist = List(KpiConstants.cisCmb3MeasureId,KpiConstants.cisRotaMeasureId,KpiConstants.cisHepaMeasureId,KpiConstants.cisInflMeasureId)
    val toutStrDf = UtilFunctions.toutOutputCreation(spark,totalPopOutDf,msrList,lobNameList,remMsrlist)
      .select(KpiConstants.memberidColName, KpiConstants.ncqaOutPayerCol, KpiConstants.ncqaOutMeasureCol)
      .repartition(2)

    println("totalPopOutDf")
    totalPopOutDf.filter($"${KpiConstants.memberidColName}" === ("96249")).show()

    totalPopOutDf.coalesce(1)
      .write
      .mode(SaveMode.Append).option("header", "true")
      .csv("/home/hbase/ncqa/CIS/totalPopOutDf/")
//    val toutStrDf =totalPopOutDf.select($"${KpiConstants.memberidColName}",$"${KpiConstants.memberidColName}".as(KpiConstants.ncqaOutmemberIdCol),$"${KpiConstants.payerColName}".as(KpiConstants.ncqaOutPayerCol))
//      .withColumn(KpiConstants.ncqaOutMeasureCol,lit(measureId))
//    toutStrDf.coalesce(1)
//      .write
//      .mode(SaveMode.Append)
//      .parquet("/home/hbase/ncqa/CIS/tout/")


    val eligiblePopDf = totalPopOutDf.select(KpiConstants.memberidColName).distinct().cache()
    eligiblePopDf.count()
    //</editor-fold>
    println("eligiblePopDf")
    eligiblePopDf.filter($"${KpiConstants.memberidColName}" === ("97014")).show()

    eligiblePopDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("/home/hbase/ncqa/CIS/denominator/")


    val argmapForVisittJoin = mutable.Map(KpiConstants.membershipTblName -> eligiblePopDf , KpiConstants.visitTblName -> indLabVisRemDf)
    val visitJoinedOutDf = UtilFunctions.initialJoinFunction(spark,argmapForVisittJoin)
    visitJoinedOutDf.count()
    visitJoinedOutDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .parquet("/home/hbase/ncqa/CIS/visitJoinedDf/")

    val visitJoinedDf = spark.read.parquet("/home/hbase/ncqa/CIS/visitJoinedDf/")

println("visitJoinedDf")
//    visitJoinedDf.cache()
*/
    /* comments */

//remove
    val visitJoinedDf = spark.read.parquet("/home/hbase/ncqa/CIS/visitJoinedDf/")
  val totalPopOutDf=spark.read.option("header", "true").csv("/home/hbase/ncqa/CIS/totalPopOutDf/")
    val  eligiblePopDf =spark.read.option("header", "true").csv("/home/hbase/ncqa/CIS/denominator/")

    val msrList = List(KpiConstants.cisDtpaMeasureId,KpiConstants.cisIpvMeasureId,KpiConstants.cisHiBMeasureId,KpiConstants.cisPneuMeasureId,KpiConstants.cisInflMeasureId,
      KpiConstants.cisRotaMeasureId,KpiConstants.cisMmrMeasureId,KpiConstants.cisHepbMeasureId,KpiConstants.cisVzvMeasureId,KpiConstants.cisHepaMeasureId,
      KpiConstants.cisCmb10MeasureId,KpiConstants.cisCmb9MeasureId,KpiConstants.cisCmb8MeasureId,KpiConstants.cisCmb7MeasureId,KpiConstants.cisCmb6MeasureId,
      KpiConstants.cisCmb5MeasureId,KpiConstants.cisCmb4MeasureId,KpiConstants.cisCmb3MeasureId,KpiConstants.cisCmb2MeasureId)

    val lobNameList = List(KpiConstants.commercialLobName, KpiConstants.medicaidLobName)
    val remMsrlist = List(KpiConstants.cisCmb10MeasureId,KpiConstants.cisCmb9MeasureId,KpiConstants.cisCmb8MeasureId,KpiConstants.cisCmb7MeasureId,KpiConstants.cisCmb6MeasureId,
      KpiConstants.cisCmb5MeasureId,KpiConstants.cisCmb4MeasureId,KpiConstants.cisCmb2MeasureId,KpiConstants.cisRotaMeasureId,KpiConstants.cisHepaMeasureId,KpiConstants.cisInflMeasureId)
    val toutStrDf = UtilFunctions.toutOutputCreation(spark,totalPopOutDf,msrList,lobNameList,remMsrlist)
      .select(KpiConstants.memberidColName, KpiConstants.ncqaOutPayerCol, KpiConstants.ncqaOutMeasureCol)
      .repartition(2)

 //remove
    val visitJoined_out_market_Df = visitJoinedDf.as("df1").join(totalPopOutDf.alias("df2"),
      (($"df1.${KpiConstants.memberidColName}"===$"df2.${KpiConstants.memberidColName}")
        && ($"df2.${KpiConstants.lobColName}"=!=(KpiConstants.marketplaceLobName))),KpiConstants.innerJoinType).select($"df1.*").distinct()

    println("visitJoined_out_market_Df")
    visitJoined_out_market_Df.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    totalPopOutDf.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    visitJoined_out_market_Df.show()
    //Numerator 1: DTap
    val DTapNumertorInput = visitJoinedDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.dtapVacAdmVal))
                  && ( UtilFunctions.add_ncqa_months (spark,$"${KpiConstants.dobColName}",KpiConstants.months24).>= ($"${KpiConstants.serviceDateColName}")
                      && date_add($"${KpiConstants.dobColName}",42).<= ($"${KpiConstants.serviceDateColName}") ) )
      .select(s"${KpiConstants.memberidColName}",s"${KpiConstants.serviceDateColName}")

    println("DTapNumertorInput")
    DTapNumertorInput.show()

    val groupedDsDtap = DTapNumertorInput.as[Member].groupByKey(k=>k.member_id)
      .mapGroups((k,itr) => (k,itr.map(f=> f.service_date.getTime).toArray.sorted))

    val DTapNumertorOutput = groupedDsDtap.map(f=>(UtilFunctions.getVisits(f._1,f._2))).toDF(KpiConstants.memberidColName,"visits").
      filter($"visits".>=(4)).select(KpiConstants.memberidColName)

    //Numerator 2: IPV

    val IPVNumertorInput = visitJoinedDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.ipvVaccineVal))
      && ( UtilFunctions.add_ncqa_months (spark,$"${KpiConstants.dobColName}",KpiConstants.months24).>= ($"${KpiConstants.serviceDateColName}")
      && date_add($"${KpiConstants.dobColName}",42).<= ($"${KpiConstants.serviceDateColName}") ) ).select(s"${KpiConstants.memberidColName}",s"${KpiConstants.serviceDateColName}")

    val groupedDsIPV = IPVNumertorInput.as[Member].groupByKey(k=>k.member_id)
      .mapGroups((k,itr) => (k,itr.map(f=> f.service_date.getTime).toArray.sorted))

    val IPVNumertorOutput = groupedDsIPV.map(f=>(UtilFunctions.getVisits(f._1,f._2))).toDF(KpiConstants.memberidColName,"visits").
      filter($"visits".>=(3)).select(KpiConstants.memberidColName)

    //Numerator 3: MMR

    val MMRNumertorInput = visitJoinedDf.filter(
       ( UtilFunctions.add_ncqa_months (spark,$"${KpiConstants.dobColName}",KpiConstants.months24).>= ($"${KpiConstants.serviceDateColName}")
  //     && UtilFunctions.add_ncqa_months (spark,$"${KpiConstants.dobColName}",KpiConstants.months12).<= ($"${KpiConstants.serviceDateColName}")
         ) ).select(KpiConstants.memberidColName,KpiConstants.valuesetColName)

    println("MMRNumertorInput")
    MMRNumertorInput.filter($"${KpiConstants.memberidColName}" === ("96533")).show()

    val MMRNumertorInput1=MMRNumertorInput.filter(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.mmrVacVal)
      && UtilFunctions.add_ncqa_months (spark,$"${KpiConstants.dobColName}",KpiConstants.months12).<= ($"${KpiConstants.serviceDateColName}") ).select(KpiConstants.memberidColName)

    println("MMRNumertorInput1")
    MMRNumertorInput1.filter($"${KpiConstants.memberidColName}" === ("96533")).show()

    val MMRNumertorInput2=MMRNumertorInput.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.mrVacVal) ) && UtilFunctions.add_ncqa_months (spark,$"${KpiConstants.dobColName}",KpiConstants.months12).<= ($"${KpiConstants.serviceDateColName}") ).select(KpiConstants.memberidColName)
    val MMRNumertorInput3=MMRNumertorInput.filter(((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.mumpsVacVal) && UtilFunctions.add_ncqa_months (spark,$"${KpiConstants.dobColName}",KpiConstants.months12).<= ($"${KpiConstants.serviceDateColName}") ) || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.mumpsVal))).select(KpiConstants.memberidColName)
    val MMRNumertorInput4=MMRNumertorInput2.intersect(MMRNumertorInput3)

    println("MMRNumertorInput2")
    MMRNumertorInput2.filter($"${KpiConstants.memberidColName}" === ("96533")).show()
    println("MMRNumertorInput3")
    MMRNumertorInput3.filter($"${KpiConstants.memberidColName}" === ("96533")).show()

    println("MMRNumertorInput4")
    MMRNumertorInput4.filter($"${KpiConstants.memberidColName}" === ("96533")).show()

    val MMRNumertorInput5=MMRNumertorInput.filter(((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.measlesVacVal) && UtilFunctions.add_ncqa_months (spark,$"${KpiConstants.dobColName}",KpiConstants.months12).<= ($"${KpiConstants.serviceDateColName}")) || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.measelesVal))).select(KpiConstants.memberidColName)
    val MMRNumertorInput6=MMRNumertorInput.filter(((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.mumpsVacVal) && UtilFunctions.add_ncqa_months (spark,$"${KpiConstants.dobColName}",KpiConstants.months12).<= ($"${KpiConstants.serviceDateColName}")) || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.mumpsVal))).select(KpiConstants.memberidColName)
    val MMRNumertorInput7=MMRNumertorInput.filter(((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.rubellaVacVal) && UtilFunctions.add_ncqa_months (spark,$"${KpiConstants.dobColName}",KpiConstants.months12).<= ($"${KpiConstants.serviceDateColName}")) || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.rubellaVal))).select(KpiConstants.memberidColName)

    val MMRNumertorInput8=MMRNumertorInput5.intersect(MMRNumertorInput6).intersect(MMRNumertorInput7)
    println("MMRNumertorInput8")
    MMRNumertorInput8.filter($"${KpiConstants.memberidColName}" === ("96533")).show()


val  MMRNumertorOutput=MMRNumertorInput1.union(MMRNumertorInput4).union(MMRNumertorInput8).distinct()

//    val groupedDsMMR = MMRNumertorInput.as[Member].groupByKey(k=>k.member_id)
//      .mapGroups((k,itr) => (k,itr.map(f=> f.service_date.getTime).toArray.sorted))
//
//    val MMRNumertorOutput = groupedDsMMR.map(f=>(UtilFunctions.getVisits(f._1,f._2))).toDF(KpiConstants.memberidColName,"visits").
//      filter($"visits".>=(4)).select(KpiConstants.memberidColName)

    //Numerator 4: HIB

    val HIBNumertorInput = visitJoinedDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hibVacVal))
      && ( UtilFunctions.add_ncqa_months (spark,$"${KpiConstants.dobColName}",KpiConstants.months24).>= ($"${KpiConstants.serviceDateColName}")
      && date_add($"${KpiConstants.dobColName}",42).<= ($"${KpiConstants.serviceDateColName}") ) )

    println("HIBNumertorInput")
    HIBNumertorInput.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    println("HIBNumertorInput")
    HIBNumertorInput.filter($"${KpiConstants.memberidColName}" === ("95834")).show()

    
    val groupedDsHIB = HIBNumertorInput.as[Member].groupByKey(k=>k.member_id)
      .mapGroups((k,itr) => (k,itr.map(f=> f.service_date.getTime).toArray.sorted))

    val HIBNumertorOutput = groupedDsHIB.map(f=>(UtilFunctions.getVisits(f._1,f._2))).toDF(KpiConstants.memberidColName,"visits").
      filter($"visits".>=(3)).select(KpiConstants.memberidColName)

    println("HIBNumertorOutput")
    HIBNumertorOutput.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    println("HIBNumertorInput")
    HIBNumertorInput.filter($"${KpiConstants.memberidColName}" === ("95834")).show()



    //Numerator 5: Hepatitis B

    val HBNumertorInputVac = visitJoinedDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hepatitisBVacVal))
      && ( UtilFunctions.add_ncqa_months (spark,$"${KpiConstants.dobColName}",KpiConstants.months24).>= ($"${KpiConstants.serviceDateColName}")
      //&& UtilFunctions.add_ncqa_months (spark,$"${KpiConstants.dobColName}",KpiConstants.months12).<= ($"${KpiConstants.serviceDateColName}")
      ))

    val HBNumertorInputNewborn = visitJoinedDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hepatitisBnewVacVal))
      && date_add($"${KpiConstants.dobColName}",7).>= ($"${KpiConstants.serviceDateColName}") )

    val HBNumertorInput=HBNumertorInputVac.union(HBNumertorInputNewborn)

    println("HBNumertorInput")
    HBNumertorInput.filter($"${KpiConstants.memberidColName}" === ("95973")).show()

    val groupedDsHB = HBNumertorInput.as[Member].groupByKey(k=>k.member_id)
      .mapGroups((k,itr) => (k,itr.map(f=> f.service_date.getTime).toArray.sorted))

    val HBNumertorOutput1 = groupedDsHB.map(f=>(UtilFunctions.getVisits(f._1,f._2))).toDF(KpiConstants.memberidColName,"visits").
      filter($"visits".>=(3)).select(KpiConstants.memberidColName)

    println("HBNumertorOutput1")
    HBNumertorOutput1.filter($"${KpiConstants.memberidColName}" === ("95973")).show()


    val HBNumertorOutput2 = visitJoinedDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hepatitisBVal))
      && ( UtilFunctions.add_ncqa_months (spark,$"${KpiConstants.dobColName}",KpiConstants.months24).>= ($"${KpiConstants.serviceDateColName}")
       )).select(KpiConstants.memberidColName)

    println("HBNumertorOutput2")
    HBNumertorOutput2.filter($"${KpiConstants.memberidColName}" === ("95973")).show()

    val HBNumertorOutput=HBNumertorOutput1.union(HBNumertorOutput2)

    //Numerator 6: VZV



    val VZVNumertorOutput = visitJoinedDf.filter(( array_contains($"${KpiConstants.valuesetColName}",KpiConstants.vzvVacVal)
      && ( UtilFunctions.add_ncqa_months (spark,$"${KpiConstants.dobColName}",KpiConstants.months24).>= ($"${KpiConstants.serviceDateColName}")
      && UtilFunctions.add_ncqa_months (spark,$"${KpiConstants.dobColName}",KpiConstants.months12).<= ($"${KpiConstants.serviceDateColName}") )  )
      ||
      ( array_contains($"${KpiConstants.valuesetColName}",KpiConstants.vzvVal)
        && ( UtilFunctions.add_ncqa_months (spark,$"${KpiConstants.dobColName}",KpiConstants.months24).>= ($"${KpiConstants.serviceDateColName}")

        ))).select(KpiConstants.memberidColName)


    println("visitJoinedDfwithznz")
    visitJoinedDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.vzvVacVal) ||
      array_contains($"${KpiConstants.valuesetColName}",KpiConstants.vzvVal)) && $"${KpiConstants.memberidColName}" === ("95276")).show()
    visitJoinedDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.vzvVacVal) ||
      array_contains($"${KpiConstants.valuesetColName}",KpiConstants.vzvVal)) && $"${KpiConstants.memberidColName}" === ("97009")).show()

       //Numerator 7: Pneumococcal conjugate
    val PCVNumertorInput = visitJoinedDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.pneConjVacVal))
      && ( UtilFunctions.add_ncqa_months (spark,$"${KpiConstants.dobColName}",KpiConstants.months24).>= ($"${KpiConstants.serviceDateColName}")
      && date_add($"${KpiConstants.dobColName}",42).<= ($"${KpiConstants.serviceDateColName}") ) )

    val groupedDsPCV = PCVNumertorInput.as[Member].groupByKey(k=>k.member_id)
      .mapGroups((k,itr) => (k,itr.map(f=> f.service_date.getTime).toArray.sorted))

    val PCVNumertorOutput = groupedDsPCV.map(f=>(UtilFunctions.getVisits(f._1,f._2))).toDF(KpiConstants.memberidColName,"visits").
      filter($"visits".>=(4)).select(KpiConstants.memberidColName)

    //Numerator 8: Hepatitis A


    val HANumertorOutput = visitJoinedDf.filter(( array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hepatitisAVacVal)
      && ( UtilFunctions.add_ncqa_months (spark,$"${KpiConstants.dobColName}",KpiConstants.months24).>= ($"${KpiConstants.serviceDateColName}")
      && UtilFunctions.add_ncqa_months (spark,$"${KpiConstants.dobColName}",KpiConstants.months12).<= ($"${KpiConstants.serviceDateColName}") )  )
      ||
      ( array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hepatitisAVal) && UtilFunctions.add_ncqa_months (spark,$"${KpiConstants.dobColName}",KpiConstants.months24).>= ($"${KpiConstants.serviceDateColName}")) ).select(KpiConstants.memberidColName)

    //Numerator 9: Rotavirus

    //Dose2
println("Rotavirus__Logic")
    val RVNumertorInput_2_dose = visitJoinedDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.rotavirusVac2Val))
      && ( UtilFunctions.add_ncqa_months (spark,$"${KpiConstants.dobColName}",KpiConstants.months24).>= ($"${KpiConstants.serviceDateColName}")
      && date_add($"${KpiConstants.dobColName}",42).<= ($"${KpiConstants.serviceDateColName}") ) )

    println("Rotavirus__Logic _2dose_input")
    RVNumertorInput_2_dose.filter($"${KpiConstants.memberidColName}" === ("97014")).show()

    val groupedDsRV_2_dose = RVNumertorInput_2_dose.as[Member].groupByKey(k=>k.member_id)
      .mapGroups((k,itr) => (k,itr.map(f=> f.service_date.getTime).toArray.sorted))

    val RVNumertorOutput_2_dose = groupedDsRV_2_dose.map(f=>(UtilFunctions.getVisits(f._1,f._2))).toDF(KpiConstants.memberidColName,"visits").
      filter($"visits".>=(2)).select(KpiConstants.memberidColName)

    println("RVNumertorOutput_2_dose")
    RVNumertorOutput_2_dose.filter($"${KpiConstants.memberidColName}" === ("97014")).show()


    val RVNumertorOutput_2_dose_recheck = groupedDsRV_2_dose.map(f=>(UtilFunctions.getVisits(f._1,f._2))).toDF(KpiConstants.memberidColName,"visits").
      filter($"visits".<=(1)).select(KpiConstants.memberidColName)

    //Dose3
    val RVNumertorInput_3_dose = visitJoinedDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.rotavirusVac3Val))
      && ( UtilFunctions.add_ncqa_months (spark,$"${KpiConstants.dobColName}",KpiConstants.months24).>= ($"${KpiConstants.serviceDateColName}")
      && date_add($"${KpiConstants.dobColName}",42).<= ($"${KpiConstants.serviceDateColName}") ) )


    println("Rotavirus__Logic _3dose_input")
    RVNumertorInput_3_dose.filter($"${KpiConstants.memberidColName}" === ("97014")).show()


    val groupedDsRV_3_dose = RVNumertorInput_3_dose.as[Member].groupByKey(k=>k.member_id)
      .mapGroups((k,itr) => (k,itr.map(f=> f.service_date.getTime).toArray.sorted))

    val RVNumertorOutput_3_dose = groupedDsRV_3_dose.map(f=>(UtilFunctions.getVisits(f._1,f._2))).toDF(KpiConstants.memberidColName,"visits").
      filter($"visits".>=(3)).select(KpiConstants.memberidColName)

    println("RVNumertorOutput_3_dose")
    RVNumertorOutput_3_dose.filter($"${KpiConstants.memberidColName}" === ("97014")).show()


    val RVNumertorOutput_3_dose_recheck = groupedDsRV_3_dose.map(f=>(UtilFunctions.getVisits(f._1,f._2))).toDF(KpiConstants.memberidColName,"visits").
      filter($"visits"===(2)).select(KpiConstants.memberidColName)

    //Dose2 and 3
    val RVNumertorOutput_recheck = RVNumertorOutput_3_dose_recheck.intersect(RVNumertorOutput_2_dose_recheck).distinct()

    println("Rotavirus__Logic _2&3dose_input")
    RVNumertorOutput_recheck.filter($"${KpiConstants.memberidColName}" === ("97014")).show()

    val RVNumertorInput_2_3_dose = visitJoinedDf.as("df1").join(RVNumertorOutput_recheck.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select("df1.*").filter( (array_contains($"${KpiConstants.valuesetColName}",KpiConstants.rotavirusVac2Val)||array_contains($"${KpiConstants.valuesetColName}",KpiConstants.rotavirusVac3Val))
      && ( UtilFunctions.add_ncqa_months (spark,$"${KpiConstants.dobColName}",KpiConstants.months24).>= ($"${KpiConstants.serviceDateColName}")
      && date_add($"${KpiConstants.dobColName}",42).<= ($"${KpiConstants.serviceDateColName}") ) )

    val groupedDsRV_2_3_dose = RVNumertorInput_2_3_dose.as[Member].groupByKey(k=>k.member_id)
      .mapGroups((k,itr) => (k,itr.map(f=> f.service_date.getTime).toArray.sorted))

    val RVNumertorOutput_2_3_dose = groupedDsRV_2_3_dose.map(f=>(UtilFunctions.getVisits(f._1,f._2))).toDF(KpiConstants.memberidColName,"visits").select(KpiConstants.memberidColName)

    println("RVNumertorOutput_2_3_dose")
    RVNumertorOutput_2_3_dose.filter($"${KpiConstants.memberidColName}" === ("97014")).show()

    val RVNumertorOutput = RVNumertorOutput_2_dose.union(RVNumertorOutput_3_dose).union(RVNumertorOutput_2_3_dose).distinct()

    println("RVNumertorOutput_temp_num")
    RVNumertorOutput.filter($"${KpiConstants.memberidColName}" === ("97014")).show()

    //Numerator 10: Influenza
    val INNumertorInput = visitJoinedDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.influenzaVacVal))
      && ( UtilFunctions.add_ncqa_months (spark,$"${KpiConstants.dobColName}",KpiConstants.months24).>= ($"${KpiConstants.serviceDateColName}")
      && date_add($"${KpiConstants.dobColName}",180).<= ($"${KpiConstants.serviceDateColName}") ) )

    val groupedDsIN = INNumertorInput.as[Member].groupByKey(k=>k.member_id)
      .mapGroups((k,itr) => (k,itr.map(f=> f.service_date.getTime).toArray.sorted))

    val INNumertorOutput = groupedDsIN.map(f=>(UtilFunctions.getVisits(f._1,f._2))).toDF(KpiConstants.memberidColName,"visits").
      filter($"visits".>=(2)).select(KpiConstants.memberidColName)

    //Numerator 11: Influenza

//  val  Numerator11Output = DTapNumertorOutput.intersect(IPVNumertorOutput).intersect(MMRNumertorOutput).intersect(HIBNumertorOutput).intersect(HBNumertorOutput).
//      intersect(VZVNumertorOutput)
//
// val   Numerator12Output = Numerator11Output.intersect(PCVNumertorOutput)
// val   Numerator13Output = Numerator12Output.intersect(HANumertorOutput)
//    val   Numerator14Output = Numerator12Output.intersect(RVNumertorOutput)
//    val   Numerator15Output = Numerator12Output.intersect(INNumertorOutput)
//    val   Numerator16Output = Numerator13Output.intersect(RVNumertorOutput)
//    val   Numerator17Output = Numerator13Output.intersect(INNumertorOutput)
//    val   Numerator18Output = Numerator12Output.intersect(RVNumertorOutput).intersect(INNumertorOutput)
//    val   Numerator19Output = Numerator16Output.intersect(INNumertorOutput)
//
///*temp Numarator */

    DTapNumertorOutput.coalesce(1).write.mode(SaveMode.Append).parquet("/home/hbase/ncqa/CIS/Numerator/Numerator1/")
    IPVNumertorOutput.coalesce(1).write.mode(SaveMode.Append).parquet("/home/hbase/ncqa/CIS/Numerator/Numerator2/")
    MMRNumertorOutput.coalesce(1).write.mode(SaveMode.Append).parquet("/home/hbase/ncqa/CIS/Numerator/Numerator3/")
    HIBNumertorOutput.coalesce(1).write.mode(SaveMode.Append).parquet("/home/hbase/ncqa/CIS/Numerator/Numerator4/")
    HBNumertorOutput.coalesce(1).write.mode(SaveMode.Append).parquet("/home/hbase/ncqa/CIS/Numerator/Numerator5/")
    VZVNumertorOutput.coalesce(1).write.mode(SaveMode.Append).parquet("/home/hbase/ncqa/CIS/Numerator/Numerator6/")
    PCVNumertorOutput.coalesce(1).write.mode(SaveMode.Append).parquet("/home/hbase/ncqa/CIS/Numerator/Numerator7/")
    HANumertorOutput.coalesce(1).write.mode(SaveMode.Append).parquet("/home/hbase/ncqa/CIS/Numerator/Numerator8/")
    RVNumertorOutput.coalesce(1).write.mode(SaveMode.Append).parquet("/home/hbase/ncqa/CIS/Numerator/Numerator9/")
    INNumertorOutput.coalesce(1).write.mode(SaveMode.Append).parquet("/home/hbase/ncqa/CIS/Numerator/Numerator10/")


    val  DTapNumertorOutputDf  =spark.read.parquet("/home/hbase/ncqa/CIS/Numerator/Numerator1/")
    val  IPVNumertorOutputDf  =spark.read.parquet("/home/hbase/ncqa/CIS/Numerator/Numerator2/")
    val  MMRNumertorOutputDf  =spark.read.parquet("/home/hbase/ncqa/CIS/Numerator/Numerator3/")
    val  HIBNumertorOutputDf  =spark.read.parquet("/home/hbase/ncqa/CIS/Numerator/Numerator4/")
    val  HBNumertorOutputDf  =spark.read.parquet("/home/hbase/ncqa/CIS/Numerator/Numerator5/")
    val  VZVNumertorOutputDf  =spark.read.parquet("/home/hbase/ncqa/CIS/Numerator/Numerator6/")
    val  PCVNumertorOutputDf  =spark.read.parquet("/home/hbase/ncqa/CIS/Numerator/Numerator7/")
    val  HANumertorOutputDf  =spark.read.parquet("/home/hbase/ncqa/CIS/Numerator/Numerator8/")
    val  RVNumertorOutputDf  =spark.read.parquet("/home/hbase/ncqa/CIS/Numerator/Numerator9/")
    val  INNumertorOutputDf  =spark.read.parquet("/home/hbase/ncqa/CIS/Numerator/Numerator10/")

    DTapNumertorOutput.unpersist()
    IPVNumertorOutput.unpersist()
    MMRNumertorOutput.unpersist()
    HIBNumertorOutput.unpersist()
    HBNumertorOutput.unpersist()
    VZVNumertorOutput.unpersist()
    PCVNumertorOutput.unpersist()
    HANumertorOutput.unpersist()
    RVNumertorOutput.unpersist()
    INNumertorOutput.unpersist()

    println("tempnumerators")
    DTapNumertorOutputDf.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    IPVNumertorOutputDf.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    MMRNumertorOutputDf.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    HIBNumertorOutputDf.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    HBNumertorOutputDf.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    VZVNumertorOutputDf.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    PCVNumertorOutputDf.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    HANumertorOutputDf.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    RVNumertorOutputDf.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    INNumertorOutputDf.filter($"${KpiConstants.memberidColName}" === ("97014")).show()



    val AlltempNumertor= DTapNumertorOutputDf.intersect(IPVNumertorOutputDf).intersect(MMRNumertorOutputDf).intersect(HIBNumertorOutputDf).intersect(HBNumertorOutputDf).
  intersect(VZVNumertorOutputDf).intersect(RVNumertorOutputDf).intersect(INNumertorOutputDf).intersect(PCVNumertorOutputDf).intersect(HANumertorOutputDf)

    val MMR_VZV_INtempNumerator=MMRNumertorOutputDf.intersect(VZVNumertorOutputDf).intersect(INNumertorOutputDf)

    val OptexclInputAll = eligiblePopDf.except(eligiblePopDf.filter($"${KpiConstants.memberidColName}".isin(AlltempNumertor.rdd.map(r=>r.getString(0)).collect():_*)))
    val OptexclInputDtap = eligiblePopDf.except(eligiblePopDf.filter($"${KpiConstants.memberidColName}".isin(DTapNumertorOutputDf.rdd.map(r=>r.getString(0)).collect():_*)))
    val OptexclInputMMR_VZV_IN = eligiblePopDf.except(eligiblePopDf.filter($"${KpiConstants.memberidColName}".isin(MMR_VZV_INtempNumerator.rdd.map(r=>r.getString(0)).collect():_*)))
    val OptexclInputRV = eligiblePopDf.except(eligiblePopDf.filter($"${KpiConstants.memberidColName}".isin(RVNumertorOutputDf.rdd.map(r=>r.getString(0)).collect():_*)))
//    val OptexclInputHB = eligiblePopDf.except(eligiblePopDf.filter($"${KpiConstants.memberidColName}".isin(HBNumertorOutputDf.rdd.map(r=>r.getString(0)).collect():_*)))
  //  val OptexclInputIPV = eligiblePopDf.except(eligiblePopDf.filter($"${KpiConstants.memberidColName}".isin(IPVNumertorOutputDf.rdd.map(r=>r.getString(0)).collect():_*)))


    println("optionInputs")
    OptexclInputAll.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    OptexclInputDtap.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    OptexclInputMMR_VZV_IN.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    OptexclInputRV.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    //OptexclInputHB.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    //OptexclInputIPV.filter($"${KpiConstants.memberidColName}" === ("97014")).show()


    val OptexclAnyOutput=  visitJoinedDf.as("df1").join(OptexclInputAll.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select("df1.*").filter( (array_contains($"${KpiConstants.valuesetColName}",KpiConstants.anaReactVacVal))
      && ( UtilFunctions.add_ncqa_months (spark,$"${KpiConstants.dobColName}",KpiConstants.months24).>= ($"${KpiConstants.serviceDateColName}")
       ) )
    val OptexclDtapOutput=  visitJoinedDf.as("df1").join(OptexclInputDtap.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select("df1.*").filter( (array_contains($"${KpiConstants.valuesetColName}",KpiConstants.encephalopathyVal) || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.vacCauseAdvEffVal))
      && ( UtilFunctions.add_ncqa_months (spark,$"${KpiConstants.dobColName}",KpiConstants.months24).>= ($"${KpiConstants.serviceDateColName}")
      ) )

    val OptexclMMR_VZV_INOutput=  visitJoinedDf.as("df1").join(OptexclInputMMR_VZV_IN.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select("df1.*").filter( (array_contains($"${KpiConstants.valuesetColName}",KpiConstants.disordersoftheImmuneSystemVal) || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hivVal) || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hivType2Val) || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.mallNeoLymTisVal))
      && ( UtilFunctions.add_ncqa_months (spark,$"${KpiConstants.dobColName}",KpiConstants.months24).>= ($"${KpiConstants.serviceDateColName}")
      ) )
    val OptexclRVOutput=  visitJoined_out_market_Df.as("df1").join(OptexclInputRV.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select("df1.*").filter( (array_contains($"${KpiConstants.valuesetColName}",KpiConstants.severeCombImmunVal) || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.intussusceptionVal))
      && ( UtilFunctions.add_ncqa_months (spark,$"${KpiConstants.dobColName}",KpiConstants.months24).>= ($"${KpiConstants.serviceDateColName}")
      ) )

//    val OptexclHBOutput=  visitJoinedDf.as("df1").join(OptexclInputHB.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
//      .select("df1.*").filter( (array_contains($"${KpiConstants.valuesetColName}",KpiConstants.) || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.vacCauseAdvEffVal))
//      && ( UtilFunctions.add_ncqa_months (spark,$"${KpiConstants.dobColName}",KpiConstants.months24).>= ($"${KpiConstants.serviceDateColName}")
//      ) )

    println("optionOutputs")
    OptexclAnyOutput.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    OptexclDtapOutput.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    OptexclMMR_VZV_INOutput.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    OptexclRVOutput.filter($"${KpiConstants.memberidColName}" === ("97014")).show()

    val OptexclOutputDf =OptexclAnyOutput.union(OptexclDtapOutput).union(OptexclMMR_VZV_INOutput).union(OptexclRVOutput).select($"${KpiConstants.memberidColName}")

    println("optionfinaloutput")
    OptexclOutputDf.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    OptexclOutputDf.filter($"${KpiConstants.memberidColName}" === ("97014")).show()

    OptexclOutputDf.coalesce(1).write.mode(SaveMode.Append).parquet("/home/hbase/ncqa/CIS/Numerator/OptexclOutput/")

    val  OptexclOutput  =spark.read.parquet("/home/hbase/ncqa/CIS/Numerator/OptexclOutput/")

    OptexclOutput.select($"${KpiConstants.memberidColName}").coalesce(1).write.mode(SaveMode.Append).option("header", "true").csv("/home/hbase/ncqa/CIS/Numerator/Optexcl/")

    val   Numerator_1Output = DTapNumertorOutputDf.except(DTapNumertorOutputDf.filter($"${KpiConstants.memberidColName}".isin(
      OptexclOutput.rdd.map(r=>r.getString(0)).collect():_*)))
    val   Numerator_2Output = IPVNumertorOutputDf.except(IPVNumertorOutputDf.filter($"${KpiConstants.memberidColName}".isin(
      OptexclOutput.rdd.map(r=>r.getString(0)).collect():_*)))
    val   Numerator_3Output = MMRNumertorOutputDf.except(MMRNumertorOutputDf.filter($"${KpiConstants.memberidColName}".isin(
      OptexclOutput.rdd.map(r=>r.getString(0)).collect():_*)))
    val   Numerator_4Output = HIBNumertorOutputDf.except(HIBNumertorOutputDf.filter($"${KpiConstants.memberidColName}".isin(
      OptexclOutput.rdd.map(r=>r.getString(0)).collect():_*)))
    val   Numerator_5Output = HBNumertorOutputDf.except(HBNumertorOutputDf.filter($"${KpiConstants.memberidColName}".isin(
      OptexclOutput.rdd.map(r=>r.getString(0)).collect():_*)))
    val   Numerator_6Output = VZVNumertorOutputDf.except(VZVNumertorOutputDf.filter($"${KpiConstants.memberidColName}".isin(
      OptexclOutput.rdd.map(r=>r.getString(0)).collect():_*)))
    val   Numerator_7Output = PCVNumertorOutputDf.except(PCVNumertorOutputDf.filter($"${KpiConstants.memberidColName}".isin(
      OptexclOutput.rdd.map(r=>r.getString(0)).collect():_*)))
    val   Numerator_8Output = HANumertorOutputDf.except(HANumertorOutputDf.filter($"${KpiConstants.memberidColName}".isin(
      OptexclOutput.rdd.map(r=>r.getString(0)).collect():_*)))
    val   Numerator_9_tempOutput = RVNumertorOutputDf.except(RVNumertorOutputDf.filter($"${KpiConstants.memberidColName}".isin(
      OptexclOutput.rdd.map(r=>r.getString(0)).collect():_*)))
    val  Numerator_9Output =Numerator_9_tempOutput.as("num").join(visitJoined_out_market_Df.as("vis")
      ,$"num.${KpiConstants.memberidColName}" === $"vis.${KpiConstants.memberidColName}", KpiConstants.innerJoinType).
      select( $"num.*")
    val   Numerator_10Output = INNumertorOutputDf.except(INNumertorOutputDf.filter($"${KpiConstants.memberidColName}".isin(
      OptexclOutput.rdd.map(r=>r.getString(0)).collect():_*)))

      val  Numerator_11Output = Numerator_1Output.intersect(Numerator_2Output).intersect(Numerator_3Output).intersect(Numerator_4Output).intersect(Numerator_5Output).
          intersect(Numerator_6Output)

     val   Numerator_12Output = Numerator_11Output.intersect(Numerator_7Output)
     val   Numerator_13Output = Numerator_12Output.intersect(Numerator_8Output)
        val   Numerator_14Output = Numerator_12Output.intersect(Numerator_9Output)
        val   Numerator_15Output = Numerator_12Output.intersect(Numerator_10Output)
        val   Numerator_16Output = Numerator_13Output.intersect(Numerator_9Output)
        val   Numerator_17Output = Numerator_13Output.intersect(Numerator_10Output)
        val   Numerator_18Output = Numerator_12Output.intersect(Numerator_9Output).intersect(Numerator_10Output)
        val   Numerator_19Output = Numerator_16Output.intersect(Numerator_10Output)



    println("numeratorOutputs")
    Numerator_1Output.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    Numerator_1Output.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    Numerator_2Output.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    Numerator_2Output.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    Numerator_3Output.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    Numerator_3Output.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    Numerator_4Output.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    Numerator_4Output.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    Numerator_5Output.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    Numerator_5Output.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    Numerator_6Output.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    Numerator_6Output.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    Numerator_7Output.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    Numerator_7Output.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    Numerator_8Output.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    Numerator_8Output.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    Numerator_9Output.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    Numerator_9Output.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    Numerator_10Output.filter($"${KpiConstants.memberidColName}" === ("97014")).show()
    Numerator_10Output.filter($"${KpiConstants.memberidColName}" === ("97014")).show()



    Numerator_2Output.coalesce(1).write.mode(SaveMode.Append).option("header", "true").csv("/home/hbase/ncqa/CIS/Numerator/Numerator_2/")
    Numerator_3Output.coalesce(1).write.mode(SaveMode.Append).option("header", "true").csv("/home/hbase/ncqa/CIS/Numerator/Numerator_3/")
    Numerator_4Output.coalesce(1).write.mode(SaveMode.Append).option("header", "true").csv("/home/hbase/ncqa/CIS/Numerator/Numerator_4/")
    Numerator_1Output.coalesce(1).write.mode(SaveMode.Append).option("header", "true").csv("/home/hbase/ncqa/CIS/Numerator/Numerator_1/")
    Numerator_5Output.coalesce(1).write.mode(SaveMode.Append).option("header", "true").csv("/home/hbase/ncqa/CIS/Numerator/Numerator_5/")
    Numerator_6Output.coalesce(1).write.mode(SaveMode.Append).option("header", "true").csv("/home/hbase/ncqa/CIS/Numerator/Numerator_6/")
    Numerator_7Output.coalesce(1).write.mode(SaveMode.Append).option("header", "true").csv("/home/hbase/ncqa/CIS/Numerator/Numerator_7/")
    Numerator_8Output.coalesce(1).write.mode(SaveMode.Append).option("header", "true").csv("/home/hbase/ncqa/CIS/Numerator/Numerator_8/")
    Numerator_9Output.coalesce(1).write.mode(SaveMode.Append).option("header", "true").csv("/home/hbase/ncqa/CIS/Numerator/Numerator_9/")
    Numerator_10Output.coalesce(1).write.mode(SaveMode.Append).option("header", "true").csv("/home/hbase/ncqa/CIS/Numerator/Numerator_10/")

    val outMap = mutable.Map(KpiConstants.totalPopDfName ->toutStrDf , KpiConstants.eligibleDfName -> eligiblePopDf,
      KpiConstants.mandatoryExclDfname -> spark.emptyDataFrame, KpiConstants.optionalExclDfName -> OptexclOutput,
      KpiConstants.numeratorDfName -> Numerator_1Output , KpiConstants.numerator2DfName -> Numerator_2Output,
      KpiConstants.numerator3DfName -> Numerator_3Output, KpiConstants.numerator4DfName -> Numerator_4Output,
      KpiConstants.numerator5DfName -> Numerator_5Output , KpiConstants.numerator6DfName -> Numerator_6Output ,
      KpiConstants.numerator7DfName -> Numerator_7Output,      KpiConstants.numerator8DfName -> Numerator_8Output,
      KpiConstants.numerator9DfName -> Numerator_9Output,  KpiConstants.numerator10DfName -> Numerator_10Output,
      KpiConstants.numerator11DfName -> Numerator_11Output , KpiConstants.numerator12DfName -> Numerator_12Output ,
      KpiConstants.numerator13DfName -> Numerator_13Output,      KpiConstants.numerator14DfName -> Numerator_14Output,
      KpiConstants.numerator15DfName -> Numerator_15Output,  KpiConstants.numerator16DfName -> Numerator_16Output,
      KpiConstants.numerator17DfName -> Numerator_17Output,      KpiConstants.numerator18DfName -> Numerator_18Output,
      KpiConstants.numerator19DfName -> Numerator_19Output)


    val outDf = UtilFunctions.ncqaCISOutputDfCreation(spark,outMap)
    outDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("/home/hbase/ncqa/CIS/outDf/")


  }

}
