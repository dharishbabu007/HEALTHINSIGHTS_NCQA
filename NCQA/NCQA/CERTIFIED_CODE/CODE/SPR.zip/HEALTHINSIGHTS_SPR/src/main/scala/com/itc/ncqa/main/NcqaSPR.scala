package com.itc.ncqa.main

import com.itc.ncqa.Constants.KpiConstants
import com.itc.ncqa.Functions.{DataLoadFunctions, UtilFunctions}
import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkConf
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{array_contains, _}
import org.apache.spark.sql.types.IntegerType

import scala.collection.mutable

object NcqaSPR {
  def main(args: Array[String]): Unit = {

    val StringtoIntger =udf((value:String) => value.toInt)
    //<editor-fold desc="Reading program arguments and SaprkSession oBject creation">

    //    val year = args(0)
    //    val measureId = args(1)
    //    val dbName = args(2)

    val measureId = "SPR"
    val year = "2018"
    /*calling function for setting the dbname for dbName variable*/
    // KpiConstants.setDbName(dbName)
    //    val conf = new SparkConf().setAppName("NcqaProgram")
    //    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    //      .set("hive.exec.dynamic.partition.mode", "nonstrict")
    //    .set("spark.sql.shuffle.partitions","5")

    val conf = new SparkConf().setAppName("NcqaProgram").setMaster("local[*]")
    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      .set("hive.exec.dynamic.partition.mode", "nonstrict")
      .set("spark.sql.shuffle.partitions","5")
    val spark = SparkSession.builder().config(conf).getOrCreate()

    // val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    import spark.implicits._
    val rootLogger=Logger.getRootLogger()
    rootLogger.setLevel(Level.ERROR)
    //</editor-fold>

    //<editor-fold desc="Loading Required Tables to memory">

    val ystDate = year+"-01-01"
    val yendDate = year+"-12-31"
    val aLiat = List("col1")
    val msrVal = s"'$measureId'"
    val ggMsrId = s"'${KpiConstants.ggMeasureId}'"
    val lobList = List(KpiConstants.commercialLobName,KpiConstants.medicareLobName, KpiConstants.medicaidLobName,KpiConstants.mmdLobName)
    val ((membershipDf,visitsDf,refHedisDf,ref_medvaluesetDf)) = DataLoadFunctions.readdatafromlocal(spark,measureId,year)
    val readallrefhedisDf=DataLoadFunctions.readallrefhedis(spark,measureId,year)
    val readmembersmonthlydf=DataLoadFunctions.readmonthly(spark,measureId,year)
    val hosposiedf = readmembersmonthlydf.filter(($"run_date".>=(ystDate)) && ($"run_date".<=(yendDate))
      and $"${KpiConstants.hospiceVal}".===(KpiConstants.yesVal) )
      .select(KpiConstants.memberidColName).distinct()

    println("hosposiedf")
    visitsDf.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    visitsDf.filter($"${KpiConstants.memberidColName}" === ("95033")).show()

    val ageEndDate = year + "-12-31"
    val ageStartDate = year + "-01-01"
    val IntakeStartDate = year.toInt-1 + "-07-01"
    val IntakeEndDate = year + "-06-30"

    val ICDList = List("J00","J06.0","J06.9")
    //    def is_icd: (String => Boolean) = {
    //
    //      val ICDList = List("J03.81", "J03.91", "J02.9", "J03.80", "J03.90", "J03.00", "J03.01")
    //      InputCode =>   if ((InputCode) == "null" || InputCode.isEmpty ) true
    //      else  ICDList.contains(InputCode)
    //    }
    //    import org.apache.spark.sql.functions.udf
    //    val ICDUDF = udf(is_icd)

  println("InputVisistsDF")
    visitsDf.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    visitsDf.filter($"${KpiConstants.memberidColName}" === ("95033")).show()
    println("InputmembersDF")
    membershipDf.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    membershipDf.filter($"${KpiConstants.memberidColName}" === ("95033")).show()
    //temporary-1//
    println("membershipDf_visitsDf_refHedisDf_ref_medvaluesetDf")
    membershipDf.show(10)
    visitsDf.show(10)
    println("membershipDfInput")
    membershipDf.filter($"${KpiConstants.memberidColName}" === ("95107")).show()

  visitsDf.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    refHedisDf.show(10)
    ref_medvaluesetDf.show(10)
    /* read from local*/
    //</editor-fold


    //<editor-fold desc="Eligible Population Calculation">

    //<editor-fold desc=" filter">



    //   val visitsDfWithAgeFilter = visitsDf.withColumn("Lastdayinmyear",add_months($"${KpiConstants.dobColName}",216)).withColumn("age",when ((dayofmonth($"${KpiConstants.dobColName}")===30 && month($"${KpiConstants.dobColName}")===6),round(datediff(lit(IntakeEndDate), $"${KpiConstants.dobColName}")/365.25)).otherwise(datediff(lit(IntakeEndDate), $"${KpiConstants.dobColName}")/365.25)).filter($"age">=3 and $"age"<18 )
    //  val visitsDfWithAgeFilter = visitsDf.filter((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}",KpiConstants.months156).>=(IntakeStartDate)) && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}",KpiConstants.months156).<=(IntakeEndDate)))
    val visitsDfWithAgeFilter = visitsDf.filter((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}",KpiConstants.months504).<=(ageEndDate))
    )
    println("ageFilterDf")
    visitsDfWithAgeFilter.show()

    println("visitsDfWithAgeFilter")
    visitsDfWithAgeFilter.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    visitsDfWithAgeFilter.filter($"${KpiConstants.memberidColName}" === ("95033")).show()

    val visitsDfWithNonsupplementDF=visitsDfWithAgeFilter.filter($"${KpiConstants.supplflagColName}".===("N"))

    println("visitsDfWithNonsupplementDF")
    visitsDfWithNonsupplementDF.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    visitsDfWithNonsupplementDF.filter($"${KpiConstants.memberidColName}" === ("95033")).show()

    val argmapforRefHedis = mutable.Map(KpiConstants.eligibleDfName -> visitsDfWithNonsupplementDF , KpiConstants.refHedisTblName -> refHedisDf,KpiConstants.refmedValueSetTblName -> ref_medvaluesetDf)
    val argmapforRefHediswithSF = mutable.Map(KpiConstants.eligibleDfName -> visitsDfWithAgeFilter , KpiConstants.refHedisTblName -> refHedisDf,KpiConstants.refmedValueSetTblName -> ref_medvaluesetDf)

    val allValueList = List(KpiConstants.independentLabVal, KpiConstants.hospiceVal,KpiConstants.copdVal,KpiConstants.edVal,KpiConstants.observationVal,KpiConstants.inPatientStayVal,KpiConstants.outPatientVal,KpiConstants.accuteInpatVal
      ,KpiConstants.emphysemaVal,KpiConstants.chronicBronchitisVal,KpiConstants.telehealthModifierVal,KpiConstants.telehealthPosVal,KpiConstants.nonAcuteInPatientStayVal,KpiConstants.telephoneVisitsVal,KpiConstants.onlineAssesmentVal,KpiConstants.spirometryVal)
    val medList =List(KpiConstants.cwpAntibioticMedicationListsVal)

    val visitRefHedisDf = UtilFunctions.joinWithRefHedisFunction(spark,argmapforRefHedis,allValueList,medList)
    val visitRefHedisDfSF = UtilFunctions.joinWithRefHedisFunction(spark,argmapforRefHediswithSF,allValueList,medList)
    println("visitRefHedisDf")
    visitRefHedisDf.show()
    visitRefHedisDf.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    visitRefHedisDf.filter($"${KpiConstants.memberidColName}" === ("95033")).show()

    
    val groupList = visitsDf.schema.fieldNames.toList.dropWhile(p=> p.equalsIgnoreCase(KpiConstants.memberidColName))
    
    val visitgroupedDf = visitRefHedisDf.groupBy(KpiConstants.memberidColName, groupList:_*).agg(collect_list(KpiConstants.valuesetColName).alias(KpiConstants.valuesetColName))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName, KpiConstants.admitDateColName, KpiConstants.dischargeDateColName,
        KpiConstants.dobColName,KpiConstants.supplflagColName, KpiConstants.ispcpColName,KpiConstants.isobgynColName, KpiConstants.valuesetColName,KpiConstants.genderColName)

    val visitgroupedDfSF = visitRefHedisDfSF.groupBy(KpiConstants.memberidColName, groupList:_*).agg(collect_list(KpiConstants.valuesetColName).alias(KpiConstants.valuesetColName))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName, KpiConstants.admitDateColName, KpiConstants.dischargeDateColName,
        KpiConstants.dobColName,KpiConstants.supplflagColName, KpiConstants.ispcpColName,KpiConstants.isobgynColName, KpiConstants.valuesetColName,KpiConstants.genderColName)

    val indLabVisRemDfSF =
      visitgroupedDfSF.filter(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)).repartition(2).cache()
    indLabVisRemDfSF.count()
    println("indLabVisRemDf")

    /*visitgroupedDf.filter($"${KpiConstants.memberidColName}" === ("107650")).show()*/

   val indLabVisRemDf =
visitgroupedDf.filter(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)).repartition(2).cache()
    indLabVisRemDf.count()
    println("indLabVisRemDf")

    indLabVisRemDf.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    indLabVisRemDf.filter($"${KpiConstants.memberidColName}" === ("95033")).show()



    val  visitsHospiceDF= indLabVisRemDf.filter(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hospiceVal) &&($"${KpiConstants.serviceDateColName}".>=(ageStartDate) && $"${KpiConstants.serviceDateColName}".<=(ageEndDate))).select($"${KpiConstants.memberidColName}")
    val visitsHospice =hosposiedf.union(visitsHospiceDF)

    val visitsHospiceremovalDF=indLabVisRemDf.except(visitgroupedDf.filter($"${KpiConstants.memberidColName}".isin(
      visitsHospice.rdd.map(r=>r.getString(0)).collect():_*)))


    visitsHospiceremovalDF.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .parquet("/home/hbase/ncqa/SPR/visitsHospiceremoval/")

    val visitsHospiceremoval = spark.read.parquet("/home/hbase/ncqa/SPR/visitsHospiceremoval/").cache()

    println("visitsHospiceremoval")
    visitsHospiceremoval.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    visitsHospiceremoval.filter($"${KpiConstants.memberidColName}" === ("95033")).show()

    // visitsHospiceremoval.show()
    val visits_step1 =visitsHospiceremoval.filter(
      (array_contains($"${KpiConstants.valuesetColName}",KpiConstants.outPatientVal) ||
        array_contains($"${KpiConstants.valuesetColName}",KpiConstants.edVal) ||
        array_contains($"${KpiConstants.valuesetColName}",KpiConstants.observationVal)
        || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.inPatientStayVal))
        && (
        array_contains($"${KpiConstants.valuesetColName}",KpiConstants.copdVal)
          || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.emphysemaVal)
          || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.chronicBronchitisVal)
          || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.inPatientStayVal)
          || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.telehealthPosVal)
          || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.telehealthModifierVal) )
        && ($"${KpiConstants.serviceDateColName}".>=(IntakeStartDate) && $"${KpiConstants.serviceDateColName}".<=(IntakeEndDate)))

    println("visits_step1")

    visits_step1.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    visits_step1.filter($"${KpiConstants.memberidColName}" === ("95033")).show()



    val visits_accute_inpatient_tmp  =visitsHospiceremoval.filter(
      (array_contains($"${KpiConstants.valuesetColName}",KpiConstants.inpatientStayVal)
        && ($"${KpiConstants.dischargeDateColName}".>=(IntakeStartDate) && $"${KpiConstants.dischargeDateColName}".<=(IntakeEndDate))
        ))
      .select(KpiConstants.memberidColName,KpiConstants.dischargeDateColName)

    val visits_accute_admitdates =visitsHospiceremoval.filter(
      (array_contains($"${KpiConstants.valuesetColName}",KpiConstants.inpatientStayVal)
        && ($"${KpiConstants.dischargeDateColName}".>=(IntakeStartDate) && $"${KpiConstants.dischargeDateColName}".<=(IntakeEndDate))
        ))
      .select(KpiConstants.memberidColName,KpiConstants.dischargeDateColName,KpiConstants.admitDateColName)

    val visits_accute_min_admitdates=visits_accute_admitdates.groupBy(
      KpiConstants.memberidColName,KpiConstants.dischargeDateColName).agg(min(KpiConstants.admitDateColName)
    .alias(KpiConstants.admitDateColName)).
      select(KpiConstants.memberidColName,KpiConstants.dischargeDateColName,KpiConstants.admitDateColName)

    val visits_accute_inpatient_with_diag  =visitsHospiceremoval.filter(
      (
        array_contains($"${KpiConstants.valuesetColName}",KpiConstants.copdVal)
          || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.emphysemaVal)
          || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.chronicBronchitisVal)
        )
        && ($"${KpiConstants.dischargeDateColName}".>=(IntakeStartDate) && $"${KpiConstants.dischargeDateColName}".<=(IntakeEndDate))
    )
      .select(KpiConstants.memberidColName,KpiConstants.dischargeDateColName)

    val visits_accute_inpatient = visits_accute_inpatient_tmp.intersect(visits_accute_inpatient_with_diag)

    println("visits_accute_inpatient")

    visits_accute_inpatient.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    visits_accute_inpatient.filter($"${KpiConstants.memberidColName}" === ("95033")).show()

    val visits_non_accute_inpatient =visitsHospiceremoval.filter(
      (array_contains( $"${KpiConstants.valuesetColName}",KpiConstants.nonAcuteInPatientStayVal)
        )  && ($"${KpiConstants.dischargeDateColName}".>=(IntakeStartDate) && $"${KpiConstants.dischargeDateColName}".<=(IntakeEndDate)))
      .select(KpiConstants.memberidColName,KpiConstants.dischargeDateColName)

    println("visits_non_accute_inpatient")

    visits_non_accute_inpatient.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    visits_non_accute_inpatient.filter($"${KpiConstants.memberidColName}" === ("95033")).show()

    val actuedf = visits_accute_inpatient.except(visits_non_accute_inpatient)

    println("actuedf")
    actuedf.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    actuedf.filter($"${KpiConstants.memberidColName}" === ("95033")).show()

    val visits_step1_ed_obr =visits_step1.filter( array_contains($"${KpiConstants.valuesetColName}",KpiConstants.edVal)||
      array_contains($"${KpiConstants.valuesetColName}",KpiConstants.observationVal)
    ).select(KpiConstants.memberidColName,KpiConstants.serviceDateColName,KpiConstants.admitDateColName)

    println("visits_step1_ed_obr")
    visits_step1_ed_obr.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    visits_step1_ed_obr.filter($"${KpiConstants.memberidColName}" === ("95033")).show()


    val visits_step1_inpatient =visitsHospiceremoval.filter( array_contains($"${KpiConstants.valuesetColName}",
      KpiConstants.inPatientStayVal) && ($"${KpiConstants.dischargeDateColName}".>=(IntakeStartDate) && $"${KpiConstants.dischargeDateColName}".<=(IntakeEndDate))
    ).select(KpiConstants.memberidColName,KpiConstants.admitDateColName,KpiConstants.dischargeDateColName
    )

    println("visits_step1_inpatient")
    visits_step1_inpatient.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    visits_step1_inpatient.filter($"${KpiConstants.memberidColName}" === ("95033")).show()

    val visits_step1_inpatient_1 =visits_step1_ed_obr.as("claimsVisitis").join(visits_step1_inpatient.as("InPatient"),
      ($"claimsVisitis.${KpiConstants.memberidColName}" === $"InPatient.${KpiConstants.memberidColName}"
        &&  ($"claimsVisitis.${KpiConstants.admitDateColName}"===($"InPatient.${KpiConstants.admitDateColName}")
        ||  ($"claimsVisitis.${KpiConstants.serviceDateColName}"
        between (date_add($"InPatient.${KpiConstants.admitDateColName}" ,-1) , $"InPatient.${KpiConstants.dischargeDateColName}")))
        ) , KpiConstants.innerJoinType).select($"claimsVisitis.*").distinct()

    println("visits_step1_inpatient_1")
    visits_step1_inpatient_1.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    visits_step1_inpatient_1.filter($"${KpiConstants.memberidColName}" === ("95033")).show()

    val visits_telehealth =visits_step1.filter(
      array_contains($"${KpiConstants.valuesetColName}",KpiConstants.telehealthModifierVal)
        || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.telehealthPosVal)
    ).select(KpiConstants.memberidColName,KpiConstants.serviceDateColName,KpiConstants.admitDateColName)

    val step1_exclude =visits_step1_inpatient_1.union(visits_telehealth).union(visits_step1_inpatient)


    println("step1_exclude")
    step1_exclude.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    step1_exclude.filter($"${KpiConstants.memberidColName}" === ("95033")).show()


    val step1_outpatient =visits_step1.except(
      visits_step1.as("df1").join(step1_exclude.as("df2"), ( $"df1.${KpiConstants.memberidColName}"===$"df2.${KpiConstants.memberidColName}"
        && $"df1.${KpiConstants.serviceDateColName}"===$"df2.${KpiConstants.serviceDateColName}"),KpiConstants.innerJoinType)
        .select($"df1.*"))

    val accutedf_step1 =actuedf.as("df1").join(visits_accute_min_admitdates.as("df2"),
      ( $"df1.${KpiConstants.memberidColName}"===$"df2.${KpiConstants.memberidColName}"
      && $"df1.${KpiConstants.dischargeDateColName}"===$"df2.${KpiConstants.dischargeDateColName}")
      ,KpiConstants.innerJoinType)
      .select($"df1.${KpiConstants.memberidColName}",$"df1.${KpiConstants.dischargeDateColName}",
        $"df2.${KpiConstants.admitDateColName}",lit("IN").alias("Type"))

    println("accutedf_step1")
    accutedf_step1.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    accutedf_step1.filter($"${KpiConstants.memberidColName}" === ("95033")).show()


    val  step1Df=step1_outpatient.select($"${KpiConstants.memberidColName}",$"${KpiConstants.serviceDateColName}"
     ,lit("").alias(KpiConstants.admitDateColName),lit("OUT").alias("Type")).union(accutedf_step1)
    println("step1Df")
    step1Df.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    step1Df.filter($"${KpiConstants.memberidColName}" === ("95033")).show()

    val step1_final_group= step1Df.groupBy($"${KpiConstants.memberidColName}")
      .agg(min($"${KpiConstants.serviceDateColName}").alias(KpiConstants.iesdDateColName))
      .select($"${KpiConstants.memberidColName}",$"${KpiConstants.iesdDateColName}")

   val step1_finaldf= step1_final_group.as("df1").join(step1Df.as("df2"),
      ( $"df1.${KpiConstants.memberidColName}"===$"df2.${KpiConstants.memberidColName}"
        && $"df1.${KpiConstants.iesdDateColName}"===$"df2.${KpiConstants.serviceDateColName}")
      ,KpiConstants.innerJoinType).select($"df1.${KpiConstants.memberidColName}",
     $"df1.${KpiConstants.iesdDateColName}",$"df2.${KpiConstants.admitDateColName}",$"df2.Type"
   )



    step1_finaldf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .parquet("/home/hbase/ncqa/SPR/step1_finaldf/")

    val step1_final = spark.read.parquet("/home/hbase/ncqa/SPR/step1_finaldf/").cache()

    println("step1_final")
    step1_final.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    step1_final.filter($"${KpiConstants.memberidColName}" === ("95033")).show()

    /*Step2*/

    val visits_step2_a =visitsHospiceremoval.filter(
      (array_contains($"${KpiConstants.valuesetColName}",KpiConstants.outPatientVal)  )
        && (
        array_contains($"${KpiConstants.valuesetColName}",KpiConstants.telephoneVisitsVal)
          || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.onlineAssesmentVal)
        )
    )

    val visits_step2_b =visitsHospiceremoval.filter(
      (array_contains($"${KpiConstants.valuesetColName}",KpiConstants.observationVal)
        || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.outPatientVal)
        ||
        array_contains($"${KpiConstants.valuesetColName}",KpiConstants.edVal)
        || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.inpatientStayVal)
        || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.telephoneVisitsVal)
        || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.onlineAssesmentVal))
        && (
        array_contains($"${KpiConstants.valuesetColName}",KpiConstants.copdVal)
          || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.emphysemaVal)
          || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.chronicBronchitisVal)
          || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.inpatientStayVal)
          || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.telephoneVisitsVal)
          || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.onlineAssesmentVal)
        )
    )
    val visits_step2 =visits_step2_a.union(visits_step2_b)

    println("visits_step2")
    visits_step2.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    visits_step2.filter($"${KpiConstants.memberidColName}" === ("95033")).show()

    val visits_accute_inpatient_2_tmp =visitsHospiceremoval.filter(
      (array_contains($"${KpiConstants.valuesetColName}",KpiConstants.inpatientStayVal)
        )
    )
      .select(KpiConstants.memberidColName,KpiConstants.dischargeDateColName)

    val visits_accute_admision_2_daig =visitsHospiceremoval.filter(
      (
        array_contains($"${KpiConstants.valuesetColName}",KpiConstants.copdVal)
          || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.emphysemaVal)
          || array_contains($"${KpiConstants.valuesetColName}",KpiConstants.chronicBronchitisVal)
        )
    )
      .select(KpiConstants.memberidColName,KpiConstants.dischargeDateColName)

    val visits_accute_inpatient_2 =visits_accute_inpatient_2_tmp.intersect(visits_accute_admision_2_daig)
    println("visits_accute_inpatient_2")
    visits_accute_inpatient_2.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    visits_accute_inpatient_2.filter($"${KpiConstants.memberidColName}" === ("95033")).show()

    println("visits_accute_inpatient_2")
    visits_accute_inpatient_2.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    visits_accute_inpatient_2.filter($"${KpiConstants.memberidColName}" === ("95033")).show()

    val visits_non_accute_inpatient_2 =visitsHospiceremoval.filter(
      (array_contains( $"${KpiConstants.valuesetColName}",KpiConstants.nonAcuteInPatientStayVal)
        ) )
      .select(KpiConstants.memberidColName,KpiConstants.dischargeDateColName)

    println("visits_non_accute_inpatient_2")
    visits_non_accute_inpatient_2.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    visits_non_accute_inpatient_2.filter($"${KpiConstants.memberidColName}" === ("95033")).show()


    val actuedf_2 = visits_accute_inpatient_2.except(visits_non_accute_inpatient_2)

    println("actuedf_2")
    actuedf_2.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    actuedf_2.filter($"${KpiConstants.memberidColName}" === ("95033")).show()

    val visits_step2_ed_obr =visits_step2.filter( array_contains($"${KpiConstants.valuesetColName}",KpiConstants.edVal)||
      array_contains($"${KpiConstants.valuesetColName}",KpiConstants.observationVal)
    ).select(KpiConstants.memberidColName,KpiConstants.serviceDateColName,KpiConstants.admitDateColName)

    println("visits_step2_ed_obr")
    visits_step2_ed_obr.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    visits_step2_ed_obr.filter($"${KpiConstants.memberidColName}" === ("95033")).show()



    val visits_step2_inpatient =visits_step2.filter( array_contains($"${KpiConstants.valuesetColName}",
      KpiConstants.inPatientStayVal)
    ).select(KpiConstants.memberidColName,KpiConstants.admitDateColName,KpiConstants.dischargeDateColName
    )

    val visits_step1_inpatient_2 =visits_step2_ed_obr.as("claimsVisitis").join(visits_step2_inpatient.as("InPatient"),
      ($"claimsVisitis.${KpiConstants.memberidColName}" === $"InPatient.${KpiConstants.memberidColName}"
        &&  ($"claimsVisitis.${KpiConstants.admitDateColName}"===($"InPatient.${KpiConstants.admitDateColName}")
        ||  ($"claimsVisitis.${KpiConstants.serviceDateColName}" between (date_add($"InPatient.${KpiConstants.admitDateColName}" ,-1) , $"InPatient.${KpiConstants.dischargeDateColName}")))
        )
      , KpiConstants.innerJoinType).select($"claimsVisitis.*").distinct()

    println("visits_step1_inpatient_2")
    visits_step1_inpatient_2.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    visits_step1_inpatient_2.filter($"${KpiConstants.memberidColName}" === ("95033")).show()


    val step2_exclude =visits_step1_inpatient_2  ///.union(visits_step2_inpatient)


    println("step2_exclude")
    step2_exclude.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    step2_exclude.filter($"${KpiConstants.memberidColName}" === ("95033")).show()


    println("visits_step1_inpatient_2")
    visits_step1_inpatient_2.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    visits_step1_inpatient_2.filter($"${KpiConstants.memberidColName}" === ("95033")).show()

    val step2_outpatient =visits_step2.except(
      visits_step2.as("df1").join(step2_exclude.as("df2"), ( $"df1.${KpiConstants.memberidColName}"===$"df2.${KpiConstants.memberidColName}"
        && $"df1.${KpiConstants.serviceDateColName}"===$"df2.${KpiConstants.serviceDateColName}"),KpiConstants.innerJoinType)
        .select($"df1.*")).filter(!array_contains($"${KpiConstants.valuesetColName}",  KpiConstants.inPatientStayVal))

    val step2_final =step2_outpatient.select(KpiConstants.memberidColName,KpiConstants.serviceDateColName).union(actuedf_2)
    println("step2_final")
    step2_final.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    step2_final.filter($"${KpiConstants.memberidColName}" === ("95033")).show()



    val iesd730days  = step1_final.as("df1").join(step2_final.as("df2"), (
      $"df1.type"===lit("OUT") &&
      $"df1.${KpiConstants.memberidColName}"===$"df2.${KpiConstants.memberidColName}"
        && ($"df2.${KpiConstants.serviceDateColName}" between (date_add($"df1.${KpiConstants.iesdDateColName}",-730),
        (date_add($"df1.${KpiConstants.iesdDateColName}",-1)) )) )
      ,KpiConstants.innerJoinType).select($"df1.*")

    println("iesd730days")
    iesd730days.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    iesd730days.filter($"${KpiConstants.memberidColName}" === ("95033")).show()

    val iesd730_days_inpatient = step1_final.as("df1").join(step2_final.as("df2"), (
      $"df1.type"===lit("IN") &&
        $"df1.${KpiConstants.memberidColName}"===$"df2.${KpiConstants.memberidColName}"
        && ($"df2.${KpiConstants.serviceDateColName}" between (date_add($"df1.${KpiConstants.admitDateColName}",-730),
        (date_add($"df1.${KpiConstants.admitDateColName}",-1)) )) )
      ,KpiConstants.innerJoinType).select($"df1.*")



    println("iesd730_days_inpatient")
    iesd730_days_inpatient.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    iesd730_days_inpatient.filter($"${KpiConstants.memberidColName}" === ("95033")).show()

    val iesd730df = iesd730days.union(iesd730_days_inpatient)


    iesd730df.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .parquet("/home/hbase/ncqa/SPR/730days/")

    val iesd730 = spark.read.parquet("/home/hbase/ncqa/SPR/730days/").cache()

    //    val step2_temp = step1_final.as("df1").join(iesd730.as("df2"),
//      ( $"df1.${KpiConstants.memberidColName}"===$"df2.${KpiConstants.memberidColName}"
//        ),KpiConstants.innerJoinType)
//      .select($"df1.${KpiConstants.memberidColName}",$"df1.${KpiConstants.iesdDateColName}")
//
//    val step_1_2_final =step1_final.except(step1_final.filter($"${KpiConstants.memberidColName}".
//      isin(step2_temp.rdd.map(r => r.getString(0)).collect():_*)))


   val  step_1_2_final= step1_final.except(
     step1_final.as("df1").join(iesd730.as("df2"),
       ( $"df1.${KpiConstants.memberidColName}"===$"df2.${KpiConstants.memberidColName}"
        ),KpiConstants.innerJoinType).
       select($"df1.${KpiConstants.memberidColName}",$"df1.${KpiConstants.iesdDateColName}",
         $"df1.${KpiConstants.admitDateColName}",$"df1.type"))


    println("step_1_2_final")
      step_1_2_final.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    step_1_2_final.filter($"${KpiConstants.memberidColName}" === ("95033")).show()


    val ageFilterDf = membershipDf.filter((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",KpiConstants.months504).<=(ageEndDate)))
    //   ageFilterDf.filter($"${KpiConstants.memberidColName}" === ("95273")).show()

    val vistitsandmemberdf=step_1_2_final.as("claimsVisitis").join(ageFilterDf.as("membershipDf"),
      $"claimsVisitis.${KpiConstants.memberidColName}" === $"membershipDf.${KpiConstants.memberidColName}"
      , KpiConstants.innerJoinType).select($"membershipDf.*",$"claimsVisitis.iesd_date".as("service_date"))
    //</editor-fold>

    println("vistitsandmemberdf")
    vistitsandmemberdf.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    vistitsandmemberdf.filter($"${KpiConstants.memberidColName}" === ("95033")).show()
    //<editor-fold desc="Continuous Enrollment, Allowable Gap Calculation">

    val inputForContEnrolldf = vistitsandmemberdf.select(KpiConstants.memberidColName, KpiConstants.benefitMedicalColname,
      KpiConstants.memStartDateColName,KpiConstants.memEndDateColName,
      KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName,
      KpiConstants.dateofbirthColName,KpiConstants.primaryPlanFlagColName,KpiConstants.serviceDateColName)


    val mapForContEnroll1 = mutable.Map("gapcount" -> "1", "checkval" -> "false","reqCovDays" -> "0","start_date" -> "730","end_date" -> "365")


    val mapForContEnroll2 = mutable.Map("gapcount" -> "1", "checkval" -> "false","reqCovDays" -> "0","start_date" -> "365","end_date" -> "1")


    val mapForContEnroll3 = mutable.Map("gapcount" -> "1", "checkval" -> "true","reqCovDays" -> "0","start_date" -> "0","end_date" -> "-180")

    val ContEnrollOutDf1 = UtilFunctions.contEnrollAndAllowableGapFilterFunction(spark,inputForContEnrolldf,mapForContEnroll1)
      .select(KpiConstants.memberidColName, KpiConstants.memStartDateColName, KpiConstants.memEndDateColName,
        KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.primaryPlanFlagColName,
        KpiConstants.payerColName,KpiConstants.serviceDateColName,KpiConstants.gapflag).distinct()
    val ContEnrollOutDf2 = UtilFunctions.contEnrollAndAllowableGapFilterFunction(spark,inputForContEnrolldf,mapForContEnroll2)
      .select(KpiConstants.memberidColName, KpiConstants.memStartDateColName, KpiConstants.memEndDateColName,
        KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.primaryPlanFlagColName,
        KpiConstants.payerColName,KpiConstants.serviceDateColName,KpiConstants.gapflag).distinct()
    val ContEnrollOutDf_tmp = UtilFunctions.contEnrollAndAllowableGapFilterFunction(spark,inputForContEnrolldf,mapForContEnroll3)
      .select(KpiConstants.memberidColName, KpiConstants.memStartDateColName, KpiConstants.memEndDateColName,
        KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.primaryPlanFlagColName,
        KpiConstants.payerColName,KpiConstants.serviceDateColName,KpiConstants.gapflag).distinct()

    val ContEnrollOutDf_3_max = ContEnrollOutDf_tmp.groupBy(KpiConstants.memberidColName).agg(max(KpiConstants.memEndDateColName).as("max_memenddate"))
    val ContEnrollOutDf3  = ContEnrollOutDf_tmp.as("df1").join(ContEnrollOutDf_3_max.as("df2"),($"df1.${KpiConstants.memberidColName}" ===
      $"df2.${KpiConstants.memberidColName}" and $"df1.${KpiConstants.memEndDateColName}" === $"df2.max_memenddate")
      , KpiConstants.innerJoinType).select("df1.*").distinct()

    println("ContEnrollOutDf1")
    ContEnrollOutDf1.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    ContEnrollOutDf1.filter($"${KpiConstants.memberidColName}" === ("95033")).show()


    println("ContEnrollOutDf2")
    ContEnrollOutDf2.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    ContEnrollOutDf2.filter($"${KpiConstants.memberidColName}" === ("95033")).show()


    println("ContEnrollOutDf3")
    ContEnrollOutDf3.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    ContEnrollOutDf3.filter($"${KpiConstants.memberidColName}" === ("95033")).show()

    val  ContEnrollOutDf= ContEnrollOutDf1.union(ContEnrollOutDf2).union(ContEnrollOutDf3)
    val ContEnrollgapcount =ContEnrollOutDf1.select(KpiConstants.memberidColName,KpiConstants.gapflag).distinct().union(
      ContEnrollOutDf2.select(KpiConstants.memberidColName,KpiConstants.gapflag).distinct()).union(
      ContEnrollOutDf3.select(KpiConstants.memberidColName,KpiConstants.gapflag).distinct())

    println("ContEnrollgapcount")
    ContEnrollgapcount.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    ContEnrollgapcount.filter($"${KpiConstants.memberidColName}" === ("95033")).show()

    val  ContEnroll_2gaps=ContEnrollgapcount.groupBy($"${KpiConstants.memberidColName}")
      .agg(sum($"${KpiConstants.gapflag}").alias(KpiConstants.gapflag))
      .select($"${KpiConstants.memberidColName}",$"${KpiConstants.gapflag}").filter($"${KpiConstants.gapflag}".<=(lit(2)))

    println("ContEnroll_2gaps")
    ContEnroll_2gaps.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    ContEnroll_2gaps.filter($"${KpiConstants.memberidColName}" === ("95033")).show()


    val  ContEnrollOutDfmembers= ContEnrollOutDf1.select(KpiConstants.memberidColName)
      .intersect(ContEnrollOutDf2.select(KpiConstants.memberidColName))
      .intersect(ContEnrollOutDf3.select(KpiConstants.memberidColName))


    println("ContEnrollOutDfmembers")
    ContEnrollOutDfmembers.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    ContEnrollOutDfmembers.filter($"${KpiConstants.memberidColName}" === ("95033")).show()


    val ContEnrollOutFinal=ContEnrollOutDf3.as("df1").join(ContEnrollOutDfmembers.as("members"),
      $"df1.${KpiConstants.memberidColName}" === $"members.${KpiConstants.memberidColName}"
      , KpiConstants.innerJoinType).
      join(ContEnroll_2gaps.as("gaps"),$"df1.${KpiConstants.memberidColName}" === $"gaps.${KpiConstants.memberidColName}",KpiConstants.innerJoinType).
      select(s"df1.${KpiConstants.memberidColName}", s"df1.${KpiConstants.lobColName}", s"df1.${KpiConstants.lobProductColName}",s"df1.${KpiConstants.payerColName}",s"df1.${KpiConstants.primaryPlanFlagColName}").dropDuplicates()



    ContEnrollOutFinal.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .parquet("/home/hbase/ncqa/SPR/ContEnrollOutFinal/")


    val ContEnrollOutFinalDf = spark.read.parquet("/home/hbase/ncqa/SPR/ContEnrollOutFinal/").cache()


    /* printf("contEnrollmemDf")
     contEnrollmemDf.show()*/

    println("ContEnrollOutFinalDf")
    ContEnrollOutFinalDf.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    ContEnrollOutFinalDf.filter($"${KpiConstants.memberidColName}" === ("95033")).show()





    val baseOutDf = UtilFunctions.baseOutDataframeCreation(spark, ContEnrollOutFinalDf, lobList)

    println("baseOutDf")
    baseOutDf.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
    baseOutDf.filter($"${KpiConstants.memberidColName}" === ("95033")).show()



    val SPRContEnrollDf = baseOutDf.filter($"${KpiConstants.lobColName}".isin(lobList:_*)).dropDuplicates().cache()
    SPRContEnrollDf.count()

    SPRContEnrollDf.select(KpiConstants.memberidColName,KpiConstants.payerColName).distinct().coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("/home/hbase/ncqa/SPR/EPOP/")
    val eligiblePopDf=SPRContEnrollDf.select(KpiConstants.memberidColName)

        println("SPRContEnrollDf")
            SPRContEnrollDf.show()
            val toutStrDf =SPRContEnrollDf.select($"${KpiConstants.memberidColName}",
            $"${KpiConstants.memberidColName}".as(KpiConstants.ncqaOutmemberIdCol),
            $"${KpiConstants.payerColName}".as(KpiConstants.ncqaOutPayerCol))
              .withColumn(KpiConstants.ncqaOutMeasureCol,lit(measureId))



//            val  eligiblePop =spark.read.option("header", "true").csv("/home/hbase/ncqa/SPR/EPOP/")
//            // val SPRVistitsInputDf = spark.read.parquet("/home/hbase/ncqa/SPR/SPRVistitsInput/").cache()

            val SPRNumerator = indLabVisRemDfSF.as("df1")
              .join(eligiblePopDf.as("df2"),
              ( ($"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}")
                &&
                (array_contains($"df1.${KpiConstants.valuesetColName}",KpiConstants.spirometryVal) )
                 ), KpiConstants.innerJoinType )
              .join(step_1_2_final.as("df3"),(
                ($"df1.${KpiConstants.memberidColName}" === $"df3.${KpiConstants.memberidColName}" ) &&
                  ($"df2.${KpiConstants.memberidColName}" === $"df3.${KpiConstants.memberidColName}") &&
                ( $"df1.${KpiConstants.serviceDateColName}"  between ( date_add($"df3.${KpiConstants.iesdDateColName}",-730),date_add($"df3.${KpiConstants.iesdDateColName}",180))
                )) ,KpiConstants.innerJoinType )
              .select($"df1.${KpiConstants.memberidColName}").distinct()
    SPRNumerator.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("/home/hbase/ncqa/SPR/Numerator/")

            println("SPRNumerator")
            SPRNumerator.filter($"${KpiConstants.memberidColName}" === ("95107")).show()
            SPRNumerator.filter($"${KpiConstants.memberidColName}" === ("95033")).show()


            val outMap = mutable.Map(KpiConstants.totalPopDfName -> toutStrDf, KpiConstants.eligibleDfName -> eligiblePopDf,
              KpiConstants.mandatoryExclDfname -> spark.emptyDataFrame, KpiConstants.optionalExclDfName -> spark.emptyDataFrame,
              KpiConstants.numeratorDfName -> SPRNumerator )

            val outDf = UtilFunctions.ncqaOutputDfCreation(spark,outMap,measureId)
            outDf.coalesce(1)
              .write
              .mode(SaveMode.Append)
              .option("header", "true")
              .csv("/home/hbase/ncqa/SPR/outDf/")

  }


}

