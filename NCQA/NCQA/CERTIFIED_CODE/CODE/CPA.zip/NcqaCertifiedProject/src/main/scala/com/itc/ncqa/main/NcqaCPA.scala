package com.itc.ncqa.main

import org.apache.hadoop.fs.{FileSystem, Path}
import com.itc.ncqa.Constants.KpiConstants
import com.itc.ncqa.Functions.{DataLoadFunctions, UtilFunctions}
import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkConf
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

import scala.collection.mutable

object NcqaCPA extends Serializable {


  def main(args: Array[String]): Unit = {

    val StringtoIntger = udf((value: String) => value.toInt)

    //<editor-fold desc="Reading program arguments and SaprkSession oBject creation">

    val year = args(0)
    val measureId = args(1)
    val dbName = args(2)
    val baseMsrPath = args(3)
    KpiConstants.setDbName(dbName)
    /*calling function for setting the dbname for dbName variable*/
    // KpiConstants.setDbName(dbName)
    //    val conf = new SparkConf().setAppName("NcqaProgram")
    //    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    //      .set("hive.exec.dynamic.partition.mode", "nonstrict")
    //    .set("spark.sql.shuffle.partitions","5")

    val conf = new SparkConf().setAppName("NcqaProgram").setMaster("local[*]")
    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      .set("hive.exec.dynamic.partition.mode", "nonstrict")
      .set("spark.sql.shuffle.partitions", "5")
    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()

    // val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    import spark.implicits._
    val rootLogger = Logger.getRootLogger()
    rootLogger.setLevel(Level.ERROR)

    //</editor-fold>

    //<editor-fold desc="Loading Required Tables to memory">

    val yearStartDate = year+"-01-01"
    val yearEndDate = year+"-12-31"
    val prevYearStDate = year.toInt-1 +"-01-01"
    val prevYearEndDate = year.toInt-1 +"-12-31"
    val nextYDate = year.toInt + 1 + "-01-15"
    val yearNovDate = year+"-11-01"
    val oct1Date = year.toInt-2 +"-10-01"
    val outInflDate1 = "1953-07-02"
    val outInflDate2 = "2000-07-01"
    val jobId = spark.sparkContext.applicationId
    val baseDir = baseMsrPath + "/" + jobId
    val outDir = baseDir + "/Out"
    val intermediateDir = baseDir + "/Intermediate"
    val aLiat = List("col1")
    val msrVal = s"'$measureId'"
    val ggMsrId = s"'${KpiConstants.ggMeasureId}'"

    val lobList = List(KpiConstants.commercialLobName, KpiConstants.medicaidLobName, KpiConstants.mmpLobName)
    val MCDList = List("MDE","MMP")

    val memqueryString = s"""SELECT * FROM ${KpiConstants.dbName}.${KpiConstants.membershipTblName} WHERE measure = $msrVal AND (member_plan_start_date IS  NOT NULL) AND(member_plan_end_date IS NOT NULL)"""
    val membershipDf = DataLoadFunctions.dataLoadFromHiveStageTable(spark,KpiConstants.dbName,KpiConstants.membershipTblName,memqueryString,aLiat)
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .repartition(1)

    val genMemqueryString = s"""SELECT * FROM ${KpiConstants.dbName}.${KpiConstants.generalmembershipTblName} WHERE measure = $msrVal"""
    val genMembershipDf = DataLoadFunctions.dataLoadFromHiveStageTable(spark,KpiConstants.dbName,KpiConstants.generalmembershipTblName,genMemqueryString,aLiat)
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .repartition(1)

    //</editor-fold>



    val membershipDfAgeFilter = membershipDf.filter(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",KpiConstants.months216).<=(yearEndDate))


    val CEMedDf = membershipDfAgeFilter.filter(((($"${KpiConstants.lobColName}").===(KpiConstants.medicaidLobName))
      ||(($"${KpiConstants.lobColName}").===(KpiConstants.mmpLobName)))
      &&(($"${KpiConstants.memStartDateColName}".<=(yearEndDate))
      &&($"${KpiConstants.memEndDateColName}".>=(yearEndDate))))
      .select($"${KpiConstants.memberidColName}").distinct()



    val CEMedInputDf = membershipDfAgeFilter.as("df1").join(CEMedDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select("df1.*")

    val mapForCeMed = mutable.Map("start_date" -> (year+"-07-01"), "end_date" -> (year+"-12-31"),"gapcount" -> "1", "checkval" -> "true","reqCovDays"-> "0","anchor_date" -> (year+"-12-31"))

    val contEnrollMed = UtilFunctions.contEnrollAndAllowableGapFilterFunction(spark,CEMedInputDf,mapForCeMed)
      .select(KpiConstants.memberidColName, KpiConstants.lobColName, KpiConstants.lobProductColName,
        KpiConstants.payerColName, KpiConstants.primaryPlanFlagColName)

   /* println("--------------contEnrollMed------------------")
    contEnrollMed.show()*/

    contEnrollMed.select(KpiConstants.memberidColName).coalesce(1)
      .write
      .mode(SaveMode.Append)
      .parquet(intermediateDir +"/contEnrollMedMem/")

    /*contEnrollMed.select(KpiConstants.memberidColName).coalesce(1)
      .write
      .mode(SaveMode.Append)
      .json(intermediateDir +"/contEnrollMedMem_json/")*/




    val CECommericalDf = membershipDfAgeFilter.filter((($"${KpiConstants.lobColName}").===(KpiConstants.commercialLobName))
      &&(($"${KpiConstants.memStartDateColName}".<=(yearEndDate))
      &&($"${KpiConstants.memEndDateColName}".>=(yearEndDate))))
      .select($"${KpiConstants.memberidColName}").distinct()



    val CECommericalInputDf = membershipDfAgeFilter.as("df1").join(CECommericalDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select("df1.*")

    val mapForCeCommerical = mutable.Map("start_date" -> (year +"-01-01"), "end_date" -> (year+"-12-31"),"gapcount" -> "1", "checkval" -> "true","reqCovDays"-> "0","anchor_date" -> (year+"-12-31"))

    val contEnrollCommerical = UtilFunctions.contEnrollAndAllowableGapFilterFunction(spark,CECommericalInputDf,mapForCeCommerical)
      .select(KpiConstants.memberidColName, KpiConstants.lobColName, KpiConstants.lobProductColName,
        KpiConstants.payerColName, KpiConstants.primaryPlanFlagColName)

   /* println("--------------contEnrollCommerical------------------")
    contEnrollCommerical.show()*/


    contEnrollCommerical.select(KpiConstants.memberidColName).coalesce(1)
      .write
      .mode(SaveMode.Append)
      .parquet(intermediateDir +"/contEnrollCommericalMem/")

    contEnrollCommerical.select(KpiConstants.memberidColName).coalesce(1)
      .write
      .mode(SaveMode.Append)
      .json(intermediateDir +"/contEnrollCommericalMem_json/")


    /* contEnrollMed.coalesce(1)
        .write
        .mode(SaveMode.Append)
        .json("D:\\Sangeeth\\NCQA\\data_file\\test_data\\cpa\\Out\\contEnrollMedDf\\")
      val contEnrollMedDf = spark.read.json("D:\\Sangeeth\\NCQA\\data_file\\test_data\\cpa\\Out\\contEnrollMedDf\\")

      contEnrollCommerical.coalesce(1)
        .write
        .mode(SaveMode.Append)
        .json("D:\\Sangeeth\\NCQA\\data_file\\test_data\\cpa\\Out\\contEnrollCommericalDf\\")*/

    // val contEnrollCommericalDf = spark.read.json("D:\\Sangeeth\\NCQA\\data_file\\test_data\\cpa\\Out\\contEnrollCommericalDf\\")


    val unionDf = contEnrollMed.union(contEnrollCommerical).dropDuplicates()

   /* println("--------------unionDf------------------")
    unionDf.show()*/

    unionDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .parquet(intermediateDir +"/unionDf/")

    unionDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .json(intermediateDir +"/unionDf_json/")



    val baseInDf = spark.read.parquet(intermediateDir +"/unionDf/")
    val commMemDf = spark.read.parquet(intermediateDir +"/contEnrollCommericalMem/").rdd.map(r=> r.getString(0)).collect()
    val medMemDf = spark.read.parquet(intermediateDir +"/contEnrollMedMem/").rdd.map(r=> r.getString(0)).collect()
    val baseOutDf= UtilFunctions.baseOutDataframeCreation_CPA(spark, baseInDf, lobList)

    val comercialDualDf = baseOutDf.filter(($"${KpiConstants.memberidColName}".isin(commMemDf:_*))
      &&($"${KpiConstants.lobColName}".===(KpiConstants.commercialLobName)))

    val medicaidDualDf = baseOutDf.filter(($"${KpiConstants.memberidColName}".isin(medMemDf:_*))
      &&($"${KpiConstants.lobColName}".===(KpiConstants.medicaidLobName)))

  /*  val memList = List("95170", "95347","95019", "95284" )
    println("--------------baseOutDf------------------")
    baseOutDf.filter($"${KpiConstants.memberidColName}".isin(memList:_*)).show()*/

    val finalDualDf = comercialDualDf.union(medicaidDualDf).dropDuplicates()
   /* val memList = List("95170", "95347","95019", "95284" )
    println("--------------finalDualDf------------------")
    finalDualDf.filter($"${KpiConstants.memberidColName}".isin(memList:_*)).show()*/

    val mcdList = List(KpiConstants.mdPayerVal, KpiConstants.mliPayerVal, KpiConstants.mrbPayerVal,KpiConstants.mdePayerVal, KpiConstants.mmpPayerVal)
    //val memInDf = membershipDfAgeFilter.withColumn(KpiConstants.payerColName, when($"${KpiConstants.payerColName}".isin(mcdList:_*), KpiConstants.mcdPayerVal).otherwise($"${KpiConstants.payerColName}"))

  /*  println("--------------finalDualDf------------------")
    finalDualDf.filter($"${KpiConstants.memberidColName}".isin(memList:_*)).show()


    println("--------------memInDf------------------")
    memInDf.filter($"${KpiConstants.memberidColName}".isin(memList:_*)).show()*/


    val joinedResultDf = finalDualDf.as("df1").join(membershipDfAgeFilter.as("df2"),
      ( ($"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}")
        && ($"df1.${KpiConstants.payerColName}").===($"df2.${KpiConstants.payerColName}")
        && ($"df2.${KpiConstants.memStartDateColName}".<=(nextYDate) && ($"df2.${KpiConstants.memEndDateColName}".>=(nextYDate)))
        )
      , KpiConstants.innerJoinType)
      .select("df1.*")

    /*println("-----------------joinedResultDf-------------------")
    joinedResultDf.filter($"${KpiConstants.memberidColName}".isin(memList:_*)).show()*/

    val epopDf = joinedResultDf.withColumn(KpiConstants.payerColName, when($"${KpiConstants.payerColName}".isin(mcdList:_*), lit(KpiConstants.mcdPayerVal)).otherwise($"${KpiConstants.payerColName}"))
                               .select(KpiConstants.memberidColName,KpiConstants.payerColName,KpiConstants.lobColName).distinct()
    epopDf.coalesce(2)
      .write
      .mode(SaveMode.Append)
      .parquet(intermediateDir+ "/EPOP/")

  /*  epopDf.select(KpiConstants.memberidColName,KpiConstants.payerColName).distinct().coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header","true").partitionBy(KpiConstants.payerColName)
      .csv(outDir  + "/EPOP/")*/


    val CEDf=spark.read.parquet(intermediateDir+ "/EPOP/")
    //  val CESommerical


    val outDf = genMembershipDf.as("df1").join(CEDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}" ,KpiConstants.innerJoinType)
                               .select("df1.*",s"df2.${KpiConstants.lobColName}", s"df2.${KpiConstants.payerColName}")


    val outHmoDf = outDf.filter($"${KpiConstants.payerColName}".===("HMO"))
    val outMcdDf = outDf.filter($"${KpiConstants.payerColName}".===("MCD"))
    val outPosDf = outDf.filter($"${KpiConstants.payerColName}".===("POS"))
    val outPpoDf = outDf.filter($"${KpiConstants.payerColName}".===("PPO"))
    val outEpoDf = outDf.filter($"${KpiConstants.payerColName}".===("CEP"))


    outHmoDf.select( concat(rpad(lit("NCQA"),60, " ") ,
        lit(1), lit(1), rpad($"SUB_FAM_ID_NUM",25, " "),rpad($"${KpiConstants.memberidColName}",25, " "),rpad($"FIRST_NAME",25, " "),$"MIDDLE_NAME",rpad($"LAST_NAME",25, " "),
        when($"${KpiConstants.genderColName}".===(KpiConstants.maleVal),1).when($"${KpiConstants.genderColName}".===(KpiConstants.femaleVal),2).otherwise(lit(9)),
        UtilFunctions.dateConvert(spark,$"${KpiConstants.dateofbirthColName}"), rpad($"ADDRESS1",50, " "),rpad($"ADDRESS2",50, " "),
        rpad($"CITY",30, " "),$"STATE",$"ZIP",$"PHONE",
      when(($"${KpiConstants.dateofbirthColName}".>=(outInflDate1))&& ($"df1.${KpiConstants.dateofbirthColName}".<=(outInflDate2)), lit(1)).otherwise(lit(2))
      )
    ).write.text(outDir+ "/Output/HMO/")


    outMcdDf.select( concat(rpad(lit("NCQA"),60, " ") ,
      lit(2), lit(1), rpad($"SUB_FAM_ID_NUM",25, " "),rpad($"${KpiConstants.memberidColName}",25, " "),rpad($"FIRST_NAME",25, " "),$"MIDDLE_NAME",rpad($"LAST_NAME",25, " "),
      when($"${KpiConstants.genderColName}".===(KpiConstants.maleVal),1).when($"${KpiConstants.genderColName}".===(KpiConstants.femaleVal),2).otherwise(lit(9)),
      UtilFunctions.dateConvert(spark,$"${KpiConstants.dateofbirthColName}"), rpad($"ADDRESS1",50, " "),rpad($"ADDRESS2",50, " "),
      rpad($"CITY",30, " "),$"STATE",$"ZIP",$"PHONE",
      when(($"${KpiConstants.dateofbirthColName}".>=(outInflDate1))&& ($"df1.${KpiConstants.dateofbirthColName}".<=(outInflDate2)), lit(1)).otherwise(lit(2))
    )
    ).write.text(outDir+ "/Output/MCD/")


    outPosDf.select( concat(rpad(lit("NCQA"),60, " ") ,
      lit(1), lit(2), rpad($"SUB_FAM_ID_NUM",25, " "),rpad($"${KpiConstants.memberidColName}",25, " "),rpad($"FIRST_NAME",25, " "),$"MIDDLE_NAME",rpad($"LAST_NAME",25, " "),
      when($"${KpiConstants.genderColName}".===(KpiConstants.maleVal),1).when($"${KpiConstants.genderColName}".===(KpiConstants.femaleVal),2).otherwise(lit(9)),
      UtilFunctions.dateConvert(spark,$"${KpiConstants.dateofbirthColName}"), rpad($"ADDRESS1",50, " "),rpad($"ADDRESS2",50, " "),
      rpad($"CITY",30, " "),$"STATE",$"ZIP",$"PHONE",
      when(($"${KpiConstants.dateofbirthColName}".>=(outInflDate1))&& ($"df1.${KpiConstants.dateofbirthColName}".<=(outInflDate2)), lit(1)).otherwise(lit(2))
    )
    ).write.text(outDir+ "/Output/POS/")


    outPpoDf.select( concat(rpad(lit("NCQA"),60, " ") ,
      lit(1), lit(3), rpad($"SUB_FAM_ID_NUM",25, " "),rpad($"${KpiConstants.memberidColName}",25, " "),rpad($"FIRST_NAME",25, " "),$"MIDDLE_NAME",rpad($"LAST_NAME",25, " "),
      when($"${KpiConstants.genderColName}".===(KpiConstants.maleVal),1).when($"${KpiConstants.genderColName}".===(KpiConstants.femaleVal),2).otherwise(lit(9)),
      UtilFunctions.dateConvert(spark,$"${KpiConstants.dateofbirthColName}"), rpad($"ADDRESS1",50, " "),rpad($"ADDRESS2",50, " "),
      rpad($"CITY",30, " "),$"STATE",$"ZIP",$"PHONE",
      when(($"${KpiConstants.dateofbirthColName}".>=(outInflDate1))&& ($"df1.${KpiConstants.dateofbirthColName}".<=(outInflDate2)), lit(1)).otherwise(lit(2))
    )
    ).write.text(outDir+ "/Output/PPO/")


    outEpoDf.select( concat(rpad(lit("NCQA"),60, " ") ,
      lit(1), lit(4), rpad($"SUB_FAM_ID_NUM",25, " "),rpad($"${KpiConstants.memberidColName}",25, " "),rpad($"FIRST_NAME",25, " "),$"MIDDLE_NAME",rpad($"LAST_NAME",25, " "),
      when($"${KpiConstants.genderColName}".===(KpiConstants.maleVal),1).when($"${KpiConstants.genderColName}".===(KpiConstants.femaleVal),2).otherwise(lit(9)),
      UtilFunctions.dateConvert(spark,$"${KpiConstants.dateofbirthColName}"), rpad($"ADDRESS1",50, " "),rpad($"ADDRESS2",50, " "),
      rpad($"CITY",30, " "),$"STATE",$"ZIP",$"PHONE",
      when(($"${KpiConstants.dateofbirthColName}".>=(outInflDate1))&& ($"df1.${KpiConstants.dateofbirthColName}".<=(outInflDate2)), lit(1)).otherwise(lit(2))
    )
    ).write.text(outDir+ "/Output/EPO/")


    //<editor-fold desc="Deleting the intermediate Files">

    val fileSystem = FileSystem.get(spark.sparkContext.hadoopConfiguration)
    fileSystem.delete(new Path(intermediateDir), true)
    //</editor-fold>

    spark.sparkContext.stop()
  }

}
