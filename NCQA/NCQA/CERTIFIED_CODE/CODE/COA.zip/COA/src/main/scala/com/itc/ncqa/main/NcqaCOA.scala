package main.scala.com.itc.ncqa.main

import main.scala.com.itc.ncqa.Constants.KpiConstants
import main.scala.com.itc.ncqa.Functions.UtilFunctions
import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkConf
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.sql.functions._

import scala.collection.mutable

object NcqaCOA {

  def main(args: Array[String]): Unit =
  {

    //<editor-fold desc="Reading program arguments and Spark Session object creation">

    val year = "2018"
    val measureId = "COA"
    val baseMsrPath = "/home/hbase/ncqa/coa"

    System.setProperty("hadoop.home.dir", "D:\\WinUtil")

    val conf = new SparkConf().setAppName("NcqaProgram")
    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    conf.set("spark.sql.shuffle.partitions", "5")
    //.set("hive.exec.dynamic.partition.mode", "nonstrict")

    val spark = SparkSession.builder().config(conf).master("local").getOrCreate()

    val rootLogger = Logger.getRootLogger()
    rootLogger.setLevel(Level.ERROR)

    val yearStartDate = year+"-01-01"
    val yearStartDate1 = year.toInt -1 +"-01-01"
    val yearEndDate = year+"-12-31"

    val jobId = spark.sparkContext.applicationId
    val baseDir = baseMsrPath + "/" + jobId
    val outDir = baseDir + "/Out"
    val intermediateDir = baseDir + "/Intermediate"
    val stagingDir =  baseDir + "/Staging"

    //</editor-fold>

    //<editor-fold desc="Loading Required Tables to memory">

    import spark.implicits._

    val lobList = List(KpiConstants.medicareLobName,KpiConstants.mmdLobName)

    //val membershipDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\COA\\MEMBERSHIP_ENROLLMENT.csv")
    val membershipDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\COA\\Test\\MEMBERSHIP_ENROLLMENT.csv")
      .filter(($"${KpiConstants.considerationsColName}".===(KpiConstants.yesVal))
        && ($"${KpiConstants.memStartDateColName}".isNotNull)
        && ($"${KpiConstants.memEndDateColName}".isNotNull))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .withColumn(KpiConstants.memStartDateColName, to_date($"${KpiConstants.memStartDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.memEndDateColName, to_date($"${KpiConstants.memEndDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.dateofbirthColName, to_date($"${KpiConstants.dateofbirthColName}", KpiConstants.dateFormatString))
      .repartition(2).cache()

    println("-------------------membership----------------")
    membershipDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    membershipDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(stagingDir+ "/membershipDf/")

    val claimStatusList = List(KpiConstants.paidVal, KpiConstants.suspendedVal, KpiConstants.pendingVal, KpiConstants.deniedVal)

    // val visitsDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\COA\\VISITS.csv")
    val visitsDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\COA\\Test\\VISITS.csv")
      .filter(($"${KpiConstants.serviceDateColName}".isNotNull)
       /* && (($"${KpiConstants.admitDateColName}".isNotNull && $"${KpiConstants.dischargeDateColName}".isNotNull)
        || ($"${KpiConstants.admitDateColName}".isNull && $"${KpiConstants.dischargeDateColName}".isNull))*/
        &&((($"${KpiConstants.dataSourceColName}".===("Claim"))&&($"${KpiConstants.claimstatusColName}".isin(claimStatusList:_*)))
        || (($"${KpiConstants.dataSourceColName}".===("RxClaim"))&&($"${KpiConstants.claimstatusColName}".isin(claimStatusList:_*)))
        || ($"${KpiConstants.dataSourceColName}".===("Rx"))
        || ($"${KpiConstants.dataSourceColName}".===("Lab"))))
      .drop(KpiConstants.lobProductColName, "latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name","product")
      .withColumn(KpiConstants.dobColName, to_date($"${KpiConstants.dobColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.serviceDateColName, to_date($"${KpiConstants.serviceDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.admitDateColName, when($"${KpiConstants.admitDateColName}".isNotNull,to_date($"${KpiConstants.admitDateColName}",  KpiConstants.dateFormatString)))
      .withColumn(KpiConstants.dischargeDateColName, when($"${KpiConstants.dischargeDateColName}".isNotNull,to_date($"${KpiConstants.dischargeDateColName}",  KpiConstants.dateFormatString)))
      .withColumn(KpiConstants.medstartdateColName, when($"${KpiConstants.medstartdateColName}".isNotNull,to_date($"${KpiConstants.medstartdateColName}",  KpiConstants.dateFormatString)))
      .withColumn(KpiConstants.revenuecodeColName, when((length($"${KpiConstants.revenuecodeColName}").as[Int].===(3)),concat(lit("0" ),lit($"${KpiConstants.revenuecodeColName}"))).otherwise($"${KpiConstants.revenuecodeColName}"))
      .withColumn(KpiConstants.billtypecodeColName, when((length($"${KpiConstants.billtypecodeColName}").as[Int].===(3)),concat(lit("0" ),lit($"${KpiConstants.billtypecodeColName}"))).otherwise($"${KpiConstants.billtypecodeColName}"))
      .withColumn(KpiConstants.proccode2ColName, when(($"${KpiConstants.proccode2mod1ColName}".isin(KpiConstants.avoidCodeList:_*)) || ($"${KpiConstants.proccode2mod2ColName}".isin(KpiConstants.avoidCodeList:_*)),lit("NA")).otherwise($"${KpiConstants.proccode2ColName}"))
      .repartition(2).cache()

    visitsDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(stagingDir+ "/visitsDf/")

    println("-------------------visits----------------")
    visitsDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()


    val refHedisDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\COA\\Test\\REF_HEDIS2019.csv")
      .filter(($"${KpiConstants.measureIdColName}".===(KpiConstants.coaMeasureId)) || ($"${KpiConstants.measureIdColName}".===(KpiConstants.ggMeasureId)))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .repartition(2).cache()

    refHedisDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(stagingDir+ "/refHedisDf/")

    // val medmonmemDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\COA\\COA_MONTHLY_MEMBERSHIP.csv")
    val medmonmemDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\COA\\Test\\COA_MONTHLY_MEMBERSHIP.csv")
      .withColumn(KpiConstants.runDateColName,to_date($"${KpiConstants.runDateColName}", KpiConstants.dateFormatString))
      .filter(($"${KpiConstants.runDateColName}".>=(yearStartDate)) && ($"${KpiConstants.runDateColName}".<=(yearEndDate)))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .repartition(2).cache()

    medmonmemDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(stagingDir+ "/medmonmemDf/")

    //val ref_medvaluesetDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\COA\\REF_MED_VALUE_SET.csv")
    val ref_medvaluesetDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\COA\\Test\\REF_MED_VALUE_SET.csv")
      .filter(($"${KpiConstants.measure_idColName}".===(KpiConstants.coaMeasureId)) )
      .drop("latest_flag", "active_flag", "ingestion_date", "source_name" ,"user_name")
      .repartition(2).cache()

    ref_medvaluesetDf.coalesce(2)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(stagingDir+ "/ref_medvaluesetDf/")

    //</editor-fold>

    //<editor-fold desc="Eligible Population Calculation">

    //<editor-fold desc="Age Filter">

    val ageEndDate = year + "-12-31"
    val ageStartDate = year + "-01-01"

    val ageClDate = year + "-12-31"

    /* The Member should be older than or equal to 20 years on 31st December Measurement Year.*/
    val ageFilterDf = membershipDf.withColumn("age",datediff(lit(ageEndDate),$"${KpiConstants.dateofbirthColName}")/365.25)
      //.filter( $"age">=66)
      .filter((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",792).<=(ageClDate))).cache()

    println("-------------------After ageFilterDf-------------")
    ageFilterDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    //</editor-fold>

    //<editor-fold desc="Continuous Enrollment, Allowable Gap Calculation">

    val inputForContEnrolldf = ageFilterDf.select(KpiConstants.memberidColName, KpiConstants.benefitMedicalColname, KpiConstants.memStartDateColName,
      KpiConstants.memEndDateColName, KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName,
      KpiConstants.dateofbirthColName,KpiConstants.primaryPlanFlagColName,"age")

    val mapForCeCurrYear = mutable.Map("start_date" -> "2018-01-01", "end_date" -> "2018-12-31","gapcount" -> "1",
      "checkval" -> "true","reqCovDays" -> "0","anchor_date" -> "2018-12-31")

    val contEnrollDf = UtilFunctions.contEnrollAndAllowableGapFilterFunction(spark,inputForContEnrolldf,mapForCeCurrYear)
      .select(KpiConstants.memberidColName, KpiConstants.dateofbirthColName, KpiConstants.memStartDateColName, KpiConstants.memEndDateColName,
        KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.primaryPlanFlagColName, KpiConstants.payerColName)

    contEnrollDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/contEnrollDf/")

    println("----------------------After contEnrollDf-----------------------")
    contEnrollDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    //</editor-fold>

    //<editor-fold desc="Dual Enrollment and COA Lob filter">

    val ConEnrDf = spark.read.parquet(intermediateDir+ "/contEnrollDf/").cache()

    //val baseOutDf = UtilFunctions.baseOutDataframeCreation(spark, ConEnrDf, lobList , measureId)

    val baseOutMedHosRemDf = UtilFunctions.baseOutDataframeCreation(spark, ConEnrDf, lobList , measureId)

    println("-------------------After baseOutMedHosRemDf-------------")
    baseOutMedHosRemDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    /*Removing the MCR payer members from the EPOP*/

    val snPayerList = List(KpiConstants.sn1PayerVal,KpiConstants.sn2PayerVal,KpiConstants.sn3PayerVal,KpiConstants.mmpPayerVal)
    val baseOutDf =baseOutMedHosRemDf.filter($"${KpiConstants.payerColName}".isin(snPayerList:_*))

    //val baseOutDf =baseOutMedHosRemDf.filter($"${KpiConstants.payerColName}".isin(snPayerList:_*))

    println("-------------------After baseOutDf-------------")
    baseOutDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    val coaContEnrollDf = baseOutDf.filter($"${KpiConstants.lobColName}".isin(lobList:_*)).dropDuplicates().cache()
    coaContEnrollDf.count() //coaContEnrollDf.count()

    println("-------------------After coaContEnrollDf-------------")
    coaContEnrollDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    //Modified Code
    val medicareContEnrollDf = coaContEnrollDf.filter(($"${KpiConstants.lobColName}".===(KpiConstants.medicareLobName))
      || ($"${KpiConstants.lobColName}".===(KpiConstants.mmdLobName)))

    println("-------------------After medicareContEnrollDf-------------")
    medicareContEnrollDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    val MedMonDf = spark.read.parquet(stagingDir+ "/medmonmemDf/").cache()

    val medicareHospiceDf = medicareContEnrollDf.as("df1").join(MedMonDf.as("df2"), Seq(KpiConstants.memberidColName))
      .groupBy(KpiConstants.memberidColName).agg(countDistinct(when($"hospice".===("Y"),1)).alias("count"))
      .filter($"count".>(0))
      .select(KpiConstants.memberidColName).rdd.map(r=> r.getString(0)).collect()

    val coacontEnrollResDf = coaContEnrollDf.except(coaContEnrollDf.filter($"${KpiConstants.memberidColName}".isin(medicareHospiceDf:_*)))

    //Ends here

    coacontEnrollResDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/coacontEnrollResDf/")

    println("-------------------After Dual Enrollment-------------")
    coacontEnrollResDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    //</editor-fold>

    //<editor-fold desc="Initial Join with Ref_Hedis">

    val VisDf = spark.read.parquet(stagingDir+ "/visitsDf/").cache()

    val RefHedDf = spark.read.parquet(stagingDir+ "/refHedisDf/").cache()

    val argmapforRefHedis = mutable.Map(KpiConstants.eligibleDfName -> VisDf , KpiConstants.refHedisTblName -> RefHedDf)
    val allValueList = List(KpiConstants.independentLabVal, KpiConstants.hospiceVal,KpiConstants.advanceCarePlanning,KpiConstants.acuteInpatientPosVal,
      KpiConstants.acuteInpatientVal,KpiConstants.medicationReviewVal,KpiConstants.medicationListVal,KpiConstants.transitionalCareMgtSerVal,
      KpiConstants.functionalStatusVal,KpiConstants.painAssessmentVal)

    val medList = KpiConstants.emptyList
    val visitRefHedisDf = UtilFunctions.joinWithRefHedisFunction(spark,argmapforRefHedis,allValueList,medList)
      .withColumn("age",datediff(lit(ageEndDate),$"${KpiConstants.dobColName}")/365.25)

    println("-------------------After visitRefHedisDf-------------")
    visitRefHedisDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    visitRefHedisDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/visitRefHedisDf/")

    //</editor-fold>

    //<editor-fold desc="Removal of Independent Lab Visits">

    val VisRefHedDf = spark.read.parquet(intermediateDir+ "/visitRefHedisDf/").cache()

    val groupList = VisDf.schema.fieldNames.toList.dropWhile(p=> p.equalsIgnoreCase(KpiConstants.memberidColName))

    val visitgroupedDf = VisRefHedDf.groupBy(KpiConstants.memberidColName, groupList:_*).agg(collect_list(KpiConstants.valuesetColName).alias(KpiConstants.valuesetColName))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName, KpiConstants.admitDateColName, KpiConstants.dischargeDateColName,
        KpiConstants.dobColName,KpiConstants.supplflagColName, KpiConstants.provprespriColName,KpiConstants.clinicalpharmacistColName, KpiConstants.valuesetColName,KpiConstants.genderColName)


    val indLabVisRemDf = visitgroupedDf.filter(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)).repartition(2).cache()
    indLabVisRemDf.count()

    println("-------------------After indLabVisRemDf-------------")
    indLabVisRemDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    //</editor-fold>

    //<editor-fold desc="Hospice Removal">

    val ConEnrResDf = spark.read.parquet(intermediateDir+ "/coacontEnrollResDf/").cache()

    val hospiceInCurrYearMemDf = indLabVisRemDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hospiceVal))
      &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)
      .dropDuplicates()
      .rdd
      .map(r=> r.getString(0))
      .collect()

    val df =  indLabVisRemDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hospiceVal))
      &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
    //.select(KpiConstants.memberidColName)

    println("-------------------df-------------")
    df.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    val hospiceRemMemEnrollDf = ConEnrResDf.except(ConEnrResDf.filter($"${KpiConstants.memberidColName}".isin(hospiceInCurrYearMemDf:_*)))

    println("-------------------hospiceRemMemEnrollDf-------------")
    hospiceRemMemEnrollDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    val totalPopOutDf = hospiceRemMemEnrollDf.distinct()

    println("-------------------After totalPopOutDf-------------")
    totalPopOutDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    totalPopOutDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .csv(outDir+ "/totalPopOutDf/")

    //</editor-fold>

    //<editor-fold desc="COA Stratification">

    val inputtoutstrDf = hospiceRemMemEnrollDf.select(KpiConstants.memberidColName,KpiConstants.payerColName,KpiConstants.lobColName)
    val lobList1 = KpiConstants.emptyList
    val remMeas = KpiConstants.emptyList
    val measureIdList = List(KpiConstants.coa1MeasureId,KpiConstants.coa2MeasureId,KpiConstants.coa3MeasureId,KpiConstants.coa4MeasureId)

    val toutstrDf = UtilFunctions.toutOutputCreation(spark, inputtoutstrDf,measureIdList, lobList1 ,remMeas )
      .select($"${KpiConstants.memberidColName}".as(KpiConstants.ncqaOutmemberIdCol),
        $"${KpiConstants.ncqaOutPayerCol}", $"${KpiConstants.ncqaOutMeasureCol}").distinct()

    println("-----------------------After Stratification-------------------------------")
    toutstrDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    //</editor-fold>

    //<editor-fold desc="EPOP Generation">

    val eligiblePopDf = totalPopOutDf.select(KpiConstants.memberidColName).distinct().repartition(2).cache()
    eligiblePopDf.count()

    eligiblePopDf.coalesce(4)
      .write
      .mode(SaveMode.Append)
      .parquet(intermediateDir+ "/epop")

    println("-------------------Selective Epop-------------------")
    eligiblePopDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    eligiblePopDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir+ "/epop_csv")

    //</editor-fold>

    //</editor-fold>

    //<editor-fold desc=" Numerator Part">

    //<editor-fold desc="Initial join function">

    val argmapForVisittJoin = mutable.Map(KpiConstants.membershipTblName -> totalPopOutDf , KpiConstants.visitTblName -> indLabVisRemDf)

    val visitJoinedDf = UtilFunctions.initialJoinFunction(spark,argmapForVisittJoin)

    println("------------------------visitJoinedOutDf----------------------------")
    visitJoinedDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    coaContEnrollDf.unpersist()
    visitgroupedDf.unpersist()
    eligiblePopDf.unpersist()

    //</editor-fold>

    //<editor-fold desc="Numerator Calculation">

    //<editor-fold desc="Non Supplementry">

    val numNonSuppVisitsDf =  visitJoinedDf.filter($"${KpiConstants.supplflagColName}".===("N"))

    val numNonSuppMemDf = numNonSuppVisitsDf.select($"${KpiConstants.memberidColName}")

    println("----------------------After numNonSuppVisitsDf-----------------------")
    numNonSuppVisitsDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    //<editor-fold desc="Numerator 1">

    val acpnonSuppNumDf = numNonSuppVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.advanceCarePlanning))
      &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
      .select(KpiConstants.memberidColName)

    acpnonSuppNumDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/acpnonSuppNumDf/")

    println("----------------------After acpnonSuppNumDf-----------------------")
    acpnonSuppNumDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    //</editor-fold>

    //<editor-fold desc="Exclusion">

    val ExcNonSuppNumDf = numNonSuppVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.acuteInpatientVal))
      || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.acuteInpatientPosVal)))
      .select(KpiConstants.memberidColName,KpiConstants.serviceDateColName)

    //---------------------Trying a new logic-----------------------

    //Capturing the service date of exclusion valueset and removing all the other visits of the same service date irrespective of the valuesets.

    val numNonSuppDf = numNonSuppVisitsDf.as("df1").join(ExcNonSuppNumDf.as("df2"), (($"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}") &&
                                                                                                              ($"df1.${KpiConstants.serviceDateColName}" === $"df2.${KpiConstants.serviceDateColName}")), KpiConstants.leftOuterJoinType)
                                                  .filter($"df2.${KpiConstants.serviceDateColName}".isNull)
                                                  .select("df1.*")

    //--------------------------Ends here----------------------------


    numNonSuppDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/numNonSuppDf/")


    println("----------------------After numNonSuppDf-----------------------")
    numNonSuppDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    println("----------------------After ExcNonSuppNumDf-----------------------")
    ExcNonSuppNumDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    //</editor-fold>

    //<editor-fold desc="Numerator 2">

    val medListNonSuppNumDf = numNonSuppDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.medicationListVal))
      &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      &&(($"${KpiConstants.clinphaColName}").===(KpiConstants.yesVal)||($"${KpiConstants.provprespriColName}").===(KpiConstants.yesVal)))
      .select(KpiConstants.memberidColName,KpiConstants.serviceDateColName)

    println("----------------------After medListNonSuppNumDf-----------------------")
    medListNonSuppNumDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()


    val medRevNonSuppNumDf = numNonSuppDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.medicationReviewVal))
      &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      &&(($"${KpiConstants.clinphaColName}").===(KpiConstants.yesVal)||($"${KpiConstants.provprespriColName}").===(KpiConstants.yesVal)))
      .select(KpiConstants.memberidColName,KpiConstants.serviceDateColName)

    println("----------------------After medRevNonSuppNumDf-----------------------")
    medRevNonSuppNumDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    val medNonSuppNumDf = medListNonSuppNumDf.intersect(medRevNonSuppNumDf).select(KpiConstants.memberidColName)

    val transNonSuppNumDf = numNonSuppDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.transitionalCareMgtSerVal))
      &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
      .select(KpiConstants.memberidColName)

    val numeratorNonSuppDf = medNonSuppNumDf.union(transNonSuppNumDf)

    numeratorNonSuppDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/numeratorNonSuppDf/")

    println("----------------------After medNonSuppNumDf-----------------------")
    medNonSuppNumDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    println("----------------------After transNonSuppNumDf-----------------------")
    transNonSuppNumDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    println("----------------------After numeratorNonSuppDf-----------------------")
    numeratorNonSuppDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    //</editor-fold>

    //<editor-fold desc="Numerator 3">

    val funcnonSuppNumDf = numNonSuppDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.functionalStatusVal))
      &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
      .select(KpiConstants.memberidColName)

    println("----------------------After funcnonSuppNumDf-----------------------")
    funcnonSuppNumDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    funcnonSuppNumDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/funcnonSuppNumDf/")


    //</editor-fold>

    //<editor-fold desc="Numerator 4">

    val painnonSuppNumDf = numNonSuppDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.painAssessmentVal))
      &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
      .select(KpiConstants.memberidColName)

    println("----------------------After painnonSuppNumDf-----------------------")
    painnonSuppNumDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    painnonSuppNumDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/painnonSuppNumDf/")


    //</editor-fold>

    val acpNSNumDf = spark.read.parquet(intermediateDir+ "/acpnonSuppNumDf/").cache()

    val numeratorNSDf = spark.read.parquet(intermediateDir+ "/numeratorNonSuppDf/").cache()

    val funcNSNumDf = spark.read.parquet(intermediateDir+ "/funcnonSuppNumDf/").cache()

    val painNSNumDf = spark.read.parquet(intermediateDir+ "/painnonSuppNumDf/").cache()

    val nonSuppTmpnumDf = acpNSNumDf.union(numeratorNSDf).union(funcNSNumDf).union(painNSNumDf)

    nonSuppTmpnumDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite).parquet(intermediateDir+ "/nonSuppTmpnumDf/")

    println("----------------------After nonSuppTmpnumDf-----------------------")
    nonSuppTmpnumDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    //</editor-fold>

    //<editor-fold desc="Other Data">

    val nonSuppTmpNumDf = spark.read.parquet(intermediateDir+ "/nonSuppTmpnumDf/").cache()

    val otherNumVisitsDf = visitJoinedDf.except(visitJoinedDf.filter($"${KpiConstants.memberidColName}".isin(nonSuppTmpNumDf.rdd.map(f=> f.getString(0)).collect():_*)))

    val otherNumMemdf = otherNumVisitsDf.select($"${KpiConstants.memberidColName}")

    println("----------------------After otherNumVisitsDf-----------------------")
    otherNumVisitsDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    //<editor-fold desc="Numerator 1">

    val acpotherNumDf = otherNumVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.advanceCarePlanning))
      &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
      .select(KpiConstants.memberidColName)

    println("----------------------After acpotherNumDf-----------------------")
    acpotherNumDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    acpotherNumDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/acpotherNumDf/")


    //</editor-fold>

    //<editor-fold desc="Exclusion">

    val ExcotherNumDf = otherNumVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.acuteInpatientVal))
      || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.acuteInpatientPosVal)))

    //---------------------Trying a new logic-----------------------

    //Capturing the service date of exclusion valueset and removing all the other visits of the same service date irrespective of the valuesets.

    val numOtherDf = otherNumVisitsDf.as("df1").join(ExcotherNumDf.as("df2"), (($"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}") &&
      ($"df1.${KpiConstants.serviceDateColName}" === $"df2.${KpiConstants.serviceDateColName}")), KpiConstants.leftOuterJoinType)
      .filter($"df2.${KpiConstants.serviceDateColName}".isNull)
      .select("df1.*")

    //--------------------------Ends here---------------------------

    println("----------------------After numOtherDf-----------------------")
    numOtherDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    //</editor-fold>

    //<editor-fold desc="Numerator 2">

    val medListOtherNumDf = numOtherDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.medicationListVal))
      &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      &&(($"${KpiConstants.clinphaColName}").===(KpiConstants.yesVal)||($"${KpiConstants.provprespriColName}").===(KpiConstants.yesVal)))
      .select(KpiConstants.memberidColName,KpiConstants.serviceDateColName)

    println("----------------------After medListOtherNumDf-----------------------")
    medListOtherNumDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()


    val medRevOtherNumDf = numOtherDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.medicationReviewVal))
      &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      &&(($"${KpiConstants.clinphaColName}").===(KpiConstants.yesVal)||($"${KpiConstants.provprespriColName}").===(KpiConstants.yesVal)))
      .select(KpiConstants.memberidColName,KpiConstants.serviceDateColName)

    println("----------------------After medRevOtherNumDf-----------------------")
    medRevOtherNumDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()


    val medOtherNumDf = medListOtherNumDf.intersect(medRevOtherNumDf).select(KpiConstants.memberidColName)

    val transOtherNumDf = numOtherDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.transitionalCareMgtSerVal))
      &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
      .select(KpiConstants.memberidColName)

    val numeratorOtherDf = medOtherNumDf.union(transOtherNumDf)

    println("----------------------After medOtherNumDf-----------------------")
    medOtherNumDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    println("----------------------After transOtherNumDf-----------------------")
    transOtherNumDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    println("----------------------After numeratorOtherDf-----------------------")
    numeratorOtherDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    numeratorOtherDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/numeratorOtherDf/")


    //</editor-fold>

    //<editor-fold desc="Numerator 3">

    val funcOtherNumDf = numOtherDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.functionalStatusVal))
      &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
      .select(KpiConstants.memberidColName)

    println("----------------------After funcOtherNumDf-----------------------")
    funcOtherNumDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    funcOtherNumDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/funcOtherNumDf/")

    //</editor-fold>

    //<editor-fold desc="Numerator 4">

    val painOtherNumDf = numOtherDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.painAssessmentVal))
      &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
      .select(KpiConstants.memberidColName)

    println("----------------------After painOtherNumDf-----------------------")
    painOtherNumDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    painOtherNumDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/painOtherNumDf/")

    //</editor-fold>

    val acpOtNumDf = spark.read.parquet(intermediateDir+ "/acpotherNumDf/").cache()

    val numeratorOtDf = spark.read.parquet(intermediateDir+ "/numeratorOtherDf/").cache()

    val funcOtNumDf = spark.read.parquet(intermediateDir+ "/funcOtherNumDf/").cache()

    val painOtNumDf = spark.read.parquet(intermediateDir+ "/painOtherNumDf/").cache()

    //</editor-fold>

    //</editor-fold>

    //<editor-fold desc="Output File Creation">

    val acpNumDf = acpNSNumDf.union(acpOtNumDf)

    val numeratorNumDf = numeratorNSDf.union(numeratorOtDf)

    val funcNumDf = funcNSNumDf.union(funcOtNumDf)

    val painNumDf = painNSNumDf.union(painOtNumDf)

    println("----------------------After acpNumDf-----------------------")
    acpNumDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    println("----------------------After numeratorNumDf-----------------------")
    numeratorNumDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    println("----------------------After funcNumDf-----------------------")
    funcNumDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    println("----------------------After painNumDf-----------------------")
    painNumDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    acpNumDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir + "/acpNumDf/")

    painNumDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir + "/painNumDf/")

    numeratorNumDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir + "/numeratorNumDf/")

    funcNumDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir + "/funcNumDf/")

    /*  val outMap = mutable.Map(KpiConstants.totalPopDfName -> toutStrDf, KpiConstants.eligibleDfName -> eligiblePopDf,
        KpiConstants.mandatoryExclDfname -> spark.emptyDataFrame, KpiConstants.optionalExclDfName -> spark.emptyDataFrame,
        KpiConstants.numeratorDfName -> numeratorDf)
  */


    val outMap = mutable.Map(KpiConstants.totalPopDfName -> toutstrDf, KpiConstants.eligibleDfName -> eligiblePopDf,
      KpiConstants.mandatoryExclDfname -> spark.emptyDataFrame, KpiConstants.optionalExclDfName -> spark.emptyDataFrame,
      KpiConstants.numeratorDfName -> acpNumDf, KpiConstants.numerator2DfName -> numeratorNumDf, KpiConstants.numerator3DfName -> funcNumDf,
      KpiConstants.numerator4DfName -> painNumDf)

    //val outDf = UtilFunctions.ncqaOutputDfCreation(spark,outMap,measureId)

    val outDf = UtilFunctions.ncqaCOAOutputDfCreation(spark,outMap)

    outDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir+ "/outDf")



    println("----------------------After outDf-----------------------")
    outDf.filter($"${KpiConstants.memberidColName}".===("116704")).show()

    //</editor-fold>

    //</editor-fold>

    spark.sparkContext.stop()

  }

}
