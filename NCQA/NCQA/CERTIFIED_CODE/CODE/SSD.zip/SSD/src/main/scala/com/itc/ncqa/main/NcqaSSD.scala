package com.itc.ncqa.main

import com.itc.ncqa.Constants.KpiConstants
import com.itc.ncqa.Functions.{DataLoadFunctions, UtilFunctions}
import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkConf
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{SaveMode, SparkSession}

import scala.collection.mutable

object NcqaSSD  {
  def main(args: Array[String]): Unit = {

    //<editor-fold desc="Reading program arguments and Spark Session object creation">

    val year = "2018"
    val measureId = "SSD"
   // val baseMsrPath = "/home/hbase/ncqa/ssd"

    //System.setProperty("hadoop.home.dir", "D:\\WinUtil")

    val conf = new SparkConf().setAppName("NcqaProgram")
    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    conf.set("spark.sql.shuffle.partitions", "5")
    //.set("hive.exec.dynamic.partition.mode", "nonstrict")

    val spark = SparkSession.builder().config(conf).master("local").getOrCreate()

    val rootLogger = Logger.getRootLogger()
    rootLogger.setLevel(Level.ERROR)

    val yearStartDate = year+"-01-01"
    val PreYrStartDate = year.toInt -1 +"-01-01"
    val yearEndDate = year+"-12-31"

    val jobId = spark.sparkContext.applicationId
    //val baseDir = baseMsrPath + "/" + jobId
   // val outDir = baseDir + "/Out"
   // val intermediateDir = baseDir + "/Intermediate"
   // val stagingDir =  baseDir + "/Staging"

    //</editor-fold>

    //<editor-fold desc="Loading Required Tables to memory">

    import spark.implicits._

    val lobList = List(KpiConstants.medicaidLobName, KpiConstants.mmdLobName)

    val claimStatusList = List(KpiConstants.paidVal, KpiConstants.suspendedVal, KpiConstants.pendingVal, KpiConstants.deniedVal)


    val ((membershipDf,visitsDf,refHedisDf,ref_medvaluesetDf)) = DataLoadFunctions.readdatafromlocal(spark,measureId,year)



    //</editor-fold>

    //<editor-fold desc="Eligible Population Calculation">

    //<editor-fold desc=" Age filter">

    //val PreYrStartDate = year.toInt -1 +"-01-01"
    val ageEndDate = year + "-12-31"
    val ageStartDate = year + "-01-01"

    val ageFilterDf = membershipDf.filter(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",KpiConstants.months216).<=(ageEndDate)
      && UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",KpiConstants.months780).>(ageEndDate))


    //ageFilterDf.show()
    //println("Age -> " + ageFilterDf.count())

    println("ageFilterDf")

    //ageFilterDf.filter($"${KpiConstants.memberidColName}" === ("100766")).show()


    //</editor-fold>

    //<editor-fold desc="Continuous Enrollment, Allowable Gap Calculation">

    val inputForContEnrolldf = ageFilterDf.select(KpiConstants.memberidColName, KpiConstants.benefitMedicalColname,
      KpiConstants.memStartDateColName,KpiConstants.memEndDateColName,
      KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName,
      KpiConstants.dateofbirthColName,KpiConstants.primaryPlanFlagColName )



    val benNonMedRemDf = inputForContEnrolldf.filter(($"${KpiConstants.benefitMedicalColname}".===(KpiConstants.yesVal))
      && ($"${KpiConstants.benefitdrugColName}".===(KpiConstants.yesVal)))


    val contEnrollInDf = benNonMedRemDf.withColumn(KpiConstants.contenrollLowCoName,UtilFunctions.add_ncqa_months(spark,lit(ageStartDate), 0))
      .withColumn(KpiConstants.contenrollUppCoName,UtilFunctions.add_ncqa_months(spark,lit(ageEndDate), 0))
      .withColumn(KpiConstants.anchorDateColName, UtilFunctions.add_ncqa_months(spark,lit(ageEndDate), 0))


    val contEnrollStep1Df = contEnrollInDf.filter((($"${KpiConstants.memStartDateColName}".>=($"${KpiConstants.contenrollLowCoName}")) && ($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.contenrollUppCoName}")))
      || (($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.contenrollLowCoName}")) && ($"${KpiConstants.memEndDateColName}".<=($"${KpiConstants.contenrollUppCoName}")))
      ||($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.contenrollLowCoName}") && ($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.contenrollUppCoName}"))))
      .withColumn(KpiConstants.anchorflagColName, when( ($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.anchorDateColName}"))
        && ($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.anchorDateColName}")), lit(1)).otherwise(lit(0)))
      .withColumn(KpiConstants.contEdFlagColName, when( ($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.contenrollUppCoName}"))
        && ($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.contenrollUppCoName}")), lit(1)).otherwise(lit(0)))


    /*Step3(select the members who satisfy both (min_start_date- ces and cee- max_end_date <= allowable gap) conditions)*/
    val listDf = contEnrollStep1Df.groupBy($"${KpiConstants.memberidColName}")
      .agg(max($"${KpiConstants.memEndDateColName}").alias(KpiConstants.maxMemEndDateColName),
        min($"${KpiConstants.memStartDateColName}").alias(KpiConstants.minMemStDateColName),
        first($"${KpiConstants.contenrollLowCoName}").alias(KpiConstants.contenrollLowCoName),
        first($"${KpiConstants.contenrollUppCoName}").alias(KpiConstants.contenrollUppCoName),
        sum($"${KpiConstants.anchorflagColName}").alias(KpiConstants.anchorflagColName))
      .filter((date_add($"max_mem_end_date",KpiConstants.days45).>=($"${KpiConstants.contenrollUppCoName}"))
        && (date_sub($"min_mem_start_date",KpiConstants.days45).<=($"${KpiConstants.contenrollLowCoName}"))
        &&($"${KpiConstants.anchorflagColName}").>(0))
      .select($"${KpiConstants.memberidColName}")


    val contEnrollStep2Df = contEnrollStep1Df.as("df1").join(listDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select("df1.*")

    /*window function creation based on partioned by member_sk and order by mem_start_date*/
    val contWindowVal = Window.partitionBy(s"${KpiConstants.memberidColName}").orderBy(org.apache.spark.sql.functions.col(s"${KpiConstants.memEndDateColName}").desc,org.apache.spark.sql.functions.col(s"${KpiConstants.memStartDateColName}"))


    /* added 3 columns (date_diff(datediff b/w next start_date and current end_date for each memeber),
     anchorflag(if member is continuously enrolled on anchor date 1, otherwise 0)
     count(if date_diff>1 1, otherwise 0) over window*/
    val contEnrollStep3Df = contEnrollStep2Df.withColumn(KpiConstants.overlapFlagColName, when(($"${KpiConstants.memStartDateColName}".>=(lag($"${KpiConstants.memStartDateColName}",1).over(contWindowVal)) && $"${KpiConstants.memStartDateColName}".<=(lag($"${KpiConstants.memEndDateColName}",1).over(contWindowVal))
      && ($"${KpiConstants.memEndDateColName}".>=(lag($"${KpiConstants.memStartDateColName}",1).over(contWindowVal)) && $"${KpiConstants.memEndDateColName}".<=(lag($"${KpiConstants.memEndDateColName}",1).over(contWindowVal))))
      ,lit(1))
      .when(($"${KpiConstants.memStartDateColName}".<(lag($"${KpiConstants.memStartDateColName}",1).over(contWindowVal)))
        && ($"${KpiConstants.memEndDateColName}".>=(lag($"${KpiConstants.memStartDateColName}",1 ).over(contWindowVal)) && $"${KpiConstants.memEndDateColName}".<=(lag($"${KpiConstants.memEndDateColName}",1).over(contWindowVal)))
        ,lit(2)).otherwise(lit(0)))

      .withColumn(KpiConstants.coverageDaysColName,when($"${KpiConstants.overlapFlagColName}".===(0) ,datediff(when($"${KpiConstants.memEndDateColName}".<=($"${KpiConstants.contenrollUppCoName}"), $"${KpiConstants.memEndDateColName}").otherwise($"${KpiConstants.contenrollUppCoName}")
        ,when($"${KpiConstants.memStartDateColName}".>=($"${KpiConstants.contenrollLowCoName}"), $"${KpiConstants.memStartDateColName}").otherwise($"${KpiConstants.contenrollLowCoName}"))+ 1 )
        .when($"${KpiConstants.overlapFlagColName}".===(2), datediff( when($"${KpiConstants.contenrollLowCoName}".>=(lag( $"${KpiConstants.memStartDateColName}",1).over(contWindowVal)), $"${KpiConstants.contenrollLowCoName}").otherwise(lag( $"${KpiConstants.memStartDateColName}",1).over(contWindowVal))
          ,$"${KpiConstants.memStartDateColName}")+1 )
        .otherwise(0))

      .withColumn(KpiConstants.countColName, when(when($"${KpiConstants.overlapFlagColName}".===(0), datediff(lag($"${KpiConstants.memStartDateColName}",1).over(contWindowVal), $"${KpiConstants.memEndDateColName}"))
        .otherwise(0).>(1),lit(1))
        .otherwise(lit(0)) )

    val contEnrollStep5Df = contEnrollStep3Df.groupBy(KpiConstants.memberidColName)
      .agg(min($"${KpiConstants.memStartDateColName}").alias(KpiConstants.minMemStDateColName),
        max($"${KpiConstants.memEndDateColName}").alias(KpiConstants.maxMemEndDateColName),
        sum($"${KpiConstants.countColName}").alias(KpiConstants.countColName),
        sum($"${KpiConstants.coverageDaysColName}").alias(KpiConstants.coverageDaysColName),
        first($"${KpiConstants.contenrollLowCoName}").alias(KpiConstants.contenrollLowCoName),
        first($"${KpiConstants.contenrollUppCoName}").alias(KpiConstants.contenrollUppCoName))
      .withColumn(KpiConstants.reqCovDaysColName, (datediff($"${KpiConstants.contenrollUppCoName}", $"${KpiConstants.contenrollLowCoName}")-44))

    val contEnrollmemDf = contEnrollStep5Df.filter(((($"${KpiConstants.countColName}") + (when(date_sub($"min_mem_start_date", 1).>=($"${KpiConstants.contenrollLowCoName}"),lit(1)).otherwise(lit(0)))
      + (when(date_add($"max_mem_end_date", 1).<=($"${KpiConstants.contenrollUppCoName}"),lit(1)).otherwise(lit(0)))).<=(1) )
      && ($"${KpiConstants.coverageDaysColName}".>=($"${KpiConstants.reqCovDaysColName}")))
      .select(KpiConstants.memberidColName).distinct()


    val contEnrollDf = contEnrollStep1Df.as("df1").join(contEnrollmemDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .filter($"df1.${KpiConstants.contEdFlagColName}".===(1))
      .select(s"df1.${KpiConstants.memberidColName}", s"df1.${KpiConstants.lobColName}", s"df1.${KpiConstants.lobProductColName}",s"df1.${KpiConstants.payerColName}",s"df1.${KpiConstants.primaryPlanFlagColName}").cache()

    //println("contEnrollDf" + contEnrollDf.count())

    println("contEnrollDf")
    //contEnrollDf.filter($"${KpiConstants.memberidColName}" === ("100766")).show()

    //</editor-fold>

    //<editor-fold desc="Dual Enrollment and SSD Lob filter">

    val baseOutDf = UtilFunctions.baseOutDataframeCreation(spark, contEnrollDf, lobList , measureId)

    val payerlist = List(KpiConstants.sn1PayerVal,KpiConstants.sn2PayerVal,KpiConstants.sn3PayerVal,KpiConstants.mmpPayerVal)

    val w15ContEnrollDf = baseOutDf.filter($"${KpiConstants.lobColName}".isin(lobList:_*) &&
      (!$"${KpiConstants.payerColName}".isin(payerlist:_*)))
      .dropDuplicates(). cache()

    //println("w15ContEnrollDf" + w15ContEnrollDf.count())


    println("w15ContEnrollDf")
    //contEnrollDf.filter($"${KpiConstants.memberidColName}" === ("100766")).show()



    //</editor-fold>

    //<editor-fold desc="Initial Join with Ref_Hedis">visitRefHedisDf

    /*
    BH Stand Alone Nonacute Inpatient,Schizophrenia,Bipolar Disorder,Glucose Tests,Other Bipolar Disorder,Long-Acting Injections,Nonacute Inpatient POS,
    ED POS,Electroconvulsive Therapy,Acute Inpatient,Partial Hospitalization/Intensive Outpatient,Telehealth POS,Community Mental Health Center POS,
    Acute Inpatient POS,Outpatient POS,BH Outpatient,Partial Hospitalization POS,Observation,Online Assessments,HbA1c Tests,Diabetes, Telehealth Modifier,
    Visit Setting Unspecified,Outpatient,BH Stand Alone Acute Inpatient,ED,Nonacute Inpatient,Telephone Visits,

SSD Antipsychotic Medications,Diabetes Medications
     */

    val argmapforRefHedis = mutable.Map(KpiConstants.eligibleDfName -> visitsDf , KpiConstants.refHedisTblName -> refHedisDf,
      KpiConstants.refmedValueSetTblName -> ref_medvaluesetDf)
    val allValueList = List(KpiConstants.independentLabVal,KpiConstants.hospiceVal,KpiConstants.bHStandAloneAcuteInpatientVal,
      KpiConstants.schizophreniaVal,KpiConstants.bipolarDisorderVal,KpiConstants.glucoseTestsValueSet,KpiConstants.otherBipolarDisorder,
      KpiConstants.longActingInjVal,KpiConstants.nonacuteInpatientPosVal,KpiConstants.edPosVal,KpiConstants.electroconvulsiveTherapyVal,KpiConstants.acuteInpatientVal,
      KpiConstants.partialHospitalizationIntensiveOutpatientVal,KpiConstants.communityMentalHealthCenterPosVal,KpiConstants.acuteInpatientPosVal,
      KpiConstants.diabetesExclusionVal,KpiConstants.transitionalCareMgtSerVal,KpiConstants.telehealthPosVal,KpiConstants.nonAcuteInPatientVal,
      KpiConstants.outpatientPosVal,KpiConstants.bhOutpatientVal,KpiConstants.partialHospitalizationPosVal,KpiConstants.observationVal
      ,KpiConstants.onlineAssesmentVal,KpiConstants.hba1cTestVal,KpiConstants.diabetesVal ,KpiConstants.bhStandAloneNonacuteInpatientVal ,KpiConstants.edVal
      ,KpiConstants.telehealthModifierVal,KpiConstants.visitSettingUnspecifiedVal,KpiConstants.telephoneVisitsVal,KpiConstants.outPatientVal)

    // val medList = KpiConstants.emptyList      allValueList --> ldlcTestsVal
    val medList =List(KpiConstants.diabetesMedicationVal,KpiConstants.antipsychoticMedVal)

    val visitRefHedisDf = UtilFunctions.joinWithRefHedisFunction(spark,argmapforRefHedis,allValueList,medList)

    visitRefHedisDf.select($"${KpiConstants.memberidColName}",$"${KpiConstants.valuesetColName}")


    println("visitRefHedisDf")
    //visitRefHedisDf.filter( $"${KpiConstants.memberidColName}" === ("100766")).show()

    //</editor-fold>

    //<editor-fold desc="Removal of Independent Lab Visits">

    val groupList = visitsDf.schema.fieldNames.toList.dropWhile(p=> p.equalsIgnoreCase(KpiConstants.memberidColName))
    val visitgroupedDf = visitRefHedisDf.groupBy(KpiConstants.memberidColName, groupList:_*).agg(collect_list(KpiConstants.valuesetColName).alias(KpiConstants.valuesetColName))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName, KpiConstants.claimstatusColName,
        KpiConstants.dobColName,KpiConstants.supplflagColName , KpiConstants.valuesetColName,KpiConstants.genderColName
        ,KpiConstants.poscodeColName
      )

    println("visitgroupedDf")
    //visitgroupedDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.bhStandAloneNonacuteInpatientVal)
     // && $"${KpiConstants.memberidColName}" === ("100766"))).show()


    val indLabVisRemDf = visitgroupedDf.filter(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)
      ||((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.hba1cTestVal)))
      ||((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.glucoseTestsValueSet)))

    ).repartition(2).cache()



    println("indLabVisRemDf")
    // indLabVisRemDf.filter($"${KpiConstants.memberidColName}" === ("95314")).show()

 //   indLabVisRemDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.bhStandAloneNonacuteInpatientVal)
   //   && $"${KpiConstants.memberidColName}" === ("100766"))).show()

    val membertotalDf = w15ContEnrollDf.dropDuplicates()
    val argmapForVisittJoin = mutable.Map(KpiConstants.membershipTblName -> membertotalDf , KpiConstants.visitTblName -> indLabVisRemDf)
    val visitJoinedOutDf = UtilFunctions.initialJoinFunction(spark,argmapForVisittJoin)


    visitJoinedOutDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .parquet("D:\\HealthCare Insight Docs\\ReadParquet\\smdvisitpq")

    val visitJoinDf = spark.read
      .parquet("D:\\HealthCare Insight Docs\\ReadParquet\\smdvisitpq").repartition(2).cache()

    println("visitJoinDf")



    //visitJoinDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.bhStandAloneNonacuteInpatientVal)
     // && $"${KpiConstants.memberidColName}" === ("100766"))).show()

    // visitJoinDf.filter($"${KpiConstants.memberidColName}" === ("95314")).show()

    //</editor-fold>

    //<editor-fold desc="Hospice Removal">

    // val yearEndDate = "2019-01-01"
    val hospiceInCurrYearMemDf = indLabVisRemDf.filter(
      (!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))  &&
        (array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hospiceVal))
        && ($"${KpiConstants.serviceDateColName}".>=(yearStartDate) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))

    println( "Hospice members")

    //hospiceInCurrYearMemDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.bhStandAloneNonacuteInpatientVal)
     // && $"${KpiConstants.memberidColName}" === ("100766"))).show()

    //hospiceInCurrYearMemDf.filter($"${KpiConstants.memberidColName}" === ("100766")).show()

    //   hospiceInCurrYearMemDf.show()

    println("hospiceInCurrYearMemDf")
    // hospiceInCurrYearMemDf.filter($"${KpiConstants.memberidColName}" === ("95314")).show()

    val hospicefinaldf =   hospiceInCurrYearMemDf .select(KpiConstants.memberidColName)
      .dropDuplicates()

    //hospicefinaldf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.bhStandAloneNonacuteInpatientVal)
      //&& $"${KpiConstants.memberidColName}" === ("100766"))).show()

    //</editor-fold>

    val hosiceremovalDf = visitJoinDf.except(visitJoinDf.filter($"${KpiConstants.memberidColName}".isin(
      hospicefinaldf.rdd.map(r=>r.getString(0)).collect():_*
    )))


    println("hosiceremovalDf" + hosiceremovalDf.count() )

    //hosiceremovalDf.filter($"${KpiConstants.memberidColName}" === ("100766")).show()

   // hosiceremovalDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.bhStandAloneNonacuteInpatientVal)
     // && $"${KpiConstants.memberidColName}" === ("100766"))).show()


    val eventsVisitsDf = hosiceremovalDf.filter(  $"${KpiConstants.supplflagColName}".===("N")  &&

      ($"${KpiConstants.claimstatusColName}".isin(claimStatusList:_*))).cache()
    eventsVisitsDf.count()

    println("eventsVisitsDf" + eventsVisitsDf.count() )
  //  eventsVisitsDf.filter($"${KpiConstants.memberidColName}" === ("100766")).show()


    println("schizophreniaVal")
    //eventsVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.schizophreniaVal)
      // && $"${KpiConstants.memberidColName}" === ("100766")) ).show()
     //println("bHStandAloneAcuteInpatientVal")
    //eventsVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.bHStandAloneAcuteInpatientVal)
     //&& $"${KpiConstants.memberidColName}" === ("100766"))).show()
/*
    println("bipolarDisorderVal")
    eventsVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.bipolarDisorderVal)
      && $"${KpiConstants.memberidColName}" === ("100766"))).show()

    println("otherBipolarDisorder")
    eventsVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.otherBipolarDisorder)
      && $"${KpiConstants.memberidColName}" === ("100766"))).show()


    println("visitSettingUnspecifiedVal")
    eventsVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.visitSettingUnspecifiedVal)
      && $"${KpiConstants.memberidColName}" === ("100766"))).show()

    println("acuteInpatientVal")
    eventsVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.acuteInpatientPosVal)
      && $"${KpiConstants.memberidColName}" === ("100766"))).show()
*/
    //</editor-fold>

    //<editor-fold desc="Events Calculation">

    //<editor-fold desc="Event Step - 1">

    val schievent11Df = eventsVisitsDf
      .filter(
        (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.bHStandAloneAcuteInpatientVal))

          && ((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.schizophreniaVal))
          || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.bipolarDisorderVal))
          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.otherBipolarDisorder)))
          &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal))
          &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate))
          &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))
          )) .select(KpiConstants.memberidColName ).distinct()
      .repartition(2).cache()

    println("schievent11Df")




  //  schievent11Df.filter($"${KpiConstants.memberidColName}" === ("100766")).show()



    val schievent12Df = eventsVisitsDf
      .filter(
         ((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.visitSettingUnspecifiedVal))
          &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.acuteInpatientPosVal))
          )

          && ((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.schizophreniaVal))
          || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.bipolarDisorderVal))
          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.otherBipolarDisorder)))
          &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal))
          &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate))
          &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))
          )) .select(KpiConstants.memberidColName ).distinct()
      .repartition(2).cache()

    println("schievent12Df")

   // schievent12Df.filter($"${KpiConstants.memberidColName}" === ("100766")).show()


    val schievent1Df = schievent12Df.union(schievent11Df)

    //println("schievent1Df")

    //schievent1Df.filter($"${KpiConstants.memberidColName}" === ("100766")).show()

    //schievent1Df.show()

    //</editor-fold>

    val schieventSc2Df = eventsVisitsDf
      .filter(
        ( (((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.visitSettingUnspecifiedVal))
          &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outpatientPosVal)))

          || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.bhOutpatientVal))

          || ((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.visitSettingUnspecifiedVal))
          && (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.partialHospitalizationPosVal)))

          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.partialHospitalizationIntensiveOutpatientVal))

          ||((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.visitSettingUnspecifiedVal))
          &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.communityMentalHealthCenterPosVal)))

          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.electroconvulsiveTherapyVal))

          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.observationVal))

          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.edVal))

          ||((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.visitSettingUnspecifiedVal))
          &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.edPosVal)) )

          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.bhStandAloneNonacuteInpatientVal))

          ||((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.visitSettingUnspecifiedVal))
          &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.nonacuteInpatientPosVal)))

          ||((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.visitSettingUnspecifiedVal))
          && (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal)))
          ))

          // &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal))

         // && ((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.schizophreniaVal))
         // || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.bipolarDisorderVal))
         // ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.otherBipolarDisorder)) //)

          &&((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.schizophreniaVal))
          &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))

          &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate))
          &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      ) //.select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)
      .repartition(2).cache()


    println("schieventSc2Df")

    //schieventSc2Df.filter($"${KpiConstants.memberidColName}" === ("100766")).show()


    val step1ScDf = schieventSc2Df //.union(schi2event2Df)

    println("step1ScDf" + step1ScDf.count())

   // step1ScDf.filter($"${KpiConstants.memberidColName}" === ("100766")).show()

    val schievent2MemVisits1Df = step1ScDf.groupBy(KpiConstants.memberidColName)
      .agg(countDistinct(KpiConstants.serviceDateColName).alias(KpiConstants.countColName))

    val schievent2_1ScDf = schievent2MemVisits1Df.filter($"${KpiConstants.countColName}".>=(2))
      .select(KpiConstants.memberidColName).distinct()

    println("schievent2_1ScDf" )
   // schievent2_1ScDf.filter($"${KpiConstants.memberidColName}" === ("100766")).show()


    //------------------------------------Bipolar-------------------------------

    val schieventBi2Df = eventsVisitsDf
      .filter(
        ( ((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.visitSettingUnspecifiedVal))
          &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outpatientPosVal)))

          || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.bhOutpatientVal))

          || ((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.visitSettingUnspecifiedVal))
          && (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.partialHospitalizationPosVal)))

          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.partialHospitalizationIntensiveOutpatientVal))

          ||((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.visitSettingUnspecifiedVal))
          &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.communityMentalHealthCenterPosVal)))

          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.electroconvulsiveTherapyVal))

          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.observationVal))

          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.edVal))

          ||((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.visitSettingUnspecifiedVal))
          &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.edPosVal)) )

          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.bhStandAloneNonacuteInpatientVal))

          ||((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.visitSettingUnspecifiedVal))
          &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.nonacuteInpatientPosVal)))

          ||((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.visitSettingUnspecifiedVal))
          && (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal)))
          )

          &&(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.bipolarDisorderVal))||
          ((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.otherBipolarDisorder))))
          &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))

          &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate))
          &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      ) //.select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)
      .repartition(2).cache()


    val step1BiDf = schieventBi2Df //.union(schi2event2Df)

    println("step1BiDf" + step1BiDf.count())

    //step1BiDf.filter($"${KpiConstants.memberidColName}" === ("100766")).show()

    val schievent2MemVisits1BiDf = step1BiDf.groupBy(KpiConstants.memberidColName)
      .agg(countDistinct(KpiConstants.serviceDateColName).alias(KpiConstants.countColName))

    val schievent2_1BiDf = schievent2MemVisits1BiDf.filter($"${KpiConstants.countColName}".>=(2))
      .select(KpiConstants.memberidColName)



    println("schievent2_1BiDf" )

    //schievent2_1BiDf.filter($"${KpiConstants.memberidColName}" === ("100766")).show()


    val schizDataset = schievent2_1ScDf .union(schievent1Df).union(schievent2_1BiDf)


println("Eligible Population")

    /*
    schizDataset.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("D:\\HealthCare Insight Docs\\SSD_OutPut")
*/


    println("schizDataset" )


    //schizDataset.filter($"${KpiConstants.memberidColName}" === ("100766")).show()

 //val step2visitsDf = eventsVisitsDf.filter($"${KpiConstants.memberidColName}"
   //   .isin(schizDataset.rdd.map(r => r.getString(0)).collect():_*)).cache()


    val EligiblePopDf = eventsVisitsDf.filter($"${KpiConstants.memberidColName}"
      .isin(schizDataset.rdd.map(r => r.getString(0)).collect():_*)).cache()

    println("step2visitsDf" )

    println("--------People Who are Using AntiPsychotic Injection with SchiZophenia or BiPolar ----")


    val event4Df = EligiblePopDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.longActingInjVal))
         ||(array_contains($"${KpiConstants.valuesetColName}",KpiConstants.antipsychoticMedVal))    )
      &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName).distinct()

    println("event4Df AntiPsychotic DF")

  //  event4Df.filter($"${KpiConstants.memberidColName}" === ("109962")).show()

     val nonAntiDf = schizDataset.except(event4Df)

    println("nonAntiDf")
    //nonAntiDf.filter($"${KpiConstants.memberidColName}" === ("109962")).show()


    val step2visitsDf = EligiblePopDf.filter($"${KpiConstants.memberidColName}"
      .isin(event4Df.rdd.map(r => r.getString(0)).collect():_*)).cache()

/*
    event4Df.select($"${KpiConstants.memberidColName}" , lit("AntiPsychotic Step1").as("Valueset"))  .coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("D:\\HealthCare Insight Docs\\SSD_OutPut")

    nonAntiDf.select($"${KpiConstants.memberidColName}" , lit("Non AntiPsychotic Step1").as("Valueset")).coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("D:\\HealthCare Insight Docs\\SSD_OutPut")
*/


    println("step2visitsDf")

    //step2visitsDf.filter($"${KpiConstants.memberidColName}" === ("109692")).show()



    //event4Df.filter($"${KpiConstants.memberidColName}" === ("100766")).show()


   // val schiz1Df = schizDataset.union(event4Df)

   // println("schiz1Df" )

    //schiz1Df.filter($"${KpiConstants.memberidColName}" === ("100766")).show()

   // val step2VisitsDf = eventsVisitsDf.filter($"${KpiConstants.memberidColName}"
     // .isin(schiz1Df.rdd.map(r => r.getString(0)).collect():_*)).cache()

    //println("step2VisitsDf" )

    //step2VisitsDf.filter($"${KpiConstants.memberidColName}" === ("100766")).show()

    val event1Df =  step2visitsDf

     .filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.acuteInpatientVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabetesVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&($"${KpiConstants.serviceDateColName}".>=(PreYrStartDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)
    //</editor-fold>
    // println("event1Df")
    // event1Df.show()

    println("event1Df")
    // event1Df.filter($"${KpiConstants.memberidColName}" === ("109962")).show()


    //<editor-fold desc="Second Event">

    val event2Step1Df=  step2visitsDf


      .filter((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.observationVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.edVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.nonAcuteInPatientVal)))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabetesVal))
      &&((!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal)))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)))
      &&(($"${KpiConstants.serviceDateColName}".>=(PreYrStartDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName).distinct()

    println("event2Step1Df")
    //event2Step1Df.filter($"${KpiConstants.memberidColName}" === ("109962")).show()

    val event2Step2Df =  step2visitsDf
      .filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabetesVal))
      &&((!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telephoneVisitsVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.onlineAssesmentVal)))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&($"${KpiConstants.serviceDateColName}".>=(PreYrStartDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName).distinct()

    println("event2Step2Df")
    //    event2Step2Df.show

    event2Step2Df.filter($"${KpiConstants.memberidColName}" === ("109962")).show()
    val event2AtLeast1VisitDf = event2Step1Df.intersect(event2Step2Df)

    println("--------------------event2AtLeast1VisitDf--------------------")
    //event2AtLeast1VisitDf.filter($"${KpiConstants.memberidColName}" === ("109962")).show()
    /*member_id, count of visits*/
    val event2MemVisits1Df = event2AtLeast1VisitDf.groupBy(KpiConstants.memberidColName)
      .agg(countDistinct(KpiConstants.serviceDateColName).alias(KpiConstants.countColName))

    println("--------------------event2MemVisits1Df--------------------")
   // event2MemVisits1Df.filter($"${KpiConstants.memberidColName}" === ("109962")).show()


    //<editor-fold desc="2 or more visits">

    val event2_1Df = event2MemVisits1Df.filter($"${KpiConstants.countColName}".>=(2))
      .select(KpiConstants.memberidColName)
    //</editor-fold>

    //<editor-fold desc="1 Visit">

    println("event2_1Df")
    //event2_1Df.filter($"${KpiConstants.memberidColName}" === ("109962")).show()

    val diabeve2df = event2AtLeast1VisitDf.except(event2AtLeast1VisitDf.filter($"${KpiConstants.memberidColName}".isin(event2_1Df.rdd.map(r => r.getString(0)).collect():_*)))

    val oneVisitInDf = event2MemVisits1Df.select(KpiConstants.memberidColName).except(event2_1Df).as("df1")
      .join(step2visitsDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}"
        , KpiConstants.innerJoinType)
      .select("df2.*")

    //val oneVisitInDf = event2MemVisits1Df.except(event2MemVisits1Df
    // .filter($"${KpiConstants.memberidColName}".isin(event2_1Df.rdd.map(r => r.getString(0)).collect():_*)))



    println("oneVisitInDf")
    //oneVisitInDf.filter($"${KpiConstants.memberidColName}" === ("109962")).show()


    val event2Step3Df= oneVisitInDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.observationVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.edVal)))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabetesVal))
      &&((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal)))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&($"${KpiConstants.serviceDateColName}".>=(PreYrStartDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)

    println("event2Step3Df")
    //event2Step3Df.filter($"${KpiConstants.memberidColName}" === ("109962")).show()

    val event2Step4Df = oneVisitInDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabetesVal))
      &&((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telephoneVisitsVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.onlineAssesmentVal)))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&($"${KpiConstants.serviceDateColName}".>=(PreYrStartDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)

    println("event2Step4Df")
    //event2Step4Df.filter($"${KpiConstants.memberidColName}" === ("109962")).show()

    val event2_2Df = (event2Step3Df.union(event2Step4Df)).as("df1").join(diabeve2df.as("df2"), $"df1.${KpiConstants.memberidColName}"=== $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .filter($"df1.${KpiConstants.serviceDateColName}".=!=($"df2.${KpiConstants.serviceDateColName}"))
      .select(s"df1.${KpiConstants.memberidColName}")
    //</editor-fold>

    val event2Df = event2_1Df.union(event2_2Df) .select(KpiConstants.memberidColName)

    println("event2Df")
    // event2Df.filter($"${KpiConstants.memberidColName}" === ("109962")).show()

    //</editor-fold>

    //<editor-fold desc="Third Event">

    val event3Df = step2visitsDf
    .filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabetesMedicationVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&($"${KpiConstants.serviceDateColName}".>=(PreYrStartDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)
    //</editor-fold>

    //println("event3Df")
   // event3Df.filter($"${KpiConstants.memberidColName}" === ("109962")).show()
    //</editor-fold>

    val diabstep2Df = event1Df.union(event2Df).union(event3Df) .union(nonAntiDf)


  //  println("Required Exclusion diabstep2Df" )

 //   diabstep2Df.filter($"${KpiConstants.memberidColName}" === ("109962")).show()



   // val diabstep2Df =  (event4Df).except(event1Df.union(event2Df).union(event3Df))

    // println("diabstep2Df")
    //diabstep2Df.filter($"${KpiConstants.memberidColName}" === ("109962")).show()

//    val eligibleDf = schizDataset.except(diabstep2Df).select(KpiConstants.memberidColName).distinct()

    // val eligibleDf = diabstep2Df.select(KpiConstants.memberidColName).distinct()

    //println("eligibleDf" + eligibleDf.count())
   // eligibleDf.filter($"${KpiConstants.memberidColName}".===("100766")).show()

  /*  println("Required Exclusion")

    diabstep2Df.select($"${KpiConstants.memberidColName}").distinct().coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("D:\\HealthCare Insight Docs\\SSD_OutPut")
*/

    val numDf = schizDataset.except(diabstep2Df)

    val ssdnumDf = hosiceremovalDf.filter($"${KpiConstants.memberidColName}"
      .isin(numDf.rdd.map(r => r.getString(0)).collect():_*)).cache()

    println("numSsdDf")


    val numSsdDf = ssdnumDf.filter(( (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.glucoseTestsValueSet))
      || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.hba1cTestVal)))
      && ($"${KpiConstants.serviceDateColName}".>=(yearStartDate) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)) )
      .select($"${KpiConstants.memberidColName}"  )
      . distinct().cache()

/*    val OthSupSsdDf = numDf.except(nonsupnumSsdDf).dropDuplicates()

    val oSsdDf = hosiceremovalDf.filter($"${KpiConstants.memberidColName}"
      .isin(OthSupSsdDf.rdd.map(r => r.getString(0)).collect():_*)
      && ($"${KpiConstants.claimstatusColName}".isin(claimStatusList:_*))).cache()


    val numothSsdDf = oSsdDf
      .filter(( (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.glucoseTestsValueSet)))
        || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.hba1cTestVal))
        && ($"${KpiConstants.serviceDateColName}".>=(yearStartDate) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate))  )
      .select($"${KpiConstants.memberidColName}"  )
      . distinct().cache()


 val numSsdDf = numothSsdDf.union(nonsupnumSsdDf)

*/

//    numSsdDf.show()
/*
    numSsdDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("D:\\HealthCare Insight Docs\\SSD_OutPut")
*/

    val toutStrDf =EligiblePopDf.select($"${KpiConstants.memberidColName}",  $"${KpiConstants.memberidColName}".as(KpiConstants.ncqaOutmemberIdCol),
      $"${KpiConstants.payerColName}".as(KpiConstants.ncqaOutPayerCol)) .withColumn(KpiConstants.ncqaOutMeasureCol,lit(measureId)).distinct()

    val ePopDf = schizDataset
    val ReqExDf = diabstep2Df .select($"${KpiConstants.memberidColName}"  ) . distinct()

    //<editor-fold desc="Ncqa Output Creation">


    val outMap = mutable.Map(KpiConstants.totalPopDfName -> toutStrDf, KpiConstants.eligibleDfName -> ePopDf  ,
      KpiConstants.mandatoryExclDfname -> ReqExDf , KpiConstants.optionalExclDfName -> spark.emptyDataFrame,
      KpiConstants.numeratorDfName -> numSsdDf )


    val outDf = UtilFunctions.ncqaOutputDfCreation(spark,outMap,measureId)

    //outDf.printSchema()

    outDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("D:\\HealthCare Insight Docs\\SSD_OutPut")


  }


}
