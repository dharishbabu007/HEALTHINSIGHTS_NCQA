package main.scala.com.itc.ncqa.main

import main.scala.com.itc.ncqa.Constants.KpiConstants
import main.scala.com.itc.ncqa.Functions.UtilFunctions
import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkConf
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, StringType}

import scala.collection.mutable

object NcqaCCS {

  def main(args: Array[String]): Unit = {

    //<editor-fold desc="Reading program arguments and Spark Session object creation">

    val year = "2018"
    val measureId = "CCS"
    val baseMsrPath = "/home/hbase/ncqa/ccs/Test_CCS"

    System.setProperty("hadoop.home.dir", "D:\\WinUtil")

    val conf = new SparkConf().setAppName("NcqaProgram")
    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    conf.set("spark.sql.shuffle.partitions", "5")
    //.set("hive.exec.dynamic.partition.mode", "nonstrict")

    val spark = SparkSession.builder().config(conf).master("local").getOrCreate()

    val rootLogger = Logger.getRootLogger()
    rootLogger.setLevel(Level.ERROR)

    val yearStartDate = year+"-01-01"
    val yearEndDate = year+"-12-31"
    val prevYearStDate = year.toInt-1 +"-01-01"
    val myMinus2StDate = year.toInt-2 +"-01-01"
    val myminus4StDate = year.toInt-4 +"-01-01"

    val jobId = spark.sparkContext.applicationId
    val baseDir = baseMsrPath + "/" + jobId
    val outDir = baseDir + "/Out"
    val intermediateDir = baseDir + "/Intermediate"
    val stagingDir =  baseDir + "/Staging"

    //</editor-fold>

    //<editor-fold desc="Loading Required Tables to memory">

    import spark.implicits._

    val lobList = List(KpiConstants.commercialLobName, KpiConstants.medicaidLobName, KpiConstants.marketplaceLobName,KpiConstants.mmdLobName)

    println("-------------------membership----------------")
    val membershipDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\CCS\\Test\\MEMBERSHIP_ENROLLMENT.csv")
      .filter(($"${KpiConstants.considerationsColName}".===(KpiConstants.yesVal))
        && ($"${KpiConstants.memStartDateColName}".isNotNull)
        && ($"${KpiConstants.memEndDateColName}".isNotNull))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .withColumn(KpiConstants.memStartDateColName, to_date($"${KpiConstants.memStartDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.memEndDateColName, to_date($"${KpiConstants.memEndDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.dateofbirthColName, to_date($"${KpiConstants.dateofbirthColName}", KpiConstants.dateFormatString))
      .repartition(2).cache()

    membershipDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(stagingDir+ "/membershipDf/")

    membershipDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()

    val claimStatusList = List(KpiConstants.paidVal, KpiConstants.suspendedVal, KpiConstants.pendingVal, KpiConstants.deniedVal)

    val visitsDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\CCS\\Test\\VISITS.csv")
      .filter(($"${KpiConstants.serviceDateColName}".isNotNull)
        && (($"${KpiConstants.admitDateColName}".isNotNull && $"${KpiConstants.dischargeDateColName}".isNotNull)
        || ($"${KpiConstants.admitDateColName}".isNull && $"${KpiConstants.dischargeDateColName}".isNull))
        &&((($"${KpiConstants.dataSourceColName}".===("Claim"))&&($"${KpiConstants.claimstatusColName}".isin(claimStatusList:_*)))
        || (($"${KpiConstants.dataSourceColName}".===("RxClaim"))&&($"${KpiConstants.claimstatusColName}".isin(claimStatusList:_*)))
        || ($"${KpiConstants.dataSourceColName}".===("Rx"))
        || ($"${KpiConstants.dataSourceColName}".===("Lab"))))
      .drop(KpiConstants.lobProductColName, "latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name","product")
      .withColumn(KpiConstants.dobColName, to_date($"${KpiConstants.dobColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.serviceDateColName, to_date($"${KpiConstants.serviceDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.admitDateColName, when($"${KpiConstants.admitDateColName}".isNotNull,to_date($"${KpiConstants.admitDateColName}",  KpiConstants.dateFormatString)))
      .withColumn(KpiConstants.dischargeDateColName, when($"${KpiConstants.dischargeDateColName}".isNotNull,to_date($"${KpiConstants.dischargeDateColName}",  KpiConstants.dateFormatString)))
      .withColumn(KpiConstants.medstartdateColName, when($"${KpiConstants.medstartdateColName}".isNotNull,to_date($"${KpiConstants.medstartdateColName}",  KpiConstants.dateFormatString)))
      .withColumn(KpiConstants.revenuecodeColName, when((length($"${KpiConstants.revenuecodeColName}").as[Int].===(3)),concat(lit("0" ),lit($"${KpiConstants.revenuecodeColName}"))).otherwise($"${KpiConstants.revenuecodeColName}"))
      .withColumn(KpiConstants.billtypecodeColName, when((length($"${KpiConstants.billtypecodeColName}").as[Int].===(3)),concat(lit("0" ),lit($"${KpiConstants.billtypecodeColName}"))).otherwise($"${KpiConstants.billtypecodeColName}"))
      .withColumn(KpiConstants.proccode2ColName, when(($"${KpiConstants.proccode2mod1ColName}".isin(KpiConstants.avoidCodeList:_*)) || ($"${KpiConstants.proccode2mod2ColName}".isin(KpiConstants.avoidCodeList:_*)),lit("NA")).otherwise($"${KpiConstants.proccode2ColName}"))
      .repartition(2).cache()

    visitsDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(stagingDir+ "/visitsDf/")

    println("-------------------visits----------------")
    visitsDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()

    println("-------------------refHedisDf----------------")
    val refHedisDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\CCS\\Test\\REF_HEDIS2019.csv")
      .filter(($"${KpiConstants.measureIdColName}".===(KpiConstants.ccsMeasureId)) || ($"${KpiConstants.measureIdColName}".===(KpiConstants.ggMeasureId)))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .repartition(2).cache()

    refHedisDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(stagingDir+ "/refHedisDf/")

    println("-------------------ref_medvaluesetDf----------------")
    val ref_medvaluesetDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\CCS\\Test\\REF_MED_VALUE_SET.csv")
      .filter(($"${KpiConstants.measure_idColName}".===(KpiConstants.ccsMeasureId)) )
      .drop("latest_flag", "active_flag", "ingestion_date", "source_name" ,"user_name")
      .repartition(2).cache()

    ref_medvaluesetDf.coalesce(2)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(stagingDir+ "/ref_medvaluesetDf/")

    //</editor-fold>

    //<editor-fold desc=" Eligible Population Calculation">

    //<editor-fold desc="Age Filter Calculation">

    val ageEndDate = year + "-12-31"
    val ageStartDate = year + "-01-01"

    val ageClDate = year+ "-12-31"

    val ageAndGenderFilterDf = membershipDf.filter((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",KpiConstants.months288).<=(ageClDate))
      &&(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",KpiConstants.months780).>(ageClDate))
      &&($"${KpiConstants.genderColName}".===(KpiConstants.femaleVal)))

    ageAndGenderFilterDf.coalesce(3)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/ageAndGenderFilterDf/")

    println("-------------------After ageAndGenderFilterDf-------------")
    ageAndGenderFilterDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()

    //</editor-fold>

    //<editor-fold desc="Continuous Enrollment, Allowable Gap Calculation">

    val ageAndGenderDf = spark.read.parquet(intermediateDir+ "/ageAndGenderFilterDf/").cache()

    val inputForContEnrolldf = ageAndGenderDf.filter(($"${KpiConstants.memStartDateColName}".<=(ageEndDate))
      && ($"${KpiConstants.memEndDateColName}".>=(ageEndDate)))

    inputForContEnrolldf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/inputForContEnrolldf/")

    val ipContEnroll = spark.read.parquet(intermediateDir+ "/inputForContEnrolldf/").cache()

    println("-------------------After ipContEnroll-------------")
    ipContEnroll.filter($"${KpiConstants.memberidColName}".===("102542")).show()


    //<editor-fold desc="Continuous Enrollment Calculation For Medicaid ">

    val ceMedDf = ipContEnroll.filter((($"${KpiConstants.lobColName}").===(KpiConstants.medicaidLobName)) ||
      (($"${KpiConstants.lobColName}").===(KpiConstants.mmdLobName)) )
      .select(KpiConstants.memberidColName).distinct()

    val contEnrollInMedDf = ceMedDf.select($"${KpiConstants.memberidColName}" as "df1_memberid")
      .as("df1").join(ageAndGenderDf.as("df2"),
      $"df1.df1_memberid" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select(KpiConstants.memberidColName, KpiConstants.benefitMedicalColname, KpiConstants.memStartDateColName,KpiConstants.memEndDateColName,
        KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName, KpiConstants.dateofbirthColName,KpiConstants.primaryPlanFlagColName)

    println("-------------------------contEnrollInMedDf----------------------------")
    contEnrollInMedDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()

    contEnrollInMedDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/contEnrollInMedDf/")


    val contEnrollMed = spark.read.parquet(intermediateDir+ "/contEnrollInMedDf/").cache()

    val mapForCeMed = mutable.Map("start_date" -> (year+"-01-01"), "end_date" -> (year+"-12-31"),"gapcount" -> "1", "checkval" -> "true",
      "reqCovDays"-> "0","anchor_date" -> (year+"-12-31"))

    val contEnrollMedDf = UtilFunctions.contEnrollAndAllowableGapFilterFunction(spark,contEnrollMed,mapForCeMed)
      .select(KpiConstants.memberidColName, KpiConstants.lobColName, KpiConstants.lobProductColName,
        KpiConstants.payerColName,KpiConstants.dateofbirthColName, KpiConstants.primaryPlanFlagColName)

    contEnrollMedDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/contEnrollMedDf/")

    contEnrollMedDf.select(KpiConstants.memberidColName).distinct().coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(intermediateDir+ "/contEnrollMedDf-CSV/")

    //</editor-fold>

    //<editor-fold desc="Continuous Enrollment Calculation For Commercial & Market Place ">

    val ceCommDf = ipContEnroll.filter((($"${KpiConstants.lobColName}").===(KpiConstants.commercialLobName))||
      (($"${KpiConstants.lobColName}").===(KpiConstants.marketplaceLobName))).select(KpiConstants.memberidColName).distinct()

    println("-------------------------CECommDf----------------------------")
    ceCommDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()

    val contEnrollInCommTmpDf = ceCommDf.select($"${KpiConstants.memberidColName}" as "df1_memberid")
      .as("df1").join(ageAndGenderDf.as("df2"),
      $"df1.df1_memberid" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      //$"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select(KpiConstants.memberidColName, KpiConstants.benefitMedicalColname, KpiConstants.memStartDateColName,KpiConstants.memEndDateColName,
        KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName, KpiConstants.dateofbirthColName,KpiConstants.primaryPlanFlagColName)

    println("-------------------------contEnrollInCommTmpDf----------------------------")
    contEnrollInCommTmpDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()

    contEnrollInCommTmpDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/contEnrollInCommTmpDf/")

    val contEnrollComm = spark.read.parquet(intermediateDir+ "/contEnrollInCommTmpDf/").cache()

    val mapForCeminus3y = mutable.Map("start_date" -> (year.toInt-2+ "-01-01"), "end_date" -> (year.toInt-2+ "-12-31"),"gapcount" -> "1",
      "reqCovDays"-> "0","checkval" -> "false")

    val ceOutminus3yDf = UtilFunctions.contEnrollAndAllowableGapFilterFunction(spark,contEnrollComm,mapForCeminus3y)

    println("----------------------------------ceOutminus3yDf-----------------------------")
    ceOutminus3yDf.show()

    ceOutminus3yDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite).parquet(intermediateDir+ "/ceOutminus3yDf/")


    val ceOut3y = spark.read.parquet(intermediateDir+ "/ceOutminus3yDf/").cache()

    val mapForCeminus2y = mutable.Map("start_date" -> (year.toInt-1+ "-01-01"), "end_date" -> (year.toInt-1+ "-12-31"),"gapcount" -> "1",
      "reqCovDays"-> "0","checkval" -> "false")

    val ceOutminus2yDf = UtilFunctions.contEnrollAndAllowableGapFilterFunction(spark,ceOut3y,mapForCeminus2y)

    ceOutminus2yDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite).parquet(intermediateDir+ "/ceOutminus2yDf/")


    val ceOut2y = spark.read.parquet(intermediateDir+ "/ceOutminus2yDf/").cache()

    val mapForCeminus1y = mutable.Map("start_date" -> (year+"-01-01"), "end_date" -> (year+"-12-31"),"gapcount" -> "1",
      "checkval" -> "true","reqCovDays"-> "0","anchor_date" -> (year+"-12-31"))

    val contEnrollInCommDf = UtilFunctions.contEnrollAndAllowableGapFilterFunction(spark,ceOut2y,mapForCeminus1y)
      .select(KpiConstants.memberidColName, KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName,
        KpiConstants.dateofbirthColName,KpiConstants.primaryPlanFlagColName)

    contEnrollInCommDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite).parquet(intermediateDir+ "/contEnrollInCommDf/")

    //</editor-fold>


    val contEnrollInComm = spark.read.parquet(intermediateDir+ "/contEnrollInCommDf/").cache()

    val contEnrollInMed = spark.read.parquet(intermediateDir+ "/contEnrollMedDf/").cache()


    val contEnrollDf = contEnrollInMed.union(contEnrollInComm)

    println("----------------------------------contEnrollDf-----------------------------")
    contEnrollDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()


    contEnrollDf.coalesce(2)
      .write
      .mode(SaveMode.Overwrite).parquet(intermediateDir+ "/contEnrollDf/")

    //</editor-fold>

    //<editor-fold desc="Dual Enrollment and AAP Lob filter">

    val conEnrDf = spark.read.parquet(intermediateDir+ "/contEnrollDf/").cache()

    val baseOutMedHosRemDf = UtilFunctions.baseOutDataframeCreation(spark, conEnrDf, lobList , measureId)

    /*Removing the SN payer members from the EPOP*/

    val snPayerList = List(KpiConstants.sn1PayerVal, KpiConstants.sn2PayerVal, KpiConstants.sn3PayerVal, KpiConstants.mmpPayerVal)
    val baseOutDf = baseOutMedHosRemDf.except(baseOutMedHosRemDf.filter($"${KpiConstants.payerColName}".isin(snPayerList:_*)))

    println("-------------------After baseOutDf-------------")
    baseOutDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()

    val ccsContEnrollDf = baseOutDf.filter($"${KpiConstants.lobColName}".isin(lobList:_*)).dropDuplicates().cache()
    ccsContEnrollDf.count()

   /* //Modified Code
    val medicareContEnrollDf = ccsContEnrollDf.filter($"${KpiConstants.lobColName}".===(KpiConstants.medicareLobName))

    println("-------------------After medicareContEnrollDf-------------")
    medicareContEnrollDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()

    val medMonDf = spark.read.parquet(stagingDir+ "/medmonmemDf/").cache()

    val medicareHospiceDf = medicareContEnrollDf.as("df1").join(medMonDf.as("df2"), Seq(KpiConstants.memberidColName))
      .groupBy(KpiConstants.memberidColName).agg(countDistinct(when($"hospice".===("Y"),1)).alias("count"))
      .filter($"count".>(0))
      .select(KpiConstants.memberidColName).rdd.map(r=> r.getString(0)).collect()

    println("-------------------After Medicare hospice-------------")
    //medicareHospiceDf.foreach(f=> println(f))

    val ccscontEnrollResDf = ccsContEnrollDf.except(ccsContEnrollDf.filter($"${KpiConstants.memberidColName}".isin(medicareHospiceDf:_*)))*/

    ccsContEnrollDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/ccsContEnrollDf/")

    println("-------------------After Dual Enrollment-------------")
    ccsContEnrollDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()

    //Ends here

    //</editor-fold>

    //<editor-fold desc="Initial Join with Ref_Hedis">

    val visDf = spark.read.parquet(stagingDir+ "/visitsDf/").cache()

    val refHedDf = spark.read.parquet(stagingDir+ "/refHedisDf/").cache()

    val argmapforRefHedis = mutable.Map(KpiConstants.eligibleDfName -> visDf , KpiConstants.refHedisTblName -> refHedDf)
    val allValueList = List(KpiConstants.independentLabVal, KpiConstants.hospiceVal,KpiConstants.cervicalCytologyVal,KpiConstants.hpvTestsVal,
      KpiConstants.absOfCervixVal)

    val medList = KpiConstants.emptyList
    val visitRefHedisDf = UtilFunctions.joinWithRefHedisFunction(spark,argmapforRefHedis,allValueList,medList)
     // .withColumn("age",datediff(lit(ageEndDate),$"${KpiConstants.dobColName}")/365.25)

    println("-------------------After visitRefHedisDf-------------")
    visitRefHedisDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()

    visitRefHedisDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/visitRefHedisDf/")

    //</editor-fold>

    //<editor-fold desc="Removal of Independent Lab Visits">

    val visRefHedDf = spark.read .parquet(intermediateDir+ "/visitRefHedisDf/").cache()

    val groupList = visDf.schema.fieldNames.toList.dropWhile(p=> p.equalsIgnoreCase(KpiConstants.memberidColName))

    val visitgroupedDf = visRefHedDf.groupBy(KpiConstants.memberidColName, groupList:_*).agg(collect_list(KpiConstants.valuesetColName).alias(KpiConstants.valuesetColName))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName, KpiConstants.admitDateColName, KpiConstants.dischargeDateColName,
        KpiConstants.dobColName,KpiConstants.supplflagColName, KpiConstants.ispcpColName,KpiConstants.isobgynColName, KpiConstants.valuesetColName,KpiConstants.genderColName)


    val indLabVisRemDf = visitgroupedDf.filter((!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      ||((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.cervicalCytologyVal)))
      ||((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.hpvTestsVal))))
      .repartition(2).cache()


    println("-------------------After indLabVisRemDf-------------")
    indLabVisRemDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()


    //</editor-fold>

    //<editor-fold desc="Hospice Removal">

    val conEnrResDf = spark.read .parquet(intermediateDir+ "/ccsContEnrollDf/").cache()

    val hospiceInCurrYearMemDf = indLabVisRemDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hospiceVal))
      &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate)
      && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)
      .dropDuplicates()
      .rdd
      .map(r=> r.getString(0))
      .collect()

    val df =  indLabVisRemDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hospiceVal))
      &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))


    val hospiceRemMemEnrollDf = conEnrResDf.except(conEnrResDf.filter($"${KpiConstants.memberidColName}".isin(hospiceInCurrYearMemDf:_*)))

    hospiceRemMemEnrollDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/hospiceRemMemEnrollDf/")

    val totalPopOutDf = hospiceRemMemEnrollDf.distinct()

    println("-------------------After totalPopOutDf-------------")
    totalPopOutDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()

    totalPopOutDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .parquet(intermediateDir+ "/totalPopOutDf/")

    //</editor-fold>

    //<editor-fold desc="EPOP Generation">

    val totPopDf = totalPopOutDf.withColumn(KpiConstants.ncqaOutMeasureCol,lit(measureId))

    val toutStrDf = totPopDf.select($"${KpiConstants.memberidColName}".alias(KpiConstants.ncqaOutmemberIdCol), $"${KpiConstants.ncqaOutMeasureCol}",
      $"${KpiConstants.payerColName}".alias(KpiConstants.ncqaOutPayerCol))
      .dropDuplicates()

    println("-------------------  toutStrDf -------------------")
    toutStrDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()


    toutStrDf.coalesce(4)
      .write
      .mode(SaveMode.Append)
      .parquet(intermediateDir+ "/tout")


    val eligiblePopDf = totalPopOutDf.select(KpiConstants.memberidColName).distinct().repartition(2).cache()
    eligiblePopDf.count()


    println("-------------------Selective Epop-------------------")
    eligiblePopDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()

    eligiblePopDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir+ "/Epop")

    //</editor-fold>

    //</editor-fold>

    //<editor-fold desc=" Numerator Calculation">

    //<editor-fold desc="Initial join function">

    val argmapForVisittJoin = mutable.Map(KpiConstants.membershipTblName -> totalPopOutDf , KpiConstants.visitTblName -> indLabVisRemDf)

    val visitJoinedDf = UtilFunctions.initialJoinFunction(spark,argmapForVisittJoin)
      //.withColumn("age",datediff(lit(ageEndDate),$"${KpiConstants.dobColName}")/365.25)

    println("------------------------visitJoinedOutDf----------------------------")
    visitJoinedDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()

    ccsContEnrollDf.unpersist()
    visitgroupedDf.unpersist()
    eligiblePopDf.unpersist()

    //</editor-fold>

    //<editor-fold desc="Temporary Numerator Calculation">

    //<editor-fold desc="Non Supplementry">

    val numNonSuppVisitsDf =  visitJoinedDf.filter($"${KpiConstants.supplflagColName}".===("N"))

    println("----------------------After numNonSuppVisitsDf-----------------------")
    numNonSuppVisitsDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()

    val numNonSuppMemDf = numNonSuppVisitsDf.select(KpiConstants.memberidColName)

    val cervnonSuppTmpNumDf = numNonSuppVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.cervicalCytologyVal))
      &&($"${KpiConstants.serviceDateColName}".>=(myMinus2StDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))
      &&((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}",KpiConstants.months288).<=(yearEndDate)))
      &&((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}",KpiConstants.months780).>(yearEndDate))))
      .select(KpiConstants.memberidColName)

    println("----------------------After cervnonSuppTmpNumDf-----------------------")
    cervnonSuppTmpNumDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()


    val numNonSuppExcCervDf = numNonSuppMemDf.except(cervnonSuppTmpNumDf)

    println("----------------------After numNonSuppExcCervDf-----------------------")
    numNonSuppExcCervDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()


    val numNonSuppDf1 = numNonSuppExcCervDf.as("df1").join(numNonSuppVisitsDf.as("df2"),
      //$"df1.df1_memberid" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select($"df2.*")
      .filter(((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}",KpiConstants.months360).<=(yearEndDate)))
        &&((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}",KpiConstants.months780).>(yearEndDate))))

    println("----------------------After numNonSuppDf1-----------------------")
    numNonSuppDf1.filter($"${KpiConstants.memberidColName}".===("102542")).show()


    val cervnonSuppTmpNumDf1 = numNonSuppDf1.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.cervicalCytologyVal))
      &&($"${KpiConstants.serviceDateColName}".>=(myminus4StDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))
      &&((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}",KpiConstants.months360).<=(($"${KpiConstants.serviceDateColName}")))))
      //.select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)

    println("----------------------After cervnonSuppTmpNumDf1-----------------------")
    cervnonSuppTmpNumDf1.filter($"${KpiConstants.memberidColName}".===("102542")).show()

    val hpvnonSuppTmpNumDf = numNonSuppDf1.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.hpvTestsVal))
      &&($"${KpiConstants.serviceDateColName}".>=(myminus4StDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))
      &&((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}",KpiConstants.months360).<=(($"${KpiConstants.serviceDateColName}")))))
      //.select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)

    println("----------------------After hpvnonSuppTmpNumDf-----------------------")
    hpvnonSuppTmpNumDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()

    val cervAndHPVnonSuppTmpNumDf = cervnonSuppTmpNumDf1.as("df1").join(hpvnonSuppTmpNumDf.as("df2"),
      Seq(KpiConstants.memberidColName), KpiConstants.innerJoinType)
      .filter(abs(datediff($"df1.${KpiConstants.serviceDateColName}", $"df2.${KpiConstants.serviceDateColName}")).<=(4))
      .select(s"df1.${KpiConstants.memberidColName}")

    println("----------------------After cervAndHPVnonSuppTmpNumDf-----------------------")
    cervAndHPVnonSuppTmpNumDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()

    val nonSuppTmpnumDf = cervnonSuppTmpNumDf.union(cervAndHPVnonSuppTmpNumDf)

    nonSuppTmpnumDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite).parquet(intermediateDir+ "/nonSuppTmpnumDf/")

    println("----------------------After nonSuppTmpnumDf-----------------------")
    nonSuppTmpnumDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()

    //</editor-fold>

    //<editor-fold desc="Other Data">

    val nonSuppTmpNumDf = spark.read.parquet(intermediateDir+ "/nonSuppTmpnumDf/").cache()

    val otherNumVisitsDf = visitJoinedDf.except(visitJoinedDf.filter($"${KpiConstants.memberidColName}".isin(nonSuppTmpNumDf.rdd.map(f=> f.getString(0)).collect():_*)))

    println("----------------------After otherNumVisitsDf-----------------------")
    otherNumVisitsDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()


    val otherNumVisitsMemDf = otherNumVisitsDf.select(KpiConstants.memberidColName)

    println("----------------------After otherNumVisitsMemDf-----------------------")
    otherNumVisitsMemDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()


  /*  val cervotherNumTmpNumDf = otherNumVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.cervicalCytologyVal))
      &&($"${KpiConstants.serviceDateColName}".>=(myMinus2StDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))
      &&((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}",KpiConstants.months288).<=(yearEndDate)))
      &&((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}",KpiConstants.months780).>(yearEndDate))))
      .select(KpiConstants.memberidColName)
    */

//--------------------
    val cervdf1 = otherNumVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.cervicalCytologyVal)))

    println("----------------------After cervdf1-----------------------")
    cervdf1.filter($"${KpiConstants.memberidColName}".===("102542")).show()

    val cervdf2 = cervdf1.filter(($"${KpiConstants.serviceDateColName}".>=(myMinus2StDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))

    println("----------------------After cervdf2-----------------------")
    cervdf2.filter($"${KpiConstants.memberidColName}".===("102542")).show()

    val cervotherNumTmpNumDf = cervdf2.filter((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}",KpiConstants.months288).<=(yearEndDate))
      &&(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}",KpiConstants.months780).>(yearEndDate)))
      .select(KpiConstants.memberidColName)

    //-----------------

    println("----------------------After cervotherNumTmpNumDf-----------------------")
    cervotherNumTmpNumDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()

    val otherNumVisitsExcCervDf = otherNumVisitsMemDf.except(cervotherNumTmpNumDf)

    println("----------------------After otherNumVisitsExcCervDf-----------------------")
    otherNumVisitsExcCervDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()

    val numotherNumVisitsDf1 = otherNumVisitsExcCervDf.as("df1").join(otherNumVisitsDf.as("df2"),
      //$"df1.df1_memberid" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select($"df2.*")
      .filter(((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}",KpiConstants.months360).<=(yearEndDate)))
        &&((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}",KpiConstants.months780).>(yearEndDate))))

    println("----------------------After numotherNumVisitsDf1-----------------------")
    numotherNumVisitsDf1.filter($"${KpiConstants.memberidColName}".===("102542")).show()

    val cervotherNumVisitsTmpNumDf1 = numotherNumVisitsDf1.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.cervicalCytologyVal))
      &&($"${KpiConstants.serviceDateColName}".>=(myminus4StDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))
      &&((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}",KpiConstants.months360).<=(($"${KpiConstants.serviceDateColName}")))))

    val hpvotherNumVisitsTmpNumDf = numotherNumVisitsDf1.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.hpvTestsVal))
      &&($"${KpiConstants.serviceDateColName}".>=(myminus4StDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))
      &&((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}",KpiConstants.months360).<=(($"${KpiConstants.serviceDateColName}")))))

    val cervAndHPVotherNumVisitsTmpNumDf = cervotherNumVisitsTmpNumDf1.as("df1").join(hpvotherNumVisitsTmpNumDf.as("df2"),
      $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .filter(abs(datediff($"df1.${KpiConstants.serviceDateColName}", $"df2.${KpiConstants.serviceDateColName}")).===(0))
      .select(s"df1.${KpiConstants.memberidColName}")

    println("----------------------After cervotherNumVisitsTmpNumDf1-----------------------")
    cervotherNumVisitsTmpNumDf1.filter($"${KpiConstants.memberidColName}".===("102542")).show()


    println("----------------------After hpvotherNumVisitsTmpNumDf-----------------------")
    hpvotherNumVisitsTmpNumDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()


    println("----------------------After cervAndHPVotherNumVisitsTmpNumDf-----------------------")
    cervAndHPVotherNumVisitsTmpNumDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()

    val otherNumTempDf = cervotherNumTmpNumDf.union(cervAndHPVotherNumVisitsTmpNumDf)

    otherNumTempDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite).parquet(intermediateDir+ "/otherNumTempDf/")

    println("----------------------After otherNumTempDf-----------------------")
    otherNumTempDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()

    //</editor-fold>

    val otherNumTmpDf = spark.read.parquet(intermediateDir+ "/otherNumTempDf/").cache()

    val numTmpDf = nonSuppTmpNumDf.union(otherNumTmpDf)

    numTmpDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir + "/numTmpDf/")

    println("----------------------After numTmpDf-----------------------")
    numTmpDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()

    //</editor-fold>

    //<editor-fold desc="Optional Exclusion Calculation">

    val optionalExclVisistsDf = visitJoinedDf.except(visitJoinedDf.filter($"${KpiConstants.memberidColName}".isin(numTmpDf.rdd.map(f=> f.getString(0)).collect():_*)))
      .repartition(2).cache()

    optionalExclVisistsDf.count()

    println("----------------------After optionalExclVisistsDf-----------------------")
    optionalExclVisistsDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()

    //<editor-fold desc="Optional Exclusion Non supplement Calculation">

    val optExclNonSupVisDf =  optionalExclVisistsDf.filter($"${KpiConstants.supplflagColName}".===("N")).cache()
    optExclNonSupVisDf.count()

    val nonSupOptExclDf = optExclNonSupVisDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.absOfCervixVal)
      && (!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
     // &&($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.dobColName}"))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)

    //</editor-fold>

    //<editor-fold desc="Optional Exclusion Other Calculation">

    val optExclOtherVisDf =  optionalExclVisistsDf.except(optionalExclVisistsDf.filter($"${KpiConstants.memberidColName}".isin(nonSupOptExclDf.rdd.map(f => f.getString(0)).collect():_*)))
    optExclOtherVisDf.count()

    val otherOptExclDf = optExclOtherVisDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.absOfCervixVal)
      && (!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
      // &&($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.dobColName}"))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)
    //</editor-fold>

    val optinalExclDf = nonSupOptExclDf.union(otherOptExclDf)

    println("----------------------After otherOptExclDf-----------------------")
    otherOptExclDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()

    println("----------------------After nonSupOptExclDf-----------------------")
    nonSupOptExclDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()

    println("----------------------After optinalExclDf-----------------------")
    optinalExclDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()

    //</editor-fold>

    val numeratorDf = numTmpDf.except(optinalExclDf)

    numeratorDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir+ "/numerator")

    println("----------------------After numeratorDf-----------------------")
    numeratorDf.filter($"${KpiConstants.memberidColName}".===("102542")).show()

    //<editor-fold desc="Ncqa Output Creation">

    val outMap = mutable.Map(KpiConstants.totalPopDfName -> toutStrDf, KpiConstants.eligibleDfName -> eligiblePopDf,
      KpiConstants.mandatoryExclDfname -> spark.emptyDataFrame, KpiConstants.optionalExclDfName -> optinalExclDf,
      KpiConstants.numeratorDfName -> numeratorDf)


    val outDf = UtilFunctions.ncqaOutputDfCreation(spark,outMap,measureId)

    outDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir+ "/outDf")


    //</editor-fold>

    spark.sparkContext.stop()

    //</editor-fold>

  }
}

