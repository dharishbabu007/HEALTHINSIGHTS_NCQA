package main.scala.com.itc.ncqa.main

import main.scala.com.itc.ncqa.Constants.KpiConstants
import main.scala.com.itc.ncqa.Functions.DataLoadFunctions
import main.scala.com.itc.ncqa.Functions.UtilFunctions
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.{add_months, to_date}
import main.scala.com.itc.ncqa.Functions._
import org.apache.spark.SparkConf
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.log4j.{Level, Logger}

import scala.collection.mutable

object NcqaLSC {

  def main(args: Array[String]): Unit = {

    //<editor-fold desc="Reading program arguments and Spark Session object creation">

    val year = "2018"
    val measureId = "LSC"

    System.setProperty("hadoop.home.dir", "D:\\WinUtil")

    val conf = new SparkConf().setAppName("NcqaProgram")
    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    conf.set("spark.sql.shuffle.partitions", "10")
    //.set("hive.exec.dynamic.partition.mode", "nonstrict")

    val spark = SparkSession.builder().config(conf).master("local").getOrCreate()

    val rootLogger = Logger.getRootLogger()
    rootLogger.setLevel(Level.ERROR)

    //</editor-fold>

    //<editor-fold desc="Loading Required Tables to memory">

    import spark.implicits._

    val lobList = List( KpiConstants.medicaidLobName)
    //val membershipDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\LSC\\MEMBERSHIP_ENROLLMENT.csv")

    val membershipDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\LSC\\Test\\MEMBERSHIP_ENROLLMENT.csv")
      .filter(($"${KpiConstants.considerationsColName}".===(KpiConstants.yesVal))
        && ($"${KpiConstants.memStartDateColName}".isNotNull)
        && ($"${KpiConstants.memEndDateColName}".isNotNull))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .withColumn(KpiConstants.memStartDateColName, to_date($"${KpiConstants.memStartDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.memEndDateColName, to_date($"${KpiConstants.memEndDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.dateofbirthColName, to_date($"${KpiConstants.dateofbirthColName}", KpiConstants.dateFormatString))
      .repartition(2)

    println("----------------membershipDf-------------------")
   // membershipDf.show()

    val claimStatusList = List(KpiConstants.paidVal, KpiConstants.suspendedVal, KpiConstants.pendingVal, KpiConstants.deniedVal)

   // val visitsDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\LSC\\VISITS.csv")

    val visitsDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\LSC\\Test\\VISITS.csv")
      .filter(($"${KpiConstants.serviceDateColName}".isNotNull)
        && (($"${KpiConstants.admitDateColName}".isNotNull && $"${KpiConstants.dischargeDateColName}".isNotNull)
        || ($"${KpiConstants.admitDateColName}".isNull && $"${KpiConstants.dischargeDateColName}".isNull))
        &&((($"${KpiConstants.dataSourceColName}".===("Claim"))&&($"${KpiConstants.claimstatusColName}".isin(claimStatusList:_*)))
        || (($"${KpiConstants.dataSourceColName}".===("RxClaim"))&&($"${KpiConstants.claimstatusColName}".isin(claimStatusList:_*)))
        || ($"${KpiConstants.dataSourceColName}".===("Rx"))
        || ($"${KpiConstants.dataSourceColName}".===("Lab"))))
      .drop(KpiConstants.lobProductColName, "latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name","product")
      .withColumn(KpiConstants.dobColName, to_date($"${KpiConstants.dobColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.serviceDateColName, to_date($"${KpiConstants.serviceDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.admitDateColName, when($"${KpiConstants.admitDateColName}".isNotNull,to_date($"${KpiConstants.admitDateColName}",  KpiConstants.dateFormatString)))
      .withColumn(KpiConstants.dischargeDateColName, when($"${KpiConstants.dischargeDateColName}".isNotNull,to_date($"${KpiConstants.dischargeDateColName}",  KpiConstants.dateFormatString)))
      .withColumn(KpiConstants.medstartdateColName, when($"${KpiConstants.medstartdateColName}".isNotNull,to_date($"${KpiConstants.medstartdateColName}",  KpiConstants.dateFormatString)))
      .withColumn(KpiConstants.revenuecodeColName, when((length($"${KpiConstants.revenuecodeColName}").as[Int].===(3)),concat(lit("0" ),lit($"${KpiConstants.revenuecodeColName}"))).otherwise($"${KpiConstants.revenuecodeColName}"))
      .withColumn(KpiConstants.billtypecodeColName, when((length($"${KpiConstants.billtypecodeColName}").as[Int].===(3)),concat(lit("0" ),lit($"${KpiConstants.billtypecodeColName}"))).otherwise($"${KpiConstants.billtypecodeColName}"))
      .withColumn(KpiConstants.proccode2ColName, when(($"${KpiConstants.proccode2mod1ColName}".isin(KpiConstants.avoidCodeList:_*)) || ($"${KpiConstants.proccode2mod2ColName}".isin(KpiConstants.avoidCodeList:_*)),lit("NA")).otherwise($"${KpiConstants.proccode2ColName}"))
      .repartition(2)


   //visitsDf.show()


    val refHedisDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\LSC\\REF_HEDIS2019.csv")
      .filter(($"${KpiConstants.measureIdColName}".===(KpiConstants.lscMeasureId)) || ($"${KpiConstants.measureIdColName}".===(KpiConstants.ggMeasureId)))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .repartition(2)

    println("----------------refHedisDf-------------------")
   // refHedisDf.show()

    //</editor-fold>

    //<editor-fold desc="Age Filter">

    val ageEndDate = year + "-12-31"
    val ageStartDate = year + "-01-01"

    /* The 2nd birthday should fall on in the membership enrollment period i.e. 01 Jan 2018 (ageStartDate) <= 2nd birthday <= 31st December 2018(ageEndDate).*/
    val ageFilterDf = membershipDf.filter((UtilFunctions.add_ncqa_months(spark, $"${KpiConstants.dateofbirthColName}", 24).>=(ageStartDate))
      && ((UtilFunctions.add_ncqa_months(spark, $"${KpiConstants.dateofbirthColName}", 24)).<=(ageEndDate)))

    println("-----------------------ageFilterDf---------------------")
    ageFilterDf.show()

    ageFilterDf.filter($"${KpiConstants.memberidColName}".===("96287")).show()

    //</editor-fold>

    //<editor-fold desc="Continuous Enrollment, Allowable Gap and Benefit">

    val inputForContEnrolldf = ageFilterDf.select(KpiConstants.memberidColName, KpiConstants.benefitMedicalColname,
      KpiConstants.memStartDateColName,KpiConstants.memEndDateColName,
      KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName, KpiConstants.dateofbirthColName,KpiConstants.primaryPlanFlagColName)

    /* Benefit = Medical */
    val benNonMedRemDf = inputForContEnrolldf.filter($"${KpiConstants.benefitMedicalColname}".===(KpiConstants.yesVal))

    /* The continous enrollment period should start from 12 months prior to the member’s 2nd birthday to the member’s 2nd birthday */
    val contEnrollInDf = benNonMedRemDf.withColumn(KpiConstants.contenrollLowCoName,UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}", 12))
      .withColumn(KpiConstants.contenrollUppCoName,UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}", 24))
      .withColumn(KpiConstants.anchorDateColName, UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}", 24))


    val contEnrollStep1Df = contEnrollInDf.filter((($"${KpiConstants.memStartDateColName}".>=($"${KpiConstants.contenrollLowCoName}")) && ($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.contenrollUppCoName}")))
      || (($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.contenrollLowCoName}")) && ($"${KpiConstants.memEndDateColName}".<=($"${KpiConstants.contenrollUppCoName}")))
      ||($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.contenrollLowCoName}") && ($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.contenrollUppCoName}"))))
      .withColumn(KpiConstants.anchorflagColName, when( ($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.anchorDateColName}"))
        && ($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.anchorDateColName}")), lit(1)).otherwise(lit(0)))
      .withColumn(KpiConstants.contEdFlagColName, when( ($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.contenrollUppCoName}"))
        && ($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.contenrollUppCoName}")), lit(1)).otherwise(lit(0)))

    println("----------------contEnrollStep1Df--------------------")
    contEnrollStep1Df.filter($"${KpiConstants.memberidColName}".===("96287")).show()

    /*Step3(select the members who satisfy both (min_start_date- ces and cee- max_end_date <= allowable gap) conditions)*/
    val listDf = contEnrollStep1Df.groupBy($"${KpiConstants.memberidColName}")
      .agg(max($"${KpiConstants.memEndDateColName}").alias(KpiConstants.maxMemEndDateColName),
        min($"${KpiConstants.memStartDateColName}").alias(KpiConstants.minMemStDateColName),
        first($"${KpiConstants.contenrollLowCoName}").alias(KpiConstants.contenrollLowCoName),
        first($"${KpiConstants.contenrollUppCoName}").alias(KpiConstants.contenrollUppCoName),
        sum($"${KpiConstants.anchorflagColName}").alias(KpiConstants.anchorflagColName))
      .filter((date_add($"max_mem_end_date",KpiConstants.days45).>=($"${KpiConstants.contenrollUppCoName}"))
        && (date_sub($"min_mem_start_date",KpiConstants.days45).<=($"${KpiConstants.contenrollLowCoName}"))
        &&($"${KpiConstants.anchorflagColName}").>(0))
      .select($"${KpiConstants.memberidColName}")

    val contEnrollStep2Df = contEnrollStep1Df.as("df1").join(listDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select("df1.*")

    /*window function creation based on partioned by member_sk and order by mem_start_date*/
    val contWindowVal = Window.partitionBy(s"${KpiConstants.memberidColName}").orderBy(org.apache.spark.sql.functions.col(s"${KpiConstants.memEndDateColName}").desc,org.apache.spark.sql.functions.col(s"${KpiConstants.memStartDateColName}"))


    /* added 3 columns (date_diff(datediff b/w next start_date and current end_date for each memeber),
     anchorflag(if member is continuously enrolled on anchor date 1, otherwise 0)
     count(if date_diff>1 1, otherwise 0) over window*/
    val contEnrollStep3Df = contEnrollStep2Df.withColumn(KpiConstants.overlapFlagColName, when(($"${KpiConstants.memStartDateColName}".>=(lag($"${KpiConstants.memStartDateColName}",1).over(contWindowVal)) && $"${KpiConstants.memStartDateColName}".<=(lag($"${KpiConstants.memEndDateColName}",1).over(contWindowVal))
      && ($"${KpiConstants.memEndDateColName}".>=(lag($"${KpiConstants.memStartDateColName}",1).over(contWindowVal)) && $"${KpiConstants.memEndDateColName}".<=(lag($"${KpiConstants.memEndDateColName}",1).over(contWindowVal))))
      ,lit(1))
      .when(($"${KpiConstants.memStartDateColName}".<(lag($"${KpiConstants.memStartDateColName}",1).over(contWindowVal)))
        && ($"${KpiConstants.memEndDateColName}".>=(lag($"${KpiConstants.memStartDateColName}",1 ).over(contWindowVal)) && $"${KpiConstants.memEndDateColName}".<=(lag($"${KpiConstants.memEndDateColName}",1).over(contWindowVal)))
        ,lit(2)).otherwise(lit(0)))

      .withColumn(KpiConstants.coverageDaysColName,when($"${KpiConstants.overlapFlagColName}".===(0) ,datediff(when($"${KpiConstants.memEndDateColName}".<=($"${KpiConstants.contenrollUppCoName}"), $"${KpiConstants.memEndDateColName}").otherwise($"${KpiConstants.contenrollUppCoName}")
        ,when($"${KpiConstants.memStartDateColName}".>=($"${KpiConstants.contenrollLowCoName}"), $"${KpiConstants.memStartDateColName}").otherwise($"${KpiConstants.contenrollLowCoName}"))+ 1 )
        .when($"${KpiConstants.overlapFlagColName}".===(2), datediff( when($"${KpiConstants.contenrollLowCoName}".>=(lag( $"${KpiConstants.memStartDateColName}",1).over(contWindowVal)), $"${KpiConstants.contenrollLowCoName}").otherwise(lag( $"${KpiConstants.memStartDateColName}",1).over(contWindowVal))
          ,$"${KpiConstants.memStartDateColName}")+1 )
        .otherwise(0))

      .withColumn(KpiConstants.countColName, when(when($"${KpiConstants.overlapFlagColName}".===(0), datediff(lag($"${KpiConstants.memStartDateColName}",1).over(contWindowVal), $"${KpiConstants.memEndDateColName}"))
        .otherwise(0).>(1),lit(1))
        .otherwise(lit(0)) )

    val contEnrollStep5Df = contEnrollStep3Df.groupBy(KpiConstants.memberidColName)
      .agg(min($"${KpiConstants.memStartDateColName}").alias(KpiConstants.minMemStDateColName),
        max($"${KpiConstants.memEndDateColName}").alias(KpiConstants.maxMemEndDateColName),
        sum($"${KpiConstants.countColName}").alias(KpiConstants.countColName),
        sum($"${KpiConstants.coverageDaysColName}").alias(KpiConstants.coverageDaysColName),
        first($"${KpiConstants.contenrollLowCoName}").alias(KpiConstants.contenrollLowCoName),
        first($"${KpiConstants.contenrollUppCoName}").alias(KpiConstants.contenrollUppCoName))

    println("----------------contEnrollStep5Df--------------------")
    contEnrollStep5Df.filter($"${KpiConstants.memberidColName}".===("96287")).show()
    val contEnrollmemDf = contEnrollStep5Df.filter(((($"${KpiConstants.countColName}") + (when(date_sub($"min_mem_start_date", 1).>=($"${KpiConstants.contenrollLowCoName}"),lit(1)).otherwise(lit(0)))
      + (when(date_add($"max_mem_end_date", 1).<=($"${KpiConstants.contenrollUppCoName}"),lit(1)).otherwise(lit(0)))).<=(1) )
      && ($"${KpiConstants.coverageDaysColName}".>=(320)))
      .select(KpiConstants.memberidColName).distinct()
    println("----------------contEnrollmemDf--------------------")
    contEnrollmemDf.filter($"${KpiConstants.memberidColName}".===("96287")).show()

    val contEnrollDf = contEnrollStep1Df.as("df1").join(contEnrollmemDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .filter($"df1.${KpiConstants.contEdFlagColName}".===(1))
      .select(s"df1.${KpiConstants.memberidColName}", s"df1.${KpiConstants.lobColName}", s"df1.${KpiConstants.lobProductColName}",s"df1.${KpiConstants.payerColName}",s"df1.${KpiConstants.primaryPlanFlagColName}").cache()

    println("----------------contEnrollDf--------------------")
    contEnrollDf.show()

    contEnrollDf.filter($"${KpiConstants.memberidColName}".===("96287")).show()

    //</editor-fold>

    //<editor-fold desc="Dual eligibility,Dual enrollment, AWC enrollment filter">

    val baseOutDf = UtilFunctions.baseOutDataframeCreation(spark, contEnrollDf, lobList,measureId)

    val lscContEnrollDf = baseOutDf.filter($"${KpiConstants.lobColName}".isin(lobList:_*)).dropDuplicates().cache()

    lscContEnrollDf.count()

    lscContEnrollDf.select(KpiConstants.memberidColName).distinct().coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("/home/hbase/ncqa/lsc/lscContEnrollDf/")

    //</editor-fold>

    //<editor-fold desc="Eligible Population Calculation">

    //<editor-fold desc="Initial Join with Ref_Hedis">

    val argmapforRefHedis = mutable.Map(KpiConstants.eligibleDfName -> visitsDf , KpiConstants.refHedisTblName -> refHedisDf)
    val allValueList = List(KpiConstants.independentLabVal, KpiConstants.hospiceVal,KpiConstants.leadTestVal)


    val medList = KpiConstants.emptyList
    val visitRefHedisDf = UtilFunctions.joinWithRefHedisFunction(spark,argmapforRefHedis,allValueList,medList)

    println("visitRefHedisDf")
    visitRefHedisDf.filter($"${KpiConstants.memberidColName}".===("96287")).show()

    //visitRefHedisDf.show()

    //</editor-fold>

    //<editor-fold desc="Removal of Independent Lab Visits">

    val groupList = visitsDf.schema.fieldNames.toList.dropWhile(p=> p.equalsIgnoreCase(KpiConstants.memberidColName))
    val visitgroupedDf = visitRefHedisDf.groupBy(KpiConstants.memberidColName, groupList:_*).agg(collect_list(KpiConstants.valuesetColName).alias(KpiConstants.valuesetColName))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName, KpiConstants.admitDateColName, KpiConstants.dischargeDateColName,
        KpiConstants.dobColName,KpiConstants.supplflagColName, KpiConstants.ispcpColName,KpiConstants.isobgynColName, KpiConstants.valuesetColName)


    val indLabVisRemDf = visitgroupedDf.filter((!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
                                            ||((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
                                              &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.leadTestVal))))
                                      .repartition(2).cache()

    indLabVisRemDf.count()
    println("indLabVisRemDf")
    //indLabVisRemDf.show()

    indLabVisRemDf.filter($"${KpiConstants.memberidColName}".===("96287")).show()

    //</editor-fold>

    //<editor-fold desc="Hospice Removal">

    val yearStartDate = year+"-01-01"
    val yearEndDate = year+"-12-31"

    val hospiceInCurrYearMemDf = indLabVisRemDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hospiceVal))
                                                     &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
                                                     &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
                                              .select(KpiConstants.memberidColName)
                                              .dropDuplicates()

   // hospiceInCurrYearMemDf.filter($"${KpiConstants.memberidColName}".===("96287")).show()

    hospiceInCurrYearMemDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("/home/hbase/ncqa/lsc/hospiceInCurrYearMemDf/")

    //</editor-fold>

    val totalPopmemidDf = lscContEnrollDf.select(KpiConstants.memberidColName).except(hospiceInCurrYearMemDf).distinct()
      .rdd
      .map(r=> r.getString(0))
      .collect()


    val totalPopOutDf = lscContEnrollDf.filter($"${KpiConstants.memberidColName}".isin(totalPopmemidDf:_*))
      .select(KpiConstants.memberidColName,KpiConstants.lobColName, KpiConstants.payerColName).dropDuplicates()


    val toutStrDf =totalPopOutDf.select($"${KpiConstants.memberidColName}",$"${KpiConstants.memberidColName}".as(KpiConstants.ncqaOutmemberIdCol),$"${KpiConstants.payerColName}".as(KpiConstants.ncqaOutPayerCol))
      .withColumn(KpiConstants.ncqaOutMeasureCol,lit(measureId))


    toutStrDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .parquet("/home/hbase/ncqa/lsc/tout")

    val eligiblePopDf = totalPopOutDf.select(KpiConstants.memberidColName).distinct().repartition(2).cache()
    eligiblePopDf.count()

    eligiblePopDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .parquet("/home/hbase/ncqa/lsc/epop")

    println("-------------------Selective Epop-------------------")
    eligiblePopDf.filter($"${KpiConstants.memberidColName}".===("102211")).show()


    //</editor-fold>

    //<editor-fold desc="Denominator calculation">

    val denominatorDf = eligiblePopDf.distinct()

    denominatorDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("/home/hbase/ncqa/lsc/denominator")

    denominatorDf.show()

    //</editor-fold>

    //<editor-fold desc="Initial join function">

    val argmapForVisittJoin = mutable.Map(KpiConstants.membershipTblName -> denominatorDf , KpiConstants.visitTblName -> indLabVisRemDf)
    val visitJoinedOutDf = UtilFunctions.initialJoinFunction(spark,argmapForVisittJoin)
    visitJoinedOutDf.count()

    visitJoinedOutDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .parquet("/home/hbase/ncqa/lsc/initialJoin")


    lscContEnrollDf.unpersist()
    visitgroupedDf.unpersist()
    eligiblePopDf.unpersist()
    denominatorDf.unpersist()

    println("------------------visitJoinedOutDf---------------")
    visitJoinedOutDf.filter($"${KpiConstants.memberidColName}".===("102211")).show()

    //</editor-fold>

    //<editor-fold desc="LSC Numerator Calculation">

    //val serviceDateFilter = UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}", 24)

    val visitJoinedDf = spark.read.parquet("/home/hbase/ncqa/lsc/initialJoin").repartition(2).cache()

    println("------------------visitJoinedDf---------------")
    visitJoinedDf.filter($"${KpiConstants.memberidColName}".===("102211")).show()

    visitJoinedDf.count()

    //<editor-fold desc="LSC Non Supp Numerator Calculation">

    val visitNonSuppDf = visitJoinedDf.filter($"${KpiConstants.supplflagColName}".===("N")).cache()
    visitNonSuppDf.count()

    println("--------------------visitNonSuppDf--------------------")
    visitNonSuppDf.filter($"${KpiConstants.memberidColName}".===("102211")).show()

    val toutDf = spark.read.parquet("/home/hbase/ncqa/lsc/tout")
    val denominatorPopDf = toutDf.select(KpiConstants.memberidColName).distinct().cache()

    //denominatorPopDf.show()

    val lscMenNonSuppDf = visitNonSuppDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.leadTestVal))
      && ($"${KpiConstants.serviceDateColName}".>=(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}", 0)))
      && ($"${KpiConstants.serviceDateColName}".<=(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}", 24))))
      .select(s"${KpiConstants.memberidColName}")

     /* println("--------------------lscMenNonSuppDf--------------------")
      lscMenNonSuppDf.show()*/

    //</editor-fold>

    //<editor-fold desc="LSC Other Mem Numerator Calculation">

    val visitForMenOtherDf = visitJoinedDf.except(visitJoinedDf.filter($"${KpiConstants.memberidColName}".isin(lscMenNonSuppDf.rdd.map(r=>r.getString(0)).collect():_*)))

    val lscNumotherDf = visitForMenOtherDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.leadTestVal))
      && ($"${KpiConstants.serviceDateColName}".>=(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}", 0)))
      && ($"${KpiConstants.serviceDateColName}".<=(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}", 24))))
      .select(s"${KpiConstants.memberidColName}")

    println("--------------------lscNumotherDf--------------------")
    lscNumotherDf.filter($"${KpiConstants.memberidColName}".===("102211")).show()

    //</editor-fold>

    val lscNumDf = lscMenNonSuppDf.union(lscNumotherDf).dropDuplicates()

    println("--------------------lscNumDf--------------------")
    lscNumDf.filter($"${KpiConstants.memberidColName}".===("102211")).show()
    //lscNumDf.show()

    lscNumDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("/home/hbase/ncqa/lsc/LSCNumDf")


    val outMap = mutable.Map(KpiConstants.totalPopDfName -> toutStrDf, KpiConstants.eligibleDfName -> denominatorPopDf,
      KpiConstants.mandatoryExclDfname -> spark.emptyDataFrame, KpiConstants.optionalExclDfName -> spark.emptyDataFrame,
      KpiConstants.numeratorDfName -> lscNumDf )


    val outDf = UtilFunctions.ncqaOutputDfCreation(spark,outMap,measureId)
    outDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("/home/hbase/ncqa/lsc/outDf")

    //outDf.select()

    //</editor-fold>

    spark.sparkContext.stop()

  }
}
