package com.itc.ncqa.Functions

import com.itc.ncqa.Constants.KpiConstants
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

object DataLoadFunctions {


  /**
    *
    * @param spark (SparkSession Object)
    * @param dbName (database name)
    * @param tblName (table name)
    * @param sourceName (source name which get from the program argument)
    * @return dataframe that laods the data which has the source name that we have passed from the coreesponding hive table.
    * @usecase Function is used to laod the dim and afact tables from the targeted Hive table
    */
  def dataLoadFromTargetModel(spark:SparkSession,dbName:String,tblName:String,sourceName:String):DataFrame ={

    val source_name = "'"+sourceName+"'"
    val query = "select * from "+ dbName+"."+ tblName/*+" where source_name ="+source_name*/
    val df_init = spark.sql(query)
    // val dfColumns = df_init.columns.map(f => f.toUpperCase)
    //println("dfColumns(0) value is:"+dfColumns(0))
    //val resultDf = UtilFunctions.removeHeaderFromDf(df_init, dfColumns, dfColumns(0))
    //println("resultDf count is:"+df_init.count()+","+ resultDf.count())
    df_init
  }



  def dataLoadFromHive(spark:SparkSession,dbName:String,tblName:String,colName:String):DataFrame ={

    import spark.implicits._

    val query = "select * from "+ dbName+"."+ tblName
    val df_init = spark.sql(query)
    val windowcreate = Window.partitionBy(s"$colName").orderBy(org.apache.spark.sql.functions.col(s"${KpiConstants.ingestiondateColName}").desc)
    val dfrankaddedDf = df_init.withColumn(KpiConstants.rankColName, rank().over(windowcreate))
    val resultDf = dfrankaddedDf.filter(($"${KpiConstants.activeflasgColname}".===("A"))
      && ($"${KpiConstants.latestflagColName}".===("Y"))
      && ($"${KpiConstants.rankColName}".===(1)))
    resultDf
  }


  /**
    *
    * @param spark
    * @param dbName
    * @param tblName
    * @return
    */
  def dataLoadFromHiveStageTable(spark:SparkSession,dbName:String,tblName:String,measureId:String,colNames:List[String]):DataFrame ={

    // val querypart=
    /* val colsStringVal = colNames.mkString(",")
     val msrVal = "'"+measureId+"'"
     val query = "select * from "+ dbName+"."+ tblName+s" where measure ="+msrVal*/
    val resultDf = spark.sql(measureId)
    resultDf
  }




  /**
    *
    * @param spark (SparkSession Object)
    * @param dbName (database name)
    * @param tblName (Table name)
    * @return Datfarme that conatins the data from thae corresponding Hive table
    * @usecase Function is used to load the ref tables.
    */
  def referDataLoadFromTragetModel(spark:SparkSession,dbName:String,tblName:String):DataFrame ={

    val query = "select * from "+ dbName+"."+ tblName
    val df_init = spark.sql(query)
    val dfColumns = df_init.columns.map(f => f.toUpperCase)
    val resultDf = UtilFunctions.removeHeaderFromDf(df_init, dfColumns, dfColumns(0))
    resultDf
  }


  /**
    *
    * @param spark (SparkSession Object)
    * @return dataframe that contains the date_sk and calender_date
    * @usecase This function is used to load the date_sk and calender_date from the dim_date table.
    */
  def dimDateLoadFunction(spark:SparkSession):DataFrame ={
    val sqlQuery = "select date_sk, calendar_date from "+KpiConstants.dbName+"."+KpiConstants.dimDateTblName
    val dimDateDf = spark.sql(sqlQuery)
    dimDateDf
  }


  /**
    *
    * @param spark (SparkSession Object)
    * @param measureTitle (Measure title which get from the program argument)
    * @return Dataframe that contains the quality_measure_sk for the measure title
    * @usecase This functio ius used to find the quality_measure_sk for the measure title that passed as argument
    */
  def dimqualityMeasureLoadFunction(spark:SparkSession,measureTitle:String):DataFrame ={

    val measure_title = "'"+measureTitle+"'"
    val query = "select quality_measure_sk,quality_program_sk from "+ KpiConstants.dbName+"."+ KpiConstants.dimQltyMsrTblName+" where measure_title ="+measure_title
    val dimQualityMsrDf = spark.sql(query)
    dimQualityMsrDf
  }

  /**
    *
    * @param spark
    * @param programName
    * @return
    */
  def dimqualityProgramLoadFunction(spark:SparkSession,programName:String):DataFrame ={

    val program_name = "'%"+programName+"%'"
    val query = "select quality_program_sk from "+ KpiConstants.dbName+"."+ KpiConstants.dimQltyPgmTblName+" where program_name like"+program_name
    val dimQualityMsrDf = spark.sql(query)
    dimQualityMsrDf
  }

  /**
    *
    * @param spark (SparkSession Object)
    * @param viewName (view name that has to call)
    * @return dataframe that contains the view data
    * @usecase This function is used to call the view name and loads the view data to dataframe
    */
  def viewLoadFunction(spark:SparkSession,viewName:String):DataFrame = {

    val newDf = viewName match {
      case KpiConstants.view45Days => spark.sql("select * from "+KpiConstants.dbName+"."+KpiConstants.view45Days)
      case KpiConstants.view60Days => spark.sql("select * from "+KpiConstants.dbName+"."+KpiConstants.view60Days)
    }
    newDf
  }

  def readdatafromlocal(spark:SparkSession,measureId:String,year:String) = {

    val Local_root_path="D:\\NCQA\\Test_data"
    val claimStatusList = List(KpiConstants.paidVal, KpiConstants.suspendedVal, KpiConstants.pendingVal, KpiConstants.deniedVal)
    val lobList = List(KpiConstants.commercialLobName, KpiConstants.medicaidLobName, KpiConstants.marketplaceLobName)
    val colList = List(KpiConstants.memberidColName, KpiConstants.dateofbirthColName)
    val condList = List("considerations = 'Y'", "isnotnull (member_plan_start_date)", "isnotnull (member_plan_end_date)")
    // val df = UtilFunctions.dataLoadFromHiveStageTable(spark, "db1", KpiConstants.membershipTblName,colList,condList)
    import spark.implicits._

    val membershipDf = spark.read.option("header", "true").csv(Local_root_path+"\\CWP_MEM_ENROLL.csv")
      .filter(($"${KpiConstants.considerationsColName}".===(KpiConstants.yesVal))
        && ($"${KpiConstants.memStartDateColName}".isNotNull)
        && ($"${KpiConstants.memEndDateColName}".isNotNull))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .withColumn(KpiConstants.memStartDateColName, to_date($"${KpiConstants.memStartDateColName}", KpiConstants.dateFormat_DDMONYY))
      .withColumn(KpiConstants.memEndDateColName, to_date($"${KpiConstants.memEndDateColName}", KpiConstants.dateFormat_DDMONYY))
      .withColumn(KpiConstants.dateofbirthColName, to_date($"${KpiConstants.dateofbirthColName}", KpiConstants.dateFormat_DDMONYY))

    membershipDf.printSchema()

    val visitsDf = spark.read.option("header", "true").csv(Local_root_path+"\\CWP_VISIT.csv")
      .filter((($"${KpiConstants.dataSourceColName}".===("Claim"))&&($"${KpiConstants.claimstatusColName}".isin(claimStatusList:_*))
        || (($"${KpiConstants.dataSourceColName}".===("RxClaim"))&&($"${KpiConstants.claimstatusColName}".isin(claimStatusList:_*)))
        ||($"${KpiConstants.dataSourceColName}".===("Rx")) || ($"${KpiConstants.dataSourceColName}".===("Lab")) && ($"${KpiConstants.serviceDateColName}".isNotNull))
        && (($"${KpiConstants.admitDateColName}".isNotNull && $"${KpiConstants.dischargeDateColName}".isNotNull)
        || ($"${KpiConstants.admitDateColName}".isNull && $"${KpiConstants.dischargeDateColName}".isNull))
        &&  ($"${KpiConstants.serviceDateColName}".isNotNull ))
      .drop(KpiConstants.lobProductColName, "latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name","product")
      .withColumn(KpiConstants.dobColName, to_date($"${KpiConstants.dobColName}", KpiConstants.dateFormat_DDMONYY))
      .withColumn(KpiConstants.serviceDateColName, to_date($"${KpiConstants.serviceDateColName}", KpiConstants.dateFormat_DDMONYY))
      .withColumn(KpiConstants.admitDateColName, when($"${KpiConstants.admitDateColName}".isNotNull,to_date($"${KpiConstants.admitDateColName}",  KpiConstants.dateFormat_DDMONYY)))
      .withColumn(KpiConstants.dischargeDateColName, when($"${KpiConstants.dischargeDateColName}".isNotNull,to_date($"${KpiConstants.dischargeDateColName}",  KpiConstants.dateFormat_DDMONYY)))
      .withColumn(KpiConstants.medstartdateColName, when($"${KpiConstants.medstartdateColName}".isNotNull,to_date($"${KpiConstants.medstartdateColName}",  KpiConstants.dateFormat_DDMONYY)))
      .withColumn(KpiConstants.revenuecodeColName, when((length($"${KpiConstants.revenuecodeColName}").as[Int].===(3)),concat(lit("0" ),lit($"${KpiConstants.revenuecodeColName}"))).otherwise($"${KpiConstants.revenuecodeColName}"))
      .withColumn(KpiConstants.billtypecodeColName, when((length($"${KpiConstants.billtypecodeColName}").as[Int].===(3)),concat(lit("0" ),lit($"${KpiConstants.billtypecodeColName}"))).otherwise($"${KpiConstants.billtypecodeColName}"))
      .withColumn(KpiConstants.proccode2ColName, when(($"${KpiConstants.proccode2mod1ColName}".isin(KpiConstants.avoidCodeList:_*)) || ($"${KpiConstants.proccode2mod2ColName}".isin(KpiConstants.avoidCodeList:_*)),lit("NA")).otherwise($"${KpiConstants.proccode2ColName}"))


    //visitsDf.show()

    val refHedisDf_1 = spark.read.option("header", "true").csv(Local_root_path+"\\REF_HEDIS2019.csv")
      .filter(($"${KpiConstants.measureIdColName}".===(measureId)) || ($"${KpiConstants.measureIdColName}".===(KpiConstants.ggMeasureId)))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")

    val refHedisDf=refHedisDf_1.repartition(col("measureid")).cache()
    val ref_medvaluesetDf_1 = spark.read.option("header", "true").csv(Local_root_path+"\\REF_MED_VALUESET.csv")
      .filter($"${KpiConstants.measure_idColName}".===(measureId))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .cache()
    val ref_medvaluesetDf=ref_medvaluesetDf_1.repartition(col("measure_id")).cache()

    (membershipDf,visitsDf,refHedisDf,ref_medvaluesetDf)
  }


}
