package com.itc.ncqa.main

import com.itc.ncqa.Constants.KpiConstants
import com.itc.ncqa.Functions.UtilFunctions
import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkConf
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.functions.{lag, lead}
import org.apache.spark.sql.types.{DateType, IntegerType}
import org.apache.spark.sql.{SaveMode, SparkSession}

import scala.collection.mutable
object dupliSPC {

  def main(args: Array[String]): Unit = {

    //<editor-fold desc="Reading program arguments and Spark Session object creation">

    val year = "2018"
    val measureId = "SPD"
    val baseMsrPath = "C:\\Users\\32676\\Desktop\\SPC2"

    System.setProperty("hadoop.home.dir", "D:\\hadoop_home")
    /*calling function for setting the dbname for dbName variable*/
    // KpiConstants.setDbName(dbName)
    val conf = new SparkConf().setMaster("local").setAppName("NcqaProgram")
      .set("hive.exec.dynamic.partition.mode", "nonstrict")
      .set("spark.sql.shuffle.partitions", "5")
      .set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")

    val spark = SparkSession.builder().config(conf)
      .getOrCreate()
    import spark.implicits._
    val rootLogger = Logger.getRootLogger()
    rootLogger.setLevel(Level.ERROR)

    val yearStartDate = year + "-01-01"
    val PreYrStartDate = year.toInt - 1 + "-01-01"
    val PreYrEndDate = year.toInt - 1 + "-12-31"
    val yearEndDate = year + "-12-31"

    val jobId = spark.sparkContext.applicationId
    val baseDir = baseMsrPath + "/" + jobId
    val outDir = baseDir + "/Out"
    val intermediateDir = baseDir + "/Intermediate"
    val stagingDir = baseDir + "/Staging"
    val temporary = baseMsrPath + "/Temporary"

    //</editor-fold>

    //<editor-fold desc="Loading Required Tables to memory">

    import spark.implicits._

    val lobList = List(KpiConstants.medicaidLobName, KpiConstants.mmdLobName, KpiConstants.commercialLobName, KpiConstants.medicareLobName)

    val membershipDf = spark.read.option("header", "true").csv("C:\\Users\\32676\\Desktop\\MEMBERSHIP_ENROLLMENT\\MEMBERSHIP_ENROLLMENT.csv")
      .filter(($"${KpiConstants.considerationsColName}".===(KpiConstants.yesVal))
        && ($"${KpiConstants.memStartDateColName}".isNotNull)
        && ($"${KpiConstants.memEndDateColName}".isNotNull))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date", "source_name", "rec_create_date", "user_name")
      .withColumn(KpiConstants.memStartDateColName, to_date($"${KpiConstants.memStartDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.memEndDateColName, to_date($"${KpiConstants.memEndDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.dateofbirthColName, to_date($"${KpiConstants.dateofbirthColName}", KpiConstants.dateFormatString))
      .repartition(2).cache()

    println("-------------------membership----------------")
    membershipDf.filter($"${KpiConstants.memberidColName}".===("95069")).show()

    membershipDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(stagingDir + "/membershipDf/")

    val claimStatusList = List(KpiConstants.paidVal, KpiConstants.suspendedVal, KpiConstants.pendingVal, KpiConstants.deniedVal)

    val visitsDf = spark.read.option("header", "true").csv("C:\\Users\\32676\\Desktop\\MEMBERSHIP_ENROLLMENT\\VISITS.csv")
      .filter(($"${KpiConstants.serviceDateColName}".isNotNull)
        && (($"${KpiConstants.admitDateColName}".isNotNull && $"${KpiConstants.dischargeDateColName}".isNotNull)
        || ($"${KpiConstants.admitDateColName}".isNull && $"${KpiConstants.dischargeDateColName}".isNull))
        && ((($"${KpiConstants.dataSourceColName}".===("Claim")) && ($"${KpiConstants.claimstatusColName}".isin(claimStatusList: _*)))
        || (($"${KpiConstants.dataSourceColName}".===("RxClaim")) && ($"${KpiConstants.claimstatusColName}".isin(claimStatusList: _*)))
        || ($"${KpiConstants.dataSourceColName}".===("Rx"))
        || ($"${KpiConstants.dataSourceColName}".===("Lab"))))
      .drop(KpiConstants.lobProductColName, "latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date", "source_name", "rec_create_date", "user_name", "product")
      .withColumn(KpiConstants.dobColName, to_date($"${KpiConstants.dobColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.serviceDateColName, to_date($"${KpiConstants.serviceDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.admitDateColName, when($"${KpiConstants.admitDateColName}".isNotNull, to_date($"${KpiConstants.admitDateColName}", KpiConstants.dateFormatString)))
      .withColumn(KpiConstants.dischargeDateColName, when($"${KpiConstants.dischargeDateColName}".isNotNull, to_date($"${KpiConstants.dischargeDateColName}", KpiConstants.dateFormatString)))
      .withColumn(KpiConstants.medstartdateColName, when($"${KpiConstants.medstartdateColName}".isNotNull, to_date($"${KpiConstants.medstartdateColName}", KpiConstants.dateFormatString)))
      .withColumn(KpiConstants.revenuecodeColName, when((length($"${KpiConstants.revenuecodeColName}").as[Int].===(3)), concat(lit("0"), lit($"${KpiConstants.revenuecodeColName}"))).otherwise($"${KpiConstants.revenuecodeColName}"))
      .withColumn(KpiConstants.billtypecodeColName, when((length($"${KpiConstants.billtypecodeColName}").as[Int].===(3)), concat(lit("0"), lit($"${KpiConstants.billtypecodeColName}"))).otherwise($"${KpiConstants.billtypecodeColName}"))
      .withColumn(KpiConstants.proccode2ColName, when(($"${KpiConstants.proccode2mod1ColName}".isin(KpiConstants.avoidCodeList: _*)) || ($"${KpiConstants.proccode2mod2ColName}".isin(KpiConstants.avoidCodeList: _*)), lit("NA")).otherwise($"${KpiConstants.proccode2ColName}"))
      .repartition(2).cache()

    visitsDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(stagingDir + "/visitsDf/")

    println("-------------------visits----------------")
    visitsDf.filter($"${KpiConstants.memberidColName}".===("95069")).show()


    val refHedisDf = spark.read.option("header", "true").csv("C:\\Users\\32676\\Desktop\\REF_HEDIS2019\\REF_HEDIS2019.csv")
      .filter(($"${KpiConstants.measureIdColName}".===(KpiConstants.spdMeasureId)) || ($"${KpiConstants.measureIdColName}".===(KpiConstants.ggMeasureId)))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date", "source_name", "rec_create_date", "user_name")
      .repartition(2).cache()

    refHedisDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(stagingDir + "/refHedisDf/")

    val ref_medvaluesetDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\SMC\\REF_MED_VALUE_SET\\REF_MED_VALUE_SET.csv")
      .filter(($"${KpiConstants.measure_idColName}".===(KpiConstants.spdMeasureId)))
      .drop("latest_flag", "active_flag", "ingestion_date", "source_name", "user_name")
      .repartition(2).cache()

    ref_medvaluesetDf.coalesce(2)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(stagingDir + "/ref_medvaluesetDf/")


    val medmonmemDf = spark.read.option("header", "true").csv("C:\\Users\\32676\\Desktop\\MEMBERSHIP_ENROLLMENT\\MEDICARE_MONTHLY_MEMBERSHIP.csv")
      .withColumn(KpiConstants.runDateColName, to_date($"${KpiConstants.runDateColName}", KpiConstants.dateFormatString))
      .filter(($"${KpiConstants.runDateColName}".>=(yearStartDate)) && ($"${KpiConstants.runDateColName}".<=(yearEndDate)))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date", "source_name", "rec_create_date", "user_name")
      .repartition(2).cache()

    medmonmemDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(stagingDir + "/medmonmemDf/")

    println("-------------------Monthly Membership----------------")
    medmonmemDf.filter($"${KpiConstants.memberidColName}" === ("95069")).show()

    val ageEndDate = year + "-12-31"
    val ageStartDate = year + "-01-01"

     val ageFilterDf = membershipDf.filter((UtilFunctions.add_ncqa_months(spark, $"${KpiConstants.dateofbirthColName}", KpiConstants.months252).<=(ageEndDate)
       && UtilFunctions.add_ncqa_months(spark, $"${KpiConstants.dateofbirthColName}", KpiConstants.months912).>=(ageEndDate))
       && ($"${KpiConstants.genderColName}".===(KpiConstants.maleVal)))
     println("ageFilterDf")
    // ageFilterDf.show()
    ageFilterDf.filter($"${KpiConstants.memberidColName}" === ("98744")).show()

     val ageFilterFemaleDf = membershipDf.filter((UtilFunctions.add_ncqa_months(spark, $"${KpiConstants.dateofbirthColName}", KpiConstants.months480).<=(ageEndDate)
       && UtilFunctions.add_ncqa_months(spark, $"${KpiConstants.dateofbirthColName}", KpiConstants.months912).>=(ageEndDate))
       && ($"${KpiConstants.genderColName}".===(KpiConstants.femaleVal)))

     println("ageFilterFemaleDf")
    ageFilterFemaleDf.filter($"${KpiConstants.memberidColName}" === ("98744")).show()
     //ageFilterFemaleDf.show()



     val resultageDf = ageFilterDf.union(ageFilterFemaleDf)

    println("resultageDf")
    resultageDf.filter($"${KpiConstants.memberidColName}" === ("98744")).show()
    resultageDf.show()






     val sn2Members = resultageDf.filter(($"${KpiConstants.lobProductColName}".===(KpiConstants.lobProductNameConVal))
       && (((($"${KpiConstants.memStartDateColName}".>=(yearStartDate)) && ($"${KpiConstants.memStartDateColName}".<=(yearEndDate)))
       || (($"${KpiConstants.memEndDateColName}".>=(yearStartDate)) && ($"${KpiConstants.memEndDateColName}".<=(yearEndDate))))
       || ((($"${KpiConstants.memStartDateColName}".<(yearStartDate)) && ($"${KpiConstants.memEndDateColName}".>(yearEndDate)))))
       && (UtilFunctions.add_ncqa_months(spark, $"${KpiConstants.dateofbirthColName}", KpiConstants.months792).<=(yearEndDate)))
       .select(KpiConstants.memberidColName).rdd.map(r => r.getString(0)).collect()
     val sn2RemovedMemDf = resultageDf.except(resultageDf.filter($"${KpiConstants.memberidColName}".isin(sn2Members: _*)))

     println("Age -> " + ageFilterDf.count())
     ageFilterDf.filter($"${KpiConstants.memberidColName}" === ("95069")).show()

     println("SN2 Age -> " + sn2RemovedMemDf.count())
     sn2RemovedMemDf.filter($"${KpiConstants.memberidColName}" === ("95069")).show()
     println("sn2RemovedMemDf")
     sn2RemovedMemDf.show()
     //</editor-fold>

     //<editor-fold desc="Continuous Enrollment, Allowable Gap Calculation">

    val inputForContEnrolldf = sn2RemovedMemDf.select(KpiConstants.memberidColName, KpiConstants.benefitMedicalColname,KpiConstants.benefitdrugColName,
      KpiConstants.memStartDateColName,KpiConstants.memEndDateColName,KpiConstants.dateofbirthColName,
      KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName, KpiConstants.primaryPlanFlagColName)

    println("Continous Enrollment 1st Year Input  -> " + inputForContEnrolldf.count())
    inputForContEnrolldf.filter($"${KpiConstants.memberidColName}" === ("95069")).show()

    val mapForCeminus1y = mutable.Map("start_date" -> "2017-01-01", "end_date" -> "2017-12-31","gapcount" -> "1",
      "checkval" -> "false", "reqCovDays" -> "0")

    val ceOutminus1yDf = UtilFunctions.contEnrollAndAllowableGapFilterFunction(spark,inputForContEnrolldf,mapForCeminus1y)

    println("Continous Enrollment 1st Year  -> " + ceOutminus1yDf.count())
    ceOutminus1yDf.filter($"${KpiConstants.memberidColName}" === ("95069")).show()

    ceOutminus1yDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite).parquet(intermediateDir+ "/CEForFirstYear/")

    val ceOutMinus1y = spark.read.parquet(intermediateDir+ "/CEForFirstYear/").cache()

    val mapForCeCurrYear = mutable.Map("start_date" -> "2018-01-01", "end_date" -> "2018-12-31","gapcount" -> "1",
      "checkval" -> "true","reqCovDays" -> "0","anchor_date" -> "2018-12-31")

    val contEnrollInputDf = UtilFunctions.contEnrollAndAllowableGapFilterFunction(spark,ceOutMinus1y,mapForCeCurrYear)
      .select(KpiConstants.memberidColName, KpiConstants.dateofbirthColName, KpiConstants.memStartDateColName, KpiConstants.memEndDateColName,
        KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.primaryPlanFlagColName, KpiConstants.payerColName)

    println("Continous Enrollment 2nd Year  -> " + contEnrollInputDf.count())
    contEnrollInputDf.filter($"${KpiConstants.memberidColName}" === ("95069")).show()

    contEnrollInputDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/contEnrollInputDf/")

    val contEnrollDf = spark.read.parquet(intermediateDir+ "/contEnrollInputDf/").cache()

    //</editor-fold>

     //<editor-fold desc="Dual Enrollment and SPD Lob filter">

     val baseOutInputDf = UtilFunctions.baseOutDataframeCreation(spark, contEnrollDf, lobList, measureId)

     baseOutInputDf.coalesce(1)
       .write
       .mode(SaveMode.Overwrite)
       .parquet(intermediateDir + "/baseOutInputDf/")

     val baseOutInDf = spark.read.parquet(intermediateDir + "/baseOutInputDf/").cache()

     val medicareContEnrollDf = baseOutInDf.filter($"${KpiConstants.lobColName}".===(KpiConstants.medicareLobName))

     val medicareHospiceDf = medicareContEnrollDf.as("df1").join(medmonmemDf.as("df2"), Seq(KpiConstants.memberidColName))
       .groupBy(KpiConstants.memberidColName).agg(countDistinct(when($"${KpiConstants.hospiceFlagColName}".===(KpiConstants.yesVal), 1)).alias(KpiConstants.countColName))
       .filter($"${KpiConstants.countColName}".>(0))
       .select(KpiConstants.memberidColName).rdd.map(r => r.getString(0)).collect()

     val baseHospRemDf = baseOutInDf.except(baseOutInDf.filter(($"${KpiConstants.memberidColName}".isin(medicareHospiceDf: _*))))

     println("baseHospRemDf" + baseHospRemDf.count())
     baseHospRemDf.filter($"${KpiConstants.memberidColName}" === ("95069")).show()

     val medicareLtiInDf = baseHospRemDf.as("df1").join(medmonmemDf.as("df2"),
       $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
       .filter(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}", KpiConstants.months792).<=(yearEndDate))
       .select(s"df1.${KpiConstants.memberidColName}", KpiConstants.ltiFlagColName)
     // .select(s"df2")

     println("medicareLtiInDf" + medicareLtiInDf.count())
     medicareLtiInDf.filter($"${KpiConstants.memberidColName}" === ("95069")).show()

     val medicareLtiDf = medicareLtiInDf
       .groupBy(KpiConstants.memberidColName).agg(count(when($"${KpiConstants.ltiFlagColName}".===(KpiConstants.yesVal), 1)).alias(KpiConstants.countColName))
       .filter($"${KpiConstants.countColName}".>=(1))
       .select(KpiConstants.memberidColName).rdd.map(r => r.getString(0)).collect()

     val baseOutDf = baseHospRemDf.except(baseHospRemDf.filter(($"${KpiConstants.memberidColName}".isin(medicareLtiDf: _*))
       && (($"${KpiConstants.lobColName}".===(KpiConstants.medicareLobName)) || ($"${KpiConstants.lobColName}".===(KpiConstants.mmdLobName)))
     ))

     println("baseOutDf" + baseOutDf.count())
     baseOutDf.filter($"${KpiConstants.memberidColName}" === ("95069")).show()
    println("baseOutDf")
     baseOutDf.show()
     //val baseOutDf = baseOutInDf.except(baseOutInDf.filter($"${KpiConstants.memberidColName}".isin(medicareHospiceDf:_*)))

     val payerlist = List(KpiConstants.sn1PayerVal, KpiConstants.sn2PayerVal, KpiConstants.sn3PayerVal, KpiConstants.mmpPayerVal)

     val spdbaseOutDf = baseOutDf.filter($"${KpiConstants.lobColName}".isin(lobList: _*) && (!$"${KpiConstants.payerColName}".isin(payerlist: _*))
     ).dropDuplicates().cache()

     println("spdbaseOutDf" + spdbaseOutDf.count())
     spdbaseOutDf.filter($"${KpiConstants.memberidColName}" === ("95069")).show()

     spdbaseOutDf.coalesce(1)
       .write
       .mode(SaveMode.Overwrite)
       .parquet(intermediateDir + "/spdbaseOutDf/")

     val spdContEnrollDf = spark.read.parquet(intermediateDir + "/spdbaseOutDf/").cache()

     //</editor-fold>

     //<editor-fold desc="Initial Join with Ref_Hedis">

     val argmapforRefHedis = mutable.Map(KpiConstants.eligibleDfName -> visitsDf, KpiConstants.refHedisTblName -> refHedisDf,
       KpiConstants.refmedValueSetTblName -> ref_medvaluesetDf)
     val allValueList = List(KpiConstants.independentLabVal, KpiConstants.hospiceVal, KpiConstants.cellulitisVal, KpiConstants.otherRevascularizationVal,
       KpiConstants.schizophreniaVal, KpiConstants.bipolarDisorderVal, KpiConstants.ldlcTestsVal, KpiConstants.otherBipolarDisorder, KpiConstants.esrdVal,
       KpiConstants.cabgVal, KpiConstants.nonacuteInpatientPosVal, KpiConstants.edPosVal, KpiConstants.acuteInpatientVal, KpiConstants.fralityVal, KpiConstants.miVal,
       KpiConstants.partialHospitalizationIntensiveOutpatientVal, KpiConstants.communityMentalHealthCenterPosVal, KpiConstants.acuteInpatientPosVal, KpiConstants.edVal,
       KpiConstants.diabetesExclusionVal, KpiConstants.pciVal, KpiConstants.telehealthPosVal, KpiConstants.nonAcuteInPatientVal, KpiConstants.ivdVal, KpiConstants.ivfVal,
       KpiConstants.outpatientPosVal, KpiConstants.bhOutpatientVal, KpiConstants.partialHospitalizationPosVal, KpiConstants.observationVal, KpiConstants.inPatientStayVal,
       KpiConstants.onlineAssesmentVal, KpiConstants.amiVal, KpiConstants.diabetesVal, KpiConstants.muscularPainAndDiseaseval, KpiConstants.dementiaMedicationVal,
       KpiConstants.highAndModerateStatinMedVal,KpiConstants.cirrhossisVal,KpiConstants.pregnancyVal,KpiConstants.femaleVal,KpiConstants.maleVal,
       KpiConstants.telehealthModifierVal, KpiConstants.visitSettingUnspecifiedVal, KpiConstants.telephoneVisitsVal, KpiConstants.outPatientVal,KpiConstants.advancedIllVal)

     val medList = List(KpiConstants.diabetesMedicationVal, KpiConstants.estrogenAgonistsMediVal, KpiConstants.dementiaMedicationVal,
       KpiConstants.highAndModerateStatinMedVal, KpiConstants.lowStatinMedVal)

     val visitRefHedisInDf = UtilFunctions.joinWithRefHedisFunction(spark, argmapforRefHedis, allValueList, medList)


     visitRefHedisInDf.coalesce(1)
       .write
       .mode(SaveMode.Overwrite)
       .parquet(intermediateDir + "/visitRefHedisInDf/")

     val visitRefHedisDf = spark.read.parquet(intermediateDir + "/visitRefHedisInDf/").cache()

     visitRefHedisDf.select($"${KpiConstants.memberidColName}", $"${KpiConstants.valuesetColName}")

     println("visitRefHedisDf" + visitRefHedisDf.count())
     visitRefHedisDf.filter($"${KpiConstants.memberidColName}" === ("95069")).show()
     println("visitRefHedisDf")
     visitRefHedisDf.show()
     //</editor-fold>

     //<editor-fold desc="Removal of Independent Lab Visits">

     val groupList = visitsDf.schema.fieldNames.toList.dropWhile(p => p.equalsIgnoreCase(KpiConstants.memberidColName))
     val visitgroupedDf = visitRefHedisDf.groupBy(KpiConstants.memberidColName, groupList: _*).agg(collect_list(KpiConstants.valuesetColName).alias(KpiConstants.valuesetColName))
       .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName, KpiConstants.claimstatusColName, KpiConstants.dischargeDateColName,
         KpiConstants.dobColName, KpiConstants.supplflagColName, KpiConstants.valuesetColName, KpiConstants.genderColName,KpiConstants.dataSourceColName,KpiConstants.ndcCodeColName,KpiConstants.rxdayssuppliedColName
         , KpiConstants.poscodeColName)

    /*visitgroupedDf.coalesce(1)
   .write
   .mode(SaveMode.Append)
   .option("header", "true")
   .json(outDir + "/rexclOutDf")*/



   val indLabVisRemDf = visitgroupedDf.filter((!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)
   || ((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal))
   && (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.hba1cTestVal)))
   || ((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal))
   && (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ldlcTestsVal)))
   )).repartition(2).cache()

 println("indLabVisRemDf")
 indLabVisRemDf.filter($"${KpiConstants.memberidColName}" === ("95069")).show()
 indLabVisRemDf.show()
 val membertotalDf = spdContEnrollDf.dropDuplicates()
 val argmapForVisittJoin = mutable.Map(KpiConstants.membershipTblName -> membertotalDf, KpiConstants.visitTblName -> indLabVisRemDf)
 val visitJoinedOutDf = UtilFunctions.initialJoinFunction(spark, argmapForVisittJoin)


 visitJoinedOutDf.coalesce(1)
   .write
   .mode(SaveMode.Append)
   .parquet(intermediateDir + "/visitJoinedOutDf")

 val visitJoinDf = spark.read.parquet(intermediateDir + "/visitJoinedOutDf").repartition(2).cache()

 println("visitJoinDf")
 visitJoinDf.filter($"${KpiConstants.memberidColName}" === ("95069")).show()

 //</editor-fold>

 //<editor-fold desc="Hospice Removal">

 val hospiceInCurrYearMemDf = indLabVisRemDf.filter(
   (!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)) &&
     (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.hospiceVal))
     && ($"${KpiConstants.serviceDateColName}".>=(yearStartDate) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))

 println("Hospice members")
 hospiceInCurrYearMemDf.filter($"${KpiConstants.memberidColName}" === ("95069")).show()

 val hospicefinaldf = hospiceInCurrYearMemDf.select(KpiConstants.memberidColName)
   .dropDuplicates()


 val hospiceremovalDf = visitJoinDf.except(visitJoinDf.filter($"${KpiConstants.memberidColName}".isin(
   hospicefinaldf.rdd.map(r => r.getString(0)).collect(): _*
 )))

 println("hospiceremovalDf")
 hospiceremovalDf.filter($"${KpiConstants.memberidColName}" === ("95069")).show()


 //Used at the time of debugging and testing.

 hospiceremovalDf.coalesce(3)
   .write
   .mode(SaveMode.Overwrite)
   .parquet(temporary + "/hospiceremovalDf/")



//</editor-fold>

//</editor-fold>


//<editor-fold desc="Events Calculation">

val hosiceremovalDf = spark.read.parquet(temporary + "/hospiceremovalDf/").cache()

println("hosiceremovalDf" + hosiceremovalDf.count())

val eventsVisitsDf = hosiceremovalDf.filter($"${KpiConstants.supplflagColName}".===("N")
    && ($"${KpiConstants.claimstatusColName}".isin(claimStatusList: _*))).cache()
eventsVisitsDf.count()

println("eventsVisitsDf" + eventsVisitsDf.count())
eventsVisitsDf.filter($"${KpiConstants.memberidColName}" === ("95069")).show()
println("eventsVisitsDf")
eventsVisitsDf.show()

//<editor-fold desc="Part - 1">

    val setDf = eventsVisitsDf.withColumn("discharge_date",when($"discharge_date".isNull,$"service_date").otherwise($"discharge_date"))

    val rexclstep1Df = setDf.filter((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.inPatientStayVal))
  && (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.miVal)))
  && (!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
  && (($"${KpiConstants.dischargeDateColName}".>=(PreYrStartDate)) && ($"${KpiConstants.dischargeDateColName}".<=(PreYrEndDate))))
  .select(KpiConstants.memberidColName)
  .repartition(2).cache()

println("rexclstep1Df" + rexclstep1Df.count())
rexclstep1Df.filter($"${KpiConstants.memberidColName}" === ("95069")).show()
//rexclstep1Df.show()

val rexclstep2Df = setDf
  .filter((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.cabgVal))
    || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.pciVal))
    || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.otherRevascularizationVal)))
    && (!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
    && (($"${KpiConstants.dischargeDateColName}".>=(PreYrStartDate)) && ($"${KpiConstants.dischargeDateColName}".<=(PreYrEndDate))))
  .select(KpiConstants.memberidColName).repartition(2).cache()

println("rexclstep2Df" +rexclstep2Df.count())
rexclstep2Df.filter($"${KpiConstants.memberidColName}" === ("95069")).show()
//rexclstep2Df.show()

val rexclevent1Df = rexclstep1Df.union(rexclstep2Df)

println("rexclevent1Df" + rexclevent1Df.count())
rexclevent1Df.filter($"${KpiConstants.memberidColName}" === ("95069")).show()


//</editor-fold>

//<editor-fold desc="Part - 2">

//rexclievent2Df1
val cleanPYDf = eventsVisitsDf
  .filter((((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal))
    || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.acuteInpatientVal)))
    && (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ivdVal)))
    && ((!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
    && (!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal))
    && (!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telephoneVisitsVal))
    && (!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.onlineAssesmentVal))))
    && (!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
    && (($"${KpiConstants.serviceDateColName}".>=(PreYrStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(PreYrEndDate))))
  .select(KpiConstants.memberidColName)
  .repartition(2).cache()

println("cleanPYDf" + cleanPYDf.count())
cleanPYDf.filter($"${KpiConstants.memberidColName}" === ("95069")).show()
//rexclievent2Df1.show()

//rexclievent2Df2
val cleanCYDf = eventsVisitsDf
  .filter((((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal))
    || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.acuteInpatientVal)))
    && (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ivdVal)))
    && ((!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
    && (!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal))
    && (!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telephoneVisitsVal))
    && (!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.onlineAssesmentVal))))
    && (!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
    && (($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
  .select(KpiConstants.memberidColName)
  .repartition(2).cache()

println("cleanCYDf" + cleanCYDf.count())
cleanCYDf.filter($"${KpiConstants.memberidColName}" === ("95069")).show()



val rexclievent2Df = cleanPYDf.intersect(cleanCYDf)
println("rexclievent2Df")
rexclievent2Df.filter($"${KpiConstants.memberidColName}" === ("95069")).show()


val dirtyPYDf = eventsVisitsDf.filter((((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
  || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal)))
  && (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal)))
  || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telephoneVisitsVal))
  || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.onlineAssesmentVal))
  && (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ivdVal)))
  && (!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
  && (($"${KpiConstants.serviceDateColName}".>=(PreYrStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(PreYrEndDate))))
  .select(KpiConstants.memberidColName)

println("dirtyPYDf" + dirtyPYDf.count())
dirtyPYDf.filter($"${KpiConstants.memberidColName}" === ("95069")).show()

val dirtyCYDf = eventsVisitsDf.filter((((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
  || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal)))
  && (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal)))
  || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telephoneVisitsVal))
  || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.onlineAssesmentVal))
  && (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ivdVal)))
  && (!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
  && (($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
  .select(KpiConstants.memberidColName)

println("dirtyCYDf" + dirtyCYDf.count())
dirtyCYDf.filter($"${KpiConstants.memberidColName}" === ("95069")).show()


val intersectDf = cleanPYDf.intersect(dirtyCYDf)

val intersect2Df = cleanCYDf.intersect(dirtyPYDf)

val unionmain1Df = rexclievent2Df.union(intersectDf).union(intersect2Df).union(rexclevent1Df).distinct()



println("unionmain1Df" + unionmain1Df.count())
unionmain1Df.filter($"${KpiConstants.memberidColName}" === ("95069")).show()




    val semieventInDf = unionmain1Df.as("df1").join(eventsVisitsDf.as("df2"),
  $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
  .select("df2.*")

// val semieventOutDf = semieventInDf.select(KpiConstants.memberidColName,KpiConstants.serviceDateColName)

println("semieventInDf" + semieventInDf.count())
semieventInDf.filter($"${KpiConstants.memberidColName}" === ("95069")).show()



 //</editor-fold>

 //<editor-fold desc="Exclusion">



    /*step 2*/

    val rexDf = semieventInDf.filter(((((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.pregnancyVal)))
  && ($"${KpiConstants.genderColName}".===(KpiConstants.femaleVal)))
  && (!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
  && (($"${KpiConstants.serviceDateColName}".>=(PreYrStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
  .select(KpiConstants.memberidColName,KpiConstants.serviceDateColName)
  .repartition(2).cache()
    
    println("rexDf")
    rexDf.filter($"${KpiConstants.memberidColName}" === ("95069")).show()
    


val rex1Df = semieventInDf
  .filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ivfVal))
    && (!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
    && (($"${KpiConstants.serviceDateColName}".>=(PreYrStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
  .select(KpiConstants.memberidColName,KpiConstants.serviceDateColName).repartition(2).cache()
    
    println("rex1Df")
    rex1Df.filter($"${KpiConstants.memberidColName}" === ("95069")).show()


//</editor-fold>

//<editor-fold desc="Part - 2">

val rex2Df = semieventInDf
  .filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.estrogenAgonistsMediVal))
    && (!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
    && (($"${KpiConstants.serviceDateColName}".>=(PreYrStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
  .select(KpiConstants.memberidColName,KpiConstants.serviceDateColName)
  .repartition(2).cache()
    
    println("rex2Df")
    rex2Df.filter($"${KpiConstants.memberidColName}" === ("95069")).show()
    
val rex3Df = semieventInDf
  .filter((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.esrdVal))
    || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.cirrhossisVal)))
    && (!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
    && (($"${KpiConstants.serviceDateColName}".>=(PreYrStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
  .select(KpiConstants.memberidColName,KpiConstants.serviceDateColName)
  .repartition(2).cache()
    
    println("rex3Df")
    rex3Df.filter($"${KpiConstants.memberidColName}" === ("95069")).show()


    val rex4Df = semieventInDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.muscularPainAndDiseaseval))
      && (!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
      && (($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
      .select(KpiConstants.memberidColName,KpiConstants.serviceDateColName )

   val rex5Df = rexDf.union(rex1Df).union(rex2Df).union(rex3Df).union(rex4Df).select(KpiConstants.memberidColName).distinct()

println("rex5Df" + rex5Df.count())
    rex5Df.filter($"${KpiConstants.memberidColName}" === ("95069")).show()


    rex5Df.coalesce(1)
      .write
      .mode(SaveMode.Append)
       .option("header", "true")
      .csv(outDir+ "/readable")

    val rexclRdd = rex5Df.select(KpiConstants.memberidColName).rdd.map(r => r.getString(0)).collect()
//rexclievent2Df.filter($"${KpiConstants.memberidColName}" === ("95069")).show()

/*val rex5Df = rex4Df.groupBy(KpiConstants.memberidColName)
  .agg(countDistinct(KpiConstants.serviceDateColName).alias(KpiConstants.countColName))

val rex6Df = rex5Df.filter($"${KpiConstants.countColName}".>=(2))

println("rex6Df" + rex6Df.count())
// rexclievent2_1Df.filter($"${KpiConstants.memberidColName}" === ("95069")).show()

val rex7Df = rex6Df.select(KpiConstants.memberidColName)*/

// val diabeve2df = schievent2MemVisits1Df.except(schievent2MemVisits1Df.filter($"${KpiConstants.memberidColName}".isin(schievent2_1MemDf.rdd.map(r => r.getString(0)).collect():_*)))

val eventstep3Df = semieventInDf.select(KpiConstants.memberidColName).as("df1")
  .join(eventsVisitsDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}"
    , KpiConstants.innerJoinType)
  .select("df2.*")

    println("eventstep3Df" + eventstep3Df.count() )
    eventstep3Df.filter($"${KpiConstants.memberidColName}" === ("95424")).show()

  /*  eventstep3Df.filter($"${KpiConstants.memberidColName}" === ("95424")).write
      .mode(SaveMode.Append)
      .json(outDir+ "/Exclusion3Df_json")*/






    //</editor-fold>

//<editor-fold desc="Exclusion">



val prevYearStDate = year.toInt-1 +"-01-01"

//<editor-fold desc="Exclusion Part 1">

val exclPart1Df = eventstep3Df.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.fralityVal))
  &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
  &&((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}", KpiConstants.months792).<=(yearEndDate))
  &&(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}", KpiConstants.months912).>(yearEndDate))))
  .select(KpiConstants.memberidColName,KpiConstants.serviceDateColName).distinct()

println("exclPart1Df" + exclPart1Df.count() )
exclPart1Df.filter($"${KpiConstants.memberidColName}" === ("95069")).show()


//</editor-fold>

//<editor-fold desc="Exclusion Part 2">

val outPatAndAdvIllDf = eventstep3Df.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal))
  &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.advancedIllVal)))
  &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
  .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)

println("outPatAndAdvIllDf" + outPatAndAdvIllDf.count())
outPatAndAdvIllDf.filter($"${KpiConstants.memberidColName}" === ("95069")).show()

val obsAndAdvIllDf = eventstep3Df.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.observationVal))
  &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.advancedIllVal)))
  &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
  .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)

println("obsAndAdvIllDf" + obsAndAdvIllDf.count() )
obsAndAdvIllDf.filter($"${KpiConstants.memberidColName}" === ("95069")).show()

val edAndAdvIllDf = eventstep3Df.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.edVal))
  &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.advancedIllVal)))
  &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
  .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)

println("edAndAdvIllDf" + edAndAdvIllDf.count())
edAndAdvIllDf.filter($"${KpiConstants.memberidColName}" === ("95069")).show()


val nAcuteInPatAndAdvIllDf = eventstep3Df.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.nonAcuteInPatientVal))
  &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.advancedIllVal)))
  &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
  .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)

println("nAcuteInPatAndAdvIllDf" + nAcuteInPatAndAdvIllDf.count() )
nAcuteInPatAndAdvIllDf.filter($"${KpiConstants.memberidColName}" === ("95069")).show()

val mandatoryExcl3Sub21InDf = outPatAndAdvIllDf.union(obsAndAdvIllDf).union(edAndAdvIllDf).union(nAcuteInPatAndAdvIllDf)

println("mandatoryExcl3Sub21InDf" + mandatoryExcl3Sub21InDf.count() )
mandatoryExcl3Sub21InDf.filter($"${KpiConstants.memberidColName}" === ("95069")).show()

val exclPart2Df = mandatoryExcl3Sub21InDf.groupBy(KpiConstants.memberidColName).agg(countDistinct(KpiConstants.serviceDateColName).alias("count"))
  .filter($"count".>=(2)).select(KpiConstants.memberidColName)

println("exclPart2Df" + exclPart2Df.count() )
exclPart2Df.filter($"${KpiConstants.memberidColName}" === ("95069")).show()

//</editor-fold>

//<editor-fold desc="Exclusion Part 3">

val exclPart3Df = eventstep3Df.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.acuteInpatientVal))
  &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.advancedIllVal))
  &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
  .select(KpiConstants.memberidColName)

println("exclPart3Df" + exclPart3Df.count() )
exclPart3Df.filter($"${KpiConstants.memberidColName}" === ("95069")).show()

//</editor-fold>

//<editor-fold desc="Exclusion Part 4">

val exclPart4Df = eventstep3Df.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.dementiaMedicationVal))
  &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
  .select(KpiConstants.memberidColName)

println("exclPart4Df" + exclPart4Df.count() )
exclPart4Df.filter($"${KpiConstants.memberidColName}" === ("95069")).show()

//</editor-fold>

val exclunionDf = exclPart2Df.union(exclPart3Df).union(exclPart4Df)

println("exclunionDf" + exclunionDf.count() )
exclunionDf.filter($"${KpiConstants.memberidColName}" === ("95069")).show()

 val exclusionDf = exclPart1Df.select(KpiConstants.memberidColName).intersect(exclunionDf)

println("exclusionDf" + exclusionDf.count() )
exclusionDf.filter($"${KpiConstants.memberidColName}" === ("95424")).show()

    exclusionDf.coalesce(1)
  .write
  .mode(SaveMode.Append)
  .option("header", "true")
  .csv(outDir+ "/exclusionDf")

val exclusionRdd = exclusionDf.select(KpiConstants.memberidColName).rdd.map(r => r.getString(0)).collect()

//</editor-fold>

//</editor-fold>

//<editor-fold desc="Denominator Calculation">

//<editor-fold desc="EPOP Calculation">

val epopDf = unionmain1Df.except(unionmain1Df.filter($"${KpiConstants.memberidColName}".isin(exclusionRdd:_*))).distinct()

epopDf.coalesce(1)
  .write
  .mode(SaveMode.Append)
  .option("header", "true")
  .csv(outDir+ "/Epop")

println("epopDf" + epopDf.count() )
epopDf.filter($"${KpiConstants.memberidColName}" === ("95069")).show()

    val totalEligDf = epopDf.as("df1").join(hosiceremovalDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select($"df2.*")

    //<editor-fold desc="Stratification Code">

    val toutStratDf = totalEligDf.withColumn(KpiConstants.ncqaOutMeasureCol, when($"${KpiConstants.genderColName}".===(KpiConstants.femaleVal),lit(KpiConstants.spc1aMeasureId)).otherwise(lit(KpiConstants.spc2aMeasureId)))
                                 .select($"${KpiConstants.memberidColName}".as(KpiConstants.ncqaOutmemberIdCol), $"${KpiConstants.payerColName}".as(KpiConstants.ncqaOutPayerCol), $"${KpiConstants.ncqaOutMeasureCol}").distinct()


    toutStratDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir + "/toutStratDf")

    //<editor-fold desc="Numerator Input Genaration">

    val tempDenomOutDf = epopDf.except(epopDf.filter($"${KpiConstants.memberidColName}".isin(rexclRdd:_*)))

    val denominatorDf = tempDenomOutDf.select(KpiConstants.memberidColName).distinct()


    denominatorDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .parquet(intermediateDir+ "/denominatorDf")

    //<editor-fold desc="Numerator Calculation">

    val tempDenomDf = spark.read.parquet(intermediateDir+ "/denominatorDf").cache()
    // tempDenomDf = Epop - R.Exclusion

    val validvisitsDf = tempDenomDf.as("df1").join(hosiceremovalDf.as("df2"),
      $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select($"df2.*")


    validvisitsDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/validvisitsDf/")

    val totalDf = spark.read.parquet(intermediateDir+ "/validvisitsDf/").cache()
    val totalNumInDf = totalDf

    totalNumInDf.coalesce(1).write.mode(SaveMode.Append).json(outDir+ "/totalNonSuppRate1Df_json")


    //<editor-fold desc="SPDA (Numerator 1) Calculation">

    val totalNonSuppRate1Df = totalNumInDf.filter($"${KpiConstants.supplflagColName}".===("N")).cache()
    totalNonSuppRate1Df.count()

    println("totalNonSuppRate1Df  -> " + totalNonSuppRate1Df.count())
    totalNonSuppRate1Df.filter($"${KpiConstants.memberidColName}".===("95069")).show()

    //<editor-fold desc="SPDA Rate 1 Non Supp Numerator Calculation">

    val numNonSuppRate1Df = totalNonSuppRate1Df.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.highAndModerateStatinMedVal)))
      //&&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)))
      &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
      .select(KpiConstants.memberidColName)

    println("numNonSuppRate1Df  -> " + numNonSuppRate1Df.count())
    numNonSuppRate1Df.filter($"${KpiConstants.memberidColName}".===("95069")).show()
    //</editor-fold>

    //<editor-fold desc="SPDA Rate 1 Other Data Numerator Calculation">

    val numOtherDataInputDf = totalNumInDf.except(totalNumInDf
      .filter($"${KpiConstants.memberidColName}".isin(numNonSuppRate1Df.rdd.map(r=> r.getString(0)).collect():_*)))

    println("numOtherDataInputDf  -> " + numOtherDataInputDf.count())
    numOtherDataInputDf.filter($"${KpiConstants.memberidColName}".===("95069")).show()

    val numOtherRate1Df = numOtherDataInputDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.highAndModerateStatinMedVal)))
      //&&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)))
      &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
      .select(KpiConstants.memberidColName)

    println("numOtherRate1Df  -> " + numOtherRate1Df.count())
    numOtherRate1Df.filter($"${KpiConstants.memberidColName}".===("95069")).show()

    //</editor-fold>

    val spadaTmpNum = numNonSuppRate1Df.union(numOtherRate1Df).distinct()

    println("spadaTmpNum  -> " + spadaTmpNum.count())
    spadaTmpNum.filter($"${KpiConstants.memberidColName}".===("95069")).show()

    spadaTmpNum.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir + "/spadaTmpNum")

    //<editor-fold desc="SPCB (Numerator 2) Calculation">

    val totalNumInNdcDf = totalNumInDf.select(KpiConstants.memberidColName,KpiConstants.ndcCodeColName,KpiConstants.valuesetColName,KpiConstants.dataSourceColName,
      KpiConstants.serviceDateColName,KpiConstants.rxdayssuppliedColName, KpiConstants.supplflagColName).distinct()

    val totalRate2Df = totalNumInNdcDf.as("df1").join(ref_medvaluesetDf.as("df2"), $"df1.${KpiConstants.ndcCodeColName}" === $"df2.${KpiConstants.ndcCodeColName}", KpiConstants.innerJoinType)
      .select(s"df1.${KpiConstants.memberidColName}",s"df2.${KpiConstants.drugIdColName}",s"df1.${KpiConstants.valuesetColName}",
        s"df1.${KpiConstants.serviceDateColName}",s"df1.${KpiConstants.rxdayssuppliedColName}",s"df1.${KpiConstants.dataSourceColName}", s"df1.${KpiConstants.supplflagColName}")


    val numRate2InDf = totalRate2Df.filter((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.highAndModerateStatinMedVal))
      //||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.lowStatinMedVal)))
      &&($"${KpiConstants.dataSourceColName}".===("RxClaim")))
      &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))))

    val memIpsdDf = numRate2InDf.groupBy(KpiConstants.memberidColName).agg(min(KpiConstants.serviceDateColName).alias(KpiConstants.ipsdDateColName))



    //<editor-fold desc="SPDB Rate 2 Numerator Non Supplement Calculation">



    val nonSupinDf = numRate2InDf.filter($"${KpiConstants.supplflagColName}".===("N"))
      .withColumn(KpiConstants.dateColName, lit(datediff($"${KpiConstants.serviceDateColName}", lit(yearStartDate).cast(DateType)) +1 ).cast(IntegerType))
      .withColumn(KpiConstants.rxdayssuppliedColName, when(datediff(lit(yearEndDate).cast(DateType), $"${KpiConstants.serviceDateColName}").<($"${KpiConstants.rxdayssuppliedColName}"), lit(datediff(lit(yearEndDate).cast(DateType), $"${KpiConstants.serviceDateColName}")).cast(IntegerType))
        .otherwise($"${KpiConstants.rxdayssuppliedColName}".cast(IntegerType)))
      .select(KpiConstants.memberidColName, KpiConstants.drugIdColName, KpiConstants.dateColName, KpiConstants.rxdayssuppliedColName)


    val nonSupcovDf = nonSupinDf.groupBy(KpiConstants.memberidColName, KpiConstants.drugIdColName).agg(sum($"${KpiConstants.rxdayssuppliedColName}").alias(KpiConstants.totalDaysColName))

    val nonSupjoinedDf = nonSupinDf.as("df1").join(nonSupcovDf.as("df2"), Seq(KpiConstants.memberidColName, KpiConstants.drugIdColName), KpiConstants.innerJoinType)
      .select(KpiConstants.memberidColName, KpiConstants.drugIdColName, KpiConstants.dateColName, KpiConstants.rxdayssuppliedColName, KpiConstants.totalDaysColName)

    val nonSupresDf = UtilFunctions.drug_function(spark,nonSupjoinedDf)


    val ipsdAddedNonSupResDf = nonSupresDf.as("df1").join(memIpsdDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select(s"df1.${KpiConstants.memberidColName}", s"df1.${KpiConstants.totalDaysColName}", s"df2.${KpiConstants.ipsdDateColName}")

    val spdbtmpNonSupDf = ipsdAddedNonSupResDf.withColumn(KpiConstants.rateColName , lit(($"${KpiConstants.totalDaysColName}"./(datediff(lit(yearEndDate).cast(DateType), $"${KpiConstants.ipsdDateColName}"))) * lit(100)))
      .filter($"${KpiConstants.rateColName}".>=(lit(79.5f)))
      .select(KpiConstants.memberidColName)



    //</editor-fold>

    //<editor-fold desc="SPDB Rate 2 Numerator Non Supplement Calculation">

    val otherinDf = numRate2InDf.except(numRate2InDf.filter($"${KpiConstants.memberidColName}".isin(spdbtmpNonSupDf.rdd.map(r => r.getString(0)).collect():_*)))
      .withColumn(KpiConstants.dateColName, lit(datediff($"${KpiConstants.serviceDateColName}", lit(yearStartDate).cast(DateType)) +1 ).cast(IntegerType))
      .withColumn(KpiConstants.rxdayssuppliedColName, when(datediff(lit(yearEndDate).cast(DateType), $"${KpiConstants.serviceDateColName}").<($"${KpiConstants.rxdayssuppliedColName}"), lit(datediff(lit(yearEndDate).cast(DateType), $"${KpiConstants.serviceDateColName}")).cast(IntegerType))
        .otherwise($"${KpiConstants.rxdayssuppliedColName}".cast(IntegerType)))
      .select(KpiConstants.memberidColName, KpiConstants.drugIdColName, KpiConstants.dateColName, KpiConstants.rxdayssuppliedColName)


    val othercovDf = otherinDf.groupBy(KpiConstants.memberidColName, KpiConstants.drugIdColName).agg(sum($"${KpiConstants.rxdayssuppliedColName}").alias(KpiConstants.totalDaysColName))

    val otherjoinedDf = otherinDf.as("df1").join(othercovDf.as("df2"), Seq(KpiConstants.memberidColName, KpiConstants.drugIdColName), KpiConstants.innerJoinType)
      .select(KpiConstants.memberidColName, KpiConstants.drugIdColName, KpiConstants.dateColName, KpiConstants.rxdayssuppliedColName, KpiConstants.totalDaysColName)


    val otherresDf = UtilFunctions.drug_function(spark,otherjoinedDf)

    val ipsdAddedOtherResDf = otherresDf.as("df1").join(memIpsdDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select(s"df1.${KpiConstants.memberidColName}", s"df1.${KpiConstants.totalDaysColName}", s"df2.${KpiConstants.ipsdDateColName}")

    val spdbtmpOtherDf = ipsdAddedOtherResDf.withColumn(KpiConstants.rateColName , lit(($"${KpiConstants.totalDaysColName}"./(datediff(lit(yearEndDate).cast(DateType), $"${KpiConstants.ipsdDateColName}"))) * lit(100)))
      .filter($"${KpiConstants.rateColName}".>=(lit(79.5f)))
      .select(KpiConstants.memberidColName)


    //</editor-fold>

    val spdbNumeratorDf = spdbtmpNonSupDf.union(spdbtmpOtherDf)

    println("spdbNumeratorDf -> " + spdbNumeratorDf.count())

    spdbNumeratorDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir + "/spdbNumeratorDf")


    val numInterSectDf  = spadaTmpNum.union(spdbNumeratorDf)


    println("numInterSectDf  -> " + numInterSectDf.count())

    numInterSectDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir + "/spdbNumerator_11Df")



    //</editor-fold>



    /*Output Function*/

    val outMap = mutable.Map(KpiConstants.totalPopDfName -> toutStratDf, KpiConstants.eligibleDfName -> toutStratDf.select(KpiConstants.ncqaOutmemberIdCol),
      KpiConstants.mandatoryExclDfname -> rex5Df, KpiConstants.optionalExclDfName -> spark.emptyDataFrame,
      KpiConstants.numeratorDfName -> spadaTmpNum, KpiConstants.numerator2DfName -> spdbNumeratorDf)


    val outDf = UtilFunctions.ncqaOutputDfCreation(spark,outMap,measureId)
    outDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir+ "/out1Df")


    spark.sparkContext.stop()

}

}









