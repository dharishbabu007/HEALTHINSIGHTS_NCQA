package com.itc.ncqa.main

import com.itc.ncqa.Constants.KpiConstants
import com.itc.ncqa.Functions.{DataLoadFunctions, UtilFunctions}
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.SparkConf
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DateType, IntegerType}

import scala.collection.mutable

object NcqaSPD {

  def main(args: Array[String]): Unit = {


    //<editor-fold desc="Reading program arguments and SaprkSession oBject creation">

    val year = args(0)
    val measureId = args(1)
    val dbName = args(2)
    val baseMsrPath = args(3)

    /*calling function for setting the dbname for dbName variable*/
    KpiConstants.setDbName(dbName)
    val conf = new SparkConf().setAppName("NcqaProgram")
    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      .set("hive.exec.dynamic.partition.mode", "nonstrict")
      .set("spark.sql.shuffle.partitions","5")


    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    import spark.implicits._

    val yearStartDate = year+"-01-01"
    val yearEndDate = year+"-12-31"
    val prevYearStDate = year.toInt-1 +"-01-01"
    val prevYearEndDate = year.toInt-1 +"-12-31"
    val nineYearStDate = year.toInt-9 +"-01-01"
    val yearNovDate = year+"-11-01"
    val july1Date = year.toInt-1 +"-07-01"
    val june30Date = year+"-06-30"
    val jobId = spark.sparkContext.applicationId
    val baseDir = baseMsrPath + "/" + jobId
    val outDir = baseDir + "/Out"
    val intermediateDir = baseDir + "/Intermediate"

    //</editor-fold>

    //<editor-fold desc="Loading Required Tables to memory">


    val aLiat = List("col1")
    val msrVal = s"'$measureId'"
    val imamsrVal = s"'${KpiConstants.imaMeasureId}'"
    val ggMsrId = s"'${KpiConstants.ggMeasureId}'"
    val lobList = List(KpiConstants.medicaidLobName, KpiConstants.mmpLobName,KpiConstants.commercialLobName,KpiConstants.medicareLobName)
    val claimStatusList = List(KpiConstants.paidVal, KpiConstants.suspendedVal, KpiConstants.pendingVal, KpiConstants.deniedVal)

    val memqueryString = s"""SELECT * FROM ${KpiConstants.dbName}.${KpiConstants.membershipTblName} WHERE measure = $msrVal AND (member_plan_start_date IS  NOT NULL) AND(member_plan_end_date IS NOT NULL)"""
    val membershipDf = DataLoadFunctions.dataLoadFromHiveStageTable(spark,KpiConstants.dbName,KpiConstants.membershipTblName,memqueryString,aLiat)
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .repartition(1)

    val visitqueryString = s"""SELECT * FROM ${KpiConstants.dbName}.${KpiConstants.visitTblName} WHERE measure = $msrVal and  (service_date IS  NOT NULL) AND((admit_date IS NULL and discharge_date IS NULL) OR (ADMIT_DATE IS NOT NULL AND DISCHARGE_DATE IS NOT NULL))"""
    val visitsDf = DataLoadFunctions.dataLoadFromHiveStageTable(spark,KpiConstants.dbName,KpiConstants.visitTblName,visitqueryString,aLiat)
      .filter((($"${KpiConstants.dataSourceColName}".===("Claim"))&&($"${KpiConstants.claimstatusColName}".isin(claimStatusList:_*)))
        ||($"${KpiConstants.dataSourceColName}".===("RxClaim"))
        ||($"${KpiConstants.dataSourceColName}".===("Rx"))
        || ($"${KpiConstants.dataSourceColName}".===("Lab"))
        || ($"${KpiConstants.dataSourceColName}".===("Obs")))
      .drop(KpiConstants.lobProductColName, "latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name","product")
      .withColumn(KpiConstants.revenuecodeColName, when((length($"${KpiConstants.revenuecodeColName}").as[Int].===(3)),concat(lit("0" ),lit($"${KpiConstants.revenuecodeColName}"))).otherwise($"${KpiConstants.revenuecodeColName}"))
      .withColumn(KpiConstants.billtypecodeColName, when((length($"${KpiConstants.billtypecodeColName}").as[Int].===(3)),concat(lit("0" ),lit($"${KpiConstants.billtypecodeColName}"))).otherwise($"${KpiConstants.billtypecodeColName}"))
      .withColumn(KpiConstants.proccode2ColName, when(($"${KpiConstants.proccode2mod1ColName}".isin(KpiConstants.avoidCodeList:_*)) || ($"${KpiConstants.proccode2mod2ColName}".isin(KpiConstants.avoidCodeList:_*)),lit("NA")).otherwise($"${KpiConstants.proccode2ColName}"))
      .repartition(3)

    val medmonmemqueryString = s"""SELECT * FROM ${KpiConstants.dbName}.${KpiConstants.medmonmemTblName} WHERE measure = $msrVal"""
    val medmonmemDf = DataLoadFunctions.dataLoadFromHiveStageTable(spark,KpiConstants.dbName,KpiConstants.medmonmemTblName,medmonmemqueryString,aLiat)
      .filter(($"run_date".>=(yearStartDate)) && ($"run_date".<=(yearEndDate)))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .repartition(1)

    val refHedisqueryString =s"""SELECT * FROM  ${KpiConstants.dbName}.${KpiConstants.refHedisTblName} WHERE measureid = $msrVal OR measureid= $ggMsrId"""
    val refHedisDf = DataLoadFunctions.dataLoadFromHiveStageTable(spark,KpiConstants.dbName,KpiConstants.medmonmemTblName,refHedisqueryString,aLiat)
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")


    val refMedqueryString = s"""SELECT * FROM  ${KpiConstants.dbName}.${KpiConstants.refmedValueSetTblName} WHERE measure_id = $msrVal"""
    val ref_medvaluesetDf = DataLoadFunctions.dataLoadFromHiveStageTable(spark,KpiConstants.dbName,KpiConstants.medmonmemTblName,refMedqueryString,aLiat)
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")




    val refHedisqueryStringForIma =s"""SELECT * FROM  ${KpiConstants.dbName}.${KpiConstants.refHedisTblName} WHERE measureid = $imamsrVal"""
    val refHedisDf_Ima = DataLoadFunctions.dataLoadFromHiveStageTable(spark,KpiConstants.dbName,KpiConstants.medmonmemTblName,refHedisqueryStringForIma,aLiat)
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")

    // println("counts:"+membershipDf.count()+","+ visitsDf.count()+","+medmonmemDf.count() +","+refHedisDf.count()+","+ref_medvaluesetDf.count())

    //</editor-fold

    //<editor-fold desc="Eligible Population Calculation">

    //<editor-fold desc=" Age filter">

    val ageEndDate = year + "-12-31"
    val ageStartDate = year + "-01-01"

    val ageFilterDf = membershipDf.filter(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",KpiConstants.months480).<=(ageEndDate)
      && UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",KpiConstants.months912).>(ageEndDate))


    val sn2Members = ageFilterDf.filter(($"${KpiConstants.lobProductColName}".===(KpiConstants.lobProductNameConVal))
      &&(((($"${KpiConstants.memStartDateColName}".>=(yearStartDate)) && ($"${KpiConstants.memStartDateColName}".<=(yearEndDate)))
      ||(($"${KpiConstants.memEndDateColName}".>=(yearStartDate)) && ($"${KpiConstants.memEndDateColName}".<=(yearEndDate))))
      || ((($"${KpiConstants.memStartDateColName}".<(yearStartDate)) && ($"${KpiConstants.memEndDateColName}".>(yearEndDate)))))
      &&(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}", KpiConstants.months792).<=(yearEndDate))
    ).select(KpiConstants.memberidColName).rdd.map(r => r.getString(0)).collect()
    val sn2RemovedMemDf = ageFilterDf.except(ageFilterDf.filter($"${KpiConstants.memberidColName}".isin(sn2Members:_*)))

    //</editor-fold>

    //<editor-fold desc="Continuous Enrollment, Allowable Gap Calculation">

    val inputForContEnrolldf = sn2RemovedMemDf.select(KpiConstants.memberidColName, KpiConstants.benefitMedicalColname,KpiConstants.benefitdrugColName,
      KpiConstants.memStartDateColName,KpiConstants.memEndDateColName,KpiConstants.dateofbirthColName,
      KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName, KpiConstants.primaryPlanFlagColName)

    val mapForCeminus1y = mutable.Map("start_date" -> "2017-01-01", "end_date" -> "2017-12-31","gapcount" -> "1",
      "checkval" -> "false", "reqCovDays" -> "0")

    val ceOutminus1yDf = UtilFunctions.contEnrollAndAllowableGapFilterFunction(spark,inputForContEnrolldf,mapForCeminus1y)

    ceOutminus1yDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite).parquet(intermediateDir+ "/CEForFirstYear/")

    val ceOutMinus1y = spark.read.parquet(intermediateDir+ "/CEForFirstYear/").cache()

    val mapForCeCurrYear = mutable.Map("start_date" -> "2018-01-01", "end_date" -> "2018-12-31","gapcount" -> "1",
      "checkval" -> "true","reqCovDays" -> "0","anchor_date" -> "2018-12-31")

    val contEnrollInputDf = UtilFunctions.contEnrollAndAllowableGapFilterFunction(spark,ceOutMinus1y,mapForCeCurrYear)
      .select(KpiConstants.memberidColName, KpiConstants.dateofbirthColName, KpiConstants.memStartDateColName, KpiConstants.memEndDateColName,
        KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.primaryPlanFlagColName, KpiConstants.payerColName)

    contEnrollInputDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/contEnrollInputDf/")

    val contEnrollDf = spark.read.parquet(intermediateDir+ "/contEnrollInputDf/").cache()

    //</editor-fold>

    //<editor-fold desc="Dual Enrollment and SPD Lob filter">

    val baseOutInputDf = UtilFunctions.baseOutDataframeCreation(spark, contEnrollDf, lobList,measureId)

    baseOutInputDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/baseOutInputDf/")

    val baseOutInDf = spark.read.parquet(intermediateDir+ "/baseOutInputDf/").cache()

    val medicareContEnrollDf = baseOutInDf.filter($"${KpiConstants.lobColName}".===(KpiConstants.medicareLobName))

    val medicareHospiceDf = medicareContEnrollDf.as("df1").join(medmonmemDf.as("df2"), Seq(KpiConstants.memberidColName))
      .groupBy(KpiConstants.memberidColName).agg(countDistinct(when($"${KpiConstants.hospiceFlagColName}".===(KpiConstants.yesVal),1)).alias(KpiConstants.countColName))
      .filter($"${KpiConstants.countColName}".>(0))
      .select(KpiConstants.memberidColName).rdd.map(r=> r.getString(0)).collect()

    val baseHospRemDf =  baseOutInDf.except(baseOutInDf.filter(($"${KpiConstants.memberidColName}".isin(medicareHospiceDf:_*))))



    val medicareLtiInDf = baseHospRemDf.as("df1").join(medmonmemDf.as("df2"),
      $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .filter(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}", KpiConstants.months792).<=(yearEndDate))
      .select(s"df1.${KpiConstants.memberidColName}", KpiConstants.ltiFlagColName)
    // .select(s"df2")



    val medicareLtiDf =  medicareLtiInDf
      .groupBy(KpiConstants.memberidColName).agg(count(when($"${KpiConstants.ltiFlagColName}".===(KpiConstants.yesVal),1)).alias(KpiConstants.countColName))
      .filter($"${KpiConstants.countColName}".>=(1))
      .select(KpiConstants.memberidColName).rdd.map(r => r.getString(0)).collect()

    val baseOutDf =  baseHospRemDf.except(baseHospRemDf.filter(($"${KpiConstants.memberidColName}".isin(medicareLtiDf:_*))
      &&(($"${KpiConstants.lobColName}".===(KpiConstants.medicareLobName)) ||($"${KpiConstants.lobColName}".===(KpiConstants.mmpLobName)))
    ))


    //val baseOutDf = baseOutInDf.except(baseOutInDf.filter($"${KpiConstants.memberidColName}".isin(medicareHospiceDf:_*)))

    val payerlist = List(KpiConstants.sn1PayerVal,KpiConstants.sn2PayerVal,KpiConstants.sn3PayerVal,KpiConstants.mmpPayerVal)

    val spdbaseOutDf = baseOutDf.filter($"${KpiConstants.lobColName}".isin(lobList:_*) && (!$"${KpiConstants.payerColName}".isin(payerlist:_*))
    ).dropDuplicates(). cache()

    spdbaseOutDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/spdbaseOutDf/")

    val spdContEnrollDf = spark.read.parquet(intermediateDir+ "/spdbaseOutDf/").cache()

    //</editor-fold>

    //<editor-fold desc="Initial Join with Ref_Hedis">

    val argmapforRefHedis = mutable.Map(KpiConstants.eligibleDfName -> visitsDf , KpiConstants.refHedisTblName -> refHedisDf,
      KpiConstants.refmedValueSetTblName -> ref_medvaluesetDf)
    val allValueList = List(KpiConstants.independentLabVal,KpiConstants.hospiceVal,KpiConstants.cellulitisVal,KpiConstants.otherRevascularizationVal,
      KpiConstants.schizophreniaVal,KpiConstants.bipolarDisorderVal,KpiConstants.ldlcTestsVal,KpiConstants.otherBipolarDisorder,KpiConstants.esrdVal,
      KpiConstants.cabgVal,KpiConstants.nonacuteInpatientPosVal,KpiConstants.edPosVal,KpiConstants.acuteInpatientVal,KpiConstants.fralityVal,
      KpiConstants.partialHospitalizationIntensiveOutpatientVal,KpiConstants.communityMentalHealthCenterPosVal,KpiConstants.acuteInpatientPosVal,
      KpiConstants.diabetesExclusionVal,KpiConstants.pciVal,KpiConstants.telehealthPosVal,KpiConstants.nonAcuteInPatientVal,KpiConstants.ivdVal,
      KpiConstants.outpatientPosVal,KpiConstants.bhOutpatientVal,KpiConstants.partialHospitalizationPosVal,KpiConstants.observationVal,KpiConstants.inPatientStayVal,
      KpiConstants.onlineAssesmentVal,KpiConstants.amiVal,KpiConstants.diabetesVal ,KpiConstants.muscularPainAndDiseaseval,KpiConstants.dementiaMedicationVal,
      KpiConstants.advancedIllVal,KpiConstants.pregnancyVal,KpiConstants.cirrhossisVal,KpiConstants.miVal,KpiConstants.edVal,KpiConstants.ivfVal,
      KpiConstants.telehealthModifierVal,KpiConstants.visitSettingUnspecifiedVal,KpiConstants.telephoneVisitsVal,KpiConstants.outPatientVal)

    val medList =List(KpiConstants.diabetesMedicationVal,KpiConstants.estrogenAgonistsMediVal,KpiConstants.dementiaMedicationVal,
      KpiConstants.highAndModerateStatinMedVal,KpiConstants.lowStatinMedVal)

    val visitRefHedisInDf = UtilFunctions.joinWithRefHedisFunction(spark,argmapforRefHedis,allValueList,medList)

    //</editor-fold>

    //<editor-fold desc="Removal of Independent Lab Visits">

    val groupList = visitsDf.schema.fieldNames.toList.dropWhile(p=> p.equalsIgnoreCase(KpiConstants.memberidColName))
    val visitgroupedDf = visitRefHedisInDf.groupBy(KpiConstants.memberidColName, groupList:_*).agg(collect_list(KpiConstants.valuesetColName)
      .alias(KpiConstants.valuesetColName)).select(KpiConstants.memberidColName, KpiConstants.serviceDateColName, KpiConstants.claimstatusColName,
      KpiConstants.dischargeDateColName,KpiConstants.dataSourceColName, KpiConstants.dobColName,KpiConstants.supplflagColName ,
      KpiConstants.valuesetColName,KpiConstants.genderColName,KpiConstants.ndcCodeColName,KpiConstants.rxdayssuppliedColName)

    val indLabVisRemDf = visitgroupedDf.filter((!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))).repartition(2).cache()
    val membertotalDf = spdContEnrollDf.dropDuplicates()
    val argmapForVisittJoin = mutable.Map(KpiConstants.membershipTblName -> membertotalDf , KpiConstants.visitTblName -> indLabVisRemDf)
    val visitJoinedOutDf = UtilFunctions.initialJoinFunction(spark,argmapForVisittJoin)


    visitJoinedOutDf.coalesce(3)
      .write
      .mode(SaveMode.Append)
      .parquet(intermediateDir+ "/visitJoinedOutDf")

    visitJoinedOutDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .json(intermediateDir+ "/visitJoinedOutDf_json")

    val visitJoinDf = spark.read.parquet(intermediateDir+ "/visitJoinedOutDf").repartition(2).cache()
    indLabVisRemDf.unpersist()

    //</editor-fold>

    //<editor-fold desc="Hospice Removal">

    val hospiceInCurrYearMemDf = indLabVisRemDf.filter(
      (!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))  &&
        (array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hospiceVal))
        && ($"${KpiConstants.serviceDateColName}".>=(yearStartDate) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))


    val hospicefinaldf =   hospiceInCurrYearMemDf.select(KpiConstants.memberidColName)
      .dropDuplicates()


    val hospiceremovalDf = visitJoinDf.except(visitJoinDf.filter($"${KpiConstants.memberidColName}".isin(
      hospicefinaldf.rdd.map(r=>r.getString(0)).collect():_*
    )))


    hospiceremovalDf.coalesce(3)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/hospiceremovalDf/")

    /*
     hospiceremovalDf.coalesce(1)
       .write
       .mode(SaveMode.Append)
       .parquet(intermediateDir+ "/hospiceremovalDf")

     val hosiceremovalDf = spark.read.parquet(intermediateDir+ "/hospiceremovalDf").repartition(2).cache()
     */

    //</editor-fold>

    //</editor-fold>

    //TODO : R.EXCL is passed.
    //<editor-fold desc="Events Calculation">

    val hosiceremovalDf = spark.read.parquet(intermediateDir+ "/hospiceremovalDf/").cache()

    val eventsVisitsDf = hosiceremovalDf.filter($"${KpiConstants.supplflagColName}".===("N")).cache()

    //<editor-fold desc="Event Step - 1">

    //<editor-fold desc="Part - 1">

    val event1StepDf = eventsVisitsDf
      .filter(((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.acuteInpatientVal))
        && (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabetesVal)))
        &&((!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
        &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal))))
        &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
        &&(($"${KpiConstants.serviceDateColName}".>=(prevYearStDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))
        )) .select(KpiConstants.memberidColName )
      .repartition(2).cache()


    //</editor-fold>

    //<editor-fold desc="Part - 2">

    val schievent2Df = eventsVisitsDf
      .filter((((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal))
        ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.observationVal))
        ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.edVal))
        ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.nonAcuteInPatientVal)))
        && (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabetesVal)))
        &&((!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
        &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal))
        &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telephoneVisitsVal))
        &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.onlineAssesmentVal))))
        &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
        &&(($"${KpiConstants.serviceDateColName}".>=(prevYearStDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))
        )) .select(KpiConstants.memberidColName,KpiConstants.serviceDateColName)
      .repartition(2).cache()


    val step2Df = schievent2Df

    val schievent2MemVisits1Df = step2Df.groupBy(KpiConstants.memberidColName)
      .agg(countDistinct(KpiConstants.serviceDateColName).alias(KpiConstants.countColName))


    val schievent2_1Df = schievent2MemVisits1Df.filter($"${KpiConstants.countColName}".>=(2))

    val schievent2_1MemDf = schievent2_1Df.select(KpiConstants.memberidColName)

    val oneVisitInDf = schievent2MemVisits1Df.select(KpiConstants.memberidColName).except(schievent2_1MemDf).as("df1").join(eventsVisitsDf.as("df2"),
      $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType).select("df2.*")


    val event1Step3Df= oneVisitInDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal)))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabetesVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)

    val event1Step3MemDf = event1Step3Df.select(KpiConstants.memberidColName)

    val event1Step4Df = oneVisitInDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telephoneVisitsVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.onlineAssesmentVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabetesVal)))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)

    val event1Step4MemDf = event1Step4Df.select(KpiConstants.memberidColName)

    val event2StepDf = schievent2_1MemDf.union(event1Step3MemDf).union(event1Step4MemDf)


    //</editor-fold>

    //<editor-fold desc="Part - 3">

    val event3Step1Df = eventsVisitsDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabetesMedicationVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
      &&(($"${KpiConstants.serviceDateColName}".>=(prevYearStDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
      .select(KpiConstants.memberidColName ).repartition(2).cache()

    //</editor-fold>

    val eventstep1Df = event3Step1Df.union(event2StepDf).union(event1StepDf).distinct()


    //</editor-fold>

    //<editor-fold desc="R Exclusion">

    val eventstep1InDf = eventstep1Df.as("df1").join(eventsVisitsDf.as("df2"),
      $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select("df2.*")

    //<editor-fold desc="Part - 1">

    val rexclstep1Df = eventstep1InDf.filter((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.inPatientStayVal))
      && (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.miVal)))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
      &&(($"${KpiConstants.dischargeDateColName}".>=(prevYearStDate)) &&($"${KpiConstants.dischargeDateColName}".<=(prevYearEndDate))))
      .select(KpiConstants.memberidColName )
      .repartition(2).cache()


    val rexclstep2Df = eventstep1InDf
      .filter((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.cabgVal))
        || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.pciVal))
        || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.otherRevascularizationVal)))
        &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
        &&(($"${KpiConstants.serviceDateColName}".>=(prevYearStDate)) &&($"${KpiConstants.serviceDateColName}".<=(prevYearEndDate))))
      .select(KpiConstants.memberidColName ).repartition(2).cache()

    val rexclevent1Df = rexclstep1Df.union(rexclstep2Df)

    //</editor-fold>

    //<editor-fold desc="Part - 2">

    //<editor-fold desc=" Clean Visits">

    val cleanInDf1 = eventstep1InDf.filter((((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.acuteInpatientVal)))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ivdVal)))
      &&((!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telephoneVisitsVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.onlineAssesmentVal))))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
      &&(($"${KpiConstants.serviceDateColName}".>=(prevYearStDate)) &&($"${KpiConstants.serviceDateColName}".<=(prevYearEndDate))))
      .select(KpiConstants.memberidColName ,KpiConstants.serviceDateColName
      ).repartition(2).cache()

    val cleanDf1 = cleanInDf1.select(KpiConstants.memberidColName)

    val cleanInDf2 = eventstep1InDf.filter((((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.acuteInpatientVal)))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ivdVal)))
      &&((!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telephoneVisitsVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.onlineAssesmentVal))))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
      &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
      .select(KpiConstants.memberidColName ,KpiConstants.serviceDateColName
      ).repartition(2).cache()

    val cleanDf2 = cleanInDf2.select(KpiConstants.memberidColName)

    val cleanDf = cleanDf1.intersect(cleanDf2).distinct()

    //</editor-fold>

    //<editor-fold desc=" Dirty Visits">

    val dirtyInDf1= eventstep1InDf.filter(((((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
      || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal)))
      && (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal)))
      || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telephoneVisitsVal))
      || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.onlineAssesmentVal)))
      && (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ivdVal)))
      && (!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
      &&(($"${KpiConstants.serviceDateColName}".>=(prevYearStDate)) &&($"${KpiConstants.serviceDateColName}".<=(prevYearEndDate))))
      .select(KpiConstants.memberidColName , KpiConstants.serviceDateColName
      )

    val dirtyDf1 = dirtyInDf1.select(KpiConstants.memberidColName)


    /*
    val dirtyInDf2 = eventstep1InDf.filter(((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
      || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal))
      && (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal)))
      || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telephoneVisitsVal))
      || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.onlineAssesmentVal))
      && (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ivdVal)))
      && (!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
      &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
      .select(KpiConstants.memberidColName , KpiConstants.serviceDateColName)
     */

    val dirtyInDf2 = eventstep1InDf.filter(((((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
      || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal)))
      && (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal)))
      || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telephoneVisitsVal))
      || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.onlineAssesmentVal)))
      && (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ivdVal)))
      && (!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.independentLabVal)))
      &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
      .select(KpiConstants.memberidColName , KpiConstants.serviceDateColName)

    val dirtyDf2 = dirtyInDf2.select(KpiConstants.memberidColName)

    val clean2AndDirty1Df = dirtyDf1.intersect(cleanDf2).select(KpiConstants.memberidColName).distinct()

    val clean1AndDirty2Df = dirtyDf2.intersect(cleanDf1).select(KpiConstants.memberidColName).distinct()

    //</editor-fold>

    val rexclevent2Df = cleanDf.union(clean2AndDirty1Df).union(clean1AndDirty2Df)

    //</editor-fold>

    //<editor-fold desc="Part - 3">

    val rexclevent1PregDf = eventstep1InDf.filter((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.pregnancyVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      &&($"${KpiConstants.genderColName}".===(KpiConstants.femaleVal)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)

    val rexclevent1RestDf = eventstep1InDf.filter((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ivfVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.estrogenAgonistsMediVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.cirrhossisVal)))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)

    val rexclevent1Step5Df = rexclevent1PregDf.union(rexclevent1RestDf)

    /*

       val rexclevent1Step5Df= eventstep1InDf.filter(((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.pregnancyVal))
         ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ivfVal))
         ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.estrogenAgonistsMediVal))
         ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.cirrhossisVal)))
         &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)))
         &&($"${KpiConstants.serviceDateColName}".>=(PreYrStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
         &&($"${KpiConstants.genderColName}".===(KpiConstants.femaleVal)))
         .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)
    */

    val rexclevent3Df = rexclevent1Step5Df.select(KpiConstants.memberidColName)

    //</editor-fold>

    //<editor-fold desc="Part - 4">

    val rexclevent1Step6Df= eventstep1InDf.filter((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.esrdVal))
      &&((!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)


    val rexclevent4Df = rexclevent1Step6Df.select(KpiConstants.memberidColName)

    //</editor-fold>

    //<editor-fold desc="Part - 5">

    val rexclevent1Step7Df= eventstep1InDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.muscularPainAndDiseaseval))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)

    val rexclevent5Df = rexclevent1Step7Df.select(KpiConstants.memberidColName)


    //</editor-fold>

    val rexclFinalDf = rexclevent1Df.union(rexclevent2Df).union(rexclevent3Df).union(rexclevent4Df).union(rexclevent5Df).distinct()

    rexclFinalDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir+ "/rexclFinalDf")

    val rexclRdd = rexclFinalDf.select(KpiConstants.memberidColName).rdd.map(r => r.getString(0)).collect()

    //</editor-fold>

    //<editor-fold desc="Exclusion">

    val eventstep3Df =  eventstep1Df.as("df1").join(eventsVisitsDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
                                                     .select("df2.*")

    //<editor-fold desc="Exclusion Part 1">

    val exclPart1Df = eventstep3Df.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.fralityVal))
      &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      &&((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}", KpiConstants.months792).<=(yearEndDate))
      &&(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}", KpiConstants.months912).>(yearEndDate))))
      .select(KpiConstants.memberidColName).distinct()

    //</editor-fold>

    //<editor-fold desc="Exclusion Part 2">

    val outPatAndAdvIllDf = eventstep3Df.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.advancedIllVal)))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)

    val obsAndAdvIllDf = eventstep3Df.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.observationVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.advancedIllVal)))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)

    val edAndAdvIllDf = eventstep3Df.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.edVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.advancedIllVal)))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)

    val nAcuteInPatAndAdvIllDf = eventstep3Df.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.nonAcuteInPatientVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.advancedIllVal)))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)



    val mandatoryExcl3Sub21InDf = outPatAndAdvIllDf.union(obsAndAdvIllDf).union(edAndAdvIllDf).union(nAcuteInPatAndAdvIllDf)


    val exclPart2Df = mandatoryExcl3Sub21InDf.groupBy(KpiConstants.memberidColName).agg(countDistinct(KpiConstants.serviceDateColName).alias("count"))
      .filter($"count".>=(2)).select(KpiConstants.memberidColName)


    //</editor-fold>

    //<editor-fold desc="Exclusion Part 3">

    val exclPart3Df = eventstep3Df.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.acuteInpatientVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.advancedIllVal))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)

    //</editor-fold>

    //<editor-fold desc="Exclusion Part 4">

    val exclPart4Df = eventstep3Df.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.dementiaMedicationVal))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)

    //</editor-fold>

    val exclunionDf = exclPart2Df.union(exclPart3Df).union(exclPart4Df)

    val exclusionDf = exclPart1Df.intersect(exclunionDf)


    exclusionDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir+ "/exclusionDf")

    val exclusionRdd = exclusionDf.select(KpiConstants.memberidColName).rdd.map(r => r.getString(0)).collect()

    //</editor-fold>

    //</editor-fold>

    //TODO : EPOP is passed.
    //<editor-fold desc="Denominator Calculation">

    //<editor-fold desc="EPOP Calculation">

    val epopDf = eventstep1Df.except(eventstep1Df.filter($"${KpiConstants.memberidColName}".isin(exclusionRdd:_*))).distinct()

    epopDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir+ "/Epop")


    val totalEligDf = epopDf.as("df1").join(hosiceremovalDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
                        .select($"df2.*")

    //<editor-fold desc="Stratification Code">

    val toutStratDf = totalEligDf.select($"${KpiConstants.memberidColName}".as(KpiConstants.ncqaOutmemberIdCol), $"${KpiConstants.payerColName}".as(KpiConstants.ncqaOutPayerCol)).distinct()
                                 .withColumn(KpiConstants.ncqaOutMeasureCol, lit(KpiConstants.spdaMeasureId))

    toutStratDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir + "/toutStratDf")


    //</editor-fold>


    //</editor-fold>

    //<editor-fold desc="Numerator Input Genaration">

    val tempDenomOutDf = epopDf.except(epopDf.filter($"${KpiConstants.memberidColName}".isin(rexclRdd:_*)))

    val denominatorDf = tempDenomOutDf.select(KpiConstants.memberidColName).distinct()


    denominatorDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .parquet(intermediateDir+ "/denominatorDf")

    //</editor-fold>

    //</editor-fold>

    //<editor-fold desc="Numerator Calculation">

    val tempDenomDf = spark.read.parquet(intermediateDir+ "/denominatorDf").cache()
    // tempDenomDf = Epop - R.Exclusion

    val validvisitsDf = tempDenomDf.as("df1").join(hosiceremovalDf.as("df2"),
      $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select($"df2.*")


    validvisitsDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/validvisitsDf/")

    val totalDf = spark.read.parquet(intermediateDir+ "/validvisitsDf/").cache()
    val totalNumInDf = totalDf

    totalNumInDf.coalesce(1).write.mode(SaveMode.Append).json(outDir+ "/totalNonSuppRate1Df_json")


    //<editor-fold desc="SPDA (Numerator 1) Calculation">

    val totalNonSuppRate1Df = totalNumInDf.filter($"${KpiConstants.supplflagColName}".===("N")).cache()
    totalNonSuppRate1Df.count()

    //<editor-fold desc="SPDA Rate 1 Non Supp Numerator Calculation">

    val numNonSuppRate1Df = totalNonSuppRate1Df.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.highAndModerateStatinMedVal))
                                                      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.lowStatinMedVal)))
      //&&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)))
      &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
      .select(KpiConstants.memberidColName)


    //</editor-fold>

    //<editor-fold desc="SPDA Rate 1 Other Data Numerator Calculation">

    val numOtherDataInputDf = totalNumInDf.except(totalNumInDf
      .filter($"${KpiConstants.memberidColName}".isin(numNonSuppRate1Df.rdd.map(r=> r.getString(0)).collect():_*)))

    val numOtherRate1Df = numOtherDataInputDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.highAndModerateStatinMedVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.lowStatinMedVal)))
      //&&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)))
      &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
      .select(KpiConstants.memberidColName)


    //</editor-fold>

    val spadaTmpNum = numNonSuppRate1Df.union(numOtherRate1Df).distinct()

    spadaTmpNum.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir + "/spadaTmpNum")

    //</editor-fold>

    //<editor-fold desc="SPDB (Numerator 2) Calculation">

    val totalNumInNdcDf = totalNumInDf.select(KpiConstants.memberidColName,KpiConstants.ndcCodeColName,KpiConstants.valuesetColName,KpiConstants.dataSourceColName,
                                              KpiConstants.serviceDateColName,KpiConstants.rxdayssuppliedColName, KpiConstants.supplflagColName).distinct()

    val totalRate2Df = totalNumInNdcDf.as("df1").join(ref_medvaluesetDf.as("df2"), $"df1.${KpiConstants.ndcCodeColName}" === $"df2.${KpiConstants.ndcCodeColName}", KpiConstants.innerJoinType)
                                                              .select(s"df1.${KpiConstants.memberidColName}",s"df2.${KpiConstants.drugIdColName}",s"df1.${KpiConstants.valuesetColName}",
                                                                            s"df1.${KpiConstants.serviceDateColName}",s"df1.${KpiConstants.rxdayssuppliedColName}",s"df1.${KpiConstants.dataSourceColName}", s"df1.${KpiConstants.supplflagColName}")


    val numRate2InDf = totalRate2Df.filter((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.highAndModerateStatinMedVal))
                                          ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.lowStatinMedVal)))
                                          &&($"${KpiConstants.dataSourceColName}".===("RxClaim")))
                                          &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate))
                                            &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))

    val memIpsdDf = numRate2InDf.groupBy(KpiConstants.memberidColName).agg(min(KpiConstants.serviceDateColName).alias(KpiConstants.ipsdDateColName))

    //<editor-fold desc="SPDB Rate 2 Numerator Non Supplement Calculation">



    val nonSupinDf = numRate2InDf.filter($"${KpiConstants.supplflagColName}".===("N"))
                           .withColumn(KpiConstants.dateColName, lit(datediff($"${KpiConstants.serviceDateColName}", lit(yearStartDate).cast(DateType)) +1 ).cast(IntegerType))
                           .withColumn(KpiConstants.rxdayssuppliedColName, when(datediff(lit(yearEndDate).cast(DateType), $"${KpiConstants.serviceDateColName}").<($"${KpiConstants.rxdayssuppliedColName}"), lit(datediff(lit(yearEndDate).cast(DateType), $"${KpiConstants.serviceDateColName}")).cast(IntegerType))
                                                                          .otherwise($"${KpiConstants.rxdayssuppliedColName}".cast(IntegerType)))
                           .select(KpiConstants.memberidColName, KpiConstants.drugIdColName, KpiConstants.dateColName, KpiConstants.rxdayssuppliedColName)


    val nonSupcovDf = nonSupinDf.groupBy(KpiConstants.memberidColName, KpiConstants.drugIdColName).agg(sum($"${KpiConstants.rxdayssuppliedColName}").alias(KpiConstants.totalDaysColName))

    val nonSupjoinedDf = nonSupinDf.as("df1").join(nonSupcovDf.as("df2"), Seq(KpiConstants.memberidColName, KpiConstants.drugIdColName), KpiConstants.innerJoinType)
                                                    .select(KpiConstants.memberidColName, KpiConstants.drugIdColName, KpiConstants.dateColName, KpiConstants.rxdayssuppliedColName, KpiConstants.totalDaysColName)

    val nonSupresDf = UtilFunctions.drug_function(spark,nonSupjoinedDf)

    val ipsdAddedNonSupResDf = nonSupresDf.as("df1").join(memIpsdDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
                                                           .select(s"df1.${KpiConstants.memberidColName}", s"df1.${KpiConstants.totalDaysColName}", s"df2.${KpiConstants.ipsdDateColName}")
    val spdbtmpNonSupDf = ipsdAddedNonSupResDf.withColumn(KpiConstants.rateColName , lit(($"${KpiConstants.totalDaysColName}"./(datediff(lit(yearEndDate).cast(DateType), $"${KpiConstants.ipsdDateColName}"))) * lit(100)))
                                              .filter($"${KpiConstants.rateColName}".>=(lit(79.5f)))
                                              .select(KpiConstants.memberidColName)

    //</editor-fold>

    //<editor-fold desc="SPDB Rate 2 Numerator Non Supplement Calculation">

    val otherinDf = numRate2InDf.except(numRate2InDf.filter($"${KpiConstants.memberidColName}".isin(spdbtmpNonSupDf.rdd.map(r => r.getString(0)).collect():_*)))
                                .withColumn(KpiConstants.dateColName, lit(datediff($"${KpiConstants.serviceDateColName}", lit(yearStartDate).cast(DateType)) +1 ).cast(IntegerType))
                                .withColumn(KpiConstants.rxdayssuppliedColName, when(datediff(lit(yearEndDate).cast(DateType), $"${KpiConstants.serviceDateColName}").<($"${KpiConstants.rxdayssuppliedColName}"), lit(datediff(lit(yearEndDate).cast(DateType), $"${KpiConstants.serviceDateColName}")).cast(IntegerType))
                                                                                .otherwise($"${KpiConstants.rxdayssuppliedColName}".cast(IntegerType)))
                                .select(KpiConstants.memberidColName, KpiConstants.drugIdColName, KpiConstants.dateColName, KpiConstants.rxdayssuppliedColName)


    val othercovDf = otherinDf.groupBy(KpiConstants.memberidColName, KpiConstants.drugIdColName).agg(sum($"${KpiConstants.rxdayssuppliedColName}").alias(KpiConstants.totalDaysColName))

    val otherjoinedDf = otherinDf.as("df1").join(othercovDf.as("df2"), Seq(KpiConstants.memberidColName, KpiConstants.drugIdColName), KpiConstants.innerJoinType)
      .select(KpiConstants.memberidColName, KpiConstants.drugIdColName, KpiConstants.dateColName, KpiConstants.rxdayssuppliedColName, KpiConstants.totalDaysColName)


    val otherresDf = UtilFunctions.drug_function(spark,otherjoinedDf)

    val ipsdAddedOtherResDf = otherresDf.as("df1").join(memIpsdDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
                                                  .select(s"df1.${KpiConstants.memberidColName}", s"df1.${KpiConstants.totalDaysColName}", s"df2.${KpiConstants.ipsdDateColName}")

    val spdbtmpOtherDf = ipsdAddedOtherResDf.withColumn(KpiConstants.rateColName , lit(($"${KpiConstants.totalDaysColName}"./(datediff(lit(yearEndDate).cast(DateType), $"${KpiConstants.ipsdDateColName}"))) * lit(100)))
                                            .filter($"${KpiConstants.rateColName}".>=(lit(79.5f)))
                                            .select(KpiConstants.memberidColName)


    //</editor-fold>

    val spdbNumeratorDf = spdbtmpNonSupDf.union(spdbtmpOtherDf)

    spdbNumeratorDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir + "/spdbNumeratorDf")


    //</editor-fold>

    //</editor-fold>

    //<editor-fold desc="Optional Exclusion Calculation">

    val numInterSectDf  = spadaTmpNum.intersect(spdbNumeratorDf)

    val optExclInDf = totalDf.except(totalDf.filter($"${KpiConstants.memberidColName}".isin(numInterSectDf.rdd.map(r=> r.getString(0)).collect():_*)))


    //<editor-fold desc="Optional Exclusion Non supplemmental Calculation">

    val optExclDiabMemDf = optExclInDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabetesVal))
                                                      &&(($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
                                                        &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
                                                  .select(KpiConstants.memberidColName)

    val optExclDiabSupMemDf = optExclInDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabetesVal))
                                                &&($"${KpiConstants.supplflagColName}".===("Y"))
                                              &&(($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
                                              &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
                                          .select(KpiConstants.memberidColName)

    val optExclNonSup_1Df = optExclInDf.select(KpiConstants.memberidColName).except(optExclDiabMemDf.except(optExclDiabSupMemDf))



    val optExclNonSup_2Df = optExclInDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabetesExclusionVal))
                                              &&($"${KpiConstants.supplflagColName}".===("N"))
                                                &&(($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
                                                &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
                                           .select(KpiConstants.memberidColName)

    val optExclNonSupDf = optExclNonSup_1Df.intersect(optExclNonSup_2Df)
    //</editor-fold>

    //<editor-fold desc="Optional Exclusion Other Calculation">

    val optExclOtherVisitsDf = optExclInDf.except(optExclInDf.filter($"${KpiConstants.memberidColName}".isin(optExclNonSupDf.rdd.map(r => r.getString(0)).collect():_*)))


    val optExclDiabOtherMemDf = optExclOtherVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabetesVal))
                                                &&(($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
                                                &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
                                           .select(KpiConstants.memberidColName)

    val optExclOther_1Df = optExclOtherVisitsDf.select(KpiConstants.memberidColName).except(optExclDiabOtherMemDf)


    val optExclOther_2Df = optExclOtherVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.diabetesExclusionVal))
                                                     &&(($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
                                                     &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))
                                                .select(KpiConstants.memberidColName)

    val optExclOtherDf = optExclOther_1Df.intersect(optExclOther_2Df)
    //</editor-fold>


    val optExclDf = optExclNonSupDf.union(optExclOtherDf)

    optExclDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir + "/optExclDf")

    //</editor-fold>



    val spdaNumDf = spadaTmpNum.except(optExclDf)

   /* spdaNumDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir + "/spdaNumDf")*/


    val spdbNumDf = spdbNumeratorDf.except(optExclDf)

   /* spdbNumDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir + "/spdbNumDf")*/


    val outMap = mutable.Map(KpiConstants.totalPopDfName -> toutStratDf, KpiConstants.eligibleDfName -> toutStratDf.select(KpiConstants.ncqaOutmemberIdCol),
      KpiConstants.mandatoryExclDfname -> rexclFinalDf, KpiConstants.optionalExclDfName -> optExclDf, KpiConstants.numeratorDfName -> spdaNumDf,
      KpiConstants.numerator2DfName -> spdbNumDf, KpiConstants.numerator3DfName -> spadaTmpNum)


    val outDf = UtilFunctions.ncqaOutputDfCreation(spark,outMap,measureId)
    outDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir+ "/outDf")

    /*

    //<editor-fold desc="Deleting the intermediate Files">

    val fileSystem = FileSystem.get(spark.sparkContext.hadoopConfiguration)
    fileSystem.delete(new Path(intermediateDir), true)
    //</editor-fold>


    */

    spark.sparkContext.stop()

  }
}
