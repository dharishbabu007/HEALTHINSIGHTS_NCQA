package com.itc.ncqa.main

import java.text.SimpleDateFormat
import java.util.Date
import java.util.concurrent.TimeUnit

import com.itc.ncqa.Constants.KpiConstants
import com.itc.ncqa.Functions.{DataLoadFunctions, UtilFunctions}
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.SparkConf
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.sql.functions._

import scala.collection.JavaConversions._
import scala.collection.mutable


object NcqaOMW extends  Serializable {

  def main(args: Array[String]): Unit = {


    //<editor-fold desc="Reading program arguments and SaprkSession oBject creation">

    val year = args(0)
    val measureId = args(1)
    val dbName = args(2)
    val baseMsrPath = args(3)

    /*calling function for setting the dbname for dbName variable*/
    KpiConstants.setDbName(dbName)
    val conf = new SparkConf().setAppName("NcqaProgram")
    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      .set("hive.exec.dynamic.partition.mode", "nonstrict")
      .set("spark.sql.shuffle.partitions","5")

    val ncqa_date_add = udf((date:String, days:String) => {

      val daysAdd = if(days == null || days.equals("") || days.equals("null")) "0" else days
      val sdf = new SimpleDateFormat("yyyy-MM-dd")
      val resultDate = new Date(sdf.parse(date).getTime() + TimeUnit.DAYS.toMillis(daysAdd.toInt))
      sdf.format(resultDate)
    })


    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    import spark.implicits._

    val yearStartDate = year+"-01-01"
    val yearEndDate = year+"-12-31"
    val prevYearStDate = year.toInt-1 +"-01-01"
    val prevYearEndDate = year.toInt-1 +"-12-31"
    val yearNovDate = year+"-11-01"
    val oct1Date = year.toInt-2 +"-10-01"
    val jul1Date = year.toInt-1 +"-07-01"
    val june30Date = year +"-06-30"
    val jobId = spark.sparkContext.applicationId
    val baseDir = baseMsrPath + "/" + jobId
    val outDir = baseDir + "/Out"
    val intermediateDir = baseDir + "/Intermediate"

    //</editor-fold>

    //<editor-fold desc="Loading Required Tables to memory">


    val aLiat = List("col1")
    val msrVal = s"'$measureId'"
    val ggMsrId = s"'${KpiConstants.ggMeasureId}'"
    val lobList = List(KpiConstants.medicareLobName, KpiConstants.mmpLobName)
    val claimStatusList = List(KpiConstants.paidVal, KpiConstants.suspendedVal, KpiConstants.pendingVal, KpiConstants.deniedVal)

    val memqueryString = s"""SELECT * FROM ${KpiConstants.dbName}.${KpiConstants.membershipTblName} WHERE measure = $msrVal AND (member_plan_start_date IS  NOT NULL) AND(member_plan_end_date IS NOT NULL)"""
    val membershipDf = DataLoadFunctions.dataLoadFromHiveStageTable(spark,KpiConstants.dbName,KpiConstants.membershipTblName,memqueryString,aLiat)
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .repartition(1)

    val visitqueryString = s"""SELECT * FROM ${KpiConstants.dbName}.${KpiConstants.visitTblName} WHERE measure = $msrVal and  (service_date IS  NOT NULL) AND((admit_date IS NULL and discharge_date IS NULL) OR (ADMIT_DATE IS NOT NULL AND DISCHARGE_DATE IS NOT NULL))"""
    val visitsDf = DataLoadFunctions.dataLoadFromHiveStageTable(spark,KpiConstants.dbName,KpiConstants.visitTblName,visitqueryString,aLiat)
      .filter((($"${KpiConstants.dataSourceColName}".===("Claim"))&&($"${KpiConstants.claimstatusColName}".isin(claimStatusList:_*)))
        ||($"${KpiConstants.dataSourceColName}".===("RxClaim"))
        ||($"${KpiConstants.dataSourceColName}".===("Rx"))
        || ($"${KpiConstants.dataSourceColName}".===("Lab")))
      .drop(KpiConstants.lobProductColName, "latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name","product")
      .withColumn(KpiConstants.revenuecodeColName, when((length($"${KpiConstants.revenuecodeColName}").as[Int].===(3)),concat(lit("0" ),lit($"${KpiConstants.revenuecodeColName}"))).otherwise($"${KpiConstants.revenuecodeColName}"))
      .withColumn(KpiConstants.billtypecodeColName, when((length($"${KpiConstants.billtypecodeColName}").as[Int].===(3)),concat(lit("0" ),lit($"${KpiConstants.billtypecodeColName}"))).otherwise($"${KpiConstants.billtypecodeColName}"))
      .withColumn(KpiConstants.proccode2ColName, when(($"${KpiConstants.proccode2mod1ColName}".isin(KpiConstants.avoidCodeList:_*)) || ($"${KpiConstants.proccode2mod2ColName}".isin(KpiConstants.avoidCodeList:_*)),lit("NA")).otherwise($"${KpiConstants.proccode2ColName}"))
      .repartition(3)

    val medmonmemqueryString = s"""SELECT * FROM ${KpiConstants.dbName}.${KpiConstants.medmonmemTblName} WHERE measure = $msrVal"""
    val medmonmemDf = DataLoadFunctions.dataLoadFromHiveStageTable(spark,KpiConstants.dbName,KpiConstants.medmonmemTblName,medmonmemqueryString,aLiat)
      .filter(($"run_date".>=(yearStartDate)) && ($"run_date".<=(yearEndDate)))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .repartition(1)

    medmonmemDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .json(intermediateDir+ "/medmonmemDf/")



    val refHedisqueryString =s"""SELECT * FROM  ${KpiConstants.dbName}.${KpiConstants.refHedisTblName} WHERE measureid = $msrVal OR measureid= $ggMsrId"""
    val refHedisDf = DataLoadFunctions.dataLoadFromHiveStageTable(spark,KpiConstants.dbName,KpiConstants.medmonmemTblName,refHedisqueryString,aLiat)
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")


    val refMedqueryString = s"""SELECT * FROM  ${KpiConstants.dbName}.${KpiConstants.refmedValueSetTblName} WHERE measure_id = $msrVal"""
    val ref_medvaluesetDf = DataLoadFunctions.dataLoadFromHiveStageTable(spark,KpiConstants.dbName,KpiConstants.medmonmemTblName,refMedqueryString,aLiat)
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")


    // println("counts:"+membershipDf.count()+","+ visitsDf.count()+","+medmonmemDf.count() +","+refHedisDf.count()+","+ref_medvaluesetDf.count())

    //</editor-fold

    //<editor-fold desc="Age And Gender Filter">

    val ageAndGenderFilterDf = membershipDf.filter((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",KpiConstants.months804).<=(yearEndDate))
                                                &&(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",KpiConstants.months1032).>(yearEndDate))
                                                &&($"${KpiConstants.genderColName}".===(KpiConstants.femaleVal)))

    val sn2Members = ageAndGenderFilterDf.filter(($"${KpiConstants.lobProductColName}".===(KpiConstants.lobProductNameConVal))
                                              &&(((($"${KpiConstants.memStartDateColName}".>=(yearStartDate)) && ($"${KpiConstants.memStartDateColName}".<=(yearEndDate)))
                                              ||(($"${KpiConstants.memEndDateColName}".>=(yearStartDate)) && ($"${KpiConstants.memEndDateColName}".<=(yearEndDate))))
                                              || ((($"${KpiConstants.memStartDateColName}".<(yearStartDate)) && ($"${KpiConstants.memEndDateColName}".>(yearEndDate)))))
                                              &&(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}", KpiConstants.months804).<=(yearEndDate)))
                                        .select(KpiConstants.memberidColName).rdd.map(r => r.getString(0)).collect()
    val sn2RemovedMemDf = ageAndGenderFilterDf.except(ageAndGenderFilterDf.filter($"${KpiConstants.memberidColName}".isin(sn2Members:_*)))

    //</editor-fold>

    //<editor-fold desc="Initial Join with Ref_Hedis">

    val argmapforRefHedis = mutable.Map(KpiConstants.eligibleDfName -> visitsDf , KpiConstants.refHedisTblName -> refHedisDf,
                                        KpiConstants.refmedValueSetTblName -> ref_medvaluesetDf)

    val allValueList = List(KpiConstants.independentLabVal, KpiConstants.hospiceVal, KpiConstants.acuteInpatientVal,
                            KpiConstants.outPatientVal,KpiConstants.observationVal, KpiConstants.edVal,KpiConstants.fracturesVal,
                            KpiConstants.telehealthModifierVal, KpiConstants.telehealthPosVal, KpiConstants.inPatientStayVal,
                            KpiConstants.boneMinDenTestVal, KpiConstants.osteoporosisMedicationVal, KpiConstants.nonAcuteInPatientVal,
                            KpiConstants.telephoneVisitsVal, KpiConstants.onlineAssesmentVal, KpiConstants.fralityVal, KpiConstants.advancedIllVal,
                            KpiConstants.longActingOsteoMedicationVal)

    val medicationlList = List(KpiConstants.diabetesMedicationVal, KpiConstants.dementiaMedicationVal, KpiConstants.osteoprosisMedication)
    val visitRefHedisDf = UtilFunctions.joinWithRefHedisFunction(spark,argmapforRefHedis,allValueList,medicationlList)

    visitRefHedisDf
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/visitRefHedisDf/")

  /*  visitRefHedisDf.filter($"${KpiConstants.memberidColName}".isin(List("96118", "98602", "102634"):_*)).coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .json(intermediateDir+ "/visitRefHedisDf_json/")
*/
    //</editor-fold>

    //<editor-fold desc="Removal of Independent Lab Visits">

    val groupList = visitsDf.schema.fieldNames.toList.dropWhile(p=> p.equalsIgnoreCase(KpiConstants.memberidColName))
    val visitgroupedDf = spark.read.parquet(intermediateDir+ "/visitRefHedisDf/")
      .groupBy(KpiConstants.memberidColName, groupList:_*).agg(collect_set(KpiConstants.valuesetColName).alias(KpiConstants.valuesetColName))
      .select(KpiConstants.memberidColName,KpiConstants.dobColName, KpiConstants.serviceDateColName, KpiConstants.admitDateColName, KpiConstants.dischargeDateColName,
        KpiConstants.supplflagColName,KpiConstants.dataSourceColName, KpiConstants.provideridColName, KpiConstants.valuesetColName, KpiConstants.rxdayssuppliedColName)
      .repartition(2)


    visitgroupedDf.coalesce(2)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/visitgroupedDf/")


    val indLabVisRemDf = spark.read.parquet(intermediateDir+ "/visitgroupedDf/")
                              .filter((!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)))

   /* indLabVisRemDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .json(intermediateDir+ "/indLabVisRemDf_json/")
*/
    //</editor-fold>

    //<editor-fold desc="Hospice removal">

    val hospiceInCurrYearMemDf = indLabVisRemDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hospiceVal))
                                                     &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate))
                                                     &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
                                              .select(KpiConstants.memberidColName)
                                              .dropDuplicates()
                                              .rdd
                                              .map(r=> r.getString(0))
                                              .collect()

    val hospiceRemVisitsDf = indLabVisRemDf.except(indLabVisRemDf.filter($"${KpiConstants.memberidColName}".isin(hospiceInCurrYearMemDf:_*)))

    val joinedDf = hospiceRemVisitsDf.as("df1").join(sn2RemovedMemDf.as("df2"), $"df1.${KpiConstants.memberidColName}"=== $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
                                                      .select("df1.*", s"df2.${KpiConstants.memStartDateColName}", s"df2.${KpiConstants.memEndDateColName}", s"df2.${KpiConstants.lobColName}",
                                                                    s"df2.${KpiConstants.lobProductColName}", s"df2.${KpiConstants.payerColName}", s"df2.${KpiConstants.benefitMedicalColname}",
                                                                    s"df2.${KpiConstants.benefitdrugColName}", s"df2.${KpiConstants.primaryPlanFlagColName}", s"df2.${KpiConstants.dateofbirthColName}")
    joinedDf.coalesce(2)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/joinedDf/")

    joinedDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .json(intermediateDir+ "/joinedDf_json/")

    //</editor-fold>

    //<editor-fold desc="Eligible Population steps">

    val epopVisistsDf = spark.read.parquet(intermediateDir + "/joinedDf/")

    val epopVisitsInDf = epopVisistsDf.filter($"${KpiConstants.supplflagColName}".===("N"))


    //<editor-fold desc="Step1">

    //<editor-fold desc="Step1-A">

    val step1_A1Df = epopVisitsInDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.observationVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.edVal)))
      &&((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.fracturesVal)))
      &&((!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthPosVal)))
      &&($"${KpiConstants.serviceDateColName}".>=(jul1Date) && $"${KpiConstants.serviceDateColName}".<=(june30Date)))

    /*println("--------step1_A1Df-----------")
    step1_A1Df.show()*/

    val step1_A2Df = step1_A1Df.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.edVal))
      || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.observationVal)))
      &&($"${KpiConstants.serviceDateColName}".>=(jul1Date) && $"${KpiConstants.serviceDateColName}".<=(june30Date)))


   /* println("--------step1_A2Df-----------")
    step1_A2Df.show()*/

    val step1_A3Df = epopVisitsInDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.inPatientStayVal)))
      &&($"${KpiConstants.serviceDateColName}".>=(jul1Date) && $"${KpiConstants.serviceDateColName}".<=(june30Date)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName, KpiConstants.admitDateColName, KpiConstants.dischargeDateColName, KpiConstants.provideridColName)

   /* println("--------step1_A3Df-----------")
    step1_A3Df.show()*/

   /* val step1_A2A3JoinedDf = step1_A2Df.as("df1").join(step1_A3Df.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}"  , KpiConstants.innerJoinType)
      .filter(((($"df1.${KpiConstants.admitDateColName}".===($"df2.${KpiConstants.admitDateColName}")) || ($"df1.${KpiConstants.admitDateColName}".isNull))
        && (($"df1.${KpiConstants.dischargeDateColName}".===($"df2.${KpiConstants.dischargeDateColName}")) || ($"df1.${KpiConstants.dischargeDateColName}".isNull))
        && ($"df1.${KpiConstants.serviceDateColName}".===($"df2.${KpiConstants.serviceDateColName}"))
        &&($"df1.${KpiConstants.provideridColName}".=!=($"df2.${KpiConstants.provideridColName}")))
        || (($"df1.${KpiConstants.serviceDateColName}".>=(date_sub($"df2.${KpiConstants.admitDateColName}", 1)))
        &&(($"df1.${KpiConstants.serviceDateColName}".<($"df2.${KpiConstants.dischargeDateColName}")))
        &&($"df1.${KpiConstants.serviceDateColName}".=!=($"df2.${KpiConstants.serviceDateColName}"))))
      .select("df1.*")
*/

    val step1edToInpatDf = step1_A2Df.as("df1").join(step1_A3Df.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}"  , KpiConstants.innerJoinType)
      .filter((($"df1.${KpiConstants.serviceDateColName}".>=(date_sub($"df2.${KpiConstants.admitDateColName}", 1)))
        &&(($"df1.${KpiConstants.serviceDateColName}".<=($"df2.${KpiConstants.dischargeDateColName}")))))
      .select("df1.*")


   /* println("--------step1edToInpatDf-----------")
    step1edToInpatDf.filter($"${KpiConstants.memberidColName}".===("112979")).show()*/

    val step1edVisists = step1_A2Df.as("df1").join(step1_A3Df.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}"  , KpiConstants.innerJoinType)
      .filter(((($"df1.${KpiConstants.admitDateColName}".===($"df2.${KpiConstants.admitDateColName}")))
        && (($"df1.${KpiConstants.dischargeDateColName}".===($"df2.${KpiConstants.dischargeDateColName}")))
        && ($"df1.${KpiConstants.serviceDateColName}".===($"df2.${KpiConstants.serviceDateColName}"))
        &&($"df1.${KpiConstants.provideridColName}".===($"df2.${KpiConstants.provideridColName}"))))
      .select("df1.*")


    /*println("--------step1edVisists-----------")
    step1edVisists.filter($"${KpiConstants.memberidColName}".===("112979")).show()*/

    val step1_A2A3JoinedDf = step1edToInpatDf.as("df1").join(step1edVisists.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.leftOuterJoinType)
                                                              .filter($"df2.${KpiConstants.serviceDateColName}".isNull)
                                                              .select("df1.*")
  /*  println("--------step1_A2A3JoinedDf-----------")
    step1_A2A3JoinedDf.filter($"${KpiConstants.memberidColName}".===("112979")).show()*/




    val step1_ADf = step1_A1Df.except(step1_A2A3JoinedDf).groupBy(KpiConstants.memberidColName)
      .agg(min($"${KpiConstants.serviceDateColName}").alias(KpiConstants.iesdDateColName))
      .withColumn(KpiConstants.iesdTypeColName, lit(KpiConstants.outIesdTypeVal))

   /* println("--------step1_ADf-----------")
    step1_ADf.show()*/

    val step1_AnegDf = step1_ADf.withColumnRenamed(KpiConstants.iesdDateColName, KpiConstants.negDateColName)
      .select(KpiConstants.memberidColName, KpiConstants.negDateColName)


  /*  println("--------step1_AnegDf-----------")
    step1_AnegDf.show()*/

    //</editor-fold>

    //<editor-fold desc="Step1-B">

    val step1_B1Df = epopVisitsInDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.inPatientStayVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.fracturesVal)))
      &&($"${KpiConstants.dischargeDateColName}".>=(jul1Date) && $"${KpiConstants.dischargeDateColName}".<=(june30Date)))
      .select(KpiConstants.memberidColName, KpiConstants.admitDateColName, KpiConstants.dischargeDateColName).distinct()

   /* println("--------step1_B1Df-----------")
    step1_B1Df.show()*/


    val inPatDf = epopVisitsInDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.inPatientStayVal))
      &&($"${KpiConstants.dischargeDateColName}".>=(jul1Date)
      && $"${KpiConstants.dischargeDateColName}".<=(june30Date)))
      .select(KpiConstants.memberidColName, KpiConstants.admitDateColName, KpiConstants.dischargeDateColName).distinct()

    /*println("--------inPatDf-----------")
    inPatDf.show()*/




    val directTransferMem = step1_B1Df.as("df1").join(inPatDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .filter((datediff($"df2.${KpiConstants.admitDateColName}", $"df1.${KpiConstants.dischargeDateColName}").>(-1))
        && (datediff($"df2.${KpiConstants.admitDateColName}", $"df1.${KpiConstants.dischargeDateColName}").<(2))
        &&($"df1.${KpiConstants.admitDateColName}".=!=($"df2.${KpiConstants.admitDateColName}")))
      .select(s"df1.${KpiConstants.memberidColName}").distinct().rdd.map(r=> r.getString(0)).collect()




    val directTransferDf = inPatDf.filter($"${KpiConstants.memberidColName}".isin(directTransferMem:_*))
   /* println("--------directTransferDf-----------")
    directTransferDf.show()*/

    val windowIesd = Window.partitionBy(KpiConstants.memberidColName)
      .orderBy(org.apache.spark.sql.functions.col(s"${KpiConstants.dischargeDateColName}").desc, org.apache.spark.sql.functions.col(s"${KpiConstants.admitDateColName}").desc)

    val directTransAddedDf = directTransferDf.withColumn("direct", when((datediff($"${KpiConstants.admitDateColName}", lead($"${KpiConstants.dischargeDateColName}", 1).over(windowIesd)).>(-1))
      && (datediff($"${KpiConstants.admitDateColName}", lead($"${KpiConstants.dischargeDateColName}", 1).over(windowIesd)).<(2)), lit(1))
      .otherwise(lit(0)))

   /* println("--------directTransAddedDf-----------")
    directTransAddedDf.show()*/

    val rankAddedDirTransDf = directTransAddedDf.filter($"direct".===(1))
      .withColumn("rank", rank().over(windowIesd))
    /*println("--------rankAddedDirTransDf-----------")
    rankAddedDirTransDf.show()*/

    val directTransIesdDf = rankAddedDirTransDf.filter($"rank".===(1))
      .select($"${KpiConstants.memberidColName}", $"${KpiConstants.dischargeDateColName}".alias(KpiConstants.iesdDateColName))

    /*println("--------directTransIesdDf-----------")
    directTransIesdDf.show()*/

    val otherIesdDf = step1_B1Df.except(step1_B1Df.filter($"${KpiConstants.memberidColName}".isin(directTransferMem:_*)))
      .groupBy(KpiConstants.memberidColName).agg(min($"${KpiConstants.dischargeDateColName}").alias(KpiConstants.iesdDateColName))
   /* println("--------otherIesdDf-----------")
    otherIesdDf.show()*/


    val step1_BDf = otherIesdDf.union(directTransIesdDf)
      .withColumn(KpiConstants.iesdTypeColName, lit(KpiConstants.inIesdTypeVal))

   /* println("--------step1_BDf-----------")
    step1_BDf.show()*/

    val step1_BnegDf = step1_B1Df.groupBy(KpiConstants.memberidColName)
      .agg(min($"${KpiConstants.admitDateColName}").alias(KpiConstants.negDateColName))

   /* println("--------step1_BnegDf-----------")
    step1_BnegDf.show()*/

    //</editor-fold>

    val iesdWindow = Window.partitionBy(KpiConstants.memberidColName).orderBy(KpiConstants.iesdDateColName)
    val step1IesdDf = step1_ADf.union(step1_BDf)
                               .withColumn(KpiConstants.rankColName, rank().over(iesdWindow))
                               .filter($"${KpiConstants.rankColName}".===(1))
                               .select(KpiConstants.memberidColName, KpiConstants.iesdDateColName, KpiConstants.iesdTypeColName)

    val step1NegDf = step1_AnegDf.union(step1_BnegDf).groupBy(KpiConstants.memberidColName).agg(min($"${KpiConstants.negDateColName}").alias(KpiConstants.negDateColName))

    val step1Df = step1IesdDf.as("df1").join(step1NegDf.as("df2"), Seq(KpiConstants.memberidColName), KpiConstants.innerJoinType)

    val step1VisistsOutDf = epopVisitsInDf.as("df1").join(step1Df.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
                                                           .select("df1.*", s"df2.${KpiConstants.iesdDateColName}", s"df2.${KpiConstants.negDateColName}", s"df2.${KpiConstants.iesdTypeColName}")



    step1VisistsOutDf.coalesce(2)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/step1VisistsOutDf/")

   /* step1VisistsOutDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .json(intermediateDir+ "/step1VisistsOutDf_json/")*/

    //</editor-fold>

    //<editor-fold desc="step2">

    val step2InDf = spark.read.parquet(intermediateDir+ "/step1VisistsOutDf/")

    //<editor-fold desc="Step2-A">

    val step2_A1Df = step2InDf.filter(((((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.observationVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.edVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telehealthModifierVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.telephoneVisitsVal))
      ||(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.onlineAssesmentVal)))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.fracturesVal)))
      &&($"${KpiConstants.serviceDateColName}".>=(date_sub($"${KpiConstants.negDateColName}", 60))
      && $"${KpiConstants.serviceDateColName}".<($"${KpiConstants.negDateColName}"))))

   /* println("------------step2_A1Df---------------")
    step2_A1Df.show()*/

    val step2_A2Df = step2_A1Df.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.edVal))
      || (array_contains($"${KpiConstants.valuesetColName}", KpiConstants.observationVal))))

  /*  println("------------step2_A2Df---------------")
    step2_A2Df.show()*/


    val step2_A3Df = step2InDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.inPatientStayVal)))
      &&($"${KpiConstants.serviceDateColName}".>=(date_sub($"${KpiConstants.negDateColName}", 60))
      && $"${KpiConstants.serviceDateColName}".<=($"${KpiConstants.negDateColName}")))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName,  KpiConstants.admitDateColName, KpiConstants.dischargeDateColName, KpiConstants.provideridColName)

   /* println("------------step2_A3Df---------------")
    step2_A3Df.show()*/


   /* val step2_A2A3JoinedDf = step2_A2Df.as("df1").join(step2_A3Df.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}" , KpiConstants.innerJoinType)
      .filter(((($"df1.${KpiConstants.admitDateColName}".===($"df2.${KpiConstants.admitDateColName}")) || ($"df1.${KpiConstants.admitDateColName}".isNull))
        && (($"df1.${KpiConstants.dischargeDateColName}".===($"df2.${KpiConstants.dischargeDateColName}")) || ($"df1.${KpiConstants.dischargeDateColName}".isNull))
        && ($"df1.${KpiConstants.serviceDateColName}".===($"df2.${KpiConstants.serviceDateColName}"))
        &&($"df1.${KpiConstants.provideridColName}".=!=($"df2.${KpiConstants.provideridColName}")))
        || (($"df1.${KpiConstants.serviceDateColName}".>=(date_sub($"df2.${KpiConstants.admitDateColName}", 1)))
        &&(($"df1.${KpiConstants.serviceDateColName}".<($"df2.${KpiConstants.dischargeDateColName}")))
        &&($"df1.${KpiConstants.serviceDateColName}".=!=($"df2.${KpiConstants.serviceDateColName}"))))
      .select("df1.*")*/



    val step2edToInpatDf = step2_A2Df.as("df1").join(step2_A3Df.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}"  , KpiConstants.innerJoinType)
      .filter((($"df1.${KpiConstants.serviceDateColName}".>=(date_sub($"df2.${KpiConstants.admitDateColName}", 1)))
        &&(($"df1.${KpiConstants.serviceDateColName}".<=($"df2.${KpiConstants.dischargeDateColName}")))))
      .select("df1.*")


    val step2edVisists = step2_A2Df.as("df1").join(step2_A3Df.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}"  , KpiConstants.innerJoinType)
      .filter(((($"df1.${KpiConstants.admitDateColName}".===($"df2.${KpiConstants.admitDateColName}")))
        && (($"df1.${KpiConstants.dischargeDateColName}".===($"df2.${KpiConstants.dischargeDateColName}")))
        && ($"df1.${KpiConstants.serviceDateColName}".===($"df2.${KpiConstants.serviceDateColName}"))
        &&($"df1.${KpiConstants.provideridColName}".===($"df2.${KpiConstants.provideridColName}"))))
      .select("df1.*")

    val step2_A2A3JoinedDf = step2edToInpatDf.as("df1").join(step2edVisists.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.leftOuterJoinType)
                                                       .filter($"df2.${KpiConstants.serviceDateColName}".isNull)
                                                       .select("df1.*")

    val step2_ResADf= step2_A1Df.except(step2_A2A3JoinedDf)


    val step2InpatDf = step2InDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.inPatientStayVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.fracturesVal))))


    val step2_ADf = step2_ResADf.select(KpiConstants.memberidColName)

   /* println("------------step2_ADf------------------")
    step2_ADf.show()*/

    //</editor-fold>

    //<editor-fold desc="Step2-B">

    val step2_B_1Df = step2InDf.filter(((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.inPatientStayVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.fracturesVal)))
      &&(($"${KpiConstants.dischargeDateColName}".>=(date_sub($"${KpiConstants.negDateColName}", 60)))
      &&($"${KpiConstants.dischargeDateColName}".<($"${KpiConstants.negDateColName}"))))

  /*  println("------------step2_B_1Df------------------")
    step2_B_1Df.show()*/



    val step2_BDf = step2_B_1Df.select(KpiConstants.memberidColName)

   /* println("------------step2_BDf------------------")
    step2_BDf.show()*/

    //</editor-fold>


    val step2Df = step2_ADf.union(step2_BDf)

    val step2OutVisistsDf = step2InDf.except(step2InDf.filter($"${KpiConstants.memberidColName}".isin(step2Df.rdd.map(r => r.getString(0)).collect():_*)))

    step2OutVisistsDf.coalesce(2)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/step2OutVisistsDf/")

   /* step2OutVisistsDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .json(intermediateDir+ "/step2OutVisistsDf_json/")*/

    //</editor-fold>

    //<editor-fold desc="Step3">

    val step3InputDf = spark.read.parquet(intermediateDir+ "/step2OutVisistsDf/").select(KpiConstants.memberidColName, KpiConstants.lobColName, KpiConstants.lobProductColName,
                                                KpiConstants.payerColName, KpiConstants.memStartDateColName, KpiConstants.memEndDateColName,
                                                KpiConstants.benefitMedicalColname, KpiConstants.benefitdrugColName, KpiConstants.primaryPlanFlagColName,
                                                KpiConstants.iesdDateColName, KpiConstants.dateofbirthColName)



    /*println("--------step3InputDf-----------")*/
    step3InputDf.show()

    val mapForContEnroll = mutable.Map("gapcount" -> "1", "checkval" -> "true","reqCovDays" -> "0")

    val step3ContEnrollOutDf = UtilFunctions.contEnrollAndAllowableGapFilterFunction(spark,step3InputDf,mapForContEnroll)
                                            .select(KpiConstants.memberidColName, KpiConstants.dateofbirthColName, KpiConstants.memStartDateColName, KpiConstants.memEndDateColName,
                                                    KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.primaryPlanFlagColName,
                                                    KpiConstants.payerColName, KpiConstants.iesdDateColName).distinct()

    step3ContEnrollOutDf.count()
  /*  println("--------step3ContEnrollOutDf-----------")
    step3ContEnrollOutDf.filter($"${KpiConstants.memberidColName}".===("102266")).show()*/

    val contEdMemDf = step3ContEnrollOutDf.groupBy(KpiConstants.memberidColName)
                                          .agg(max(KpiConstants.memEndDateColName).alias(KpiConstants.maxDateColName),
                                               first(KpiConstants.iesdDateColName).alias(KpiConstants.iesdDateColName))
                                          .withColumn(KpiConstants.maxDateColName, when($"${KpiConstants.maxDateColName}".>(date_add($"${KpiConstants.iesdDateColName}", 180)), date_add($"${KpiConstants.iesdDateColName}", 180))
                                                                                  .otherwise($"${KpiConstants.maxDateColName}"))


    contEdMemDf.count()
   /* println("--------contEdMemDf-----------")
    contEdMemDf.filter($"${KpiConstants.memberidColName}".===("102266")).show()*/

    val step3ContEnrollDf = step3ContEnrollOutDf.as("df1").join(contEdMemDf.as("df2"), $"df1.${KpiConstants.memberidColName}"=== $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
                                                          .filter($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.maxDateColName}"))
                                                          .select(s"df1.${KpiConstants.memberidColName}", KpiConstants.dateofbirthColName, KpiConstants.memStartDateColName, KpiConstants.memEndDateColName,
                                                                        KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.primaryPlanFlagColName,
                                                                        KpiConstants.payerColName).distinct()

   /* println("--------step3ContEnrollDf-----------")
    step3ContEnrollDf.filter($"${KpiConstants.memberidColName}".===("102266")).show()*/

    step3ContEnrollDf.coalesce(2)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/step3ContEnrollDf/")



    val step3ContEnrollInDf = spark.read.parquet(intermediateDir+ "/step3ContEnrollDf/")

    val baseOutInDf = UtilFunctions.baseOutDataframeCreation(spark, step3ContEnrollInDf, lobList,measureId).cache()
    baseOutInDf.count()
    /*println("--------baseOutInDf-----------")
    baseOutInDf.filter($"${KpiConstants.memberidColName}".===("102266")).show()*/

    baseOutInDf.coalesce(2)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/baseOutInDf/")

    val baseOutDataDf = spark.read.parquet(intermediateDir+ "/baseOutInDf/")

    val medicareContEnrollDf = baseOutDataDf.filter($"${KpiConstants.lobColName}".===(KpiConstants.medicareLobName)).cache()
    medicareContEnrollDf.count()

    /*Find out the Medicare Hospice Mmebers by lookung in the hospice flag in medicare_monthly_membership table*/
    val medicareHospiceDf = medicareContEnrollDf.as("df1").join(medmonmemDf.as("df2"), Seq(KpiConstants.memberidColName))
      .groupBy(KpiConstants.memberidColName).agg(countDistinct(when($"${KpiConstants.hospiceFlagColName}".===(KpiConstants.yesVal),1)).alias(KpiConstants.countColName))
      .filter($"${KpiConstants.countColName}".>(0))
      .select(KpiConstants.memberidColName).rdd.map(r=> r.getString(0)).collect()

    /*Remove the members who has lti flag inmonthly_medicare_membership table*/
    val baseOutStep1Df = baseOutDataDf.except(baseOutDataDf.filter($"${KpiConstants.memberidColName}".isin(medicareHospiceDf:_*)))

    /*Find out the Medicare  Members who has atleast 1 lti_flag in medicare_monthly_membership table*/
    val medicareLtiDf = medicareContEnrollDf.as("df1").join(medmonmemDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
                                            .select(s"df1.${KpiConstants.memberidColName}",KpiConstants.dateofbirthColName, KpiConstants.ltiFlagColName)
      .filter((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",KpiConstants.months804).<=(yearEndDate)))
      .groupBy(KpiConstants.memberidColName).agg(count(when($"${KpiConstants.ltiFlagColName}".===(KpiConstants.yesVal),1)).alias(KpiConstants.countColName))
      .filter($"${KpiConstants.countColName}".>=(1))
      .select(KpiConstants.memberidColName).rdd.map(r => r.getString(0)).collect()

    /*Remove the member's medicare and Medicare-Medicaid Plans data whao has atleast 1 LTI flag*/
    val baseOutDf = baseOutStep1Df.except(baseOutStep1Df.filter(($"${KpiConstants.memberidColName}".isin(medicareLtiDf:_*))
                                        &&(($"${KpiConstants.lobColName}".===(KpiConstants.medicareLobName))
                                        ||($"${KpiConstants.lobColName}".===(KpiConstants.mmpLobName)))))
                                  .select(KpiConstants.memberidColName, KpiConstants.payerColName)


    val stepDf = spark.read.parquet(intermediateDir+ "/step2OutVisistsDf/")
    stepDf.count()
    val step3OutVisistsDf = stepDf.as("df1").join(baseOutDf.as("df2"), $"df1.${KpiConstants.memberidColName}"=== $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
                                        .select(s"df1.${KpiConstants.memberidColName}", KpiConstants.dobColName, KpiConstants.serviceDateColName, KpiConstants.admitDateColName, KpiConstants.dischargeDateColName,
                                                  KpiConstants.supplflagColName,KpiConstants.dataSourceColName, KpiConstants.valuesetColName, KpiConstants.iesdDateColName, KpiConstants.iesdTypeColName, KpiConstants.negDateColName ,s"df2.${KpiConstants.payerColName}")


   /* println("--------step3OutVisistsDf-----------")
    step3OutVisistsDf.filter($"${KpiConstants.memberidColName}".===("102266")).show()*/
    //step3OutVisistsDf.printSchema()

    step3OutVisistsDf.coalesce(2)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/step3OutVisistsDf/")

    step3OutVisistsDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .json(intermediateDir+ "/step3OutVisistsDf_json/")

    step3OutVisistsDf.printSchema()

    //</editor-fold>

    //<editor-fold desc="Step5">

    val step5VisistsInDf = spark.read.parquet(intermediateDir+ "/step3OutVisistsDf/")

    val step5Sub1Df = step5VisistsInDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.fralityVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      &&(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}", KpiConstants.months972).<=(yearEndDate)))
      .select(KpiConstants.memberidColName)
      .distinct()


    val step5Sub2_1Df = step5VisistsInDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.fralityVal))
                                                     &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
                                                     &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
                                                     &&(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}", KpiConstants.months804).<=(yearEndDate))
                                                     &&(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}", KpiConstants.months972).>=(yearEndDate)))
                                               .select(KpiConstants.memberidColName)
                                                .distinct()

    val outPatAndAdvIllDf = step5VisistsInDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.advancedIllVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)



    val obsAndAdvIllDf = step5VisistsInDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.observationVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.advancedIllVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)

    val edAndAdvIllDf = step5VisistsInDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.edVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.advancedIllVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)

    val nAcuteInPatAndAdvIllDf = step5VisistsInDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.nonAcuteInPatientVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.advancedIllVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)



    val mandatoryExcl3Sub21Df = outPatAndAdvIllDf.union(obsAndAdvIllDf).union(edAndAdvIllDf).union(nAcuteInPatAndAdvIllDf)
      .groupBy(KpiConstants.memberidColName)
      .agg(countDistinct(KpiConstants.serviceDateColName).alias("count"))
      .filter($"count".>=(2))
      .select(KpiConstants.memberidColName)


    val mandatoryExcl3Sub22Df = step5VisistsInDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.acuteInpatientVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.advancedIllVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)

    val mandatoryExcl3Sub23Df = step5VisistsInDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.dementiaMedicationVal))
      &&(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)


    val mandatoryExcl3Sub2Df = mandatoryExcl3Sub21Df.union(mandatoryExcl3Sub22Df).union(mandatoryExcl3Sub23Df)

    val step5Sub2Df = step5Sub2_1Df.intersect(mandatoryExcl3Sub2Df)

    val step5Df = step5Sub1Df.union(step5Sub2Df)

    val step5OutDf = step5VisistsInDf.except(step5VisistsInDf.filter($"${KpiConstants.memberidColName}".isin(step5Df.rdd.map(r => r.getString(0)).collect():_*)))
                                     .select(KpiConstants.memberidColName, KpiConstants.payerColName, KpiConstants.iesdDateColName, KpiConstants.negDateColName, KpiConstants.iesdTypeColName)



    step5OutDf.select(KpiConstants.memberidColName, KpiConstants.iesdDateColName, KpiConstants.iesdTypeColName, KpiConstants.negDateColName).coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/step5OutDf/")

   /* step5OutDf.coalesce(2)
      .write
      .mode(SaveMode.Overwrite)
      .json(intermediateDir+ "/step5OutDf_json/")*/

    val toutStrDf = step5OutDf.select($"${KpiConstants.memberidColName}".as(KpiConstants.ncqaOutmemberIdCol),$"${KpiConstants.payerColName}".as(KpiConstants.ncqaOutPayerCol))
      .withColumn(KpiConstants.ncqaOutMeasureCol, lit(KpiConstants.omwMeasureId)).distinct()

    /*toutStrDf
      .coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir+ "/toutStrDf/")*/

    step5OutDf.select(KpiConstants.memberidColName).coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir+ "/step5OutDf/")

    //</editor-fold>

    //<editor-fold desc="Step4">

    val step4in_1Df = spark.read.parquet(intermediateDir+ "/step5OutDf/")

    val step4InDf = epopVisistsDf.as("df1").join(step4in_1Df.as("df2"), Seq(KpiConstants.memberidColName), KpiConstants.innerJoinType)
                                                  .select("df1.*", s"df2.${KpiConstants.iesdDateColName}", s"df2.${KpiConstants.iesdTypeColName}", s"df2.${KpiConstants.negDateColName}")

    step4InDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .json(intermediateDir+ "/step4InDf_json/")

    val step4_1Df =  step4InDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.boneMinDenTestVal))
                                    &&(($"${KpiConstants.serviceDateColName}".>=(date_sub($"${KpiConstants.negDateColName}", KpiConstants.days730))))
                                      &&($"${KpiConstants.serviceDateColName}".<($"${KpiConstants.negDateColName}")))
                              .select(KpiConstants.memberidColName)

  /*  val step4_2Df =  step4InDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.osteoporosisMedicationVal))
                                    &&((ncqa_date_add($"${KpiConstants.serviceDateColName}", $"${KpiConstants.rxdayssuppliedColName}").>=(date_sub($"${KpiConstants.negDateColName}", KpiConstants.days365)))
                                    &&(ncqa_date_add($"${KpiConstants.serviceDateColName}", $"${KpiConstants.rxdayssuppliedColName}").<($"${KpiConstants.negDateColName}"))))
                              .select(KpiConstants.memberidColName)*/


    val step4_3Df =  step4InDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.osteoprosisMedication))
                                    &&((ncqa_date_add($"${KpiConstants.serviceDateColName}", $"${KpiConstants.rxdayssuppliedColName}").>=(date_sub($"${KpiConstants.negDateColName}", KpiConstants.days365)))
                                    &&($"${KpiConstants.serviceDateColName}".<($"${KpiConstants.negDateColName}"))))
                            .select(KpiConstants.memberidColName)


    val step4Df = step4_1Df.union(step4_3Df)

    val step4visitOutDf = step4InDf.except(step4InDf.filter($"${KpiConstants.memberidColName}".isin(step4Df.rdd.map(r => r.getString(0)).collect():_*)))

    step4visitOutDf.coalesce(2)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/step4visitOutDf/")

    step4visitOutDf.coalesce(2)
      .write
      .mode(SaveMode.Overwrite)
      .json(intermediateDir+ "/step4visitOutDf_json/")

   /* step4Df.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir+ "/step4Df/")*/

    //</editor-fold>

    //</editor-fold>

    //<editor-fold desc="Numerator Calculation">

    val numeratorIn1Df = spark.read.parquet(intermediateDir+ "/step4visitOutDf/")

    val numInIesdAdDisDf = numeratorIn1Df.filter(($"${KpiConstants.iesdTypeColName}".===(KpiConstants.inIesdTypeVal))
                                              &&($"${KpiConstants.dischargeDateColName}".===($"${KpiConstants.iesdDateColName}")))
                                        .select($"${KpiConstants.memberidColName}", $"${KpiConstants.admitDateColName}".as(KpiConstants.iesdAdmitDateColname), $"${KpiConstants.dischargeDateColName}".as(KpiConstants.iesdDisDateColName)).distinct()

    val numeratorInDf = numeratorIn1Df.as("df1").join(numInIesdAdDisDf.as("df2"), Seq(KpiConstants.memberidColName), KpiConstants.leftOuterJoinType)

    //<editor-fold desc="Numerator Non Supplement Calculation">

    val numNonSupVisistsDf = numeratorInDf.filter($"${KpiConstants.supplflagColName}".===("N"))


    val nonSupNum1Df = numNonSupVisistsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.boneMinDenTestVal))
                                                &&(($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.iesdDateColName}"))
                                                  &&($"${KpiConstants.serviceDateColName}".<=(date_add($"${KpiConstants.iesdDateColName}", KpiConstants.days180)))))
                                          .select(KpiConstants.memberidColName)


    val nonSupNum2Df = numNonSupVisistsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.boneMinDenTestVal))
                                               &&($"${KpiConstants.iesdTypeColName}".===(KpiConstants.inIesdTypeVal))
                                                &&(($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.iesdAdmitDateColname}"))
                                                && ($"${KpiConstants.serviceDateColName}".<=($"${KpiConstants.iesdDisDateColName}"))))
                                         .select(KpiConstants.memberidColName)


  /*  val nonSupNum3Df = numNonSupVisistsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.osteoporosisMedicationVal))
                                               &&($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.iesdDateColName}")
                                                  && $"${KpiConstants.serviceDateColName}".<=(date_add($"${KpiConstants.iesdDateColName}", KpiConstants.days180)))
          )
      .select(KpiConstants.memberidColName)*/


    val nonSupNum4Df = numNonSupVisistsDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.longActingOsteoMedicationVal))
                                                &&($"${KpiConstants.iesdTypeColName}".===(KpiConstants.inIesdTypeVal))
                                                    &&(($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.iesdAdmitDateColname}"))
                                                && ($"${KpiConstants.serviceDateColName}".<=($"${KpiConstants.iesdDisDateColName}"))))
                                        .select(KpiConstants.memberidColName)

    val nonSupNum5Df = numNonSupVisistsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.osteoprosisMedication))
      &&($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.iesdDateColName}")
      &&($"${KpiConstants.serviceDateColName}".<=(date_add($"${KpiConstants.iesdDateColName}", KpiConstants.days180)))))
      .select(KpiConstants.memberidColName)

    val nonSupNumDf = nonSupNum1Df.union(nonSupNum2Df).union(nonSupNum4Df).union(nonSupNum5Df)

    //</editor-fold>

    //<editor-fold desc="Numerator Other Calculation">

    val numOtherVisitsDf = numeratorInDf.except(numeratorInDf.filter($"${KpiConstants.memberidColName}".isin(nonSupNumDf.rdd.map(r => r.getString(0)).collect():_*)))


    /*Numerator-1*/
    val otherNum1Df = numOtherVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.boneMinDenTestVal))
      &&(($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.iesdDateColName}"))
      &&($"${KpiConstants.serviceDateColName}".<=(date_add($"${KpiConstants.iesdDateColName}", KpiConstants.days180)))))
      .select(KpiConstants.memberidColName)


    val otherNum2Df = numOtherVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.boneMinDenTestVal))
      &&($"${KpiConstants.iesdTypeColName}".===(KpiConstants.inIesdTypeVal))
      &&(($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.iesdAdmitDateColname}"))
      && ($"${KpiConstants.serviceDateColName}".<=($"${KpiConstants.iesdDisDateColName}"))))
      .select(KpiConstants.memberidColName)



   /* val otherNum3Df = numOtherVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.osteoporosisMedicationVal))
      &&($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.iesdDateColName}")
      && $"${KpiConstants.serviceDateColName}".<=(date_add($"${KpiConstants.iesdDateColName}", KpiConstants.days180)))
    )
      .select(KpiConstants.memberidColName)*/


    val otherNum4Df = numOtherVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.longActingOsteoMedicationVal))
      &&($"${KpiConstants.iesdTypeColName}".===(KpiConstants.inIesdTypeVal))
      &&(($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.iesdAdmitDateColname}"))
      && ($"${KpiConstants.serviceDateColName}".<=($"${KpiConstants.iesdDisDateColName}"))))
      .select(KpiConstants.memberidColName)

    val otherNum5Df = numOtherVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.osteoprosisMedication))
      &&($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.iesdDateColName}")
      &&($"${KpiConstants.serviceDateColName}".<=(date_add($"${KpiConstants.iesdDateColName}", KpiConstants.days180)))))
      .select(KpiConstants.memberidColName)


    val otherNumDf = otherNum1Df.union(otherNum2Df).union(otherNum4Df).union(otherNum5Df)

    //</editor-fold>


    val numeratorDf = nonSupNumDf.union(otherNumDf)


    numeratorDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir+ "/numeratorDf/")

    //</editor-fold>

    //<editor-fold desc="Ncqa Output Creation">

    val outMap = mutable.Map(KpiConstants.totalPopDfName -> toutStrDf, KpiConstants.eligibleDfName -> toutStrDf.select(KpiConstants.ncqaOutmemberIdCol).distinct(),
      KpiConstants.mandatoryExclDfname -> step4Df, KpiConstants.optionalExclDfName -> spark.emptyDataFrame,
      KpiConstants.numeratorDfName -> numeratorDf)


    val outDf = UtilFunctions.ncqaOutputDfCreation(spark,outMap,measureId)
    outDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir+ "/outDf")
    //</editor-fold>

    //<editor-fold desc="Deleting the intermediate Files">

    val fileSystem = FileSystem.get(spark.sparkContext.hadoopConfiguration)
    fileSystem.delete(new Path(intermediateDir), true)
    //</editor-fold>

    spark.sparkContext.stop()
  }

}




