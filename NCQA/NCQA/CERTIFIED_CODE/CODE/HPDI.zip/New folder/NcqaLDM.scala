package com.itc.ncqa.main

import com.itc.ncqa.Constants.KpiConstants
import com.itc.ncqa.Functions.UtilFunctions
import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkConf
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.functions.{lead, lag}
import org.apache.spark.sql.types.DateType
import org.apache.spark.sql.{SaveMode, SparkSession}
//import org.apache.log4j.{Level, Logger}

   object NcqaLDM {

  def main(args: Array[String]): Unit = {


    //<editor-fold desc="Reading program arguments and SaprkSession oBject creation">

    /*val year = args(0)
    val measureId = args(1)
    val dbName = args(2) */

    val year = 2018
    val measureId = "EBS"
    // val dbName = args(2)

    System.setProperty("hadoop.home.dir", "D:\\hadoop_home")
    /*calling function for setting the dbname for dbName variable*/
    // KpiConstants.setDbName(dbName)
    val conf = new SparkConf().setMaster("local").setAppName("NcqaProgram")
      .set("hive.exec.dynamic.partition.mode", "nonstrict")
      .set("spark.sql.shuffle.partitions", "5")
      .set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")

    val spark = SparkSession.builder().config(conf)
      .getOrCreate()
    import spark.implicits._
    val rootLogger = Logger.getRootLogger()
    rootLogger.setLevel(Level.ERROR)

  //  val rootLogger = Logger.getRootLogger()
    //rootLogger.setLevel(Level.ERROR)

    //</editor-fold>

    //<editor-fold desc="Loading Required Tables to memory">

    val ystDate = year + "-01-01"
    val yendDate = year + "-12-31"
    val aLiat = List("col1")
    val msrVal = s"'$measureId'"
    val ggMsrId = s"'${KpiConstants.ggMeasureId}'"
    val lobList = List(KpiConstants.commercialLobName, KpiConstants.medicaidLobName, KpiConstants.medicareLobName,KpiConstants.mmdLobName)
    val memqueryString = s"""SELECT * FROM ${KpiConstants.dbName}.${KpiConstants.membershipTblName} WHERE measure = $msrVal AND (member_plan_start_date IS  NOT NULL) AND(member_plan_end_date IS NOT NULL)"""
    /*val membershipDf = DataLoadFunctions.dataLoadFromHiveStageTable(spark,KpiConstants.dbName,KpiConstants.membershipTblName,memqueryString,aLiat)
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .repartition(2) */

    val path = "C:\\Users\\32676\\Desktop\\HPDI\\MEMBERSHIP_ENROLLMENT.csv"
    val membershipDf = spark.read.option("header", "true").csv(path)
      .filter(($"${KpiConstants.considerationsColName}".===(KpiConstants.yesVal))
        && ($"${KpiConstants.memStartDateColName}".isNotNull)
        && ($"${KpiConstants.memEndDateColName}".isNotNull))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .withColumn(KpiConstants.memStartDateColName, to_date($"${KpiConstants.memStartDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.memEndDateColName, to_date($"${KpiConstants.memEndDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.dateofbirthColName, to_date($"${KpiConstants.dateofbirthColName}", KpiConstants.dateFormatString))

    println("--------------------------membershipDf------------------------------")
    membershipDf.show()
    //val countDF =membershipDf.select($"${KpiConstants.memberidColName}").count()

    //println("countDF"+ countDF)

    //<editor-fold desc="Continuous Enrollment, Allowable Gap Calculatio">

      /*val inputForContEnrolldf = membershipDf.select(KpiConstants.memberidColName, KpiConstants.benefitMedicalColname,
      KpiConstants.memStartDateColName, KpiConstants.memEndDateColName,
      KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName, KpiConstants.dateofbirthColName, KpiConstants.primaryPlanFlagColName)*/

   /* val memberDf = inputForContEnrolldf.filter($"${KpiConstants.memberidColName}".===("108644"))
    println("------------memberDf---------------")
    memberDf.show()*/


    // val benNonMedRemDf = inputForContEnrolldf.filter($"${KpiConstants.benefitMedicalColname}".===(KpiConstants.yesVal))

    val ageEndDate = year + "-12-31"

    val ageStartDate = year + "-01-01"

    /*val contEnrollInDf = inputForContEnrolldf.withColumn(KpiConstants.contenrollLowCoName, UtilFunctions.add_ncqa_months(spark, lit(ageStartDate), 0))
      .withColumn(KpiConstants.contenrollUppCoName, UtilFunctions.add_ncqa_months(spark, lit(ageEndDate), 0))
      .withColumn(KpiConstants.anchorDateColName, UtilFunctions.add_ncqa_months(spark, lit(ageEndDate), 0))


    val contEnrollStep1Df = contEnrollInDf.filter((($"${KpiConstants.memStartDateColName}".>=($"${KpiConstants.contenrollLowCoName}")) && ($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.contenrollUppCoName}")))
      || (($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.contenrollLowCoName}")) && ($"${KpiConstants.memEndDateColName}".<=($"${KpiConstants.contenrollUppCoName}")))
      || ($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.contenrollLowCoName}") && ($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.contenrollUppCoName}"))))
      .withColumn(KpiConstants.anchorflagColName, when(($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.anchorDateColName}"))
        && ($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.anchorDateColName}")), lit(1)).otherwise(lit(0)))
      .withColumn(KpiConstants.contEdFlagColName, when(($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.contenrollUppCoName}"))
        && ($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.contenrollUppCoName}")), lit(1)).otherwise(lit(0)))


    /*Step3(select the members who satisfy both (min_start_date- ces and cee- max_end_date <= allowable gap) conditions)*/
    val listDf = contEnrollStep1Df.groupBy($"${KpiConstants.memberidColName}")
      .agg(max($"${KpiConstants.memEndDateColName}").alias(KpiConstants.maxMemEndDateColName),
        min($"${KpiConstants.memStartDateColName}").alias(KpiConstants.minMemStDateColName),
        first($"${KpiConstants.contenrollLowCoName}").alias(KpiConstants.contenrollLowCoName),
        first($"${KpiConstants.contenrollUppCoName}").alias(KpiConstants.contenrollUppCoName),
        sum($"${KpiConstants.anchorflagColName}").alias(KpiConstants.anchorflagColName))
      .filter((date_add($"max_mem_end_date", KpiConstants.days45).>=($"${KpiConstants.contenrollUppCoName}"))
        && (date_sub($"min_mem_start_date", KpiConstants.days45).<=($"${KpiConstants.contenrollLowCoName}"))
        && ($"${KpiConstants.anchorflagColName}").>(0))
      .select($"${KpiConstants.memberidColName}")


    val contEnrollStep2Df = contEnrollStep1Df.as("df1").join(listDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select("df1.*")

    /*window function creation based on partioned by member_sk and order by mem_start_date*/
    val contWindowVal = Window.partitionBy(s"${KpiConstants.memberidColName}").orderBy(org.apache.spark.sql.functions.col(s"${KpiConstants.memEndDateColName}").desc, org.apache.spark.sql.functions.col(s"${KpiConstants.memStartDateColName}"))


    /* added 3 columns (date_diff(datediff b/w next start_date and current end_date for each memeber),
 anchorflag(if member is continuously enrolled on anchor date 1, otherwise 0)
 count(if date_diff>1 1, otherwise 0) over window*/
    val contEnrollStep3Df = contEnrollStep2Df.withColumn(KpiConstants.overlapFlagColName, when(($"${KpiConstants.memStartDateColName}".>=(lag($"${KpiConstants.memStartDateColName}", 1).over(contWindowVal)) && $"${KpiConstants.memStartDateColName}".<=(lag($"${KpiConstants.memEndDateColName}", 1).over(contWindowVal))
      && ($"${KpiConstants.memEndDateColName}".>=(lag($"${KpiConstants.memStartDateColName}", 1).over(contWindowVal)) && $"${KpiConstants.memEndDateColName}".<=(lag($"${KpiConstants.memEndDateColName}", 1).over(contWindowVal))))
      , lit(1))
      .when(($"${KpiConstants.memStartDateColName}".<(lag($"${KpiConstants.memStartDateColName}", 1).over(contWindowVal)))
        && ($"${KpiConstants.memEndDateColName}".>=(lag($"${KpiConstants.memStartDateColName}", 1).over(contWindowVal)) && $"${KpiConstants.memEndDateColName}".<=(lag($"${KpiConstants.memEndDateColName}", 1).over(contWindowVal)))
        , lit(2)).otherwise(lit(0)))

      .withColumn(KpiConstants.coverageDaysColName, when($"${KpiConstants.overlapFlagColName}".===(0), datediff(when($"${KpiConstants.memEndDateColName}".<=($"${KpiConstants.contenrollUppCoName}"), $"${KpiConstants.memEndDateColName}").otherwise($"${KpiConstants.contenrollUppCoName}")
        , when($"${KpiConstants.memStartDateColName}".>=($"${KpiConstants.contenrollLowCoName}"), $"${KpiConstants.memStartDateColName}").otherwise($"${KpiConstants.contenrollLowCoName}")) + 1)
        .when($"${KpiConstants.overlapFlagColName}".===(2), datediff(when($"${KpiConstants.contenrollLowCoName}".>=(lag($"${KpiConstants.memStartDateColName}", 1).over(contWindowVal)), $"${KpiConstants.contenrollLowCoName}").otherwise(lag($"${KpiConstants.memStartDateColName}", 1).over(contWindowVal))
          , $"${KpiConstants.memStartDateColName}") + 1)
        .otherwise(0))

      .withColumn(KpiConstants.countColName, when(when($"${KpiConstants.overlapFlagColName}".===(0), datediff(lag($"${KpiConstants.memStartDateColName}", 1).over(contWindowVal), $"${KpiConstants.memEndDateColName}"))
        .otherwise(0).>(1), lit(1))
        .otherwise(lit(0)))


    val contEnrollStep5Df = contEnrollStep3Df.groupBy(KpiConstants.memberidColName)
      .agg(min($"${KpiConstants.memStartDateColName}").alias(KpiConstants.minMemStDateColName),
        max($"${KpiConstants.memEndDateColName}").alias(KpiConstants.maxMemEndDateColName),
        sum($"${KpiConstants.countColName}").alias(KpiConstants.countColName),
        sum($"${KpiConstants.coverageDaysColName}").alias(KpiConstants.coverageDaysColName),
        first($"${KpiConstants.contenrollLowCoName}").alias(KpiConstants.contenrollLowCoName),
        first($"${KpiConstants.contenrollUppCoName}").alias(KpiConstants.contenrollUppCoName))
      .withColumn(KpiConstants.reqCovDaysColName, (datediff($"${KpiConstants.contenrollUppCoName}", $"${KpiConstants.contenrollLowCoName}") - 44))


    val contEnrollmemDf = contEnrollStep5Df.filter(((($"${KpiConstants.countColName}") + (when(date_sub($"min_mem_start_date", 1).>=($"${KpiConstants.contenrollLowCoName}"), lit(1)).otherwise(lit(0)))
      + (when(date_add($"max_mem_end_date", 1).<=($"${KpiConstants.contenrollUppCoName}"), lit(1)).otherwise(lit(0)))).<=(1))
      && ($"${KpiConstants.coverageDaysColName}".>=($"${KpiConstants.reqCovDaysColName}")))
      .select(KpiConstants.memberidColName).distinct()


    val contEnrollDf = contEnrollStep1Df.as("df1").join(contEnrollmemDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .filter($"df1.${KpiConstants.contEdFlagColName}".===(1))
      .select(s"df1.${KpiConstants.memberidColName}", s"df1.${KpiConstants.lobColName}", s"df1.${KpiConstants.lobProductColName}", s"df1.${KpiConstants.payerColName}", s"df1.${KpiConstants.primaryPlanFlagColName}").cache()
*/



   /* val contEnrolDf = membershipDfmembershipDf.filter(($"${KpiConstants.memStartDateColName}".<(ageStartDate)) && ($"${KpiConstants.memEndDateColName}".>=(ageStartDate))
      || ($"${KpiConstants.memStartDateColName}".>=(ageStartDate)) && ($"${KpiConstants.memStartDateColName}".<=(ageEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.payerColName,KpiConstants.lobProductColName,KpiConstants.lobColName,KpiConstants.memStartDateColName,KpiConstants.memEndDateColName,KpiConstants.primaryPlanFlagColName)
*/
    // println("contEnrollDf:"+ contEnrollDf.count())
    //</editor-fold>va0
    val yearStDate = year + "-01-01"
    val yearEndDate = year + "-12-31"




    //val anchor_date = yearEndDate
    val validDf = membershipDf.filter($"${KpiConstants.memEndDateColName}".>=(yearStDate) && ($"${KpiConstants.memStartDateColName}" .<= (yearEndDate)))
        .withColumn(KpiConstants.memEndDateColName, when($"${KpiConstants.memEndDateColName}".>(yearEndDate), lit(yearEndDate).cast(DateType)).otherwise($"${KpiConstants.memEndDateColName}"))
      .select(KpiConstants.memberidColName, KpiConstants.memStartDateColName, KpiConstants.memEndDateColName, KpiConstants.lobColName,
        KpiConstants.lobproductColName, KpiConstants.payerColName,KpiConstants.memEndDateColName,KpiConstants.memStartDateColName,KpiConstants.primaryPlanFlagColName)



    val inDf = validDf.select(KpiConstants.memberidColName, KpiConstants.memStartDateColName, KpiConstants.memEndDateColName, KpiConstants.lobColName,
      KpiConstants.lobproductColName, KpiConstants.payerColName,KpiConstants.primaryPlanFlagColName)


    val dualWindow = Window.partitionBy(KpiConstants.memberidColName).orderBy(KpiConstants.memStartDateColName, KpiConstants.memEndDateColName)

    val rankAddedDf = inDf.withColumn("rank", rank().over(dualWindow))
      .withColumn("rnkflag", when(lag($"rank",1).over(dualWindow).===($"rank"), "Y").otherwise("N"))
      .withColumn("rnkflag", when(lead($"rnkflag",1).over(dualWindow).===("Y"), "Y").otherwise($"rnkflag"))
     // .filter($"${KpiConstants.memberidColName}" === ("97150"))

    println("rankAddedDf")
    rankAddedDf.show()



    val dualInDf = rankAddedDf.filter($"rnkflag".===("Y"))
    .select(KpiConstants.memberidColName, KpiConstants.lobColName, KpiConstants.lobproductColName, KpiConstants.payerColName,KpiConstants.primaryPlanFlagColName)




    val otherInDf = rankAddedDf.filter($"rnkflag".===("N"))
      .select(KpiConstants.memberidColName, KpiConstants.lobColName, KpiConstants.lobproductColName, KpiConstants.payerColName,KpiConstants.primaryPlanFlagColName)



   // val setDf = validDf.withColumn("anchor_date", when($"anchor_date".<=(yearEndDate), lit(yearEndDate).cast(DateType)).otherwise($"anchor_date"))
    //  .withColumn("anchor_date")

     //.withColumn("anchor_date")
                       // when($"anchor_date".===(yearEndDate),lit(yearEndDate).cast(DateType)).otherwise($"anchor_date")

   /*val contEnrollDf = contEnrolDf.as("df1").join(setDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      //.filter($"${KpiConstants.memEndDateColName}".===($"anchor_date"))
      .select("df1.*","df2.anchor_date")*/

   /* val baseDf = contEnrollDf.filter($"${KpiConstants.memEndDateColName}".===($"anchor_date"))
      .select(KpiConstants.memberidColName,KpiConstants.lobColName, KpiConstants.lobProductColName,
        KpiConstants.payerColName, KpiConstants.primaryPlanFlagColName)
    val base2Df = contEnrollDf.filter($"${KpiConstants.memEndDateColName}".=!=($"anchor_date"))
      .select(KpiConstants.memberidColName,KpiConstants.lobColName, KpiConstants.lobProductColName,
        KpiConstants.payerColName, KpiConstants.primaryPlanFlagColName)*/


   // val contEnrollResDf = basee3Df.select(KpiConstants.memberidColName, KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName, KpiConstants.primaryPlanFlagColName)

    //<editor-fold desc="Dual enrollment Calculation">

    val baseOutDf = UtilFunctions.baseOutDataframeCreation(spark, dualInDf, lobList, measureId)
    //val basee3Df = baseOutDf.union(base2Df)

    val imaContEnrollDf = baseOutDf.filter($"${KpiConstants.lobColName}".isin(lobList: _*))
      .select(KpiConstants.memberidColName, KpiConstants.payerColName,KpiConstants.lobColName,KpiConstants.lobProductColName,KpiConstants.primaryPlanFlagColName).dropDuplicates().cache()
       println("----------------imaContEnrollDf----------------------")
    imaContEnrollDf.show()

    val AGE27Df = imaContEnrollDf.filter($"${KpiConstants.memberidColName}" === ("95733"))
    println("AGE27Df")
    AGE27Df.show()



    val mcdPayers = List(KpiConstants.mdPayerVal,KpiConstants.mliPayerVal, KpiConstants.mrbPayerVal,KpiConstants.mdePayerVal)
    val snPayerList = List(KpiConstants.sn1PayerVal, KpiConstants.sn2PayerVal, KpiConstants.sn3PayerVal)


    /*mcd payers converted to MCD*/
    val mcdAddedDf = otherInDf.withColumn(KpiConstants.payerColName, when($"${KpiConstants.payerColName}".isin(mcdPayers:_*),lit(KpiConstants.mcdPayerVal)).otherwise($"${KpiConstants.payerColName}"))

    println("----mcdAddedDf-----")
    mcdAddedDf.filter($"${KpiConstants.memberidColName}" === ("95733")).show()
     // .select(KpiConstants.memberidColName, KpiConstants.payerColName,KpiConstants.lobProductColName,KpiConstants.lobColName,KpiConstants.memStartDateColName,KpiConstants.memEndDateColName,KpiConstants.primaryPlanFlagColName)

    /*SN logic*/
    val snDf = mcdAddedDf.filter($"${KpiConstants.payerColName}".isin(snPayerList:_*))

    val mcrAddedDf = snDf.withColumn(KpiConstants.payerColName, lit(KpiConstants.mcrPayerVal))

    println("----mcrAddedDf-----")
    mcrAddedDf.filter($"${KpiConstants.memberidColName}" === ("95733")).show()

    val mcrAddedSnDf = mcdAddedDf.union(mcrAddedDf)
     // .select(KpiConstants.memberidColName, KpiConstants.payerColName,KpiConstants.lobProductColName,KpiConstants.lobColName,KpiConstants.memStartDateColName,KpiConstants.memEndDateColName,KpiConstants.primaryPlanFlagColName)
  /* println("----------------------mcrAddedSnDf----------------------------")
    mcrAddedSnDf.show()
*/
    /*MMP Logic*/
    val mmpDf = mcrAddedSnDf.filter($"${KpiConstants.payerColName}".===(KpiConstants.mmpPayerVal))

    val mcrAddedmmpDf = mmpDf.withColumn(KpiConstants.payerColName, lit(KpiConstants.mcrPayerVal))

    val mcdAddedmmpDf = mmpDf.withColumn(KpiConstants.payerColName, lit(KpiConstants.mcdPayerVal))

    val resultDf = mcrAddedSnDf.union(mcrAddedmmpDf).union(mcdAddedmmpDf)

    println("----resultDf-----")
    resultDf.filter($"${KpiConstants.memberidColName}" === ("95733")).show()


   /* val AGE28Df = resultDf.filter($"${KpiConstants.memberidColName}" === ("95733"))
    println("AGE28Df")
    AGE27Df.show()*/

    //resultDf.printSchema()
    //println("resultDf")
    //resultDf.show()




     val mainresultDf = resultDf.select(KpiConstants.memberidColName, KpiConstants.payerColName,KpiConstants.lobProductColName,KpiConstants.lobColName,KpiConstants.primaryPlanFlagColName)
                          .union(imaContEnrollDf.select(KpiConstants.memberidColName, KpiConstants.payerColName,KpiConstants.lobProductColName,KpiConstants.lobColName,KpiConstants.primaryPlanFlagColName))

    mainresultDf .printSchema()
    val AGE29Df = mainresultDf.filter($"${KpiConstants.memberidColName}" === ("95733"))
    println("AGE29Df")
    AGE29Df.show()

      //.select(KpiConstants.memberidColName, KpiConstants.payerColName,KpiConstants.lobProductColName,KpiConstants.lobColName,KpiConstants.memStartDateColName,KpiConstants.memEndDateColName,KpiConstants.primaryPlanFlagColName)
      //.dropDuplicates()
   /* println("-----------------------------mainresultDf-------------------------------------")
    mainresultDf.show()*/

   /* mainresultDf
      //.select("Language","member_id","payer")
      .coalesce(1).write.mode(SaveMode.Overwrite)
      .parquet("D:\\HealthInsight\\Final_paraq\\")

    val result1Df = spark.read.parquet("D:\\HealthInsight\\Final_paraq\\")*/

    val path1 = "C:\\Users\\32676\\Desktop\\HPDI\\GENERAL_MEMBERSHIP.csv"

    val genMemShipDf  = spark.read.option("header", "true").csv(path1)
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .withColumn(KpiConstants.dateofbirthColName, to_date($"${KpiConstants.dateofbirthColName}", KpiConstants.dateFormatString))

   // println("--------------------------Member Count------------------------------")
   // genMemShipDf.show()
    //val countDF =genMemShipDf.select($"${KpiConstants.memberidColName}").count()

   // println("countDF"+ countDF)


    //println("countDF"+ countDF)
    val joinMemShipDf = genMemShipDf.as("df1").join(mainresultDf.as("df2")
      , $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}"
      , KpiConstants.innerJoinType)

    println("----joinMemShipDf-----")
    joinMemShipDf.filter($"df1.${KpiConstants.memberidColName}" === ("95733")).show()




    val schemaDF = joinMemShipDf.select(s"df2.${KpiConstants.memberidColName}",
      s"df2.${KpiConstants.payerColName}"
      ,  s"df1.SPOKEN_LANGUAGE" , s"df1.SPOKEN_LANGUAGE_SOURCE" , s"df1.WRITTEN_LANGUAGE"
      ,s"df1.WRITTEN_LANGUAGE_SOURCE", s"df1.OTHER_LANGUAGE" , s"df1.OTHER_LANGUAGE_SOURCE")
      println("--------------------------schemaDF---------------------------")
    schemaDF.show()

    val SpokLangDf =  schemaDF.select(s"df2.${KpiConstants.memberidColName}", s"df2.${KpiConstants.payerColName}"
      ,  s"df1.SPOKEN_LANGUAGE"  ).withColumnRenamed("SPOKEN_LANGUAGE" , "Language")

    val SpokLangSrDf =  schemaDF.select(s"df2.${KpiConstants.memberidColName}", s"df2.${KpiConstants.payerColName}"
      ,  s"df1.SPOKEN_LANGUAGE_SOURCE"  ).withColumnRenamed("SPOKEN_LANGUAGE_SOURCE" , "Language")

    val WrLangDf =  schemaDF.select(s"df2.${KpiConstants.memberidColName}",s"df2.${KpiConstants.payerColName}"
      ,  s"df1.WRITTEN_LANGUAGE"  ).withColumnRenamed("WRITTEN_LANGUAGE" , "Language")

    val WrLangSrDf =  schemaDF.select(s"df2.${KpiConstants.memberidColName}", s"df2.${KpiConstants.payerColName}"
      ,  s"df1.WRITTEN_LANGUAGE_SOURCE"  ).withColumnRenamed("WRITTEN_LANGUAGE_SOURCE" , "Language")

    val OthLangDf =  schemaDF.select(s"df2.${KpiConstants.memberidColName}", s"df2.${KpiConstants.payerColName}"
     ,  s"df1.OTHER_LANGUAGE"  ).withColumnRenamed("OTHER_LANGUAGE" , "Language")

    val OthLangSrDf =  schemaDF.select(s"df2.${KpiConstants.memberidColName}", s"df2.${KpiConstants.payerColName}"
      ,  s"df1.OTHER_LANGUAGE_SOURCE"  ).withColumnRenamed("OTHER_LANGUAGE_SOURCE" , "Language")


    val union1Df =  SpokLangDf.union (SpokLangSrDf).union(WrLangDf).union(WrLangSrDf).union(OthLangDf).union(OthLangSrDf)
    // val union2Df =  union1Df.union(WrLangDf).cache()
println("----------------union1Df-----------------------------")
    union1Df.show()

   //union1Df.select("Language","member_id","payer").write.parquet("D:\\HealthInsight\\Final_paraq\\")
    //spark.read.parquet("D:\\HealthInsight\\Final_paraq\\").coalesce(1)
    //val union3Df = union2Df.union(WrLangSrDf)
   // val union4Df = union3Df.union(OthLangDf)
   // val unionDf = union4Df.union(OthLangSrDf)
   val result2 = union1Df.select("Language","member_id","payer").distinct()

    val resDf = result2 .withColumn("MEAS" , concat( lit("LDM") , col("Language") ) )
      .groupBy("MEAS")

    .agg(sum(when($"${KpiConstants.payerColName}" === "HMO", 1).otherwise(0)).as("HMO")
       ,sum(when($"${KpiConstants.payerColName}" === "POS", 1).otherwise(0)).as("POS")
      ,sum(when($"${KpiConstants.payerColName}" === "PPO", 1).otherwise(0)).as("PPO")
      ,sum(when($"${KpiConstants.payerColName}" === "CEP", 1).otherwise(0)).as("CEP")
       ,sum(when($"${KpiConstants.payerColName}" === "MCR", 1).otherwise(0)).as("MCR")
      ,sum(when($"${KpiConstants.payerColName}" === "MC", 1).otherwise(0)).as("MC")
      ,sum(when($"${KpiConstants.payerColName}" === "MCS", 1).otherwise(0)).as("MCS")
      ,sum(when($"${KpiConstants.payerColName}" === "MP", 1).otherwise(0)).as("MP")
      ,sum(when($"${KpiConstants.payerColName}" === "MCD", 1).otherwise(0)).as("MCD"))
     println("------------resDf---------------------------")
       resDf.show()
     //resDf.coalesce(1).write.parquet("D:\\HealthInsight\\Final_paraq\\")


    resDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("D:\\HealthInsight\\Final\\")


  }
}

