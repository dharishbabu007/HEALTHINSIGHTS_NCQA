package com.itc.ncqa.main

import com.itc.ncqa.Constants.KpiConstants
import com.itc.ncqa.Functions.UtilFunctions
import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkConf
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.functions.{lead, lag}
import org.apache.spark.sql.types.DateType
import org.apache.spark.sql.{SaveMode, SparkSession}
//import org.apache.log4j.{Level, Logger}

object EBS {

  def main(args: Array[String]): Unit = {


    //<editor-fold desc="Reading program arguments and SaprkSession oBject creation">

    /*val year = args(0)
    val measureId = args(1)
    val dbName = args(2) */

    val year = 2018
    val measureId = "EBS"
    // val dbName = args(2)

    System.setProperty("hadoop.home.dir", "D:\\hadoop_home")
    /*calling function for setting the dbname for dbName variable*/
    // KpiConstants.setDbName(dbName)
    val conf = new SparkConf().setMaster("local").setAppName("NcqaProgram")
      .set("hive.exec.dynamic.partition.mode", "nonstrict")
      .set("spark.sql.shuffle.partitions", "5")
      .set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")

    val spark = SparkSession.builder().config(conf)
      .getOrCreate()
    import spark.implicits._
    val rootLogger = Logger.getRootLogger()
    rootLogger.setLevel(Level.ERROR)

    //  val rootLogger = Logger.getRootLogger()
    //rootLogger.setLevel(Level.ERROR)

    //</editor-fold>

    //<editor-fold desc="Loading Required Tables to memory">

    val ystDate = year + "-01-01"
    val yendDate = year + "-12-31"
    val aLiat = List("col1")
    val msrVal = s"'$measureId'"
    val ggMsrId = s"'${KpiConstants.ggMeasureId}'"
    val lobList = List(KpiConstants.commercialLobName, KpiConstants.medicaidLobName, KpiConstants.medicareLobName,KpiConstants.mmdLobName)
    val memqueryString = s"""SELECT * FROM ${KpiConstants.dbName}.${KpiConstants.membershipTblName} WHERE measure = $msrVal AND (member_plan_start_date IS  NOT NULL) AND(member_plan_end_date IS NOT NULL)"""
    /*val membershipDf = DataLoadFunctions.dataLoadFromHiveStageTable(spark,KpiConstants.dbName,KpiConstants.membershipTblName,memqueryString,aLiat)
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .repartition(2) */

    val memEnrolPath = "C:\\Users\\32676\\Desktop\\HPDI\\MEMBERSHIP_ENROLLMENT.csv"
    val membershipDf = spark.read.option("header", "true").csv(memEnrolPath)
      .filter(($"${KpiConstants.considerationsColName}".===(KpiConstants.yesVal))
        && ($"${KpiConstants.memStartDateColName}".isNotNull)
        && ($"${KpiConstants.memEndDateColName}".isNotNull))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .withColumn(KpiConstants.memStartDateColName, to_date($"${KpiConstants.memStartDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.memEndDateColName, to_date($"${KpiConstants.memEndDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.dateofbirthColName, to_date($"${KpiConstants.dateofbirthColName}", KpiConstants.dateFormatString))

    val anchorDate = year+"-12-31"

    val mcdPayers = List(KpiConstants.mdPayerVal,KpiConstants.mliPayerVal, KpiConstants.mrbPayerVal,KpiConstants.mdePayerVal)
    val snPayerList = List(KpiConstants.sn1PayerVal, KpiConstants.sn2PayerVal, KpiConstants.sn3PayerVal)

    val memEnrollDf = membershipDf
      .filter(  ($"${KpiConstants.memEndDateColName}">= anchorDate) &&
        ($"${KpiConstants.memStartDateColName}"<= anchorDate)  &&
        ($"${KpiConstants.lobColName}".isin(lobList:_*))
      )


    val  contEnrollDf = memEnrollDf
      .select($"${KpiConstants.memberidColName}" , $"${KpiConstants.lobColName}"
        , $"${KpiConstants.lobProductColName}",$"${KpiConstants.payerColName}"
        ,$"${KpiConstants.primaryPlanFlagColName}").distinct().cache()


    val baseOutDf = UtilFunctions.baseOutDataframeCreation(spark, contEnrollDf, lobList , measureId)

    // memEnrollDf.printSche
    // ma()

    println("memEnrollDf")
    memEnrollDf .filter($"${KpiConstants.memberidColName}" === ("103999")).show

    val genMemPath = "C:\\Users\\32676\\Desktop\\HPDI\\GENERAL_MEMBERSHIP.csv"

    val genMemShipDf = spark.read.options(Map("inferSchema"->"true","sep"->",","header"->"true")).csv(genMemPath)
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .withColumn(KpiConstants.dateofbirthColName, to_date($"${KpiConstants.dateofbirthColName}"
        , KpiConstants.dateFormatString))

    //genMemShipDf.printSchema()

    println("genMemShipDf")
    genMemShipDf .filter($"${KpiConstants.memberidColName}" === ("103999")).show

    val joinMemShipDf = genMemShipDf.as("df1").join(baseOutDf.as ("df2")
      , $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}"
      , KpiConstants.innerJoinType )
      .select(s"df2.${KpiConstants.memberidColName}", s"df2.${KpiConstants.lobColName}"  , s"df2.${KpiConstants.payerColName}", s"df1.${KpiConstants.stateColName}"
      )//, s"df1.SUB_FAM_ID_NUM" )
      .withColumn("state" , when(col("state") .isin("MH" ,"PW") , "OT")
      .otherwise(col("state" )))
    //.withColumn(KpiConstants.payerColName, when($"${KpiConstants.payerColName}".isin(mcdPayers:_*),lit(KpiConstants.mcdPayerVal))
    //.otherwise($"${KpiConstants.payerColName}"))

    println("joinMemShipDf")
    // joinMemShipDf .filter($"${KpiConstants.memberidColName}" === ("103999")).show
    /*
        /*SN logic*/
        val snDf = joinMemShipDf.filter($"${KpiConstants.payerColName}".isin(snPayerList:_*))


        val mcrAddedDf = snDf.withColumn(KpiConstants.payerColName, lit(KpiConstants.mcrPayerVal))

        val mcrAddedSnDf = joinMemShipDf.union(mcrAddedDf)

        println("mcrAddedSnDf")
        mcrAddedSnDf .filter($"${KpiConstants.memberidColName}" === ("103999")).show
        */

    /*
        /*MMP Logic*/
        val mmpDf = mcrAddedSnDf.filter($"${KpiConstants.payerColName}".===(KpiConstants.mmpPayerVal))

        val mcrAddedmmpDf = mmpDf.withColumn(KpiConstants.payerColName, lit(KpiConstants.mcrPayerVal))

        val mcdAddedmmpDf = mmpDf.withColumn(KpiConstants.payerColName, lit(KpiConstants.mcdPayerVal))

        val resultDf = mcrAddedSnDf.union(mcrAddedmmpDf).union(mcdAddedmmpDf)

        println("resultDf")
        resultDf .filter($"${KpiConstants.memberidColName}" === ("103999")).show

    */

    // .withColumn("state"
    // , when(($"${KpiConstants.stateColName}" .isin("" ,null) )
    //   && $"${KpiConstants.memberidColName}" =!= col("SUB_FAM_ID_NUM") , "OT")
    //   .otherwise(col("state" )))

    println("joinMemShipDf ")
    val testdf =   joinMemShipDf.filter($"${KpiConstants.stateColName}" === ("NV")
      && ($"${KpiConstants.payerColName}" === "MCR"   ))

      .select($"${KpiConstants.memberidColName}" ) // ,$"${KpiConstants.stateColName}",  $"${KpiConstants.payerColName}"  )


    testdf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("D:\\HealthInsight\\Final\\")


    val resDf = joinMemShipDf.withColumn("MEAS" , concat( lit("EBS") , $"${KpiConstants.stateColName}" ) )
      .groupBy( col("MEAS") )
      .agg(sum(when($"${KpiConstants.payerColName}" === "HMO", 1).otherwise(0)).as("HMO")
        ,sum(when($"${KpiConstants.payerColName}" === "POS", 1).otherwise(0)).as("POS")
        ,sum(when($"${KpiConstants.payerColName}" === "PPO", 1).otherwise(0)).as("PPO")
        ,sum(when($"${KpiConstants.payerColName}" === "CEP", 1).otherwise(0)).as("CEP")
        ,sum(when(($"${KpiConstants.payerColName}" === "MCR")  , 1).otherwise(0)).as("MCR")
        ,sum(when($"${KpiConstants.payerColName}" === "MC", 1).otherwise(0)).as("MC")
        ,sum(when($"${KpiConstants.payerColName}" === "MCS", 1).otherwise(0)).as("MCS")
        ,sum(when($"${KpiConstants.payerColName}" === "MP", 1).otherwise(0)).as("MP")
        ,sum(when(($"${KpiConstants.payerColName}" === "MCD")   , 1).otherwise(0)).as("MCD"))

    resDf.show




    resDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("D:\\HealthInsight\\Final\\")



  }

}
