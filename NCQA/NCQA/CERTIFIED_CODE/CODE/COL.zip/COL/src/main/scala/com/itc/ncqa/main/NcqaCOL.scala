package main.scala.com.itc.ncqa.main

import main.scala.com.itc.ncqa.Constants.KpiConstants
import main.scala.com.itc.ncqa.Functions.UtilFunctions
import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkConf
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, StringType}

import scala.collection.mutable

object NcqaCOL {

  def main(args: Array[String]): Unit = {

    //<editor-fold desc="Reading program arguments and Spark Session object creation">

    val year = "2018"
    val measureId = "COL"
    val baseMsrPath = "/home/hbase/ncqa/col/Test_Col"

    System.setProperty("hadoop.home.dir", "D:\\WinUtil")

    val conf = new SparkConf().setAppName("NcqaProgram")
    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    conf.set("spark.sql.shuffle.partitions", "5")
    //.set("hive.exec.dynamic.partition.mode", "nonstrict")

    val spark = SparkSession.builder().config(conf).master("local").getOrCreate()

    val rootLogger = Logger.getRootLogger()
    rootLogger.setLevel(Level.ERROR)

    val myminus2StDate = year.toInt-2 +"-01-01"
    val myminus4StDate = year.toInt-4 +"-01-01"
    val myminus9StDate = year.toInt-9 +"-01-01"

    val yearStartDate = year+"-01-01"
    val yearEndDate = year+"-12-31"
    val prevYearStDate = year.toInt-1 +"-01-01"
    val yearNovDate = year+"-11-01"
    val oct1Date = year.toInt-2 +"-10-01"
    val jobId = spark.sparkContext.applicationId
    val baseDir = baseMsrPath + "/" + jobId
    val outDir = baseDir + "/Out"
    val intermediateDir = baseDir + "/Intermediate"

    //</editor-fold>

    //<editor-fold desc="Loading Required Tables to memory">

    import spark.implicits._

    val ystDate = year+"-01-01"
    val yendDate = year+"-12-31"

    val lobList = List(KpiConstants.commercialLobName, KpiConstants.medicareLobName, KpiConstants.marketplaceLobName,KpiConstants.mmdLobName)

    println("-------------------membership----------------")
    //val membershipDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\COL\\MEMBERSHIP_ENROLLMENT.csv")

    val membershipDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\COL\\Test\\MEMBERSHIP_ENROLLMENT.csv")
      .filter(($"${KpiConstants.considerationsColName}".===(KpiConstants.yesVal))
        && ($"${KpiConstants.memStartDateColName}".isNotNull)
        && ($"${KpiConstants.memEndDateColName}".isNotNull))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .withColumn(KpiConstants.memStartDateColName, to_date($"${KpiConstants.memStartDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.memEndDateColName, to_date($"${KpiConstants.memEndDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.dateofbirthColName, to_date($"${KpiConstants.dateofbirthColName}", KpiConstants.dateFormatString))
      .repartition(2).cache()

    membershipDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet("/home/hbase/ncqa/col/membershipDf/")

    membershipDf.filter($"${KpiConstants.memberidColName}".===("96934")).show()

    val claimStatusList = List(KpiConstants.paidVal, KpiConstants.suspendedVal, KpiConstants.pendingVal, KpiConstants.deniedVal)

    //val visitsDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\COL\\VISITS.csv")

    val visitsDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\COL\\Test\\VISITS.csv")
      .filter(($"${KpiConstants.serviceDateColName}".isNotNull)
        && (($"${KpiConstants.admitDateColName}".isNotNull && $"${KpiConstants.dischargeDateColName}".isNotNull)
        || ($"${KpiConstants.admitDateColName}".isNull && $"${KpiConstants.dischargeDateColName}".isNull))
        &&((($"${KpiConstants.dataSourceColName}".===("Claim"))&&($"${KpiConstants.claimstatusColName}".isin(claimStatusList:_*)))
        || (($"${KpiConstants.dataSourceColName}".===("RxClaim"))&&($"${KpiConstants.claimstatusColName}".isin(claimStatusList:_*)))
        || ($"${KpiConstants.dataSourceColName}".===("Rx"))
        || ($"${KpiConstants.dataSourceColName}".===("Lab"))))
      .drop(KpiConstants.lobProductColName, "latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name","product")
      .withColumn(KpiConstants.dobColName, to_date($"${KpiConstants.dobColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.serviceDateColName, to_date($"${KpiConstants.serviceDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.admitDateColName, when($"${KpiConstants.admitDateColName}".isNotNull,to_date($"${KpiConstants.admitDateColName}",  KpiConstants.dateFormatString)))
      .withColumn(KpiConstants.dischargeDateColName, when($"${KpiConstants.dischargeDateColName}".isNotNull,to_date($"${KpiConstants.dischargeDateColName}",  KpiConstants.dateFormatString)))
      .withColumn(KpiConstants.medstartdateColName, when($"${KpiConstants.medstartdateColName}".isNotNull,to_date($"${KpiConstants.medstartdateColName}",  KpiConstants.dateFormatString)))
      .withColumn(KpiConstants.revenuecodeColName, when((length($"${KpiConstants.revenuecodeColName}").as[Int].===(3)),concat(lit("0" ),lit($"${KpiConstants.revenuecodeColName}"))).otherwise($"${KpiConstants.revenuecodeColName}"))
      .withColumn(KpiConstants.billtypecodeColName, when((length($"${KpiConstants.billtypecodeColName}").as[Int].===(3)),concat(lit("0" ),lit($"${KpiConstants.billtypecodeColName}"))).otherwise($"${KpiConstants.billtypecodeColName}"))
      .withColumn(KpiConstants.proccode2ColName, when(($"${KpiConstants.proccode2mod1ColName}".isin(KpiConstants.avoidCodeList:_*)) || ($"${KpiConstants.proccode2mod2ColName}".isin(KpiConstants.avoidCodeList:_*)),lit("NA")).otherwise($"${KpiConstants.proccode2ColName}"))
      .repartition(2).cache()

    visitsDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet("/home/hbase/ncqa/col/visitsDf/")

    println("-------------------visits----------------")
    visitsDf.filter($"${KpiConstants.memberidColName}".===("96934")).show()

    println("-------------------refHedisDf----------------")
    //val refHedisDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\COL\\REF_HEDIS2019.csv")

    val refHedisDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\COL\\Test\\REF_HEDIS2019.csv")
      .filter(($"${KpiConstants.measureIdColName}".===(KpiConstants.colMeasureId)) || ($"${KpiConstants.measureIdColName}".===(KpiConstants.ggMeasureId)))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .repartition(2).cache()

    refHedisDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet("/home/hbase/ncqa/col/refHedisDf/")

    println("-------------------ref_medvaluesetDf----------------")
    // val ref_medvaluesetDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\COL\\REF_MED_VALUE_SET.csv")

    val ref_medvaluesetDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\COL\\Test\\REF_MED_VALUE_SET.csv")
      .filter(($"${KpiConstants.measure_idColName}".===(KpiConstants.colMeasureId)) )
      .drop("latest_flag", "active_flag", "ingestion_date", "source_name" ,"user_name")
      .repartition(2).cache()

    ref_medvaluesetDf.coalesce(2)
      .write
      .mode(SaveMode.Overwrite)
      .parquet("/home/hbase/ncqa/col/ref_medvaluesetDf/")

    //val medmonmemDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\COL\\COL_MONTHLY_MEMBERSHIP.csv")

    val medmonmemDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\COL\\Test\\COL_MONTHLY_MEMBERSHIP.csv")
      .withColumn(KpiConstants.runDateColName,to_date($"${KpiConstants.runDateColName}", KpiConstants.dateFormatString))
      .filter(($"${KpiConstants.runDateColName}".>=(ystDate)) && ($"${KpiConstants.runDateColName}".<=(yendDate)))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .repartition(2).cache()

    medmonmemDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet("/home/hbase/ncqa/col/medmonmemDf/")

    println("-------------------Monthly Membership----------------")
    medmonmemDf.filter($"${KpiConstants.memberidColName}".===("96934")).show()

    //</editor-fold>

    //<editor-fold desc=" Eligible Population Calculation">

    //<editor-fold desc="Age Filter And SN2 Removal Calculation">

    val ageClDate = year+ "-12-31"
    val ageFilterDf = membershipDf.filter((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",KpiConstants.months612).<=(ageClDate))
      &&(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",KpiConstants.months912).>(ageClDate)))

    val sn2Members = ageFilterDf.filter(($"${KpiConstants.lobProductColName}".===(KpiConstants.lobProductNameConVal))
      &&(((($"${KpiConstants.memStartDateColName}".>=(yearStartDate)) && ($"${KpiConstants.memStartDateColName}".<=(yearEndDate)))
      ||(($"${KpiConstants.memEndDateColName}".>=(yearStartDate)) && ($"${KpiConstants.memEndDateColName}".<=(yearEndDate))))
      || ((($"${KpiConstants.memStartDateColName}".<(yearStartDate)) && ($"${KpiConstants.memEndDateColName}".>(yearEndDate)))))
      &&(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}", KpiConstants.months792).<=(yearEndDate)))
      .select(KpiConstants.memberidColName).rdd.map(r => r.getString(0)).collect()
    val sn2RemovedMemDf = ageFilterDf.except(ageFilterDf.filter($"${KpiConstants.memberidColName}".isin(sn2Members:_*)))

    sn2RemovedMemDf.filter($"${KpiConstants.memberidColName}".===("96934")).show()

    sn2RemovedMemDf.coalesce(3)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/sn2RemovedMemDf/")


    //</editor-fold>

    //<editor-fold desc="Continuous Enrollment, Allowable Gap Calculation">

    val ageDf = spark.read.parquet(intermediateDir+ "/sn2RemovedMemDf/").cache()

    val inputForContEnrolldf = ageDf.select(KpiConstants.memberidColName, KpiConstants.benefitMedicalColname,
      KpiConstants.memStartDateColName,KpiConstants.memEndDateColName,
      KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName, KpiConstants.dateofbirthColName,KpiConstants.primaryPlanFlagColName)

    val mapForCeminus1y = mutable.Map("start_date" -> "2017-01-01", "end_date" -> "2017-12-31","gapcount" -> "1",
      "checkval" -> "false", "reqCovDays" -> "0")

    val ceOutminus1yDf = UtilFunctions.contEnrollAndAllowableGapFilterFunction(spark,inputForContEnrolldf,mapForCeminus1y)

    ceOutminus1yDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite).parquet(intermediateDir+ "/ceOutminus1yDf/")

    val ceOutMinus1y = spark.read.parquet(intermediateDir+ "/ceOutminus1yDf/").cache()

    val mapForCeCurrYear = mutable.Map("start_date" -> "2018-01-01", "end_date" -> "2018-12-31","gapcount" -> "1",
      "checkval" -> "true","reqCovDays" -> "0","anchor_date" -> "2018-12-31")

    val contEnrollDf = UtilFunctions.contEnrollAndAllowableGapFilterFunction(spark,ceOutMinus1y,mapForCeCurrYear)
      .select(KpiConstants.memberidColName, KpiConstants.dateofbirthColName, KpiConstants.memStartDateColName, KpiConstants.memEndDateColName,
        KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.primaryPlanFlagColName, KpiConstants.payerColName)

    contEnrollDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/contEnrollDf/")

    println("----------------------After contEnrollDf-----------------------")
    contEnrollDf.filter($"${KpiConstants.memberidColName}".===("96934")).show()

    //</editor-fold>

    //<editor-fold desc="Dual Enrollment calculation">

    val contDf = spark.read.parquet(intermediateDir+ "/contEnrollDf/")
    val inbaseoutdf = UtilFunctions.baseOutDataframeCreation(spark, contDf, lobList,measureId)

    println("----------------------After inbaseoutdf-----------------------")
    inbaseoutdf.filter($"${KpiConstants.memberidColName}".===("96934")).show()

    inbaseoutdf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite).parquet(intermediateDir+ "/inbaseoutdf/")

    val baseOutInDf = spark.read.parquet(intermediateDir+ "/inbaseoutdf/").cache()

    val colBaseOutDf = baseOutInDf.filter($"${KpiConstants.lobColName}".isin(lobList:_*))

    val medicareContEnrollDf = colBaseOutDf.filter($"${KpiConstants.lobColName}".===(KpiConstants.medicareLobName)
                                               || $"${KpiConstants.lobColName}".===(KpiConstants.mmdLobName)).repartition(2).cache()
    medicareContEnrollDf.count()

    /*Find out the Medicare Hospice Mmebers by lookung in the hospice flag in medicare_monthly_membership table*/
    val medicareHospiceDf = medicareContEnrollDf.as("df1").join(medmonmemDf.as("df2"), Seq(KpiConstants.memberidColName))
      .groupBy(KpiConstants.memberidColName).agg(countDistinct(when($"${KpiConstants.hospiceFlagColName}".===(KpiConstants.yesVal),1)).alias(KpiConstants.countColName))
      .filter($"${KpiConstants.countColName}".>(0))
      .select(KpiConstants.memberidColName).rdd.map(r=> r.getString(0)).collect()

    /*Remove the members who has lti flag inmonthly_medicare_membership table*/
    val baseOutStep1Df = colBaseOutDf.except(colBaseOutDf.filter($"${KpiConstants.memberidColName}".isin(medicareHospiceDf:_*)))

    /*Find out the Medicare  Members who has atleast 1 lti_flag in medicare_monthly_membership table*/
    val medicareLtiDf = medicareContEnrollDf.as("df1").join(medmonmemDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select(s"df1.${KpiConstants.memberidColName}",KpiConstants.dateofbirthColName, KpiConstants.ltiFlagColName)
      .filter((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",KpiConstants.months792).<=(yearEndDate)))
      .groupBy(KpiConstants.memberidColName).agg(count(when($"${KpiConstants.ltiFlagColName}".===(KpiConstants.yesVal),1)).alias(KpiConstants.countColName))
      .filter($"${KpiConstants.countColName}".>=(1))
      .select(KpiConstants.memberidColName).rdd.map(r => r.getString(0)).collect()

    /*val baseOutMedHosRemDf = baseOutStep1Df.except(baseOutStep1Df.filter(($"${KpiConstants.memberidColName}".isin(medicareLtiDf:_*))
      &&($"${KpiConstants.lobColName}".===(KpiConstants.medicareLobName))))*/

    val baseOutDf = baseOutStep1Df.except(baseOutStep1Df.filter(($"${KpiConstants.memberidColName}".isin(medicareLtiDf:_*))
      &&(($"${KpiConstants.lobColName}".===(KpiConstants.medicareLobName)) || ($"${KpiConstants.lobColName}".===(KpiConstants.mmdLobName)))))

    /*Removing the SN payer members from the EPOP*/
    /*

    val snPayerList = List(KpiConstants.sn1PayerVal, KpiConstants.sn2PayerVal, KpiConstants.sn3PayerVal, KpiConstants.mmpPayerVal)
    val baseOutDf = baseOutMedHosRemDf.except(baseOutMedHosRemDf.filter($"${KpiConstants.payerColName}".isin(snPayerList:_*)))

   */

    baseOutDf.coalesce(3)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/baseOutDf/")

    println("----------------------After baseOutDf-----------------------")
    baseOutDf.filter($"${KpiConstants.memberidColName}".===("96934")).show()

    //</editor-fold>

    //<editor-fold desc="Initial Join with Ref_Hedis">

    val argmapforRefHedis = mutable.Map(KpiConstants.eligibleDfName -> visitsDf , KpiConstants.refHedisTblName -> refHedisDf,
      KpiConstants.refmedValueSetTblName -> ref_medvaluesetDf)

    val allValueList = List(KpiConstants.independentLabVal, KpiConstants.hospiceVal, KpiConstants.fralityVal,
      KpiConstants.outPatientVal, KpiConstants.advancedIllVal, KpiConstants.observationVal,
      KpiConstants.edVal, KpiConstants.nonAcuteInPatientVal, KpiConstants.acuteInpatientVal,
      KpiConstants.fobtVal, KpiConstants.flexibleSigmodoscopyVal, KpiConstants.colonoscopyVal,
      KpiConstants.ctColonographyVal,KpiConstants.fitDnaVal, KpiConstants.colorectalCancerVal,
      KpiConstants.totalColectomyVal)

    val medicationlList = List(KpiConstants.dementiaMedicationVal)
    val visitRefHedisDf = UtilFunctions.joinWithRefHedisFunction(spark,argmapforRefHedis,allValueList,medicationlList)

    //</editor-fold>

    //<editor-fold desc="Removal of Independent Lab Visits">

    val groupList = visitsDf.schema.fieldNames.toList.dropWhile(p=> p.equalsIgnoreCase(KpiConstants.memberidColName))
    val visitgroupedDf = visitRefHedisDf.groupBy(KpiConstants.memberidColName, groupList:_*).agg(collect_list(KpiConstants.valuesetColName).alias(KpiConstants.valuesetColName))
      .select(KpiConstants.memberidColName,KpiConstants.dobColName, KpiConstants.serviceDateColName, KpiConstants.admitDateColName, KpiConstants.dischargeDateColName,
        KpiConstants.supplflagColName, KpiConstants.valuesetColName)


/*
    val indLabVisRemDf = visitgroupedDf.filter((!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)))
      .repartition(2).cache()
*/

    val indLabVisRemDf = visitgroupedDf.filter((!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      ||((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.fitDnaVal)))
      ||((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.fobtVal))))
      .repartition(2).cache()


    indLabVisRemDf.count()

    println("----------------------After indLabVisRemDf-----------------------")
    indLabVisRemDf.filter($"${KpiConstants.memberidColName}".===("96934")).show()

    //</editor-fold>

    //<editor-fold desc="Hospice Removal">

    val baseMemDf = spark.read.parquet(intermediateDir+ "/baseOutDf/").repartition(2)
    val hospiceInCurrYearMemDf = indLabVisRemDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hospiceVal))
      &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)
      .dropDuplicates()
      .rdd
      .map(r=> r.getString(0))
      .collect()


    val hospiceRemMemEnrollDf = baseMemDf.except(baseMemDf.filter($"${KpiConstants.memberidColName}".isin(hospiceInCurrYearMemDf:_*)))
      .select(KpiConstants.memberidColName,KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName, KpiConstants.memStartDateColName).dropDuplicates()
    /* hospiceRemMemEnrollDf.select(KpiConstants.memberidColName).distinct().coalesce(1)
       .write
       .mode(SaveMode.Append)
       .option("header", "true")
       .csv(outDir +"/hospiceRemMemEnrollDf/")*/

    println("----------------------After hospiceRemMemEnrollDf-----------------------")
    hospiceRemMemEnrollDf.filter($"${KpiConstants.memberidColName}".===("96934")).show()

    //</editor-fold>

    //<editor-fold desc="Stratification code">

    /*Stratification code*/
    val stratificationInputDf = hospiceRemMemEnrollDf.filter($"${KpiConstants.lobColName}".===(KpiConstants.medicareLobName)
                                                          || $"${KpiConstants.lobColName}".===(KpiConstants.mmdLobName))

    /*Step1*/
    val joinWithMedMonDf = stratificationInputDf.as("df1").join(medmonmemDf.as("df2"), Seq(KpiConstants.memberidColName))

    /*create the window function based on partitioned by memebr_id and descending order of run_date*/
    val windowForStratification = Window.partitionBy(KpiConstants.memberidColName, KpiConstants.payerColName).orderBy(org.apache.spark.sql.functions.col(KpiConstants.runDateColName).desc)

    val rankColAddedDf = joinWithMedMonDf.withColumn(KpiConstants.rankColName, rank().over(windowForStratification))
      .filter($"${KpiConstants.rankColName}".<=(3))
      .withColumn(KpiConstants.lisPreSubsColName,concat(lit($"${KpiConstants.lisPreSubsColName}"), lit(":"), lit($"${KpiConstants.rankColName}")))
      .groupBy(KpiConstants.memberidColName, KpiConstants.payerColName)
      .agg(first($"${KpiConstants.lobColName}").alias(KpiConstants.lobColName),
        first($"${KpiConstants.lobProductColName}").alias(KpiConstants.lobProductColName),
        first($"${KpiConstants.memStartDateColName}").alias(KpiConstants.memStartDateColName),
        first($"${KpiConstants.orecCodeColName}").alias(KpiConstants.orecCodeColName),
        collect_list(KpiConstants.lisPreSubsColName).alias(KpiConstants.lisPreSubsColName))

    //<editor-fold desc="Last 2 months enrolled memebers">

    val joinLast2MonthsMemDf = rankColAddedDf.withColumn("count",size($"${KpiConstants.lisPreSubsColName}"))
      .filter($"count".<(3))
      .drop("count")

    val rankAdded2MonthsMemDf = joinLast2MonthsMemDf.withColumn(KpiConstants.ncqaOutMeasureCol,
      when($"${KpiConstants.orecCodeColName}".cast(IntegerType).===(0),lit("COLNON"))
      .when($"${KpiConstants.orecCodeColName}".cast(IntegerType).===(2)|| $"${KpiConstants.orecCodeColName}".cast(IntegerType).===(9),lit("COLOT"))
      .when($"${KpiConstants.orecCodeColName}".cast(IntegerType).===(1) || $"${KpiConstants.orecCodeColName}".cast(IntegerType).===(3),lit("COLDIS"))
        //.when($"${KpiConstants.orecCodeColName}".cast(IntegerType).===(null) || $"${KpiConstants.orecCodeColName}".cast(IntegerType).===(3),lit("COLUN"))
    ).select(KpiConstants.memberidColName, KpiConstants.lobColName, KpiConstants.lobProductColName,KpiConstants.payerColName, KpiConstants.ncqaOutMeasureCol)


    //</editor-fold>

    //<editor-fold desc="More than 2 months enrolled members">

    val joinFullYearMemDf = rankColAddedDf.except(joinLast2MonthsMemDf)

   /* val lis = udf((value : Seq[String]) =>  {
      val map = value.map(f => (f.split(":")(1).toInt, f.split(":")(0).toInt)).toMap
      if((map.get(1).get == map.get(2).get == map.get(3).get) || ((map.get(1).get != map.get(2).get)&&(map.get(2).get != map.get(3).get)) || (map.get(1).get == map.get(2))) map.get(1).get
      else
        map.get(2).get
    }*/


    val lis = udf((value : Seq[String]) =>  {
      val map = value.map(f => (f.split(":")(1).toInt, f.split(":")(0).toInt)).toMap
      if((map.get(2).get == map.get(3).get) && (map.get(1).get != map.get(2).get)) map.get(2).get
      else
        map.get(1).get
    }


    )
    val lisPreSubAddedDf = joinFullYearMemDf.withColumn(KpiConstants.lisPreSubsColName, lis($"${KpiConstants.lisPreSubsColName}"))


    val measAddedFullYearDf = lisPreSubAddedDf.withColumn(KpiConstants.ncqaOutMeasureCol, when(($"${KpiConstants.lisPreSubsColName}".cast(StringType).===(""))&& ($"${KpiConstants.orecCodeColName}".cast(StringType).===("")), lit("COLUN"))
      .when(($"${KpiConstants.lisPreSubsColName}".cast(StringType).=!=(""))&& ($"${KpiConstants.orecCodeColName}".cast(IntegerType).===(2) || $"${KpiConstants.orecCodeColName}".cast(IntegerType).===(9)), lit("COLOT"))
      .when(($"${KpiConstants.lisPreSubsColName}".cast(IntegerType).<=(0))&& ($"${KpiConstants.orecCodeColName}".cast(IntegerType).===(0)), lit("COLNON"))
      .when(($"${KpiConstants.lisPreSubsColName}".cast(IntegerType).>(0))&& ($"${KpiConstants.orecCodeColName}".cast(IntegerType).===(0)), lit("COLLISDE"))
      .when(($"${KpiConstants.lisPreSubsColName}".cast(IntegerType).<=(0))&& ($"${KpiConstants.orecCodeColName}".cast(IntegerType).===(1) || $"${KpiConstants.orecCodeColName}".cast(IntegerType).===(3)), lit("COLDIS"))
      .when(($"${KpiConstants.lisPreSubsColName}".cast(IntegerType).>(0))&& ($"${KpiConstants.orecCodeColName}".cast(IntegerType).===(1) || $"${KpiConstants.orecCodeColName}".cast(IntegerType).===(3)), lit("COLCMB")))
      //.when(($"${KpiConstants.lisPreSubsColName}".cast(StringType).===(""))&& ($"${KpiConstants.orecCodeColName}".cast(IntegerType).===(1) || $"${KpiConstants.orecCodeColName}".cast(IntegerType).===(3)), lit("COLUN")))
    .select(KpiConstants.memberidColName, KpiConstants.lobColName, KpiConstants.lobProductColName,KpiConstants.payerColName, KpiConstants.ncqaOutMeasureCol)

    //</editor-fold>

    /*Medicare members startification*/
    val medicareMemStratifiedDf = rankAdded2MonthsMemDf.union(measAddedFullYearDf)

    /*Other LOB members startification*/
    val otherMemStratifiedDf = hospiceRemMemEnrollDf.except(stratificationInputDf)
      .withColumn(KpiConstants.ncqaOutMeasureCol, lit(KpiConstants.colMeasureId))
      .select(KpiConstants.memberidColName, KpiConstants.lobColName, KpiConstants.lobProductColName,KpiConstants.payerColName, KpiConstants.ncqaOutMeasureCol)

    val startifiedTotalPopDf = medicareMemStratifiedDf.union(otherMemStratifiedDf).dropDuplicates()

    println("----------------------After startifiedTotalPopDf-----------------------")
    startifiedTotalPopDf.filter($"${KpiConstants.memberidColName}".===("96934")).show()


    //</editor-fold>

    //<editor-fold desc="Initial join function">

    val argmapForVisittJoin = mutable.Map(KpiConstants.membershipTblName -> startifiedTotalPopDf , KpiConstants.visitTblName -> indLabVisRemDf)
    val validVisitsOutDf = UtilFunctions.initialJoinFunction(spark,argmapForVisittJoin).repartition(2).cache()
    validVisitsOutDf.coalesce(3)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/validVisitsOutDf/")

    println("----------------------After validVisitsOutDf-----------------------")
    validVisitsOutDf.filter($"${KpiConstants.memberidColName}".===("96934")).show()


    //</editor-fold>

    //<editor-fold desc="Mandatory Exclusion Calculation">

    val visitForMandExclDf = spark.read.parquet(intermediateDir+ "/validVisitsOutDf/").cache()
    visitForMandExclDf.count()


    val visitForMandExclInDf = visitForMandExclDf.filter($"${KpiConstants.supplflagColName}".===("N")).cache()
    visitForMandExclInDf.count()


    //<editor-fold desc="Mandatory Exclusion2">


    val mandatoryExcl2Sub1Df = visitForMandExclInDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.fralityVal))
      &&(($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      &&(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}", KpiConstants.months792).<=(yearEndDate)))
      .select(KpiConstants.memberidColName)
      .distinct()

    val outPatAndAdvIllDf = visitForMandExclInDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.outPatientVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.advancedIllVal))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)



    val obsAndAdvIllDf = visitForMandExclInDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.observationVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.advancedIllVal))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)

    val edAndAdvIllDf = visitForMandExclInDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.edVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.advancedIllVal))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)

    val nAcuteInPatAndAdvIllDf = visitForMandExclInDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.nonAcuteInPatientVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.advancedIllVal))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName)



    val mandatoryExcl2Sub21Df = outPatAndAdvIllDf.union(obsAndAdvIllDf).union(edAndAdvIllDf).union(nAcuteInPatAndAdvIllDf)
      .groupBy(KpiConstants.memberidColName)
      .agg(countDistinct(KpiConstants.serviceDateColName).alias("count"))
      .filter($"count".>=(2))
      .select(KpiConstants.memberidColName)


    val mandatoryExcl2Sub22Df = visitForMandExclInDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.acuteInpatientVal))
      &&(array_contains($"${KpiConstants.valuesetColName}", KpiConstants.advancedIllVal))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)

    val mandatoryExcl2Sub23Df = visitForMandExclInDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.dementiaMedicationVal))
      &&($"${KpiConstants.serviceDateColName}".>=(prevYearStDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)


    println("----------------------After mandatoryExcl2Sub21Df-----------------------")
    mandatoryExcl2Sub21Df.filter($"${KpiConstants.memberidColName}".===("96934")).show()

    println("----------------------After mandatoryExcl2Sub22Df-----------------------")
    mandatoryExcl2Sub22Df.filter($"${KpiConstants.memberidColName}".===("96934")).show()

    println("----------------------After mandatoryExcl2Sub23Df-----------------------")
    mandatoryExcl2Sub23Df.filter($"${KpiConstants.memberidColName}".===("96934")).show()

    val mandatoryExcl2Sub2Df = mandatoryExcl2Sub21Df.union(mandatoryExcl2Sub22Df).union(mandatoryExcl2Sub23Df)

    println("----------------------After mandatoryExcl2Sub2Df-----------------------")
    mandatoryExcl2Sub2Df.filter($"${KpiConstants.memberidColName}".===("96934")).show()

    val mandatoryExcl2Df = mandatoryExcl2Sub1Df.intersect(mandatoryExcl2Sub2Df)

    println("----------------------After mandatoryExcl2Df-----------------------")
    mandatoryExcl2Df.filter($"${KpiConstants.memberidColName}".===("96934")).show()

    //</editor-fold>

    //</editor-fold>

    //<editor-fold desc="Eligible Population Calculation">

    /*Member level Removal of Mandatory Exclusion*/
    val eligibleVisitsDf = visitForMandExclDf.except(visitForMandExclDf.filter($"${KpiConstants.memberidColName}".isin(mandatoryExcl2Df.rdd.map(r=> r.getString(0)).collect():_*)))

    eligibleVisitsDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir + "/eligibleVisitsDf/")


    val epopDf = eligibleVisitsDf.select(KpiConstants.memberidColName).distinct().cache()
    epopDf.count()

    epopDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir + "/eligiblePop/")

    //</editor-fold>

    //</editor-fold>

    //<editor-fold desc=" Numerator Calculation ">

    //<editor-fold desc="Temporary Numerator Calculation">

    val numValidVisitsDf = spark.read.parquet(intermediateDir + "/eligibleVisitsDf/").repartition(2).cache()

    println("----------------------After numValidVisitsDf-----------------------")
    numValidVisitsDf.filter($"${KpiConstants.memberidColName}".===("96934")).show()

    numValidVisitsDf.count()

    val toutStrDf = numValidVisitsDf.select($"${KpiConstants.memberidColName}".alias(KpiConstants.ncqaOutmemberIdCol), $"${KpiConstants.ncqaOutMeasureCol}",
      $"${KpiConstants.payerColName}".alias(KpiConstants.ncqaOutPayerCol)).dropDuplicates()

    println("----------------------After toutStrDf-----------------------")
    toutStrDf.filter($"${KpiConstants.memberidColName}".===("96934")).show()

    //<editor-fold desc="Non Supplementry">

    val numNonSuppVisitsDf =  numValidVisitsDf.filter($"${KpiConstants.supplflagColName}".===("N"))

    val fobtnonSuppTmpNumDf = numNonSuppVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.fobtVal))
      &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)

    val flexnonSuppTmpNumDf = numNonSuppVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.flexibleSigmodoscopyVal))
      &&($"${KpiConstants.serviceDateColName}".>=(myminus4StDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)

    val colononSuppTmpNumDf = numNonSuppVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.colonoscopyVal))
      &&($"${KpiConstants.serviceDateColName}".>=(myminus9StDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)

    val ctcolononSuppTmpNumDf = numNonSuppVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ctColonographyVal))
      &&($"${KpiConstants.serviceDateColName}".>=(myminus4StDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)

    val fitdnaonSuppTmpNumDf = numNonSuppVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.fitDnaVal))
      &&($"${KpiConstants.serviceDateColName}".>=(myminus2StDate)) &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)

    val nonSuppTmpnumDf = fobtnonSuppTmpNumDf.union(flexnonSuppTmpNumDf).union(colononSuppTmpNumDf).union(ctcolononSuppTmpNumDf).union(fitdnaonSuppTmpNumDf)

    nonSuppTmpnumDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite).parquet(intermediateDir+ "/nonSuppTmpnumDf/")

    println("----------------------After nonSuppTmpnumDf-----------------------")
    nonSuppTmpnumDf.filter($"${KpiConstants.memberidColName}".===("96934")).show()

    //</editor-fold>

    //<editor-fold desc="Other Data">

    val nonSuppTmpNumDf = spark.read.parquet(intermediateDir+ "/nonSuppTmpnumDf/").cache()

    val otherNumVisitsDf = numValidVisitsDf.except(numValidVisitsDf.filter($"${KpiConstants.memberidColName}".isin(nonSuppTmpNumDf.rdd.map(f=> f.getString(0)).collect():_*)))

    val fobtotherNumTmpNumDf = otherNumVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.fobtVal))
      &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)

    val flexotherNumTmpNumDf = otherNumVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.flexibleSigmodoscopyVal))
      &&($"${KpiConstants.serviceDateColName}".>=(myminus4StDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)

    val colootherNumTmpNumDf = otherNumVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.colonoscopyVal))
      &&($"${KpiConstants.serviceDateColName}".>=(myminus9StDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)

    val ctcolootherNumTmpNumDf = otherNumVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.ctColonographyVal))
      &&($"${KpiConstants.serviceDateColName}".>=(myminus4StDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)

    val fitdnaotherNumTmpNumDf = otherNumVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.fitDnaVal))
      &&($"${KpiConstants.serviceDateColName}".>=(myminus2StDate))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)

    val otherNumTempDf = fobtotherNumTmpNumDf.union(flexotherNumTmpNumDf).union(colootherNumTmpNumDf).union(ctcolootherNumTmpNumDf).union(fitdnaotherNumTmpNumDf)

       otherNumTempDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite).parquet(intermediateDir+ "/otherNumTempDf/")

    //</editor-fold>

    println("----------------------After otherNumTempDf-----------------------")
    otherNumTempDf.filter($"${KpiConstants.memberidColName}".===("96934")).show()

    val otherNumTmpDf = spark.read.parquet(intermediateDir+ "/otherNumTempDf/").cache()

    val numTmpDf = nonSuppTmpNumDf.union(otherNumTmpDf)

    numTmpDf.coalesce(1)
       .write
       .mode(SaveMode.Append)
       .option("header", "true")
       .csv(outDir + "/numTmpDf/")

    println("----------------------After numTmpDf-----------------------")
    numTmpDf.filter($"${KpiConstants.memberidColName}".===("96934")).show()

    //</editor-fold>

    //<editor-fold desc="Optional Exclusion Calculation">

    val optionalExclVisistsDf = numValidVisitsDf.except(numValidVisitsDf.filter($"${KpiConstants.memberidColName}".isin(numTmpDf.rdd.map(f=> f.getString(0)).collect():_*)))
      .repartition(2).cache()

    optionalExclVisistsDf.count()

    println("----------------------After optionalExclVisistsDf-----------------------")
    optionalExclVisistsDf.filter($"${KpiConstants.memberidColName}".===("96934")).show()

    //<editor-fold desc="Optional Exclusion Non supplement Calculation">

    val optExclNonSupVisDf =  optionalExclVisistsDf.filter($"${KpiConstants.supplflagColName}".===("N")).cache()
    optExclNonSupVisDf.count()

    //<editor-fold desc="First Optional Exclsuion">

    val firstOptExclNonSupDf = optExclNonSupVisDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.colorectalCancerVal))
      &&($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.dobColName}"))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)
    //</editor-fold>

    //<editor-fold desc="Second Optional Exclsuion">

    val secondOptExclNonSupDf = optExclNonSupVisDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.totalColectomyVal))
      &&($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.dobColName}"))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)
    //</editor-fold>

    val nonSupOptExclDf = firstOptExclNonSupDf.union(secondOptExclNonSupDf)

    //</editor-fold>

    //<editor-fold desc="Optional Exclusion Other Calculation">

    val optExclOtherVisDf =  optionalExclVisistsDf.except(optionalExclVisistsDf.filter($"${KpiConstants.memberidColName}".isin(nonSupOptExclDf.rdd.map(f => f.getString(0)).collect():_*)))
    optExclOtherVisDf.count()

    //<editor-fold desc="First Optional Exclsuion">

    val firstOptExclOtherDf = optExclOtherVisDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.colorectalCancerVal))
      &&($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.dobColName}"))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)
    //</editor-fold>

    //<editor-fold desc="Second Optional Exclsuion">

    val secondOptExclOtherDf = optExclOtherVisDf.filter((array_contains($"${KpiConstants.valuesetColName}", KpiConstants.totalColectomyVal))
      &&($"${KpiConstants.serviceDateColName}".>=($"${KpiConstants.dobColName}"))
      &&($"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)
    //</editor-fold>

    val otherOptExclDf = firstOptExclOtherDf.union(secondOptExclOtherDf)

    //</editor-fold>

    val optinalExclDf = nonSupOptExclDf.union(otherOptExclDf)

    println("----------------------After otherOptExclDf-----------------------")
    otherOptExclDf.filter($"${KpiConstants.memberidColName}".===("96934")).show()

    println("----------------------After nonSupOptExclDf-----------------------")
    nonSupOptExclDf.filter($"${KpiConstants.memberidColName}".===("96934")).show()

    println("----------------------After optinalExclDf-----------------------")
    optinalExclDf.filter($"${KpiConstants.memberidColName}".===("96934")).show()

    //</editor-fold>

    /*Numerator Calculation*/
    val numeratorDf = numTmpDf.except(optinalExclDf)

    println("----------------------After numeratorDf-----------------------")
    numeratorDf.filter($"${KpiConstants.memberidColName}".===("96934")).show()

    //<editor-fold desc="Ncqa Output Creation">

    val outMap = mutable.Map(KpiConstants.totalPopDfName -> toutStrDf, KpiConstants.eligibleDfName -> epopDf,
      KpiConstants.mandatoryExclDfname -> spark.emptyDataFrame, KpiConstants.optionalExclDfName -> optinalExclDf,
      KpiConstants.numeratorDfName -> numeratorDf)


    val outDf = UtilFunctions.ncqaOutputDfCreation(spark,outMap,measureId)

    outDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir+ "/outDf")


    //</editor-fold>


    //</editor-fold>

    spark.sparkContext.stop()
  }
}
