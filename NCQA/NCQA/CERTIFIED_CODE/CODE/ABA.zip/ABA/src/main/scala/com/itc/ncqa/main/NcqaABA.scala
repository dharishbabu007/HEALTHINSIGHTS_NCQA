package main.scala.com.itc.ncqa.main

import main.scala.com.itc.ncqa.Constants
import main.scala.com.itc.ncqa.Constants.KpiConstants
import main.scala.com.itc.ncqa.Functions.UtilFunctions
import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkConf
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DateType

import scala.collection.mutable

object NcqaABA {

  def main(args: Array[String]): Unit = {

    //<editor-fold desc="Reading program arguments and Spark Session object creation">

    val year = "2018"
    val measureId = "ABA"

    System.setProperty("hadoop.home.dir", "D:\\WinUtil")

    val conf = new SparkConf().setAppName("NcqaProgram")
    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    conf.set("spark.sql.shuffle.partitions", "5")
    //.set("hive.exec.dynamic.partition.mode", "nonstrict")

    val spark = SparkSession.builder().config(conf).master("local").getOrCreate()

    val rootLogger = Logger.getRootLogger()
    rootLogger.setLevel(Level.ERROR)

    //</editor-fold>

    //<editor-fold desc="Loading Required Tables to memory">

    import spark.implicits._

    val ystDate = year+"-01-01"
    val yendDate = year+"-12-31"

    val lobList = List(KpiConstants.commercialLobName, KpiConstants.medicaidLobName, KpiConstants.medicareLobName, KpiConstants.marketplaceLobName)

    //val membershipDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\ABA\\Test\\MEMBERSHIP_ENROLLMENT.csv")

    println("-------------------membership----------------")
    val membershipDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\ABA\\Test\\MEMBERSHIP_ENROLLMENT.csv")
      .filter(($"${KpiConstants.considerationsColName}".===(KpiConstants.yesVal))
        && ($"${KpiConstants.memStartDateColName}".isNotNull)
        && ($"${KpiConstants.memEndDateColName}".isNotNull))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .withColumn(KpiConstants.memStartDateColName, to_date($"${KpiConstants.memStartDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.memEndDateColName, to_date($"${KpiConstants.memEndDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.dateofbirthColName, to_date($"${KpiConstants.dateofbirthColName}", KpiConstants.dateFormatString))
      .repartition(2).cache()

    membershipDf.filter($"${KpiConstants.memberidColName}".===("100018")).show()

    membershipDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet("/home/hbase/ncqa/aba/membershipDf/")

    val claimStatusList = List(KpiConstants.paidVal, KpiConstants.suspendedVal, KpiConstants.pendingVal, KpiConstants.deniedVal)

    // val visitsDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\ABA\\Test\\VISITS.csv")

    println("-------------------visits----------------")
    val visitsDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\ABA\\Test\\VISITS.csv")
      .filter(($"${KpiConstants.serviceDateColName}".isNotNull)
        && (($"${KpiConstants.admitDateColName}".isNotNull && $"${KpiConstants.dischargeDateColName}".isNotNull)
        || ($"${KpiConstants.admitDateColName}".isNull && $"${KpiConstants.dischargeDateColName}".isNull))
        &&((($"${KpiConstants.dataSourceColName}".===("Claim"))&&($"${KpiConstants.claimstatusColName}".isin(claimStatusList:_*)))
        || (($"${KpiConstants.dataSourceColName}".===("RxClaim"))&&($"${KpiConstants.claimstatusColName}".isin(claimStatusList:_*)))
        || ($"${KpiConstants.dataSourceColName}".===("Rx"))
        || ($"${KpiConstants.dataSourceColName}".===("Lab"))))
      .drop(KpiConstants.lobProductColName, "latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name","product")
      .withColumn(KpiConstants.dobColName, to_date($"${KpiConstants.dobColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.serviceDateColName, to_date($"${KpiConstants.serviceDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.admitDateColName, when($"${KpiConstants.admitDateColName}".isNotNull,to_date($"${KpiConstants.admitDateColName}",  KpiConstants.dateFormatString)))
      .withColumn(KpiConstants.dischargeDateColName, when($"${KpiConstants.dischargeDateColName}".isNotNull,to_date($"${KpiConstants.dischargeDateColName}",  KpiConstants.dateFormatString)))
      .withColumn(KpiConstants.medstartdateColName, when($"${KpiConstants.medstartdateColName}".isNotNull,to_date($"${KpiConstants.medstartdateColName}",  KpiConstants.dateFormatString)))
      .withColumn(KpiConstants.revenuecodeColName, when((length($"${KpiConstants.revenuecodeColName}").as[Int].===(3)),concat(lit("0" ),lit($"${KpiConstants.revenuecodeColName}"))).otherwise($"${KpiConstants.revenuecodeColName}"))
      .withColumn(KpiConstants.billtypecodeColName, when((length($"${KpiConstants.billtypecodeColName}").as[Int].===(3)),concat(lit("0" ),lit($"${KpiConstants.billtypecodeColName}"))).otherwise($"${KpiConstants.billtypecodeColName}"))
      .withColumn(KpiConstants.proccode2ColName, when(($"${KpiConstants.proccode2mod1ColName}".isin(KpiConstants.avoidCodeList:_*)) || ($"${KpiConstants.proccode2mod2ColName}".isin(KpiConstants.avoidCodeList:_*)),lit("NA")).otherwise($"${KpiConstants.proccode2ColName}"))
      .repartition(2).cache()

    visitsDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet("/home/hbase/ncqa/aba/visitsDf/")

    visitsDf.filter($"${KpiConstants.memberidColName}".===("100018")).show()

    println("-------------------refHedisDf----------------")
    val refHedisDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\ABA\\REF_HEDIS2019.csv")
      .filter(($"${KpiConstants.measureIdColName}".===(KpiConstants.abaMeasureId)) || ($"${KpiConstants.measureIdColName}".===(KpiConstants.ggMeasureId)))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .repartition(2).cache()

    refHedisDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet("/home/hbase/ncqa/aba/refHedisDf/")

    // val medmonmemDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\ABA\\Test\\ABA_MONTHLY_MEMBERSHIP.csv")

    val medmonmemDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\ABA\\Test\\ABA_MONTHLY_MEMBERSHIP.csv")
      .withColumn(KpiConstants.runDateColName,to_date($"${KpiConstants.runDateColName}", KpiConstants.dateFormatString))
      .filter(($"${KpiConstants.runDateColName}".>=(ystDate)) && ($"${KpiConstants.runDateColName}".<=(yendDate)))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .repartition(2).cache()

    medmonmemDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet("/home/hbase/ncqa/aba/medmonmemDf/")

    println("-------------------Monthly Membership----------------")
    medmonmemDf.show()

    //</editor-fold>

    //<editor-fold desc="Age Filter">

    val ageEndDate = year + "-12-31"
    val ageStartDate = year.toInt - 1 + "-01-01"

    val ageStartDate1 = year + "-01-01"

    membershipDf.withColumn("A",UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",888)).show()
    val ageFilterDf = membershipDf.filter((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",216).<=(ageStartDate))
      &&(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",900).>(ageEndDate))).cache()

    ageFilterDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet("/home/hbase/ncqa/aba/ageFilterDf/")

    println("-------------------Age Filter----------------")
    ageFilterDf.filter($"${KpiConstants.memberidColName}".===("100018")).show()

    //</editor-fold>

    //<editor-fold desc="Continuous Enrollment, Allowable Gap Calculation">

    val ageDf = spark.read.parquet("/home/hbase/ncqa/aba/ageFilterDf/").cache()

    val inputForContEnrolldf = ageDf.select(KpiConstants.memberidColName, KpiConstants.benefitMedicalColname,
      KpiConstants.memStartDateColName,KpiConstants.memEndDateColName,KpiConstants.genderColName,
      KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName, KpiConstants.dateofbirthColName,KpiConstants.primaryPlanFlagColName)

    val mapForCeminus2y = mutable.Map("start_date" -> (year.toInt-1+ "-01-01"), "end_date" -> (year.toInt-1+ "-12-31"),"gapcount" -> "1",
      "checkval" -> "false")

    val ceOutminus2yDf = UtilFunctions.contEnrollAndAllowableGapFilterFunction(spark,inputForContEnrolldf,mapForCeminus2y)

    val mapForCeminus1y = mutable.Map("start_date" -> (year+"-01-01"), "end_date" -> (year+"-12-31"),"gapcount" -> "1",
      "checkval" -> "true","anchor_date" -> (year+"-12-31"))

    val contEnrollDf = UtilFunctions.contEnrollAndAllowableGapFilterFunction(spark,ceOutminus2yDf,mapForCeminus1y)
      .select(KpiConstants.memberidColName, KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName, KpiConstants.primaryPlanFlagColName)

    contEnrollDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet("/home/hbase/ncqa/aba/contEnrollDf/")

    println("-------------------Continous Enrollment----------------")
    contEnrollDf.filter($"${KpiConstants.memberidColName}".===("100018")).show()

    //</editor-fold>

    //<editor-fold desc="Dual eligibility,Dual enrollment, AWC enrollment filter">

    val ConEnrDf = spark.read.parquet("/home/hbase/ncqa/aba/contEnrollDf/").cache()

    val baseOutDf = UtilFunctions.baseOutDataframeCreation(spark, ConEnrDf, lobList)

    println("----------------baseOutDf-------------------")

    val abaContEnrollDf = baseOutDf.filter($"${KpiConstants.lobColName}".isin(lobList:_*)).dropDuplicates().cache()
    abaContEnrollDf.count()

    //Modified Code
    val medicareContEnrollDf = abaContEnrollDf.filter($"${KpiConstants.lobColName}".===(KpiConstants.medicareLobName))

    val medicareHospiceDf = medicareContEnrollDf.as("df1").join(medmonmemDf.as("df2"), Seq(KpiConstants.memberidColName))
      .groupBy(KpiConstants.memberidColName).agg(countDistinct(when($"hospice".===("Y"),1)).alias("count"))
      .filter($"count".>(0))
      .select(KpiConstants.memberidColName).rdd.map(r=> r.getString(0)).collect()

    val abacontEnrollResDf = abaContEnrollDf.except(abaContEnrollDf.filter($"${KpiConstants.memberidColName}".isin(medicareHospiceDf:_*)))

    abacontEnrollResDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet("/home/hbase/ncqa/aba/abacontEnrollResDf/")

    println("-------------------After Dual Enrollment----------------")
    abacontEnrollResDf.filter($"${KpiConstants.memberidColName}".===("100018")).show()


    //Ends here

    //</editor-fold>

    //<editor-fold desc="Eligible Population Calculation">

    //<editor-fold desc="Initial Join with Ref_Hedis">

    val VisDf = spark.read.parquet("/home/hbase/ncqa/aba/visitsDf/").cache()

    val RefHedDf = spark.read.parquet("/home/hbase/ncqa/aba/refHedisDf/").cache()

    val argmapforRefHedis = mutable.Map(KpiConstants.eligibleDfName -> VisDf , KpiConstants.refHedisTblName -> RefHedDf)
    val allValueList = List(KpiConstants.independentLabVal, KpiConstants.hospiceVal,KpiConstants.outPatientVal,KpiConstants.bmiVal,
      KpiConstants.bmiPercentileVal,KpiConstants.pregnancyVal)

    val medList = KpiConstants.emptyList
    val visitRefHedisDf = UtilFunctions.joinWithRefHedisFunction(spark,argmapforRefHedis,allValueList,medList)
    println("visitRefHedisDf")

    visitRefHedisDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet("/home/hbase/ncqa/aba/visitRefHedisDf/")


    //</editor-fold>

    //<editor-fold desc="Removal of Independent Lab Visits">

    val VisRefHedDf = spark.read.parquet("/home/hbase/ncqa/aba/visitRefHedisDf/").cache()

    val groupList = VisDf.schema.fieldNames.toList.dropWhile(p=> p.equalsIgnoreCase(KpiConstants.memberidColName))
    val visitgroupedDf = VisRefHedDf.groupBy(KpiConstants.memberidColName, groupList:_*).agg(collect_list(KpiConstants.valuesetColName).alias(KpiConstants.valuesetColName))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName, KpiConstants.admitDateColName, KpiConstants.dischargeDateColName,KpiConstants.genderColName,
        KpiConstants.dobColName,KpiConstants.supplflagColName, KpiConstants.ispcpColName,KpiConstants.isobgynColName, KpiConstants.valuesetColName)


    val indLabVisRemDf = visitgroupedDf.filter(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)).repartition(2).cache()
    println("indLabVisRemDf")

    //</editor-fold>

    //<editor-fold desc="Hospice Removal">

    val yearStartDate = year+"-01-01"
    val yearEndDate = year+"-12-31"
    val yearStartDate1 = year.toInt - 1 +"-01-01"

    val ConEnrResDf = spark.read.parquet("/home/hbase/ncqa/aba/abacontEnrollResDf/").cache()

    val hospiceInCurrYearMemDf = indLabVisRemDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hospiceVal))
      &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate)
      && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)
      .dropDuplicates()
      .rdd
      .map(r=> r.getString(0))
      .collect()

    val hospiceRemMemEnrollDf = ConEnrResDf.except(ConEnrResDf.filter($"${KpiConstants.memberidColName}".isin(hospiceInCurrYearMemDf:_*)))

    hospiceRemMemEnrollDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet("/home/hbase/ncqa/aba/hospiceRemMemEnrollDf/")

    println("------------------After Hospice Removal----------------")
    hospiceRemMemEnrollDf.filter($"${KpiConstants.memberidColName}".===("100018")).show()

    //</editor-fold>

    //<editor-fold desc="Initial join function">

    val HosRemMemEnrDf = spark.read.parquet("/home/hbase/ncqa/aba/hospiceRemMemEnrollDf/").cache()

    val argmapForVisittJoin = mutable.Map(KpiConstants.membershipTblName -> HosRemMemEnrDf , KpiConstants.visitTblName -> indLabVisRemDf)
    val validVisitsOutDf = UtilFunctions.initialJoinFunction(spark,argmapForVisittJoin).repartition(2).cache()

    validVisitsOutDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet("/home/hbase/ncqa/aba/validVisitsOutDf/")

    //</editor-fold>

    //<editor-fold desc="Eligible Event calculation">

    val validVisitsDf = spark.read.parquet("/home/hbase/ncqa/aba/validVisitsOutDf/").repartition(2).cache()
    validVisitsDf.count()

    val visitForEventDf = validVisitsDf.filter($"${KpiConstants.supplflagColName}".===("N"))


    println("-----------------------validVisitsDf-----------------------")
    //validVisitsDf.show()

    //<editor-fold desc="Event Calculation">

    val eventStartDate = year.toInt -1 +"-01-01"
    val eventEndDate = year+"-12-31"

    /*Find out the memebers who has Outpatient */
    val eventDf = visitForEventDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.outPatientVal))
      &&($"${KpiConstants.serviceDateColName}".>=(eventStartDate))
      &&($"${KpiConstants.serviceDateColName}".<=(eventEndDate)))
      .select(KpiConstants.memberidColName)

    eventDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet("/home/hbase/ncqa/aba/eventDf/")


    println("---------------eventDf-------------------")

    //</editor-fold>

    val EvenDf = spark.read.parquet("/home/hbase/ncqa/aba/eventDf/").repartition(2).cache()

    val totalPopulationVisitsDf = validVisitsDf.as("df1").join(EvenDf.as("df2"), KpiConstants.memberidColName)
      .select(s"df1.*")

    val totalPopDf = totalPopulationVisitsDf.select($"${KpiConstants.memberidColName}",$"${KpiConstants.memberidColName}".as(KpiConstants.ncqaOutmemberIdCol)
      ,$"${KpiConstants.payerColName}".as(KpiConstants.ncqaOutPayerCol)).withColumn(KpiConstants.ncqaOutMeasureCol,lit(measureId)).distinct()

    val eligiblePopDf = totalPopulationVisitsDf.select(KpiConstants.memberidColName)

    totalPopulationVisitsDf.select(KpiConstants.memberidColName).coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("/home/hbase/ncqa/aba/totalPopulationVisitsDf/")

    println("---------------totalPopulationVisitsDf-------------------")
    totalPopulationVisitsDf.show()

    //</editor-fold>

    //<editor-fold desc="Denominator calculation">

    totalPopulationVisitsDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet("/home/hbase/ncqa/aba/totalPopulationVisitsDf/")

    println("-------------------E pop----------------")
    val denominatorDf = eligiblePopDf.distinct()

    denominatorDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("/home/hbase/ncqa/aba/denominator")

    println("---------------denominatorDf-------------------")
    denominatorDf.filter($"${KpiConstants.memberidColName}".===("100018")).show()

    //</editor-fold>

    //</editor-fold>

    val visitsForNumDf = spark.read.parquet("/home/hbase/ncqa/aba/totalPopulationVisitsDf/").cache()
    visitsForNumDf.count()

    //<editor-fold desc="ABA tmp Numerator Calculation">

    val visitNonSuppDf = visitsForNumDf.filter($"${KpiConstants.supplflagColName}".===("N")).cache()
    visitNonSuppDf.count()
    println("---------------------------visitNonSuppDf-------------------------")
    visitNonSuppDf.filter($"${KpiConstants.memberidColName}".===("100018")).show()

    //<editor-fold desc="ABA BMI tmp Numerator Calculation">

    val abaBmiNonSuppDf = visitNonSuppDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.bmiVal))
      &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate1) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate))
      &&(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}",240).<=($"${KpiConstants.serviceDateColName}")))
      .select(s"${KpiConstants.memberidColName}").cache()

    println("---------------------------abaBmiNonSuppDf-------------------------")
    abaBmiNonSuppDf.filter($"${KpiConstants.memberidColName}".===("100018")).show()

    val abaBmiOtherVisitsDf = visitsForNumDf.except(visitsForNumDf
      .filter($"${KpiConstants.memberidColName}".isin(abaBmiNonSuppDf.rdd.map(r=> r.getString(0)).collect():_*)))

    println("---------------------------abaBmiOtherVisitsDf-------------------------")
    abaBmiOtherVisitsDf.filter($"${KpiConstants.memberidColName}".===("100018")).show()

    val abaBmiMenOtherDf = abaBmiOtherVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.bmiVal))
      &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate1) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate))
      &&(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}",240).<=($"${KpiConstants.serviceDateColName}"))
    )
      .select(s"${KpiConstants.memberidColName}")


    println("---------------------------abaBmiMenOtherDf-------------------------")
    abaBmiMenOtherDf.filter($"${KpiConstants.memberidColName}".===("100018")).show()

    val abaBmiMenTmpDf = abaBmiNonSuppDf.union(abaBmiMenOtherDf).dropDuplicates().cache()

    abaBmiMenTmpDf.schema
    println("---------------------------abaBmiMenTmpDf-------------------------")
    abaBmiMenTmpDf.filter($"${KpiConstants.memberidColName}".===("100018")).show()

    //</editor-fold>

    //<editor-fold desc="ABA BMI Percentile tmp Numerator Calculation">

    val abaBmiPercNonSuppDf = visitNonSuppDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.bmiPercentileVal))
      &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate1) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate))
      &&(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}",240).>($"${KpiConstants.serviceDateColName}"))
    )
      .select(s"${KpiConstants.memberidColName}").cache()

    println("---------------------------abaBmiPercNonSuppDf-------------------------")
    abaBmiPercNonSuppDf.filter($"${KpiConstants.memberidColName}".===("100018")).show()

    val abaBmiPercOtherVisitsDf = visitsForNumDf.except(visitsForNumDf.filter($"${KpiConstants.memberidColName}".isin(abaBmiPercNonSuppDf.
      rdd.map(r=> r.getString(0)).collect():_*)))

    val abaBmiPercMenOtherDf = abaBmiPercOtherVisitsDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.bmiPercentileVal))
      &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate1) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate))
      &&(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dobColName}",240).>($"${KpiConstants.serviceDateColName}"))
    )
      .select(s"${KpiConstants.memberidColName}")

    abaBmiPercMenOtherDf.filter($"${KpiConstants.memberidColName}".===("100018")).show()

    val abaBmiPercMenTmpDf = abaBmiPercNonSuppDf.union(abaBmiPercMenOtherDf).dropDuplicates().cache()

    println("---------------------------abaBmiPercMenTmpDf-------------------------")
    abaBmiPercMenTmpDf.filter($"${KpiConstants.memberidColName}".===("100018")).show()

    //</editor-fold>

    abaBmiPercMenTmpDf.schema

    val abiTmpOutput = abaBmiMenTmpDf.union(abaBmiPercMenTmpDf)


    println("---------------------------abiTmpOutput-------------------------")
    abiTmpOutput.filter($"${KpiConstants.memberidColName}".===("100018")).show()


    abiTmpOutput.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("/home/hbase/ncqa/aba/abiTmpOutput")

    //</editor-fold>

    //<editor-fold desc="Optional Exclusion Calculation">

    val NumIntersect = abaBmiMenTmpDf.intersect(abaBmiPercMenTmpDf)

    println("---------------------------totalNum-------------------------")
    NumIntersect.filter($"${KpiConstants.memberidColName}".===("100018")).show()

    val visitForOptExclDf = visitsForNumDf.except(visitsForNumDf.filter($"${KpiConstants.memberidColName}".isin(abiTmpOutput.rdd.map(r=> r.getString(0)).collect():_*))).cache()
    visitForOptExclDf.count()



    println("---------------------------visitForOptExclDf-------------------------")
    visitForOptExclDf.filter($"${KpiConstants.memberidColName}".===("100018")).show()

    visitForOptExclDf.select($"${KpiConstants.memberidColName}")
      .coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("/home/hbase/ncqa/aba/visitForOptExclDf")

    //<editor-fold desc="Optional Exclusion Calculation For Non Supplementry And Other Data">


    val abaOptExclNonSupp= visitForOptExclDf.filter(($"${KpiConstants.genderColName}".===("F")) && ($"${KpiConstants.supplflagColName}".===("N")) &&
      (array_contains($"${KpiConstants.valuesetColName}",KpiConstants.pregnancyVal)) && ($"${KpiConstants.serviceDateColName}".>=(yearStartDate1) &&
      $"${KpiConstants.serviceDateColName}".<=(yearEndDate))).select(KpiConstants.memberidColName)

    val abaOptExclSuppInput = visitForOptExclDf.except(visitForOptExclDf.filter($"${KpiConstants.memberidColName}".isin(
      abaOptExclNonSupp.rdd.map(r=>r.getString(0)).collect():_*)))

    val abaOptExclSupp= abaOptExclSuppInput.filter(($"${KpiConstants.genderColName}".===("F")) &&
      (array_contains($"${KpiConstants.valuesetColName}",KpiConstants.pregnancyVal))
      && ($"${KpiConstants.serviceDateColName}".>=(yearStartDate1) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate))).select(KpiConstants.memberidColName)

    val abaOptExclDf=abaOptExclNonSupp.union(abaOptExclSupp)

    val abaOptExclDistinctDf = abaOptExclDf.distinct()

    //</editor-fold>

    abaOptExclDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("/home/hbase/ncqa/aba/abaOptExclDf/")

    println("After Optional Exclusion")
    abaOptExclDf.filter($"${KpiConstants.memberidColName}" === ("100018")).show()


    //</editor-fold>

    val Num1 = abaBmiMenTmpDf.except(abaBmiMenTmpDf.filter($"${KpiConstants.memberidColName}".isin(
      abaOptExclDf.rdd.map(r=>r.getString(0)).collect():_*)))

    println("Num1")
    //Num1.filter($"${KpiConstants.memberidColName}" === ("105720")).show()

    val Num2 = abaBmiPercMenTmpDf.except(abaBmiPercMenTmpDf.filter($"${KpiConstants.memberidColName}".isin(
      abaOptExclDf.rdd.map(r=>r.getString(0)).collect():_*)))

    println("Num2")

    Num1.filter($"${KpiConstants.memberidColName}".===("100018")).show()

    Num2.filter($"${KpiConstants.memberidColName}".===("100018")).show()

    Num1.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("/home/hbase/ncqa/aba/Num1/")


    Num2.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("/home/hbase/ncqa/aba/Num2/")

    val Final_Num = Num1.union(Num2).dropDuplicates().cache()

    Final_Num.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("/home/hbase/ncqa/aba/Final_Num/")


    val outMap = mutable.Map(KpiConstants.totalPopDfName -> totalPopDf, KpiConstants.eligibleDfName -> denominatorDf,
      KpiConstants.mandatoryExclDfname -> spark.emptyDataFrame, KpiConstants.optionalExclDfName -> abaOptExclDistinctDf
      ,KpiConstants.numeratorDfName -> Final_Num
    )

    println("-------------------Output File----------------")
    val outDf = UtilFunctions.ncqaOutputDfCreation(spark,outMap,measureId)

    outDf.filter($"${KpiConstants.memberidColName}".===("100018")).show()

    outDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("/home/hbase/ncqa/aba/outDf")


    spark.sparkContext.stop()
  }

}
