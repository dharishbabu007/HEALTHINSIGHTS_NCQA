package main.scala.com.itc.ncqa.main

import main.scala.com.itc.ncqa.Constants.KpiConstants
import main.scala.com.itc.ncqa.Functions.UtilFunctions
import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkConf
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.sql.functions._
import scala.collection.mutable

object NcqaCAP {


  def main(args: Array[String]): Unit =
  {

    //<editor-fold desc="Reading program arguments and Spark Session object creation">

    val year = "2018"
    val measureId = "CAP"
    val baseMsrPath = "/home/hbase/ncqa/cap/Test_CAP"

    System.setProperty("hadoop.home.dir", "D:\\WinUtil")

    val conf = new SparkConf().setAppName("NcqaProgram")
    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    conf.set("spark.sql.shuffle.partitions", "5")
    //.set("hive.exec.dynamic.partition.mode", "nonstrict")

    val spark = SparkSession.builder().config(conf).master("local").getOrCreate()

    val rootLogger = Logger.getRootLogger()
    rootLogger.setLevel(Level.ERROR)

    val yearStartDate = year+"-01-01"
    val yearStartDate1 = year.toInt -1 +"-01-01"
    val yearEndDate = year+"-12-31"

    val jobId = spark.sparkContext.applicationId
    val baseDir = baseMsrPath + "/" + jobId
    val outDir = baseDir + "/Out"
    val intermediateDir = baseDir + "/Intermediate"
    val stagingDir =  baseDir + "/Staging"

    //</editor-fold>

    //<editor-fold desc="Loading Required Tables to memory">

    import spark.implicits._

    val ystDate = year+"-01-01"
    val yendDate = year+"-12-31"

    val lobList = List(KpiConstants.commercialLobName, KpiConstants.medicaidLobName)

    // val membershipDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\CAP\\MEMBERSHIP_ENROLLMENT.csv")

    val membershipDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\CAP\\Test\\MEMBERSHIP_ENROLLMENT.csv")
      .filter(($"${KpiConstants.considerationsColName}".===(KpiConstants.yesVal))
        && ($"${KpiConstants.memStartDateColName}".isNotNull)
        && ($"${KpiConstants.memEndDateColName}".isNotNull))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .withColumn(KpiConstants.memStartDateColName, to_date($"${KpiConstants.memStartDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.memEndDateColName, to_date($"${KpiConstants.memEndDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.dateofbirthColName, to_date($"${KpiConstants.dateofbirthColName}", KpiConstants.dateFormatString))
      .repartition(2).cache()

    println("--------------------------Membership DF------------------------")
    membershipDf.filter($"${KpiConstants.memberidColName}".===("95401")).show()

    membershipDf.coalesce(2)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(stagingDir+ "/membershipDf/")

    val claimStatusList = List(KpiConstants.paidVal, KpiConstants.suspendedVal, KpiConstants.pendingVal, KpiConstants.deniedVal)

    // val visitsDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\CAP\\VISITS.csv")

    val visitsDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\CAP\\Test\\VISITS.csv")
      .filter(($"${KpiConstants.serviceDateColName}".isNotNull)
        && (($"${KpiConstants.admitDateColName}".isNotNull && $"${KpiConstants.dischargeDateColName}".isNotNull)
        || ($"${KpiConstants.admitDateColName}".isNull && $"${KpiConstants.dischargeDateColName}".isNull))
        &&((($"${KpiConstants.dataSourceColName}".===("Claim"))&&($"${KpiConstants.claimstatusColName}".isin(claimStatusList:_*)))
        || (($"${KpiConstants.dataSourceColName}".===("RxClaim"))&&($"${KpiConstants.claimstatusColName}".isin(claimStatusList:_*)))
        || ($"${KpiConstants.dataSourceColName}".===("Rx"))
        || ($"${KpiConstants.dataSourceColName}".===("Lab"))))
      .drop(KpiConstants.lobProductColName, "latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name","product")
      .withColumn(KpiConstants.dobColName, to_date($"${KpiConstants.dobColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.serviceDateColName, to_date($"${KpiConstants.serviceDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.admitDateColName, when($"${KpiConstants.admitDateColName}".isNotNull,to_date($"${KpiConstants.admitDateColName}",  KpiConstants.dateFormatString)))
      .withColumn(KpiConstants.dischargeDateColName, when($"${KpiConstants.dischargeDateColName}".isNotNull,to_date($"${KpiConstants.dischargeDateColName}",  KpiConstants.dateFormatString)))
      .withColumn(KpiConstants.medstartdateColName, when($"${KpiConstants.medstartdateColName}".isNotNull,to_date($"${KpiConstants.medstartdateColName}",  KpiConstants.dateFormatString)))
      .withColumn(KpiConstants.revenuecodeColName, when((length($"${KpiConstants.revenuecodeColName}").as[Int].===(3)),concat(lit("0" ),lit($"${KpiConstants.revenuecodeColName}"))).otherwise($"${KpiConstants.revenuecodeColName}"))
      .withColumn(KpiConstants.billtypecodeColName, when((length($"${KpiConstants.billtypecodeColName}").as[Int].===(3)),concat(lit("0" ),lit($"${KpiConstants.billtypecodeColName}"))).otherwise($"${KpiConstants.billtypecodeColName}"))
      .withColumn(KpiConstants.proccode2ColName, when(($"${KpiConstants.proccode2mod1ColName}".isin(KpiConstants.avoidCodeList:_*)) || ($"${KpiConstants.proccode2mod2ColName}".isin(KpiConstants.avoidCodeList:_*)),lit("NA")).otherwise($"${KpiConstants.proccode2ColName}"))
      .repartition(2).cache()

    println("--------------------------visitsDf------------------------")
    visitsDf.filter($"${KpiConstants.memberidColName}".===("95401")).show()

    visitsDf.coalesce(2)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(stagingDir+ "/visitsDf/")


    // val refHedisDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\CAP\\REF_HEDIS2019.csv")

    val refHedisDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\CAP\\Test\\REF_HEDIS2019.csv")
      .filter(($"${KpiConstants.measureIdColName}".===(KpiConstants.capMeasureId)) || ($"${KpiConstants.measureIdColName}".===(KpiConstants.ggMeasureId)))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .repartition(2).cache()

    refHedisDf.coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(stagingDir+ "/refHedisDf/")

    //val medmonmemDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\cap\\Test\\cap_MONTHLY_MEMBERSHIP.csv")
/*
    val medmonmemDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\CAP\\CAP_MONTHLY_MEMBERSHIP.csv")
      .withColumn(KpiConstants.runDateColName,to_date($"${KpiConstants.runDateColName}", KpiConstants.dateFormatString))
      .filter(($"${KpiConstants.runDateColName}".>=(ystDate)) && ($"${KpiConstants.runDateColName}".<=(yendDate)))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date" , "source_name" , "rec_create_date", "user_name")
      .repartition(2).cache()

    println("---------------------------Monthly Membership--------------------------------")
    medmonmemDf.filter($"${KpiConstants.memberidColName}".===("95401")).show()

    medmonmemDf.coalesce(2)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(stagingDir+ "/medmonmemDf/")*/

    //val ref_medvaluesetDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\CAP\\REF_MED_VALUE_SET.csv")

    val ref_medvaluesetDf = spark.read.option("header", "true").csv("D:\\Scala\\NCQA_CSVs\\CAP\\Test\\REF_MED_VALUE_SET.csv")
      .filter(($"${KpiConstants.measure_idColName}".===(KpiConstants.capMeasureId)) )
      .drop("latest_flag", "active_flag", "ingestion_date", "source_name" ,"user_name")
      .repartition(2).cache()

    ref_medvaluesetDf.coalesce(2)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(stagingDir+ "/ref_medvaluesetDf/")

    //</editor-fold>

    //<editor-fold desc="Eligible Population Calculation">

    //<editor-fold desc="Age Filter">

    val ageEndDate = year + "-12-31"
    val ageStartDate = year + "-01-01"

    val ageClDate = year+ "-12-31"

    /* The Member should be younger than 20 years on 31st December Measurement Year.*/

    val ageFilterDf = membershipDf.withColumn("age",datediff(lit(ageEndDate),$"${KpiConstants.dateofbirthColName}")/365.25)
      .filter((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",12).<=(ageClDate))
        && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",240).>(ageClDate)))
      //.filter(  $"age">=1 && $"age"<20)
      .select(KpiConstants.memberidColName, KpiConstants.benefitMedicalColname,
      KpiConstants.memStartDateColName,KpiConstants.memEndDateColName,
      KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName, KpiConstants.dateofbirthColName,KpiConstants.primaryPlanFlagColName,"age")
      .cache()

    println("-------------------After ageFilterDf-------------")
    ageFilterDf.filter($"${KpiConstants.memberidColName}".===("95401")).show()

    //</editor-fold>

    //<editor-fold desc="Continuous Enrollment, Allowable Gap Calculation">

    val inputForContEnrolldf = ageFilterDf.filter(($"${KpiConstants.memStartDateColName}".<=(ageEndDate))
      && ($"${KpiConstants.memEndDateColName}".>=(ageEndDate)))

    inputForContEnrolldf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/inputForContEnrolldf/")

    val ipContEnroll = spark.read.parquet(intermediateDir+ "/inputForContEnrolldf/").cache()

    println("----------------After inputForContEnrolldf----------------------")
    ipContEnroll.filter($"${KpiConstants.memberidColName}".===("95401")).show()

    //<editor-fold desc="Continuous Enrollment Calculation For 12–24 month and 25 months–6 years ">

    val ce1to6Df = ipContEnroll.filter((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",12).<=(ageClDate))
      && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",84).>(ageClDate)))
      .select(KpiConstants.memberidColName).distinct()

    println("-------------------------After ce1to6Df----------------------------")
    ce1to6Df.filter($"${KpiConstants.memberidColName}".===("95401")).show()


    val contEnroll1to6Df = ce1to6Df.as("df1").join(ageFilterDf.as("df2"),
      $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select($"df2.*")

    println("-------------------------After contEnroll1to6Df----------------------------")
    contEnroll1to6Df.filter($"${KpiConstants.memberidColName}".===("95401")).show()

    contEnroll1to6Df.coalesce(4)
      .write
      .mode(SaveMode.Overwrite).parquet(intermediateDir+ "/contEnroll1to6Df/")


    val contEnroll1to6 = spark.read.parquet(intermediateDir+ "/contEnroll1to6Df/").cache()

    val mapFor1to6Ce = mutable.Map("start_date" -> (year+"-01-01"), "end_date" -> (year+"-12-31"),"gapcount" -> "1", "checkval" -> "true","reqCovDays"-> "0","anchor_date" -> (year+"-12-31"))

    val contEnroll1to6OutDf = UtilFunctions.contEnrollAndAllowableGapFilterFunction(spark,contEnroll1to6,mapFor1to6Ce)
      .select(KpiConstants.memberidColName, KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName,
        KpiConstants.dateofbirthColName,KpiConstants.primaryPlanFlagColName)


    contEnroll1to6OutDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite).parquet(intermediateDir+ "/contEnroll1to6OutDf/")

    //</editor-fold>

    //<editor-fold desc="Continuous Enrollment Calculation For 7–11 years and 12–19 years ">

    val ce7to20Df = ipContEnroll.filter((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",84).<=(ageClDate))
      && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",240).>(ageClDate)))
      .select(KpiConstants.memberidColName).distinct()

    println("-------------------------After ce7to20Df----------------------------")
    ce7to20Df.filter($"${KpiConstants.memberidColName}".===("95401")).show()

    val contEnrollIn7to20TmpDf = ce7to20Df.select($"${KpiConstants.memberidColName}" as "df1_memberid")
      .as("df1").join(ageFilterDf.as("df2"),
      $"df1.df1_memberid" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select(KpiConstants.memberidColName, KpiConstants.benefitMedicalColname, KpiConstants.memStartDateColName,KpiConstants.memEndDateColName,
        KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName, KpiConstants.dateofbirthColName,KpiConstants.primaryPlanFlagColName,"age")

    println("-------------------------After contEnrollIn7to20TmpDf----------------------------")
    contEnrollIn7to20TmpDf.filter($"${KpiConstants.memberidColName}".===("95401")).show()

    contEnrollIn7to20TmpDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite).parquet(intermediateDir+ "/contEnrollIn7to20TmpDf/")

    val contEnroll7to20 = spark.read.parquet(intermediateDir+ "/contEnrollIn7to20TmpDf/").cache()

    val mapForCeminus2y = mutable.Map("start_date" -> (year.toInt-1+ "-01-01"), "end_date" -> (year.toInt-1+ "-12-31"),"gapcount" -> "1",
      "reqCovDays"-> "0","checkval" -> "false")

    val ceOutminus2yDf = UtilFunctions.contEnrollAndAllowableGapFilterFunction(spark,contEnroll7to20,mapForCeminus2y)

    ceOutminus2yDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite).parquet(intermediateDir+ "/ceOutminus2yDf/")

    val ceOut2y = spark.read.parquet(intermediateDir+ "/ceOutminus2yDf/").cache()

    val mapForCeminus1y = mutable.Map("start_date" -> (year+"-01-01"), "end_date" -> (year+"-12-31"),"gapcount" -> "1",
      "checkval" -> "true","reqCovDays"-> "0","anchor_date" -> (year+"-12-31"))

    val contEnrollIn7to20Df = UtilFunctions.contEnrollAndAllowableGapFilterFunction(spark,ceOut2y,mapForCeminus1y)
      .select(KpiConstants.memberidColName, KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName,
        KpiConstants.dateofbirthColName,KpiConstants.primaryPlanFlagColName)

    contEnrollIn7to20Df.coalesce(4)
      .write
      .mode(SaveMode.Overwrite).parquet(intermediateDir+ "/contEnrollIn7to20Df/")

    //</editor-fold>

    val contEnrollIn7to20 = spark.read.parquet(intermediateDir+ "/contEnrollIn7to20Df/").cache()

    val contEnrollIn1to6 = spark.read.parquet(intermediateDir+ "/contEnroll1to6OutDf/").cache()

    println("-------------------------contEnrollIn7to20------------------------------")
    contEnrollIn7to20.filter($"${KpiConstants.memberidColName}".===("95401")).show()

    println("-------------------------contEnrollIn1to6------------------------------")
    contEnrollIn1to6.filter($"${KpiConstants.memberidColName}".===("95401")).show()

    val contEnrollDf = contEnrollIn1to6.union(contEnrollIn7to20)

    println("-------------------------contEnrollDf------------------------------")
    contEnrollDf.filter($"${KpiConstants.memberidColName}".===("95401")).show()

    contEnrollDf.coalesce(2)
      .write
      .mode(SaveMode.Overwrite).parquet(intermediateDir+ "/contEnrollDf/")

    //</editor-fold>

    //<editor-fold desc="Dual Enrollment and CAP Lob filter">

    val conEnrDf = spark.read.parquet(intermediateDir+ "/contEnrollDf/").cache()

    val baseOutMedHosRemDf = UtilFunctions.baseOutDataframeCreation(spark, conEnrDf, lobList , measureId)

    /*Removing the SN payer members from the EPOP*/

    val snPayerList = List(KpiConstants.sn1PayerVal, KpiConstants.sn2PayerVal, KpiConstants.sn3PayerVal, KpiConstants.mmpPayerVal)
    val baseOutDf = baseOutMedHosRemDf.except(baseOutMedHosRemDf.filter($"${KpiConstants.payerColName}".isin(snPayerList:_*)))

    println("-------------------After baseOutDf-------------")
    baseOutDf.filter($"${KpiConstants.memberidColName}".===("95401")).show()

    val capContEnrollDf = baseOutDf.filter($"${KpiConstants.lobColName}".isin(lobList:_*)).dropDuplicates().cache()
    capContEnrollDf.count()

    capContEnrollDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/capContEnrollDf/")

    println("-------------------After Dual Enrollment-------------")
    capContEnrollDf.filter($"${KpiConstants.memberidColName}".===("95401")).show()

    //</editor-fold>

    //<editor-fold desc="Initial Join with Ref_Hedis">

    val visDf = spark.read.parquet(stagingDir+ "/visitsDf/").cache()

    val refHedDf = spark.read.parquet(stagingDir+ "/refHedisDf/").cache()

    val argmapforRefHedis = mutable.Map(KpiConstants.eligibleDfName -> visDf , KpiConstants.refHedisTblName -> refHedDf)
    val allValueList = List(KpiConstants.independentLabVal, KpiConstants.hospiceVal,KpiConstants.ambulatoryVisitVal)

    val medList = KpiConstants.emptyList
    val visitRefHedisDf = UtilFunctions.joinWithRefHedisFunction(spark,argmapforRefHedis,allValueList,medList)
      .withColumn("age",datediff(lit(ageEndDate),$"${KpiConstants.dobColName}")/365.25)

    println("-------------------After visitRefHedisDf-------------")
    visitRefHedisDf.filter($"${KpiConstants.memberidColName}".===("95401")).show()

    visitRefHedisDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/visitRefHedisDf/")

    //</editor-fold>

    //<editor-fold desc="Removal of Independent Lab Visits">

    val visRefHedDf = spark.read.parquet(intermediateDir+ "/visitRefHedisDf/").cache()

    val groupList = visDf.schema.fieldNames.toList.dropWhile(p=> p.equalsIgnoreCase(KpiConstants.memberidColName))

    val visitgroupedDf = visRefHedDf.groupBy(KpiConstants.memberidColName, groupList:_*).agg(collect_list(KpiConstants.valuesetColName).alias(KpiConstants.valuesetColName))
      .select(KpiConstants.memberidColName, KpiConstants.serviceDateColName, KpiConstants.admitDateColName, KpiConstants.dischargeDateColName,
        KpiConstants.dobColName,KpiConstants.supplflagColName, KpiConstants.ispcpColName,KpiConstants.isobgynColName, KpiConstants.valuesetColName,KpiConstants.genderColName)


    val indLabVisRemDf = visitgroupedDf.filter(!array_contains($"${KpiConstants.valuesetColName}",KpiConstants.independentLabVal)).repartition(2).cache()
    indLabVisRemDf.count()

    println("-------------------After indLabVisRemDf-------------")
    indLabVisRemDf.filter($"${KpiConstants.memberidColName}".===("95401")).show()


    //</editor-fold>

    //<editor-fold desc="Hospice Removal">

    val conEnrResDf = spark.read.parquet(intermediateDir+ "/capContEnrollDf/").cache()

    val hospiceInCurrYearMemDf = indLabVisRemDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hospiceVal))
      &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate)
      && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
      .select(KpiConstants.memberidColName)
      .dropDuplicates()
      .rdd
      .map(r=> r.getString(0))
      .collect()

    val df =  indLabVisRemDf.filter((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.hospiceVal))
      &&($"${KpiConstants.serviceDateColName}".>=(yearStartDate) && $"${KpiConstants.serviceDateColName}".<=(yearEndDate)))
    //.select(KpiConstants.memberidColName)

    println("-------------------df-------------")
    df.filter($"${KpiConstants.memberidColName}".===("95401")).show()

    val hospiceRemMemEnrollDf = conEnrResDf.except(conEnrResDf.filter($"${KpiConstants.memberidColName}".isin(hospiceInCurrYearMemDf:_*)))

    println("-------------------hospiceRemMemEnrollDf-------------")
    hospiceRemMemEnrollDf.filter($"${KpiConstants.memberidColName}".===("95401")).show()

    hospiceRemMemEnrollDf.coalesce(4)
      .write
      .mode(SaveMode.Overwrite)
      .parquet(intermediateDir+ "/hospiceRemMemEnrollDf/")

    val totalPopOutDf = hospiceRemMemEnrollDf.distinct()

    println("-------------------After totalPopOutDf-------------")
    totalPopOutDf.filter($"${KpiConstants.memberidColName}".===("95401")).show()

    totalPopOutDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .csv(outDir+ "/totalPopOutDf/")

    //</editor-fold>

    //<editor-fold desc="EPOP Generation">

    val eligiblePopDf = totalPopOutDf.select(KpiConstants.memberidColName).distinct().repartition(2).cache()
    eligiblePopDf.count()

    println("-------------------Selective Epop-------------------")
    eligiblePopDf.filter($"${KpiConstants.memberidColName}".===("95401")).show()

    eligiblePopDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir + "/epop-csv")

    //</editor-fold>

    //<editor-fold desc="CAP Stratification">

    val toutStrDf= totalPopOutDf.withColumn("Classfication",
        when(((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",12).<=(ageClDate))
          && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",25).>(ageClDate))),lit("CH1")).
          when(((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",25).<=(ageClDate))
            && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",84).>(ageClDate))),lit("CH2")).
          when(((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",84).<=(ageClDate))
            && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",144).>(ageClDate))),lit("CH3")).
          when(((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",144).<=(ageClDate))
          && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",240).>(ageClDate))),lit("CH4")))


    println("-----------------------toutStratDf-------------------------------")
    toutStrDf.filter($"${KpiConstants.memberidColName}".===("95401")).show()

    val statification = Seq(("CH1", "CAP1"),("CH2", "CAP2"),("CH3", "CAP3"),("CH4", "CAP4")).toDF("Classfication","Measure")

    println("-----------------------statification-------------------------------")
    statification.show()

    val visitJoinedOutDf=toutStrDf.as("df1").join(statification.as("df2"), $"df1.Classfication"===$"df2.Classfication", KpiConstants.innerJoinType)
      .select("df1.*","df2.Measure").cache()

    println("-----------------------visitJoinedOutDf-------------------------------")
    visitJoinedOutDf.filter($"${KpiConstants.memberidColName}".===("95401")).show()

    val toutStratOutDf = visitJoinedOutDf.select($"${KpiConstants.memberidColName}".as(KpiConstants.ncqaOutmemberIdCol),
      $"${KpiConstants.payerColName}".as(KpiConstants.ncqaOutPayerCol), $"Measure".alias(KpiConstants.ncqaOutMeasureCol)).distinct()

    toutStratOutDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir + "/toutStratOutDf")

    //</editor-fold>

    //</editor-fold>

    //<editor-fold desc="Numerator Part">

    //<editor-fold desc="Initial join function">

    val argmapForVisittJoin = mutable.Map(KpiConstants.membershipTblName -> totalPopOutDf , KpiConstants.visitTblName -> indLabVisRemDf)

    val visitJoinedDf = UtilFunctions.initialJoinFunction(spark,argmapForVisittJoin)
      .withColumn("age",datediff(lit(ageEndDate),$"${KpiConstants.dobColName}")/365.25)

    println("------------------------visitJoinedDf----------------------------")
    visitJoinedDf.filter($"${KpiConstants.memberidColName}".===("95401")).show()

    capContEnrollDf.unpersist()
    visitgroupedDf.unpersist()
    eligiblePopDf.unpersist()

    //</editor-fold>

    //<editor-fold desc="CAP Numerator Calculation">

    //<editor-fold desc="CAP Non Supp Numerator Calculation">

    val visitNonSuppDf = visitJoinedDf.filter($"${KpiConstants.supplflagColName}".===("N")).cache()
    visitNonSuppDf.count()

    println("--------------------visitNonSuppDf---------------------")
    visitNonSuppDf.filter($"${KpiConstants.memberidColName}".===("95401")).show()

    //<editor-fold desc="For 12 to 25 Months">

    val cap12To25NonSuppDf = visitNonSuppDf.filter(((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.ambulatoryVisitVal))  &&
      (($"${KpiConstants.ispcpColName}".===("Y")) ))
      && ((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",12).<=(ageClDate))
      && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",25).>(ageClDate)))
    && (($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))


    println("--------------------cap12To25NonSuppDf---------------------")
    cap12To25NonSuppDf.filter($"${KpiConstants.memberidColName}".===("95401")).show()

    //</editor-fold>

    //<editor-fold desc="For 25 to 84 Months">

    val cap25To84NonSuppDf = visitNonSuppDf.filter(((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.ambulatoryVisitVal))  &&
      (($"${KpiConstants.ispcpColName}".===("Y")) ))
      && ((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",25).<=(ageClDate))
      && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",84).>(ageClDate)))
      && (($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))


    println("--------------------cap25To84NonSuppDf---------------------")
    cap25To84NonSuppDf.filter($"${KpiConstants.memberidColName}".===("95401")).show()

    //</editor-fold>

    //<editor-fold desc="For 84 to 144 Months">

    val cap84To144NonSuppDf = visitNonSuppDf.filter(((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.ambulatoryVisitVal))  &&
      (($"${KpiConstants.ispcpColName}".===("Y")) ))
      && ((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",84).<=(ageClDate))
      && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",144).>(ageClDate)))
      && (($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))


    println("--------------------cap84To144NonSuppDf---------------------")
    cap84To144NonSuppDf.filter($"${KpiConstants.memberidColName}".===("95401")).show()

    //</editor-fold>

    //<editor-fold desc="For 144 to 240 Months">

    val cap144To240NonSuppDf = visitNonSuppDf.filter(((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.ambulatoryVisitVal))  &&
      (($"${KpiConstants.ispcpColName}".===("Y")) ))
      && ((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",144).<=(ageClDate))
      && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",240).>(ageClDate)))
      && (($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))


    println("--------------------cap144To240NonSuppDf---------------------")
    cap144To240NonSuppDf.filter($"${KpiConstants.memberidColName}".===("95401")).show()

    //</editor-fold>

    val capMenNonSuppDf =  cap12To25NonSuppDf.union(cap25To84NonSuppDf).union(cap84To144NonSuppDf).union(cap144To240NonSuppDf)

    println("--------------------capMenNonSuppDf---------------------")
    capMenNonSuppDf.filter($"${KpiConstants.memberidColName}".===("95401")).show()

    //</editor-fold>

    //<editor-fold desc="CAP Other Mem Numerator Calculation">

    val visitForMenOtherDf = visitJoinedDf.except(visitJoinedDf.filter($"${KpiConstants.memberidColName}".isin(capMenNonSuppDf.rdd.map(r=>r.getString(0)).collect():_*)))

    //<editor-fold desc="For 12 to 25 Months">

    val cap12To25MenOtherDf = visitForMenOtherDf.filter(((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.ambulatoryVisitVal))  &&
      (($"${KpiConstants.ispcpColName}".===("Y")) ))
      && ((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",12).<=(ageClDate))
      && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",25).>(ageClDate)))
      && (($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))


    println("--------------------cap12To25MenOtherDf---------------------")
    cap12To25MenOtherDf.filter($"${KpiConstants.memberidColName}".===("95401")).show()

    //</editor-fold>

    //<editor-fold desc="For 25 to 84 Months">

    val cap25To84MenOtherDf = visitForMenOtherDf.filter(((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.ambulatoryVisitVal))  &&
      (($"${KpiConstants.ispcpColName}".===("Y")) ))
      && ((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",25).<=(ageClDate))
      && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",84).>(ageClDate)))
      && (($"${KpiConstants.serviceDateColName}".>=(yearStartDate)) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))


    println("--------------------cap25To84MenOtherDf---------------------")
    cap25To84MenOtherDf.filter($"${KpiConstants.memberidColName}".===("95401")).show()

    //</editor-fold>

    //<editor-fold desc="For 84 to 144 Months">

    val cap84To144MenOtherDf = visitForMenOtherDf.filter(((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.ambulatoryVisitVal))  &&
      (($"${KpiConstants.ispcpColName}".===("Y")) ))
      && ((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",84).<=(ageClDate))
      && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",144).>(ageClDate)))
      && (($"${KpiConstants.serviceDateColName}".>=(yearStartDate1)) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))


    println("--------------------cap84To144MenOtherDf---------------------")
    cap84To144MenOtherDf.filter($"${KpiConstants.memberidColName}".===("95401")).show()

    //</editor-fold>

    //<editor-fold desc="For 144 to 240 Months">

    val cap144To240MenOtherDf = visitForMenOtherDf.filter(((array_contains($"${KpiConstants.valuesetColName}",KpiConstants.ambulatoryVisitVal))  &&
      (($"${KpiConstants.ispcpColName}".===("Y")) ))
      && ((UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",144).<=(ageClDate))
      && (UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",240).>(ageClDate)))
      && (($"${KpiConstants.serviceDateColName}".>=(yearStartDate1)) && ($"${KpiConstants.serviceDateColName}".<=(yearEndDate))))


    println("--------------------cap144To240MenOtherDf---------------------")
    cap144To240MenOtherDf.filter($"${KpiConstants.memberidColName}".===("95401")).show()

    //</editor-fold>

    val capMenOtherDf =  cap12To25MenOtherDf.union(cap25To84MenOtherDf).union(cap84To144MenOtherDf).union(cap144To240MenOtherDf).distinct()

    println("--------------------After capMenOtherDf---------------------")
    capMenOtherDf.filter($"${KpiConstants.memberidColName}".===("95401")).show()


    //</editor-fold>

    val numeratorDf = capMenOtherDf.union(capMenNonSuppDf).distinct()


    println("--------------------After numeratorDf---------------------")
    numeratorDf.filter($"${KpiConstants.memberidColName}".===("95401")).show()

    val numDf = numeratorDf.select($"${KpiConstants.memberidColName}").distinct()

    val outMap = mutable.Map(KpiConstants.totalPopDfName -> toutStratOutDf, KpiConstants.eligibleDfName -> eligiblePopDf,
      KpiConstants.mandatoryExclDfname -> spark.emptyDataFrame, KpiConstants.optionalExclDfName -> spark.emptyDataFrame,
      KpiConstants.numeratorDfName -> numDf)


    val outDf = UtilFunctions.ncqaOutputDfCreation(spark,outMap,measureId)
    outDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv(outDir+ "/outDf")


    //</editor-fold>

    //</editor-fold>
    
    spark.sparkContext.stop()
  }

}
