package com.itc.ncqa.main

import com.itc.ncqa.Constants.KpiConstants
import com.itc.ncqa.Functions.{DataLoadFunctions, UtilFunctions}
import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkConf
import org.apache.spark.sql.{Row, SaveMode, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.functions.year
import org.apache.spark.sql.types.StringType

import scala.collection.mutable

object A {

  def main(args: Array[String]): Unit = {


    val measureId = "CPC"
    val myear = "2018"
    // val PreYrStartDate = year.toInt -1 +"-01-01"
    System.setProperty("hadoop.home.dir", "D:\\hadoop_home")
    val conf = new SparkConf().setAppName("NcqaProgram").setMaster("local[*]")
    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      .set("hive.exec.dynamic.partition.mode", "nonstrict")
      .set("spark.sql.shuffle.partitions", "5")
    val spark = SparkSession.builder().config(conf).getOrCreate()

    import spark.implicits._
    val rootLogger = Logger.getRootLogger()
    rootLogger.setLevel(Level.ERROR)
    //</editor-fold>

    //<editor-fold desc="Loading Required Tables to memory">

    val lobList = List(KpiConstants.medicaidLobName, KpiConstants.mmpPayerVal)
    val claimStatusList = List(KpiConstants.paidVal, KpiConstants.suspendedVal, KpiConstants.pendingVal, KpiConstants.deniedVal)

    val path = "D:\\CPC_TEST.zip1\\MEMBERSHIP_ENROLLMENT.csv"
    val membershipDf = spark.read.option("header", "true").csv(path)
      .filter(($"${KpiConstants.considerationsColName}".===(KpiConstants.yesVal))
        && ($"${KpiConstants.memStartDateColName}".isNotNull)
        && ($"${KpiConstants.memEndDateColName}".isNotNull))
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date", "source_name", "rec_create_date", "user_name")
      .withColumn(KpiConstants.memStartDateColName, to_date($"${KpiConstants.memStartDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.memEndDateColName, to_date($"${KpiConstants.memEndDateColName}", KpiConstants.dateFormatString))
      .withColumn(KpiConstants.dateofbirthColName, to_date($"${KpiConstants.dateofbirthColName}", KpiConstants.dateFormatString))


    println("membershipDf")
    // membershipDf.show()

    // val ((membershipDf,visitsDf,refHedisDf,ref_medvaluesetDf)) = DataLoadFunctions.readdatafromlocal(spark,measureId,year)

    // println("MembershipDF")
    // membershipDf.show(10)
    // println("visitsDf"
    // visitsDf.printSchema()
    // visitsDf.show(10)
    // println("refHedisDf")
    // refHedisDf.show(10)

    // println("ref_medvaluesetDf")
    // ref_medvaluesetDf.show(10)
    /* read from local*/
    //</editor-fold


    //<editor-fold desc="Eligible Population Calculation">

    //<editor-fold desc=" filter">


    val ageEndDate = myear + "-12-31"
    val ageStartDate = myear + "-07-01"

    val ageFilterDf = membershipDf.filter(UtilFunctions.add_ncqa_months(spark, $"${KpiConstants.dateofbirthColName}", KpiConstants.months216).>(ageEndDate))

    val ageDf = ageFilterDf.filter($"${KpiConstants.memberidColName}" === ("123521"))
    //println("ageDf")
    //ageDf.show()
    /*[
 val ageFilterDf = membershipDf.filter(UtilFunctions.add_ncqa_months(spark,$"${KpiConstants.dateofbirthColName}",204).>=(ageClDate))).cache()

*/


    //</editor-fold>

    //<editor-fold desc="Continuous Enrollment, Allowable Gap Calculation">

    val inputForContEnrolldf = ageFilterDf.select(KpiConstants.memberidColName, KpiConstants.benefitMedicalColname,
      KpiConstants.memStartDateColName, KpiConstants.memEndDateColName,
      KpiConstants.lobColName, KpiConstants.lobProductColName, KpiConstants.payerColName,
      KpiConstants.dateofbirthColName, KpiConstants.primaryPlanFlagColName)


    val benNonMedRemDf = inputForContEnrolldf.filter($"${KpiConstants.benefitMedicalColname}".===(KpiConstants.yesVal))


    val contEnrollInDf = benNonMedRemDf.withColumn(KpiConstants.contenrollLowCoName, UtilFunctions.add_ncqa_months(spark, lit(ageStartDate), 0))
      .withColumn(KpiConstants.contenrollUppCoName, UtilFunctions.add_ncqa_months(spark, lit(ageEndDate), 0))
      .withColumn(KpiConstants.anchorDateColName, UtilFunctions.add_ncqa_months(spark, lit(ageEndDate), 0))

    println("-------contEnrollInDf--------------------")
    //contEnrollInDf.filter($"${KpiConstants.memberidColName}" === ("123521")).show()

    val nextYDate = myear.toInt + 1 + "-01-15"

    val contEnrollStep1Df = contEnrollInDf.filter((($"${KpiConstants.memStartDateColName}".>=($"${KpiConstants.contenrollLowCoName}")) && ($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.contenrollUppCoName}")))
      || (($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.contenrollLowCoName}")) && ($"${KpiConstants.memEndDateColName}".<=($"${KpiConstants.contenrollUppCoName}")))
      || ($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.contenrollLowCoName}") && ($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.contenrollUppCoName}"))))
      .withColumn(KpiConstants.anchorflagColName, when((($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.anchorDateColName}"))
        && ($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.anchorDateColName}"))), lit(1)).otherwise(lit(0)))
      .withColumn(KpiConstants.contEdFlagColName, when(($"${KpiConstants.memStartDateColName}".<=($"${KpiConstants.contenrollUppCoName}"))
        && ($"${KpiConstants.memEndDateColName}".>=($"${KpiConstants.contenrollUppCoName}")), lit(1)).otherwise(lit(0)))

    // (&&
    //        (($"${KpiConstants.memStartDateColName}".<=(nextYDate))
    //        && ($"${KpiConstants.memEndDateColName}".>=(nextYDate))), lit(1)).otherwise(lit(0)))

    // val imp5Df=contEnrollStep1Df.filter($"${KpiConstants.memberidColName}" === ("123521"))
    //println("imp5Df")
    //imp5Df.show()

    /*Step3(select the members who satisfy both (min_start_date- ces and cee- max_end_date <= allowable gap) conditions)*/
    val listDf = contEnrollStep1Df.groupBy($"${KpiConstants.memberidColName}")
      .agg(max($"${KpiConstants.memEndDateColName}").alias(KpiConstants.maxMemEndDateColName),
        min($"${KpiConstants.memStartDateColName}").alias(KpiConstants.minMemStDateColName),
        first($"${KpiConstants.contenrollLowCoName}").alias(KpiConstants.contenrollLowCoName),
        first($"${KpiConstants.contenrollUppCoName}").alias(KpiConstants.contenrollUppCoName),
        sum($"${KpiConstants.anchorflagColName}").alias(KpiConstants.anchorflagColName))
      .filter((date_add($"max_mem_end_date", KpiConstants.days45).>=($"${KpiConstants.contenrollUppCoName}"))
        && (date_sub($"min_mem_start_date", KpiConstants.days45).<=($"${KpiConstants.contenrollLowCoName}"))
        && ($"${KpiConstants.anchorflagColName}").>(0))
      .select($"${KpiConstants.memberidColName}")

    // val imp6Df=contEnrollStep1Df.filter($"${KpiConstants.memberidColName}" === ("123521"))
    // println("imp6Df")
    //imp6Df.show()

    val contEnrollStep2Df = contEnrollStep1Df.as("df1").join(listDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .select("df1.*")

    // val impDf=contEnrollStep2Df.filter($"${KpiConstants.memberidColName}" === ("123521"))
    println("impDf")
    //impDf.show()
    /*window function creation based on partioned by member_sk and order by mem_start_date*/
    val contWindowVal = Window.partitionBy(s"${KpiConstants.memberidColName}").orderBy(org.apache.spark.sql.functions.col(s"${KpiConstants.memEndDateColName}").desc, org.apache.spark.sql.functions.col(s"${KpiConstants.memStartDateColName}"))


    /* added 3 columns (date_diff(datediff b/w next start_date and current end_date for each memeber),
     anchorflag(if member is continuously enrolled on anchor date 1, otherwise 0)
     count(if date_diff>1 1, otherwise 0) over window*/
    val contEnrollStep3Df = contEnrollStep2Df.withColumn(KpiConstants.overlapFlagColName, when(($"${KpiConstants.memStartDateColName}".>=(lag($"${KpiConstants.memStartDateColName}", 1).over(contWindowVal)) && $"${KpiConstants.memStartDateColName}".<=(lag($"${KpiConstants.memEndDateColName}", 1).over(contWindowVal))
      && ($"${KpiConstants.memEndDateColName}".>=(lag($"${KpiConstants.memStartDateColName}", 1).over(contWindowVal)) && $"${KpiConstants.memEndDateColName}".<=(lag($"${KpiConstants.memEndDateColName}", 1).over(contWindowVal))))
      , lit(1))
      .when(($"${KpiConstants.memStartDateColName}".<(lag($"${KpiConstants.memStartDateColName}", 1).over(contWindowVal)))
        && ($"${KpiConstants.memEndDateColName}".>=(lag($"${KpiConstants.memStartDateColName}", 1).over(contWindowVal)) && $"${KpiConstants.memEndDateColName}".<=(lag($"${KpiConstants.memEndDateColName}", 1).over(contWindowVal)))
        , lit(2)).otherwise(lit(0)))

      .withColumn(KpiConstants.coverageDaysColName, when($"${KpiConstants.overlapFlagColName}".===(0), datediff(when($"${KpiConstants.memEndDateColName}".<=($"${KpiConstants.contenrollUppCoName}"), $"${KpiConstants.memEndDateColName}").otherwise($"${KpiConstants.contenrollUppCoName}")
        , when($"${KpiConstants.memStartDateColName}".>=($"${KpiConstants.contenrollLowCoName}"), $"${KpiConstants.memStartDateColName}").otherwise($"${KpiConstants.contenrollLowCoName}")) + 1)
        .when($"${KpiConstants.overlapFlagColName}".===(2), datediff(when($"${KpiConstants.contenrollLowCoName}".>=(lag($"${KpiConstants.memStartDateColName}", 1).over(contWindowVal)), $"${KpiConstants.contenrollLowCoName}").otherwise(lag($"${KpiConstants.memStartDateColName}", 1).over(contWindowVal))
          , $"${KpiConstants.memStartDateColName}") + 1)
        .otherwise(0))

      .withColumn(KpiConstants.countColName, when(when($"${KpiConstants.overlapFlagColName}".===(0), datediff(lag($"${KpiConstants.memStartDateColName}", 1).over(contWindowVal), $"${KpiConstants.memEndDateColName}"))
        .otherwise(0).>(1), lit(1))
        .otherwise(lit(0)))

    val contEnrollStep5Df = contEnrollStep3Df.groupBy(KpiConstants.memberidColName)
      .agg(min($"${KpiConstants.memStartDateColName}").alias(KpiConstants.minMemStDateColName),
        max($"${KpiConstants.memEndDateColName}").alias(KpiConstants.maxMemEndDateColName),
        sum($"${KpiConstants.countColName}").alias(KpiConstants.countColName),
        sum($"${KpiConstants.coverageDaysColName}").alias(KpiConstants.coverageDaysColName),
        first($"${KpiConstants.contenrollLowCoName}").alias(KpiConstants.contenrollLowCoName),
        first($"${KpiConstants.contenrollUppCoName}").alias(KpiConstants.contenrollUppCoName))
      .withColumn(KpiConstants.reqCovDaysColName, (datediff($"${KpiConstants.contenrollUppCoName}", $"${KpiConstants.contenrollLowCoName}") - 44))
    //val contDf =contEnrollStep5Df.filter($"${KpiConstants.memberidColName}" === ("123521"))
    //println("contDf")
    // contDf.show()
    val contEnrollmemDf = contEnrollStep5Df.filter(((($"${KpiConstants.countColName}") + (when(date_sub($"min_mem_start_date", 1).>=($"${KpiConstants.contenrollLowCoName}"), lit(1)).otherwise(lit(0)))
      + (when(date_add($"max_mem_end_date", 1).<=($"${KpiConstants.contenrollUppCoName}"), lit(1)).otherwise(lit(0)))).<=(1))
      && ($"${KpiConstants.coverageDaysColName}".>=($"${KpiConstants.reqCovDaysColName}")))
      .select(KpiConstants.memberidColName).distinct()
    //val imo21Df=contEnrollmemDf.filter($"${KpiConstants.memberidColName}" === ("123521"))
    //println("imo21Df")
    //imo21Df.show()

    val contEnrollDf = contEnrollStep1Df.as("df1").join(contEnrollmemDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)
      .filter($"df1.${KpiConstants.contEdFlagColName}".===(1))
      .select(s"df1.${KpiConstants.memberidColName}", s"df1.${KpiConstants.lobColName}", s"df1.${KpiConstants.lobProductColName}", s"df1.${KpiConstants.payerColName}", s"df1.${KpiConstants.primaryPlanFlagColName}").cache()
    //val imo22Df=contEnrollDf.filter($"${KpiConstants.memberidColName}" === ("123521"))
    //println("imo22Df")
    //imo22Df.show()
    val memberDf = membershipDf.filter($"${KpiConstants.memStartDateColName}".<=(nextYDate) && ($"${KpiConstants.memEndDateColName}".>=(nextYDate)))
      .select($"${KpiConstants.memberidColName}", $"${KpiConstants.payerColName}")

    val joinDf = contEnrollDf.as("df1").join(memberDf.as("df2"), $"df1.${KpiConstants.memberidColName}" === $"df2.${KpiConstants.memberidColName}", KpiConstants.innerJoinType)

    val joiningDf = joinDf.filter($"df1.${KpiConstants.payerColName}".===($"df2.${KpiConstants.payerColName}"))
      .select("df1.*")

    // val imo23Df=joiningDf.filter($"${KpiConstants.memberidColName}" === ("123521"))
    println("imo23Df")
    // imo23Df.show()


    //<editor-fold desc="Dual Enrollment and W15 Lob filter">

    val baseOutDf = UtilFunctions.baseOutDataframeCreation(spark, joiningDf, lobList, measureId)
    // .select(s"df1.${KpiConstants.memberidColName}", s"df1.${KpiConstants.lobColName}", s"df1.${KpiConstants.payerColName}")
    // val imo2Df=baseOutDf.filter($"${KpiConstants.memberidColName}" === ("123521"))
    //println("imo2Df")
    // imo2Df.show()
    //val payerlist = List(KpiConstants.sn1PayerVal,KpiConstants.sn2PayerVal,KpiConstants.sn3PayerVal,KpiConstants.mmpPayerVal)

    val imaContEnrollDf = baseOutDf.filter($"${KpiConstants.lobColName}".isin(lobList: _*)).dropDuplicates().cache()
    //.select(s"df1.${KpiConstants.memberidColName}", s"df1.${KpiConstants.lobColName}", s"df1.${KpiConstants.payerColName}")
    //imaContEnrollDf.count()
    // val imo1Df=imaContEnrollDf.filter($"${KpiConstants.memberidColName}" === ("123521"))
    // println("imo1Df")
    // imo1Df.show()

    // (!$"${KpiConstants.payerColName}".isin(payerlist:_*))
    //).dropDuplicates()
    //. cache()

    //println("Payer List")

    imaContEnrollDf.select($"${KpiConstants.payerColName}").distinct().show

    println("imaContEnrollDf")

    //val imoDf=imaContEnrollDf.filter($"${KpiConstants.memberidColName}" === ("123521"))
    // println("imoDf")
    //imoDf.show()


    /* imaContEnrollDf.coalesce(1)
      .write
      .mode(SaveMode.Append)
      .option("header", "true")
      .csv("D:\\HealthInsight\\Final\\")*/

    val path1 = "D:\\CPC_TEST.zip1\\GENERAL_MEMBERSHIP.csv"

    val genMemShipDf = spark.read.option("header", "true").csv(path1)
      .drop("latest_flag", "curr_flag", "active_flag", "ingestion_date", "rec_update_date", "rec_create_date", "user_name")
      .withColumn(KpiConstants.dateofbirthColName, to_date($"${KpiConstants.dateofbirthColName}", KpiConstants.dateFormatString))

    val renamedDf = genMemShipDf.withColumnRenamed("MEMBER_ID", "MEMBER_ID_1")


    val joinMemShipDf = renamedDf.as("df1").join(imaContEnrollDf.as("df2")
      , $"df1.${"MEMBER_ID_1"}" === $"df2.${KpiConstants.memberidColName}"
      , KpiConstants.innerJoinType)

    val finalDf1 = joinMemShipDf.withColumnRenamed("SOURCE_NAME", "Health care organization name")
      .withColumnRenamed("LOB", "Product line")
      .withColumnRenamed("PAYER", "Product")
      //.withColumnRenamed("MIDDLE_NAME", "LAST_NAME")
     // .withColumnRenamed("LAST_NAME", "MIDDLE_NAME")


     val finalDf2 = finalDf1.na.replace("GENDER", Map("M" -> "1", "F" -> "2","" -> "9"))
    .na.replace("Product", Map("HMO" -> "1", "POS" -> "2", "PPO" -> "3", "EPO" -> "4","MCD" -> "1"))
    .na.replace("Product line", Map("Medicaid" -> "2"))
   //val fanDf = finalDf2 .withColumn(KpiConstants.dateofbirthColName, concat(lit((dayofmonth($"${KpiConstants.dateofbirthColName}").cast(StringType)),lit(month($"${KpiConstants.dateofbirthColName}").cast(StringType)),lit(year($"${KpiConstants.dateofbirthColName}").cast(StringType)))))

    val fanalDf5 = finalDf2 .drop("MEMBER_ID_1", "RACE", "ETHNICITY", "EMAIL_ADDRESS", "MARITAL_STATUS", "LANGUAGE", "LNGTD", "LATTD", "RACE_SOURCE", "ETHN_SOURCE", "SPOKEN_LANGUAGE", "SPOKEN_LANGUAGE_SOURCE", "WRITTEN_LANGUAGE", "WRITTEN_LANGUAGE_SOURCE", "OTHER_LANGUAGE", "OTHER_LANGUAGE_SOURCE", "IMAGE_PATH", "SCHOLARSHIP", "IS_SMOKER", "IS_ALCOHOLIC","lob_product","primary_plan_flag","DATE_OF_DEATH","COUNTY_NAME","COUNTRY_NAME")
    fanalDf5.printSchema()
    println("fanalDf5")

    //finalDf1.filter($"GENDER"=!= "1" || $"GENDER"=!= "2").show()

    //finalDf1.filter($"GENDER".isNull).show()
    val final33Df = fanalDf5.select("Health care organization name","Product line","Product","SUB_FAM_ID_NUM","member_id","FIRST_NAME","MIDDLE_NAME","LAST_NAME","GENDER","date_of_birth","ADDRESS1","ADDRESS2","CITY","STATE","ZIP","PHONE","PARENT_FIRST_NAME","PARENT_MIDDLE_NAME","PARENT_LAST_NAME")
    println("final33Df")
    final33Df.show(5)
    val lenList = List(60,30)

    def func1(row: Row, length:List[Int]): String ={
      var res = ""

      for (i <- 0 to 1){

        val d= row.getString(i)
         val str = if(length(i) > d.length) d.padTo(length(i)-d.length, " " )

        res = res+ str
      }
      res
    }
    val d = final33Df.rdd.map( r=> func1(r,lenList))

    d.take(5).foreach(println)

    // val finalDf = finalDf2.withColumn("MEMBER_ID",rpad($"MEMBER_ID",25-(length($"MEMBER_ID").toString().replaceAll("[\\[\\]]","").toInt)," "))
    // joinMemShipDf.show(5)

    //val joinmemDf= joinMemShipDf.select((s"df2.${KpiConstants.healthpefColName}")

    final33Df.coalesce(1)
     .write
    .mode(SaveMode.Append)
    .option("header", "true")
    .csv("D:\\HealthInsight\\Final\\")


  }

}


